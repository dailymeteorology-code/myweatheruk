const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

import TCMSection from '@/components/TCMSection';
import {
  CloudLightning, Wind, Zap, AlertTriangle, ShieldAlert,
  ChevronDown, ChevronUp, ChevronRight, Home, Menu, X,
  RefreshCw, Loader2, Clock, Calendar, Archive, Camera,
  Radio, Trash2,
} from 'lucide-react';
import HistoricalLightningPanel from '@/components/tcm/HistoricalLightningPanel';

/* ═══════════════════════════════════════════════════════════════
   RENDER BACKEND — single 24/7 source of Blitzortung strikes
   ═══════════════════════════════════════════════════════════════ */
// Render worker — used as fallback/snapshot source. Both schemes from the same host.
const RENDER_WORKER_HOST = 'blitzortungworker-3.onrender.com';
const RENDER_WORKER_WS   = `wss://${RENDER_WORKER_HOST}`;
const RENDER_WORKER_HTTP = `https://${RENDER_WORKER_HOST}`;

// Direct Blitzortung — used while a user is on the site
const BLITZORTUNG_DIRECT_SERVERS = [
  'wss://ws1.blitzortung.org',
  'wss://ws7.blitzortung.org',
  'wss://ws8.blitzortung.org',
];

/* RISK_LEVEL_GUIDE removed — replaced by RiskLegendPanel import in components/tcm */

const RISK_ORDER = ['No Risk', 'Very Low', 'Low', 'Marginal', 'Moderate', 'High', 'Severe'];
const RISK_COLOR_MAP = { 'No Risk': '#64748b', 'Very Low': '#16a34a', 'Low': '#15803d', 'Marginal': '#ca8a04', 'Moderate': '#ea580c', 'High': '#dc2626', 'Severe': '#000000ff' };

const RISK_TYPES = [
  { id: 'thunderstorm', label: 'Thunderstorm', icon: CloudLightning, color: '#facc15' },
  { id: 'hail',         label: 'Hail',         icon: CloudLightning, color: '#38bdf8' },
  { id: 'tornado',      label: 'Tornado',       icon: Wind,           color: '#f97316' },
  { id: 'lightning',    label: 'Lightning',     icon: Zap,            color: '#a78bfa' },
];

/* ═══════════════════════════════════════════════════════════════
   ENHANCED CITY DATABASE — ~350 UK towns for accuracy
   ═══════════════════════════════════════════════════════════════ */
import { CITY_DB } from '@/components/tcm/cityDB';

const BLITZORTUNG_DATE_IMAGES = {};
async function fetchBlitzortungArchive(dateStr, hourEnd) {
  const d = new Date(dateStr + 'T00:00:00Z');
  const endTs  = Math.floor(d.getTime() / 1000) + hourEnd * 3600;
  const startTs = endTs - 3600;
  return `https://www.blitzortung.org/en/archive_data.php?stations_users=0&selected_numbers=&end_date=${endTs}&end_time=0&start_date=${startTs}&start_time=0&north=90&west=-180&east=180&south=-90&rawdata_image=1&map=10&width_orig=640&width_result=640&png_gif=0`;
}
function tsToDateHour(ts) {
  const d = new Date(ts);
  return { dateStr: d.toISOString().slice(0, 10), hour: d.getUTCHours() };
}

/* nearestCity / nearestCityShort moved to components/tcm/stormTracker */

/* Storage helpers moved to components/tcm/strikeStorage */
import {
  STORE_KEY, DATE_KEY, ARCHIVE_KEY, STORM_STORE_KEY, SNAPSHOT_KEY,
  todayDateStr, localDateKey,
  loadStoredWarnings, saveWarnings, broadcastWarnings,
  loadSnapshots, saveSnapshot,
  loadTodayStrikes, saveTodayStrikes, loadNewStrikesSince,
  loadArchive, saveArchive,
} from '@/components/tcm/strikeStorage';

/* ═══════════════════════════════════════════════════════════════
   GEO BOUNDS
   ═══════════════════════════════════════════════════════════════ */
const GEO_BOUNDS_UK = { latMin: 49.5, latMax: 61.0, lonMin: -10.8, lonMax: 2.5 };
const GEO_BOUNDS_EU = { latMin: 34.0, latMax: 72.0, lonMin: -25.0, lonMax: 45.0 };
function warningInRegion(poly, region) {
  if (!poly?.centroid) return false;
  return inBounds(poly.centroid.lat, poly.centroid.lon, region);
}
function inBounds(lat, lon, region = 'europe') {
  const b = region === 'uk' ? GEO_BOUNDS_UK : GEO_BOUNDS_EU;
  return lat >= b.latMin && lat <= b.latMax && lon >= b.lonMin && lon <= b.lonMax;
}

/* ═══════════════════════════════════════════════════════════════
   SERVICE WORKER — Render worker is the 24/7 upstream
   ═══════════════════════════════════════════════════════════════ */
import { SW_CODE } from '@/components/tcm/swCode';

function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  try {
    const blob = new Blob([SW_CODE], { type: 'application/javascript' });
    const url  = URL.createObjectURL(blob);
    navigator.serviceWorker.register(url, { scope: '/' }).catch(() => {});
  } catch (_) {}
}

import { AlertQueue, playThunder as _playThunder, playWarningSiren as _playWarningSiren, speakWarning as _speakWarning, renderGlowFlash } from '@/components/tcm/lightningAudio';

/* ═══════════════════════════════════════════════════════════════
   ENSEMBLE FORECAST (CAPE/wind only — no lightning data)
   ═══════════════════════════════════════════════════════════════ */
const UK_GRID = [
  { lat: 51.5, lon: -0.1, name: 'London & SE England' },
  { lat: 52.5, lon: -1.8, name: 'Midlands' },
  { lat: 53.8, lon: -2.5, name: 'Northern England' },
  { lat: 55.8, lon: -4.2, name: 'Scotland' },
  { lat: 51.5, lon: -3.2, name: 'Wales' },
  { lat: 52.0, lon: -0.5, name: 'East Anglia' },
  { lat: 50.7, lon: -3.5, name: 'SW England' },
  { lat: 54.6, lon: -5.9, name: 'N Ireland' },
];
const EUROPE_GRID = [
  { lat: 51.5, lon: 0,    name: 'UK' },
  { lat: 48.8, lon: 2.3,  name: 'France' },
  { lat: 52.5, lon: 13.4, name: 'Germany' },
  { lat: 40.4, lon: -3.7, name: 'Spain' },
  { lat: 41.9, lon: 12.5, name: 'Italy' },
  { lat: 52.4, lon: 21.0, name: 'Poland' },
  { lat: 50.1, lon: 14.4, name: 'Czechia' },
  { lat: 45.8, lon: 15.9, name: 'Balkans' },
];

async function fetchEnsembleForPoint(lat, lon) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&hourly=cape,lifted_index,precipitation_probability,relative_humidity_2m,wind_gusts_10m` +
    `&daily=cape_max,precipitation_probability_max,wind_gusts_10m_max,wind_speed_10m_max,precipitation_sum` +
    `&timezone=Europe%2FLondon&forecast_days=3`;
  const res = await fetch(url, { signal: AbortSignal.timeout(12000) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}
function aggregateHourlyByDay(data) {
  const hourly = data.hourly, daily = data.daily;
  if (!hourly || !daily) return null;
  const nDays = daily.time.length, results = [];
  for (let d = 0; d < nDays; d++) {
    const s = d * 24, e = Math.min(s + 24, hourly.time.length);
    const capeV = [], liV = [], rhV = [], ppV = [], gustV = [];
    for (let h = s; h < e; h++) {
      if (hourly.cape?.[h] != null) capeV.push(hourly.cape[h]);
      if (hourly.lifted_index?.[h] != null) liV.push(hourly.lifted_index[h]);
      if (hourly.relative_humidity_2m?.[h] != null) rhV.push(hourly.relative_humidity_2m[h]);
      if (hourly.precipitation_probability?.[h] != null) ppV.push(hourly.precipitation_probability[h]);
      if (hourly.wind_gusts_10m?.[h] != null) gustV.push(hourly.wind_gusts_10m[h]);
    }
    const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
    const max = a => a.length ? Math.max(...a) : 0;
    results.push({
      date: daily.time[d],
      capeMax: daily.cape_max?.[d] ?? max(capeV),
      capeAvg: avg(capeV),
      liMin:   liV.length ? Math.min(...liV) : 5,
      rhAvg:   avg(rhV),
      ppMax:   daily.precipitation_probability_max?.[d] ?? max(ppV),
      gustMax: daily.wind_gusts_10m_max?.[d] ?? max(gustV),
    });
  }
  return results;
}
function computeRiskFromMetrics({ capeMax, capeAvg, liMin, rhAvg, ppMax, gustMax }, type) {
  let score = 0;
  if      (capeMax >= 2000) score += 45;
  else if (capeMax >= 1000) score += 35;
  else if (capeMax >= 500)  score += 25;
  else if (capeMax >= 200)  score += 15;
  else if (capeMax >= 50)   score += 7;
  else if (capeAvg >= 20)   score += 3;
  if      (liMin <= -8) score += 25;
  else if (liMin <= -6) score += 20;
  else if (liMin <= -4) score += 14;
  else if (liMin <= -2) score += 8;
  else if (liMin <= 0)  score += 3;
  if      (rhAvg >= 85) score += 15;
  else if (rhAvg >= 75) score += 10;
  else if (rhAvg >= 65) score += 6;
  else if (rhAvg >= 55) score += 2;
  if      (ppMax >= 80) score += 10;
  else if (ppMax >= 60) score += 7;
  else if (ppMax >= 40) score += 4;
  else if (ppMax >= 20) score += 1;
  if      (gustMax >= 80) score += 5;
  else if (gustMax >= 60) score += 3;
  else if (gustMax >= 45) score += 1;
  if (type === 'hail')    { if (capeMax < 500 || gustMax < 40) score = Math.max(0, score - 20); if (capeMax >= 1500 && gustMax >= 60) score += 10; }
  else if (type === 'tornado') { score = Math.max(0, score - 35); if (capeMax >= 1000 && liMin <= -6 && gustMax >= 70) score += 15; }
  else if (type === 'lightning') { if (capeMax >= 300 && rhAvg >= 60) score += 5; }
  score = Math.max(0, Math.min(100, score));
  if (score >= 90) return 'Severe';
  if (score >= 75) return 'High';
  if (score >= 55) return 'Moderate';
  if (score >= 38) return 'Marginal';
  if (score >= 22) return 'Low';
  if (score >= 10) return 'Very Low';
  return 'No Risk';
}
async function buildEnsembleForecasts(useEurope = false) {
  const grid = useEurope ? EUROPE_GRID : UK_GRID;
  const results = await Promise.allSettled(grid.map(pt => fetchEnsembleForPoint(pt.lat, pt.lon)));
  const pointData = results.map((r, i) => ({
    point: grid[i],
    days:  r.status === 'fulfilled' ? aggregateHourlyByDay(r.value) : null,
  })).filter(p => p.days && p.days.length > 0);
  if (!pointData.length) throw new Error('No forecast data available');
  const nDays = pointData[0].days.length;
  const forecasts = {};
  RISK_TYPES.forEach(({ id: type }) => {
    forecasts[type] = Array.from({ length: nDays }, (_, dayIdx) => {
      const regionRisks = {};
      let sumCape = 0, sumRH = 0, count = 0;
      pointData.forEach(({ point, days }) => {
        const d = days[dayIdx];
        if (!d) return;
        sumCape += d.capeMax; sumRH += d.rhAvg; count++;
        regionRisks[point.name] = computeRiskFromMetrics(d, type);
      });
      const avgCape = count ? sumCape / count : 0;
      const avgRH   = count ? sumRH   / count : 60;
      const sampleDay = pointData[0].days[dayIdx];
      const overallRisk = computeRiskFromMetrics(
        { capeMax: avgCape, capeAvg: avgCape * 0.6, liMin: sampleDay?.liMin ?? 5, rhAvg: avgRH, ppMax: sampleDay?.ppMax ?? 0, gustMax: sampleDay?.gustMax ?? 0 },
        type
      );
      const sortedRisks = [...new Set(Object.values(regionRisks))].sort((a, b) => RISK_ORDER.indexOf(a) - RISK_ORDER.indexOf(b));
      const dateStr  = pointData[0].days[dayIdx].date;
      const dayLabel = dayIdx === 0 ? 'Today' : dayIdx === 1 ? 'Tomorrow' : 'Day 3';
      const formattedDate = new Date(dateStr + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
      return {
        date: dateStr, dayLabel, formattedDate, type,
        riskLevel: overallRisk,
        minRisk: sortedRisks[0] || 'No Risk',
        maxRisk: sortedRisks[sortedRisks.length - 1] || 'No Risk',
        avgCape: Math.round(avgCape), avgRH: Math.round(avgRH),
        regionRisks, generatedAt: new Date().toISOString(),
      };
    });
  });
  return { forecasts, generatedAt: new Date().toISOString() };
}
async function fetchWindForPoint(lat, lon) {
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=wind_speed_10m,wind_direction_10m&timezone=UTC`;
    const res  = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const data = await res.json();
    const speed = data.current?.wind_speed_10m ?? 0;
    const dir   = data.current?.wind_direction_10m ?? 0;
    const toRad = Math.PI / 180;
    const goDir = (dir + 180) % 360;
    return { u: speed * Math.sin(goDir * toRad), v: speed * Math.cos(goDir * toRad), speed, dir };
  } catch (_) { return null; }
}

/* ═══════════════════════════════════════════════════════════════
   STRIKE DENSITY HEATMAP — bumped opacities for visibility
   ═══════════════════════════════════════════════════════════════ */
function buildStrikeDensityGrid(strikes, cellDeg = 0.15) {
  const bins = {};
  strikes.forEach(s => {
    const latKey = Math.round(s.lat / cellDeg) * cellDeg;
    const lonKey = Math.round(s.lon / cellDeg) * cellDeg;
    const key = `${latKey.toFixed(3)}_${lonKey.toFixed(3)}`;
    if (!bins[key]) bins[key] = { lat: latKey, lon: lonKey, count: 0 };
    bins[key].count++;
  });
  return Object.values(bins);
}
function strikeDensityColor(count) {
  if (count >= 50) return { fill: '#ef4444', opacity: 0.75 };
  if (count >= 20) return { fill: '#f97316', opacity: 0.65 };
  if (count >= 8)  return { fill: '#facc15', opacity: 0.55 };
  if (count >= 3)  return { fill: '#a78bfa', opacity: 0.42 };
  if (count >= 1)  return { fill: '#7c3aed', opacity: 0.30 };
  return null;
}
function strikeDensityRadius(count) {
  if (count >= 50) return 18000;
  if (count >= 20) return 14000;
  if (count >= 8)  return 10000;
  return 7000;
}

const RAINVIEWER_COLORS = [
  '#00d8ff', '#00b4ff', '#0090ff', '#0070f0', '#0050e0',
  '#00a000', '#00c000', '#00e000', '#80ff00', '#c0ff00',
  '#ffff00', '#ffe000', '#ffc000', '#ff9000', '#ff6000',
  '#ff3000', '#ff0000', '#d00000', '#a00000', '#ff00ff',
];

import useAutoArchive from '@/components/tcm/useAutoArchive';

/* HistoricalLightningPanel moved to components/tcm/HistoricalLightningPanel.jsx */

/* ═══════════════════════════════════════════════════════════════
   HAMBURGER
   ═══════════════════════════════════════════════════════════════ */
function TCMHamburger({ isAdmin, tcmLogoUrl, isEurope, lightMode, onToggleLightMode }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (open) {
      document.getElementById('tcm-main-content')?.classList.add('menu-open-blur');
    } else {
      document.getElementById('tcm-main-content')?.classList.remove('menu-open-blur');
    }
  }, [open]);

  return (
    <>
      <motion.button
        onClick={() => setOpen(o => !o)}
        whileTap={{ scale: 0.92 }}
        style={{
          position: 'fixed', top: 20, left: 20, zIndex: 9999,
          width: 46, height: 46, borderRadius: 14,
          background: open ? 'rgba(15,23,42,0.95)' : 'rgba(15,23,42,0.75)',
          border: `1px solid ${open ? 'rgba(56,189,248,0.35)' : 'rgba(255,255,255,0.1)'}`,
          backdropFilter: 'blur(16px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
          boxShadow: open ? '0 0 0 1px rgba(56,189,248,0.15), 0 8px 32px rgba(0,0,0,0.4)' : '0 4px 24px rgba(0,0,0,0.3)',
          transition: 'all 0.25s ease'
        }}>
        <AnimatePresence mode="wait">
          {open
            ? <motion.div key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.18 }}><X style={{ width: 18, height: 18, color: '#38bdf8' }} /></motion.div>
            : <motion.div key="m" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.18 }}><Menu style={{ width: 18, height: 18, color: '#94a3b8' }} /></motion.div>
          }
        </AnimatePresence>
      </motion.button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.22 }} onClick={() => setOpen(false)}
              style={{ position: 'fixed', inset: 0, zIndex: 9998, background: 'rgba(2,6,15,0.7)', backdropFilter: 'blur(6px)' }} />
            <motion.div initial={{ x: -340, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -340, opacity: 0 }} transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
              style={{ position: 'fixed', left: 0, top: 0, bottom: 0, width: 300, zIndex: 9999, background: 'linear-gradient(180deg, #090f1e 0%, #0d1525 60%, #090f1e 100%)', borderRight: '1px solid rgba(255,255,255,0.07)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: -60, left: -40, width: 280, height: 280, borderRadius: '50%', background: 'radial-gradient(circle, rgba(56,189,248,0.07) 0%, transparent 70%)', pointerEvents: 'none' }} />
              <div style={{ position: 'absolute', bottom: -60, right: -40, width: 220, height: 220, borderRadius: '50%', background: 'radial-gradient(circle, rgba(167,139,250,0.06) 0%, transparent 70%)', pointerEvents: 'none' }} />
              <div style={{ padding: '28px 20px 18px', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: 'linear-gradient(135deg, rgba(56,189,248,0.2), rgba(167,139,250,0.2))', border: '1px solid rgba(56,189,248,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <CloudLightning style={{ width: 17, height: 17, color: '#38bdf8' }} />
                  </div>
                  <div>
                    <p style={{ margin: 0, fontSize: '0.95rem', fontWeight: 700, color: '#f1f5f9', letterSpacing: '-0.02em', background: 'linear-gradient(135deg, #f1f5f9 0%, #94a3b8 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>TCM Navigator</p>
                    <p style={{ margin: 0, fontSize: '0.62rem', fontWeight: 600, color: 'rgba(255,255,255,0.2)', letterSpacing: '0.1em', textTransform: 'uppercase', fontFamily: 'monospace' }}>
                      {isEurope ? 'Europe Mode' : 'UK Mode'}
                    </p>
                  </div>
                </div>
              </div>
              <div style={{ flex: 1, overflowY: 'auto', padding: '12px 8px', scrollbarWidth: 'none' }}>
                {[
                  { label: 'Back to Home', icon: Home, to: '/', color: '#38bdf8' },
                  { label: 'Weather Patterns', icon: CloudLightning, to: '/WeatherPatterns', color: '#a78bfa' },
                  ...(isAdmin ? [{ label: 'Admin Settings', icon: ShieldAlert, to: '/AdminSettings', color: '#f59e0b' }] : []),
                ].map((item, i) => (
                  <motion.div key={item.label} initial={{ opacity: 0, x: -28 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.06 + i * 0.055, duration: 0.38, ease: [0.22, 1, 0.36, 1] }}>
                    <Link to={item.to} onClick={() => setOpen(false)} style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 13, padding: '11px 14px 11px 18px', borderRadius: 14, marginBottom: 4, color: '#94a3b8', transition: 'all 0.2s' }}>
                      <div style={{ width: 34, height: 34, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.07)' }}>
                        <item.icon style={{ width: 15, height: 15, color: item.color }} />
                      </div>
                      <span style={{ fontSize: '0.85rem', fontWeight: 600, color: '#94a3b8' }}>{item.label}</span>
                    </Link>
                  </motion.div>
                ))}
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 18px', margin: '4px 0' }}>
                  <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
                  <span style={{ fontSize: '0.6rem', fontWeight: 700, color: 'rgba(255,255,255,0.2)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>Display</span>
                  <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
                </div>
                <motion.button initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3, duration: 0.32 }}
                  onClick={() => { onToggleLightMode(); setOpen(false); }}
                  className="tcm-hamburger-btn"
                  style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 13, padding: '10px 14px 10px 18px', borderRadius: 12, background: 'transparent', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                  <div style={{ width: 32, height: 32, borderRadius: 9, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(56,189,248,0.1)', border: '1px solid rgba(56,189,248,0.2)' }}>
                    <span style={{ fontSize: '1rem' }}>{lightMode ? '🌙' : '☀️'}</span>
                  </div>
                  <span style={{ fontSize: '0.82rem', fontWeight: 600, color: '#64748b' }}>{lightMode ? 'Dark Mode' : 'Light Mode'}</span>
                </motion.button>
              </div>
              <div style={{ padding: '14px 20px', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                <p style={{ margin: 0, fontSize: '0.62rem', fontWeight: 600, color: 'rgba(255,255,255,0.15)', letterSpacing: '0.1em', textTransform: 'uppercase', textAlign: 'center', fontFamily: 'monospace' }}>Thunderstorm Climatology Monitor</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

import AutoForecastPanel from '@/components/tcm/AutoForecastPanelWrapper';
import USAMonitor from '@/components/USAMonitor';

function hexToRgb(hex) {
  if (!hex || hex[0] !== '#') return '148,163,184';
  return [parseInt(hex.slice(1,3),16), parseInt(hex.slice(3,5),16), parseInt(hex.slice(5,7),16)].join(',');
}

function StatPill({ icon, label, value, color }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{ color }}>{icon}</span>
      <div>
        <p style={{ margin: 0, fontSize: '0.65rem', color: '#475569', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{label}</p>
        <p style={{ margin: 0, fontSize: '0.88rem', fontWeight: 700, color: '#e2e8f0', fontFamily: 'monospace' }}>{value}</p>
      </div>
    </div>
  );
}

function strikeColor(timeMs) {
  const ageMin = (Date.now() - timeMs) / 60000;
  if (ageMin < 2)   return '#ffffff';
  if (ageMin < 5)   return '#fffde0';
  if (ageMin < 10)  return '#facc15';
  if (ageMin < 30)  return '#f97316';
  if (ageMin < 60)  return '#ef4444';
  if (ageMin < 360) return '#7f1d1d';
  if (ageMin < 720) return '#7c3aed';
  return '#4c1d95';
}

/* Storm tracking helpers moved to components/tcm/stormTracker */
import { STORM_RISK, convexHull, bufferHull, pointInPolygon, buildTtsString, createStormTracker, nearestCity, nearestCityShort } from '@/components/tcm/stormTracker';

/* renderGlowFlash moved to components/tcm/lightningAudio */

/* ArchivedDayMap + ArchivePanel moved to components/tcm/LightningArchivePanel */
import ArchivePanel from '@/components/tcm/LightningArchivePanel';

/* ═══════════════════════════════════════════════════════════════
   LAYER DEFS — OM layers removed, only strikes / heatmap / warnings / radar
   ═══════════════════════════════════════════════════════════════ */
const LAYER_DEFS = [
  { id: 'strikes',    label: 'Strikes',     icon: CloudLightning, color: '#facc15' },
  { id: 'strikeheat', label: 'Strike Heat', icon: Zap,            color: '#a78bfa' },
  { id: 'storms',     label: 'Warnings',    icon: AlertTriangle,  color: '#f97316' },
  { id: 'radar',      label: 'Radar',       icon: Radio,          color: '#38bdf8' },
];

const MAP_VIEWS = {
  uk:     { center: [54.8, -3.2], zoom: 6 },
  europe: { center: [52.0,  9.0], zoom: 4 },
};

import { connectBlitzortung } from '@/components/tcm/connectBlitzortung'; import { LIGHTNING_MAP_CSS } from '@/components/tcm/lightningMapStyles';

/* ═══════════════════════════════════════════════════════════════
   MAIN LIGHTNING MAP COMPONENT
   ═══════════════════════════════════════════════════════════════ */
function LightningMap({ region = 'uk', isAdmin, archive, setArchive }) {
  const isEuropeMap = region === 'europe';

  const [mapFullscreen, setMapFullscreen] = useState(false);
  const mapRef            = useRef(null);
  const mapInst           = useRef(null);
  const allDayLayer       = useRef(null);
  const strikeHeatLayer   = useRef(null);
  const flashLayer        = useRef(null);
  const stormLayer        = useRef(null);
  const radarLayer        = useRef(null);
  const stormPolygonMap   = useRef({});
  const tracker           = useRef(createStormTracker());
  const audioCtx          = useRef(null);
  const knownStormIds     = useRef(new Set());
  const knownStormRisks   = useRef({});
  const markerPoolRef     = useRef([]);
  const newestLoadedTsRef = useRef(0);
  const heatRebuildTimer  = useRef(null);
  const alertQueue        = useRef(new AlertQueue());
  const todayStrikesRef = useRef([]);
  const dirtyRef        = useRef(false);

  const [view,             setView]             = useState(isEuropeMap ? 'europe' : 'uk');
  const [activeLayers,     setActiveLayers]     = useState(['strikes', 'strikeheat', 'storms', 'radar']);
  const [stormPolys, setStormPolys] = useState(() => loadStoredWarnings());
  const restoredWarningsRef = useRef(false);
  const [selectedStorm, setSelectedStorm] = useState(null);
const [warningsExpanded, setWarningsExpanded] = useState(false);
const [warningRegionFilter, setWarningRegionFilter] = useState('all');
  const [newStormAlert,    setNewStormAlert]    = useState(null);
  const [leafletReady,     setLeafletReady]     = useState(false);
  const [wsStatus,         setWsStatus]         = useState('connecting');
  const [lastUpdate,       setLastUpdate]       = useState(new Date());
  const [strikeCount,      setStrikeCount]      = useState(0);
  const [lastMinCount, setLastMinCount] = useState(0);
const [lastMinUkCount, setLastMinUkCount] = useState(0);
const [lastMinEuCount, setLastMinEuCount] = useState(0);
const lastMinBufferRef = useRef([]);
const lastMinUkRef = useRef([]);
const lastMinEuRef = useRef([]);
useEffect(() => {
  const cutoff = Date.now() - 60000;
  lastMinBufferRef.current = lastMinBufferRef.current.filter(s => s.t > cutoff);
  const ukMs = lastMinBufferRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length;
  const euMs = lastMinBufferRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length;
  setLastMinUkCount(ukMs);
  setLastMinEuCount(euMs);
  setLastMinCount(view === 'europe' ? euMs : ukMs);
}, [view]);
useEffect(() => {
  if (mapInst.current) {
    setTimeout(() => { try { mapInst.current.invalidateSize(); } catch(_) {} }, 100);
  }
}, [mapFullscreen]);
useEffect(() => {
  if (mapFullscreen) {
    document.body.classList.add('tcm-map-fullscreen');
  } else {
    document.body.classList.remove('tcm-map-fullscreen');
  }
  return () => document.body.classList.remove('tcm-map-fullscreen');
}, [mapFullscreen]);
  const [todayCount,       setTodayCount]       = useState(0);
  const [ukCount,          setUkCount]          = useState(0);
  const [euCount,          setEuCount]          = useState(0);
  const [isFlashing,       setIsFlashing]       = useState({});
  const [timeTravelMode,   setTimeTravelMode]   = useState(false);
  const [timeTravelDate,   setTimeTravelDate]   = useState('');
  const [timeTravelHour,   setTimeTravelHour]   = useState(12);
  const [timeTravelImgUrl, setTimeTravelImgUrl] = useState(null);
  const [timeTravelLoading,setTimeTravelLoading]= useState(false);
  const timeTravelLayerRef = useRef(null);

  const [soundEnabled,     setSoundEnabled]     = useState(() => localStorage.getItem('tcm_sound') !== 'false');
  const [ttsEnabled,       setTtsEnabled]       = useState(() => localStorage.getItem('tcm_tts')   !== 'false');
  const [warnSoundEnabled, setWarnSoundEnabled] = useState(() => localStorage.getItem('tcm_warnsound') !== 'false');
  const soundEnabledRef     = useRef(soundEnabled);
  const ttsEnabledRef       = useRef(ttsEnabled);
  const warnSoundEnabledRef = useRef(warnSoundEnabled);
  useEffect(() => { soundEnabledRef.current = soundEnabled;         localStorage.setItem('tcm_sound',    String(soundEnabled));    }, [soundEnabled]);
  useEffect(() => { ttsEnabledRef.current   = ttsEnabled;           localStorage.setItem('tcm_tts',      String(ttsEnabled));      }, [ttsEnabled]);
  useEffect(() => { warnSoundEnabledRef.current = warnSoundEnabled; localStorage.setItem('tcm_warnsound', String(warnSoundEnabled)); }, [warnSoundEnabled]);

  useEffect(() => {
    if (!document.getElementById('leaflet-css')) {
      const l = document.createElement('link');
      l.id = 'leaflet-css'; l.rel = 'stylesheet';
      l.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(l);
    }
    if (window.L) { setLeafletReady(true); return; }
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    s.onload = () => setLeafletReady(true);
    document.head.appendChild(s);
  }, []);

  useEffect(() => {
    if (!leafletReady || !mapRef.current) return;
    const L = window.L;
    const v = MAP_VIEWS[view];
    const renderer = L.canvas({ padding: 0.5, tolerance: 3 });
    const map = L.map(mapRef.current, { center: v.center, zoom: v.zoom, zoomControl: false, attributionControl: false, preferCanvas: true, renderer });
    mapRef.current.style.background = '#060d1a';
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { maxZoom: 19, subdomains: 'abcd' }).addTo(map);
    L.control.attribution({ position: 'bottomright', prefix: '' })
      .addAttribution('© <a href="https://carto.com/">CARTO</a> | ⚡ <a href="https://blitzortung.org">Blitzortung</a> | 🌧 <a href="https://rainviewer.com">RainViewer</a>')
      .addTo(map);
    if (!document.getElementById('blitz-popup-css')) {
      const style = document.createElement('style');
      style.id = 'blitz-popup-css';
      style.textContent = `.blitz-popup .leaflet-popup-content-wrapper{background:transparent!important;border:none!important;box-shadow:none!important;padding:0!important}.blitz-popup .leaflet-popup-content{margin:0!important}.blitz-popup .leaflet-popup-tip-container{display:none}.menu-open-blur{filter:blur(5px)!important;transition:filter 0.3s ease;pointer-events:none;}`;
      document.head.appendChild(style);
    }
    radarLayer.current      = L.layerGroup().addTo(map);
    strikeHeatLayer.current = L.layerGroup().addTo(map);
    stormLayer.current      = L.layerGroup().addTo(map);
    allDayLayer.current     = L.layerGroup().addTo(map);
    flashLayer.current      = L.layerGroup().addTo(map);
    timeTravelLayerRef.current = L.layerGroup().addTo(map);
    mapInst.current = map;
    return () => { map.remove(); mapInst.current = null; };
  }, [leafletReady]); // eslint-disable-line

  const loadTimeTravelImage = useCallback(async () => {
    if (!timeTravelDate) return;
    setTimeTravelLoading(true);
    const d = new Date(timeTravelDate + 'T00:00:00Z');
    const endTs   = Math.floor(d.getTime() / 1000) + (timeTravelHour + 1) * 3600;
    const startTs = endTs - 3600;
    const url = `https://www.blitzortung.org/en/archive_data.php?stations_users=0&selected_numbers=&end_date=${endTs}&end_time=0&start_date=${startTs}&start_time=0&north=90&west=-180&east=180&south=-90&rawdata_image=1&map=10&width_orig=640&width_result=640&png_gif=0`;
    setTimeTravelImgUrl(url);
    const L = window.L;
    if (L && timeTravelLayerRef.current && mapInst.current) {
      timeTravelLayerRef.current.clearLayers();
      if (!document.getElementById('blitz-overlay-css')) {
        const s = document.createElement('style');
        s.id = 'blitz-overlay-css';
        s.textContent = `.blitz-screen { mix-blend-mode: screen !important; }`;
        document.head.appendChild(s);
      }
      L.imageOverlay(url, [[-90, -180], [90, 180]], { opacity: 1.0, className: 'blitz-screen' }).addTo(timeTravelLayerRef.current);
    }
    setTimeTravelLoading(false);
  }, [timeTravelDate, timeTravelHour]);

  const exitTimeTravel = useCallback(() => {
    setTimeTravelMode(false);
    setTimeTravelImgUrl(null);
    if (timeTravelLayerRef.current) timeTravelLayerRef.current.clearLayers();
  }, []);

  const handleTimeTravelSnapshot = useCallback(() => {
    if (!timeTravelDate || !timeTravelImgUrl) return;
    const d = new Date(timeTravelDate + 'T00:00:00Z');
    const snapshotTs = d.getTime() + timeTravelHour * 3600 * 1000;
    const windowStart = snapshotTs - 3600 * 1000;
    const windowStrikes = todayStrikesRef.current.filter(s => s.time >= windowStart && s.time <= snapshotTs);
    const prevStrikes = todayStrikesRef.current;
    todayStrikesRef.current = windowStrikes;
    forceSnapshotRef.current(true, snapshotTs);
    todayStrikesRef.current = prevStrikes;
  }, [timeTravelDate, timeTravelHour, timeTravelImgUrl]);

  function strikePopupHtml(s) {
    const t = new Date(s.time);
    const timeStr = t.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    const dateStr = t.toLocaleDateString('en-GB',{day:'2-digit',month:'short'});
    const ageMin = Math.round((Date.now()-s.time)/60000);
    const ageStr = ageMin<60?`${ageMin}m ago`:`${Math.round(ageMin/60)}h ${ageMin%60}m ago`;
    const locStr = nearestCityShort(s.lat, s.lon);
    return `<div style="background:#0f172a;border:1px solid rgba(250,204,21,0.35);border-radius:11px;padding:11px 14px;min-width:170px;font-family:system-ui,sans-serif;box-shadow:0 8px 32px rgba(0,0,0,0.6)">
      <p style="margin:0 0 6px;font-size:0.82rem;font-weight:700;color:#facc15">⚡ Lightning Strike</p>
      <p style="margin:0 0 3px;font-size:0.74rem;color:#e2e8f0;font-family:monospace">${dateStr} · ${timeStr}</p>
      <p style="margin:0 0 3px;font-size:0.7rem;color:#94a3b8">📍 ${locStr}</p>
      <p style="margin:0 0 3px;font-size:0.68rem;color:#64748b">${ageStr}</p>
      ${s.amp?`<p style="margin:3px 0 0;font-size:0.68rem;color:#94a3b8">Amplitude: <b style="color:#f1f5f9">${Math.abs(s.amp)} kA</b></p>`:''}
    </div>`;
  }

  const paintStrikeOnMap = useCallback((L, strike) => {
    if (!L || !allDayLayer.current) return;
    const color = strikeColor(strike.time);
    const v = L.polyline([[strike.lat - 0.026, strike.lon],[strike.lat + 0.026, strike.lon]], { color, weight: 2.8, opacity: 0.97, smoothFactor: 0, interactive: false, pane: 'markerPane' }).addTo(allDayLayer.current);
const h = L.polyline([[strike.lat, strike.lon - 0.038],[strike.lat, strike.lon + 0.038]], { color, weight: 2.8, opacity: 0.97, smoothFactor: 0, interactive: false, pane: 'markerPane' }).addTo(allDayLayer.current);
    const dot = L.circleMarker([strike.lat, strike.lon], {
  radius: 3, color: strikeColor(strike.time),
  fillColor: strikeColor(strike.time), fillOpacity: 0.9,
  weight: 0, interactive: true,
}).addTo(allDayLayer.current);
dot.on('click', () => dot.bindPopup(strikePopupHtml(strike), { className: 'blitz-popup', maxWidth: 220 }).openPopup());
dot._strikeTime = strike.time;
markerPoolRef.current.push(dot);
  }, []);

  const paintStrikes = useCallback((strikes, L) => {
    if (!L || !allDayLayer.current) return;
    const regionKey = isEuropeMap ? 'europe' : 'uk';
    const filtered  = strikes.filter(s => inBounds(s.lat, s.lon, regionKey));
    const sample = filtered;
    sample.forEach(s => paintStrikeOnMap(L, s));
  }, [isEuropeMap, paintStrikeOnMap]);

    const rebuildStrikeHeatmap = useCallback(() => {
  const L = window.L;
  if (!L || !strikeHeatLayer.current || !mapInst.current) return;
  strikeHeatLayer.current.clearLayers();
  const regionKey = isEuropeMap ? 'europe' : 'uk';

  // Current 24h strikes
  const liveStrikes = todayStrikesRef.current.filter(s =>
    s && inBounds(s.lat, s.lon, regionKey)
  );

  // All archived strikes regardless of age
  const archiveStrikes = (archive || []).flatMap(d => {
    if (!d.strikes) return [];
    return d.strikes.filter(s => s && inBounds(s.lat, s.lon, regionKey));
  });

  // Merge, deduplicate by time+lat
  const seen = new Set();
  const allStrikes = [];
  [...liveStrikes, ...archiveStrikes].forEach(s => {
    const key = `${Math.round(s.lat * 1000)}_${Math.round(s.lon * 1000)}_${s.time}`;
    if (!seen.has(key)) { seen.add(key); allStrikes.push(s); }
  });

  // Weight recent strikes more heavily by counting them multiple times
  const now = Date.now();
  const weightedStrikes = [];
  allStrikes.forEach(s => {
    const ageH = (now - s.time) / 3600000;
    // Recent strikes count more: <1h = 4x, <6h = 3x, <24h = 2x, older = 1x
    const weight = ageH < 1 ? 4 : ageH < 6 ? 3 : ageH < 24 ? 2 : 1;
    for (let i = 0; i < weight; i++) weightedStrikes.push(s);
  });

  const cellSize = isEuropeMap ? 0.4 : 0.12;
  const grid = buildStrikeDensityGrid(weightedStrikes, cellSize);
  grid.sort((a, b) => a.count - b.count);

  grid.forEach(cell => {
    const cfg = strikeDensityColor(cell.count);
    if (!cfg) return;
    const halfDeg = isEuropeMap ? 0.20 : 0.06;
    const bounds = [
      [cell.lat - halfDeg, cell.lon - halfDeg * 1.4],
      [cell.lat + halfDeg, cell.lon + halfDeg * 1.4],
    ];
    L.rectangle(bounds, {
      color: 'transparent',
      fillColor: cfg.fill,
      fillOpacity: cfg.opacity * 0.55,
      weight: 0,
      interactive: false,
    }).addTo(strikeHeatLayer.current);
  });
}, [isEuropeMap, archive]);

  useEffect(() => {
    const mapView = MAP_VIEWS[view]; const c = mapView?.center;
    if (!mapInst.current || !Array.isArray(c) || !Number.isFinite(c[0]) || !Number.isFinite(c[1])) return;
    try { mapInst.current.flyTo(c, mapView.zoom, { animate: true, duration: 1.0 }); } catch (_) {}
    const L = window.L;
    if (!L || !allDayLayer.current) return;
    allDayLayer.current.clearLayers();
    markerPoolRef.current = [];
    const regionKey = view === 'europe' ? 'europe' : 'uk';
    const filtered = todayStrikesRef.current.filter(s => s && s.lat != null && s.lon != null && inBounds(s.lat, s.lon, regionKey));
    const sample = filtered;
    sample.forEach(s => paintStrikeOnMap(L, s));
    rebuildStrikeHeatmap();
  }, [view]); // eslint-disable-line

  useEffect(() => {
    if (!mapInst.current) return;
    [
      [allDayLayer,     'strikes'],
      [strikeHeatLayer, 'strikeheat'],
      [stormLayer,      'storms'],
      [radarLayer,      'radar'],
    ].forEach(([ref, id]) => {
      if (!ref.current) return;
      activeLayers.includes(id)
        ? (!mapInst.current.hasLayer(ref.current) && mapInst.current.addLayer(ref.current))
        : ( mapInst.current.hasLayer(ref.current) && mapInst.current.removeLayer(ref.current));
    });
  }, [activeLayers]);

  useEffect(() => {
    const iv = setInterval(() => {
      const pool = markerPoolRef.current;
      pool.forEach(dot => {
        try {
          const t = dot._strikeTime;
          if (!t) return;
          const c = strikeColor(t);
          if (dot._vLine) dot._vLine.setStyle({ color: c, opacity: 0.92 });
          if (dot._hLine) dot._hLine.setStyle({ color: c, opacity: 0.92 });
        } catch (_) {}
      });
    }, 90 * 1000);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
  if (!leafletReady) return;
  const L = window.L;
  // Always re-read from localStorage on mount — another tab or the SW may have saved more
  const existing = loadTodayStrikes();
  if (existing.length) {
    // Merge with anything already in memory (shouldn't be much, but be safe)
    const held = new Set(todayStrikesRef.current.map(s => `${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
    const toAdd = existing.filter(s => s && s.lat != null && s.lon != null && !held.has(`${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
    todayStrikesRef.current = [...todayStrikesRef.current, ...toAdd];
    todayStrikesRef.current.sort((a, b) => a.time - b.time);
    newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
    setTodayCount(todayStrikesRef.current.length);
    setUkCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length);
    setEuCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length);
    if (L) paintStrikes(existing, L);
    existing.forEach(s => tracker.current.ingest(s));
    setTimeout(rebuildStrikeHeatmap, 800);
    setTimeout(rebuildStrikeHeatmap, 3000);
  }
}, [leafletReady]); // eslint-disable-line
  // Pull strikes the Render worker collected while no users were on the site
    // Cross-device sync — fetch from Render on mount AND poll every 60s
  useEffect(() => {
    if (!leafletReady) return;
    let cancelled = false;

    const pullFromBackend = async () => {
      try {
        const regionKey = isEuropeMap ? 'europe' : 'uk';
        const res = await db.functions.invoke('historicalLightning', { region: regionKey, hoursBack: 24 });
        const strikes = res?.data?.strikes;
        if (cancelled || !Array.isArray(strikes) || !strikes.length) return;
        const held = new Set(todayStrikesRef.current.filter(s => s && s.lat != null && s.lon != null).map(s => `${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
        const fresh = strikes.filter(s => s && s.time && s.lat != null && s.lon != null && !held.has(`${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
        if (!fresh.length) return;
        todayStrikesRef.current.push(...fresh);
        todayStrikesRef.current.sort((a,b)=>a.time-b.time);
        saveTodayStrikes(todayStrikesRef.current);
        newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length-1]?.time || 0;
        setTodayCount(todayStrikesRef.current.length);
        setUkCount(todayStrikesRef.current.filter(s=>inBounds(s.lat,s.lon,'uk')).length);
        setEuCount(todayStrikesRef.current.filter(s=>inBounds(s.lat,s.lon,'europe')).length);
        const L = window.L; if (L) paintStrikes(fresh, L);
        fresh.forEach(s => tracker.current.ingest(s));
        setTimeout(rebuildStrikeHeatmap, 600);
      } catch (e) { console.warn('[historicalLightning]', e?.message); }
    };
    const pullFromRender = async () => {
      try {
        const r = await fetch(`${RENDER_WORKER_HTTP}/strikes/recent`);
        if (!r.ok) return;
        const strikes = await r.json();
        if (cancelled || !Array.isArray(strikes) || !strikes.length) return;
        const held = new Set(todayStrikesRef.current.filter(s => s && s.lat != null && s.lon != null).map(s => `${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
        const fresh = strikes.filter(s => s && s.time && s.lat != null && s.lon != null && !held.has(`${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
        if (!fresh.length) return;
        todayStrikesRef.current.push(...fresh);
        todayStrikesRef.current.sort((a, b) => a.time - b.time);
        saveTodayStrikes(todayStrikesRef.current);
        newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
        setTodayCount(todayStrikesRef.current.length);
        setUkCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length);
        setEuCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length);
        const L = window.L;
        if (L) paintStrikes(fresh, L);
        fresh.forEach(s => tracker.current.ingest(s));
        setTimeout(rebuildStrikeHeatmap, 600);
      } catch (_) {}
    };

    pullFromBackend();
    pullFromRender();
    const iv1 = setInterval(pullFromBackend, 60000);
    const iv = setInterval(pullFromRender, 20000);
    const onFocus = () => { pullFromBackend(); pullFromRender(); };
    window.addEventListener('focus', onFocus);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { pullFromBackend(); pullFromRender(); } });
    return () => { cancelled = true; clearInterval(iv); clearInterval(iv1); window.removeEventListener('focus', onFocus); };
  }, [leafletReady]); // eslint-disable-line
  const playThunder = useCallback(() => _playThunder(audioCtx, soundEnabledRef.current), []);
  const playWarningSiren = useCallback((r='yellow') => _playWarningSiren(audioCtx, warnSoundEnabledRef.current, r), []);
  const speakWarning = useCallback((t,r='yellow') => _speakWarning(t, ttsEnabledRef.current, r), []);

  const queueAlert = useCallback((poly, isUpgrade = false) => {
    alertQueue.current.push(async () => {
      if (!isUpgrade) {
        setNewStormAlert(poly);
        setTimeout(() => setNewStormAlert(null), 7000);
      }
      await playWarningSiren(poly.risk);
      const ttsText = buildTtsString(poly.risk, poly.count, poly.centroid.lat, poly.centroid.lon);
      await speakWarning(ttsText, poly.risk);
    });
  }, [playWarningSiren, speakWarning]);

  const loadRadar = useCallback(async () => {
    try {
      const res = await fetch('https://api.rainviewer.com/public/weather-maps.json');
      const data = await res.json();
      const frames = data?.radar?.past;
      if (!frames?.length) return;
      const latest = frames[frames.length - 1];
      const L = window.L;
      if (!L || !radarLayer.current) return;
      radarLayer.current.clearLayers();
      L.tileLayer(`https://tilecache.rainviewer.com${latest.path}/256/{z}/{x}/{y}/6/1_1.png`, {
  opacity: 0.65,
  tileSize: 256,
  maxZoom: 19,
  maxNativeZoom: 18,
  minZoom: 0,
  detectRetina: false,
  updateWhenIdle: false,
  updateWhenZooming: false,
  keepBuffer: 4,
}).addTo(radarLayer.current);
    } catch (_) {}
  }, []);

  const renderFlash = useCallback((lat, lon) => {
  if (!activeLayers.current?.includes('strikes') && !activeLayers.includes('strikes')) return;
  if (!mapInst.current) return;
  try {
    const bounds = mapInst.current.getBounds();
    if (!bounds.contains([lat, lon])) return;
  } catch (_) { return; }
  renderGlowFlash(lat, lon, flashLayer);
}, [activeLayers]);

  const pendingStrikesRef = useRef([]);
  const rafPendingRef     = useRef(null);
  const flushPendingStrikes = useCallback(() => {
    const L = window.L;
    rafPendingRef.current = null;
    if (!pendingStrikesRef.current.length || !L || !allDayLayer.current) return;
    const batch = pendingStrikesRef.current.splice(0, 300);
    batch.forEach(strike => paintStrikeOnMap(L, strike));
    if (pendingStrikesRef.current.length > 0) rafPendingRef.current = requestAnimationFrame(flushPendingStrikes);
  }, [paintStrikeOnMap]);

  const handleStrike = useCallback((strike) => {
    if (!strike || strike.lat == null || strike.lon == null || !strike.time) return;
    const dupKey = `${strike.time}_${Math.round(strike.lat*1000)}_${Math.round(strike.lon*1000)}`;
    if (todayStrikesRef.current.filter(s => s && s.lat != null && s.lon != null).some(s => `${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}` === dupKey)) return;
    setStrikeCount(c => c + 1);
    setTodayCount(c => c + 1);
    if (inBounds(strike.lat, strike.lon, 'uk'))     setUkCount(c => c + 1);
    if (inBounds(strike.lat, strike.lon, 'europe')) setEuCount(c => c + 1);
    const nowMs = Date.now();
lastMinBufferRef.current.push({ t: nowMs, lat: strike.lat, lon: strike.lon });
const cutoff = nowMs - 60000;
lastMinBufferRef.current = lastMinBufferRef.current.filter(s => s.t > cutoff);
const ukMs = lastMinBufferRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length;
const euMs = lastMinBufferRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length;
setLastMinUkCount(ukMs);
setLastMinEuCount(euMs);
const regionKey = isEuropeMap ? 'europe' : 'uk';
setLastMinCount(regionKey === 'uk' ? ukMs : euMs);
    playThunder();
        todayStrikesRef.current.push(strike);
    dirtyRef.current = true;

    // Save immediately on every strike — no debounce, no data loss on reload
saveTodayStrikes(todayStrikesRef.current);
newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
    renderFlash(strike.lat, strike.lon);

    // Live-update warning cards: if this strike falls inside an existing warning polygon,
    // bump that warning's count + recentCount immediately
    setStormPolys(prev => {
  let changed = false;
  const updated = prev.map(p => {
    if (pointInPolygon(strike.lat, strike.lon, p.corePolygon)) {
      changed = true;
      return { ...p, count: (p.count || 0) + 1, recentCount: (p.recentCount || 0) + 1 };
    }
    return p;
  });
  return changed ? updated : prev;
});
// Skip ingesting into tracker if already inside an existing warning
const alreadyCovered = stormPolys.some(p => pointInPolygon(strike.lat, strike.lon, p.corePolygon));
if (!alreadyCovered) tracker.current.ingest(strike);

    pendingStrikesRef.current.push(strike);
    if (!rafPendingRef.current) rafPendingRef.current = requestAnimationFrame(flushPendingStrikes);
    if (navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({ type: 'NEW_STRIKES', strikes: [strike] });
    }
        if (heatRebuildTimer.current) clearTimeout(heatRebuildTimer.current);
    heatRebuildTimer.current = setTimeout(rebuildStrikeHeatmap, 8000); // faster — was 60s
  }, [playThunder, renderFlash, flushPendingStrikes, rebuildStrikeHeatmap]);

  const renderStormPolygons = useCallback((polys) => {
    const L = window.L;
    if (!L || !stormLayer.current) return;
    const now = Date.now();
    const currentIds = new Set(polys.map(p => p.id));
    Object.keys(stormPolygonMap.current).forEach(id => {
      const entry = stormPolygonMap.current[id];
      if (!currentIds.has(id) && entry.expiresAt && now > entry.expiresAt) {
        try { stormLayer.current?.removeLayer(entry.core); }   catch (_) {}
        try { stormLayer.current?.removeLayer(entry.glow); }   catch (_) {}
        try { stormLayer.current?.removeLayer(entry.marker); } catch (_) {}
        delete stormPolygonMap.current[id];
        delete knownStormRisks.current[id];
        knownStormIds.current.delete(id);
      }
    });
    polys.forEach(poly => {
      const cfg = STORM_RISK[poly.risk];
      const existing = stormPolygonMap.current[poly.id];
      if (existing) {
        try { existing.core.setLatLngs(poly.corePolygon); existing.core.setStyle({ color: cfg.color, fillColor: cfg.color }); } catch (_) {}
        try { existing.glow.setLatLngs(poly.corePolygon); existing.glow.setStyle({ color: cfg.color }); } catch (_) {}
        try { existing.marker.setLatLng([poly.centroid.lat, poly.centroid.lon]); } catch (_) {}
        existing.updatedAt = now;
        existing.expiresAt = poly.expiresAt;
        const prevRisk = knownStormRisks.current[poly.id];
        const RISK_RANK = { yellow: 0, amber: 1, red: 2 };
        if (prevRisk && RISK_RANK[poly.risk] > RISK_RANK[prevRisk]) {
          knownStormRisks.current[poly.id] = poly.risk;
          queueAlert(poly, true);
        }
      } else {
        const glow = L.polygon(poly.corePolygon, {
          color: cfg.color, fillColor: 'transparent', fillOpacity: 0,
          weight: 8, opacity: 0.18, smoothFactor: 1.5, interactive: false, pane: 'overlayPane',
        }).addTo(stormLayer.current);
        const core = L.polygon(poly.corePolygon, {
          color: cfg.color, fillColor: cfg.color, fillOpacity: 0.22,
          weight: 2.5, smoothFactor: 1.5,
          dashArray: poly.risk === 'red' ? null : '6 3',
          pane: 'overlayPane',
        }).addTo(stormLayer.current);
        core.on('click', () => setSelectedStorm(poly));
        const marker = L.marker([poly.centroid.lat, poly.centroid.lon], { icon: L.divIcon({ html: '', className: '', iconSize: [0,0] }), interactive: false }).addTo(stormLayer.current);
        stormPolygonMap.current[poly.id] = { core, glow, marker, updatedAt: now, expiresAt: poly.expiresAt };
        let fc = 0;
        const fi = setInterval(() => {
          try { core.setStyle({ weight: fc%2===0?5:2.5, fillOpacity: fc%2===0?0.45:0.22 }); } catch(_){}
          if (++fc > 8) clearInterval(fi);
        }, 300);
        if (!knownStormIds.current.has(poly.id)) {
          knownStormIds.current.add(poly.id);
          knownStormRisks.current[poly.id] = poly.risk;
          setIsFlashing(prev => ({ ...prev, [poly.id]: true }));
          setTimeout(() => setIsFlashing(prev => { const n={...prev}; delete n[poly.id]; return n; }), 2500);
          queueAlert(poly, false);
        }
      }
    });
  }, [queueAlert]);

  const doMidnightSnapshot = useCallback((isForced = false, snapshotAt = null) => {
    const snap = [...todayStrikesRef.current];
    const captureTime = snapshotAt || Date.now();
    const dateKey = isForced
      ? `${localDateKey(captureTime)} [FORCED ${new Date(captureTime).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})}]`
      : localDateKey(snap.length ? snap[snap.length-1].time : captureTime);
    const hourBuckets = {};
    snap.forEach(s => { const h = new Date(s.time).getHours(); hourBuckets[h] = (hourBuckets[h]||0)+1; });
    const peakHour = Object.entries(hourBuckets).sort((a,b) => b[1]-a[1])[0];
    const entry = {
      date: dateKey, capturedAt: captureTime, isForced,
      strikes: snap.map(s => ({ lat: s.lat, lon: s.lon, time: s.time, amp: s.amp })),
      stormCount: stormPolys.length,
      peakHour: peakHour ? `${String(peakHour[0]).padStart(2,'0')}:00` : '—',
      stormWarnings: stormPolys.map(p => ({
        id: p.id, risk: p.risk, count: p.count,
        centroid: p.centroid, corePolygon: p.corePolygon,
        locationLabel: p.locationLabel, expiresAt: p.expiresAt,
      })),
    };
    setArchive(prev => {
      const updated = [...prev.filter(d => d.date !== dateKey), entry].slice(-30);
      saveArchive(updated);
      return updated;
    });
    if (!isForced) {
      const cutoff24h = Date.now() - 25 * 60 * 60 * 1000;
      todayStrikesRef.current = todayStrikesRef.current.filter(s => s.time > cutoff24h);
      dirtyRef.current = true;
      saveTodayStrikes(todayStrikesRef.current);
      setTodayCount(todayStrikesRef.current.length);
      try { allDayLayer.current?.clearLayers(); } catch (_) {}
      markerPoolRef.current = [];
      const L = window.L;
      if (L && allDayLayer.current) {
        const regionFiltered = todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, isEuropeMap ? 'europe' : 'uk'));
        regionFiltered.forEach(s => paintStrikeOnMap(L, s));
      }
      if (strikeHeatLayer.current) strikeHeatLayer.current.clearLayers();
      setTimeout(rebuildStrikeHeatmap, 800);
    }
  }, [stormPolys, isEuropeMap, paintStrikeOnMap, rebuildStrikeHeatmap, setArchive]);

  const forceSnapshotRef = useRef(doMidnightSnapshot);
  useEffect(() => { forceSnapshotRef.current = doMidnightSnapshot; }, [doMidnightSnapshot]);

  const handleForceSnapshot = useCallback((snapshotTime) => {
    return new Promise(resolve => {
      const cutoff = snapshotTime || Date.now();
      const cutoffStart = cutoff - 24 * 60 * 60 * 1000;
      const windowStrikes = todayStrikesRef.current.filter(s => s.time >= cutoffStart && s.time <= cutoff);
      const prevStrikes = todayStrikesRef.current;
      todayStrikesRef.current = windowStrikes;
      forceSnapshotRef.current(true, cutoff);
      todayStrikesRef.current = prevStrikes;
      const snap = {
        capturedAt: cutoff, isForced: true,
        strikes: windowStrikes.map(s => ({ lat: s.lat, lon: s.lon, time: s.time, amp: s.amp })),
        stormCount: stormPolys.length,
        peakHour: new Date(cutoff).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
        stormWarnings: stormPolys.map(p => ({
          id: p.id, risk: p.risk, count: p.count,
          centroid: p.centroid, corePolygon: p.corePolygon,
          locationLabel: p.locationLabel, expiresAt: p.expiresAt,
        })),
      };
      saveSnapshot(snap);
      window.dispatchEvent(new StorageEvent('storage', { key: SNAPSHOT_KEY, newValue: JSON.stringify(loadSnapshots()) }));
      setTimeout(resolve, 200);
    });
  }, [stormPolys]);

  useEffect(() => {
    if (!leafletReady) return;
    registerServiceWorker();

    if (!restoredWarningsRef.current) {
  restoredWarningsRef.current = true;
  const stored = loadStoredWarnings();
  if (stored.length > 0) {
    setStormPolys(stored);
    // Wait for map layers to be fully ready before rendering polygons
    const tryRender = (attempts = 0) => {
      if (stormLayer.current && mapInst.current) {
        stored.forEach(w => {
          knownStormIds.current.add(w.id);
          knownStormRisks.current[w.id] = w.risk;
        });
        renderStormPolygons(stored);
      } else if (attempts < 20) {
        setTimeout(() => tryRender(attempts + 1), 250);
      }
    };
    setTimeout(() => tryRender(), 500);
  }
}

    if (window.speechSynthesis) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
    }

    const onStorage = (e) => {
      if (e.key !== STORE_KEY) return;
      try {
        const incoming = JSON.parse(e.newValue || '[]');
        const cutoff24h = Date.now() - 25 * 60 * 60 * 1000;
        const fresh = incoming.filter(s => s.time && s.time > cutoff24h && s.time > newestLoadedTsRef.current);
        if (!fresh.length) return;
        const held = new Set(todayStrikesRef.current.filter(s => s && s.lat != null && s.lon != null).map(s => `${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
        const toAdd = fresh.filter(s => !held.has(`${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
        if (!toAdd.length) return;
        todayStrikesRef.current.push(...toAdd);
        todayStrikesRef.current.sort((a, b) => a.time - b.time);
        newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
        setTodayCount(todayStrikesRef.current.length);
        setUkCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length);
        setEuCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length);
        const L = window.L;
        if (L) paintStrikes(toAdd, L);
        toAdd.forEach(s => tracker.current.ingest(s));
      } catch (_) {}
    };
    const onWarningStorage = (e) => {
      if (e.key !== STORM_STORE_KEY) return;
      try {
        const incoming = JSON.parse(e.newValue || '[]');
        const live = incoming.filter(w => w.expiresAt && w.expiresAt > Date.now());
        setStormPolys(prev => {
          const prevIds = new Set(prev.map(p => p.id));
          const toAdd = live.filter(w => !prevIds.has(w.id));
          if (!toAdd.length) return prev;
          return [...prev, ...toAdd];
        });
        if (live.length) renderStormPolygons(live);
      } catch (_) {}
    };
    window.addEventListener('storage', onStorage);
    window.addEventListener('storage', onWarningStorage);

    const crossSessionStrikes = loadNewStrikesSince(newestLoadedTsRef.current) || [];
    if (crossSessionStrikes.length) {
      const held = new Set(todayStrikesRef.current.filter(s => s && s.lat != null && s.lon != null).map(s => `${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
      const toAdd = crossSessionStrikes.filter(s => s && s.lat != null && s.lon != null && !held.has(`${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
      if (toAdd.length) {
        todayStrikesRef.current.push(...toAdd);
        todayStrikesRef.current.sort((a, b) => a.time - b.time);
        setTodayCount(todayStrikesRef.current.length);
        const L = window.L;
        if (L) paintStrikes(toAdd, L);
      }
    }

    const swMessageHandler = (event) => {
      if (event.data?.type === 'BUFFERED_STRIKES') {
        event.data.strikes.forEach(s => {
          const exists = todayStrikesRef.current.some(e => e.time === s.time && e.lat === s.lat);
          if (!exists) handleStrike(s);
        });
      }
      if (event.data?.type === 'DO_MIDNIGHT_SNAPSHOT') doMidnightSnapshot(false);
    };
    navigator.serviceWorker?.addEventListener('message', swMessageHandler);

    navigator.serviceWorker?.ready.then(reg => { reg.active?.postMessage({ type: 'TAB_ACTIVE' }); }).catch(() => {});
    navigator.serviceWorker?.ready.then(async () => {
      try {
        const cache = await caches.open('tcm-bg-strikes-v1');
        const response = await cache.match('/tcm-bg-strikes');
        if (response) {
          const { strikes } = await response.json();
          if (strikes?.length) {
            const held = new Set(todayStrikesRef.current.filter(s => s && s.lat != null && s.lon != null).map(s => `${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
            const toAdd = (strikes || []).filter(s => s && s.lat != null && s.lon != null && s.time > Date.now() - 86400000 && !held.has(`${s.time}_${Math.round(s.lat*1000)}_${Math.round(s.lon*1000)}`));
            if (toAdd.length) {
              todayStrikesRef.current.push(...toAdd);
              todayStrikesRef.current.sort((a, b) => a.time - b.time);
              setTodayCount(todayStrikesRef.current.length);
              setUkCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length);
              setEuCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length);
              const L = window.L;
              if (L) paintStrikes(toAdd, L);
              toAdd.forEach(s => tracker.current.ingest(s));
            }
          }
          await cache.delete('/tcm-bg-strikes');
        }
      } catch (_) {}
    }).catch(() => {});

    const onVisible = () => {
      if (document.visibilityState === 'hidden') {
        saveTodayStrikes(todayStrikesRef.current);
        newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
        broadcastWarnings(stormPolys);
        navigator.serviceWorker?.ready.then(reg => { reg.active?.postMessage({ type: 'TAB_HIDDEN' }); }).catch(() => {});
      } else {
        navigator.serviceWorker?.ready.then(reg => { reg.active?.postMessage({ type: 'TAB_ACTIVE' }); }).catch(() => {});
      }
    };
    document.addEventListener('visibilitychange', onVisible);

    const stopWs = connectBlitzortung(handleStrike, setWsStatus);

    const clusterIv = setInterval(() => {
      const fresh = tracker.current.cluster();
      const storedLive = loadStoredWarnings();
      const freshIds = new Set(fresh.map(x => x.id));
      const merged = [...fresh, ...storedLive.filter(w => !freshIds.has(w.id))];
      setStormPolys(merged);
      renderStormPolygons(merged);
      broadcastWarnings(merged);
    }, 60000);

    const expireIv = setInterval(() => {
      const now = Date.now();
      Object.keys(stormPolygonMap.current).forEach(id => {
        const entry = stormPolygonMap.current[id];
        if (entry.expiresAt && now > entry.expiresAt) {
          try { stormLayer.current?.removeLayer(entry.core); }   catch (_) {}
          try { stormLayer.current?.removeLayer(entry.glow); }   catch (_) {}
          try { stormLayer.current?.removeLayer(entry.marker); } catch (_) {}
          delete stormPolygonMap.current[id];
          delete knownStormRisks.current[id];
          knownStormIds.current.delete(id);
          setStormPolys(prev => {
            const updated = prev.filter(p => p.id !== id);
            broadcastWarnings(updated);
            return updated;
          });
        }
      });
      broadcastWarnings(loadStoredWarnings());
    }, 60000);

    loadRadar();
    const radarIv  = setInterval(loadRadar, 10*60*1000);
    const updateIv = setInterval(() => setLastUpdate(new Date()), 30*1000);
    const saveIv = setInterval(() => {
  if (dirtyRef.current) {
    saveTodayStrikes(todayStrikesRef.current);
    newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
    dirtyRef.current = false;
  }
}, 3000);
    const lastMinIv = setInterval(() => {
  const cutoff = Date.now() - 60000;
  lastMinBufferRef.current = lastMinBufferRef.current.filter(s => s.t > cutoff);
  const ukMs = lastMinBufferRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length;
  const euMs = lastMinBufferRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length;
  setLastMinUkCount(ukMs);
  setLastMinEuCount(euMs);
  const regionKey = view === 'europe' ? 'europe' : 'uk';
  setLastMinCount(regionKey === 'uk' ? ukMs : euMs);
}, 5000);

    let snapshotDone = false;
    const snapshotIv = setInterval(() => {
      const now = new Date();
      if (now.getHours() === 23 && now.getMinutes() === 59 && !snapshotDone) {
        snapshotDone = true;
        doMidnightSnapshot(false);
        setTimeout(() => { snapshotDone = false; }, 70000);
      }
    }, 30000);

    let swPingInterval = null;
    if ('serviceWorker' in navigator) {
      swPingInterval = setInterval(() => {
        navigator.serviceWorker.ready.then(reg => { reg.active?.postMessage({ type: 'PING' }); }).catch(() => {});
        if (todayStrikesRef.current.length) saveTodayStrikes(todayStrikesRef.current);
      }, 25000);
    }

    return () => {
      stopWs();
      clearInterval(clusterIv); clearInterval(expireIv); clearInterval(radarIv);
      clearInterval(updateIv); clearInterval(snapshotIv); clearInterval(swPingInterval);
      clearInterval(lastMinIv);
      document.removeEventListener('visibilitychange', onVisible);
      navigator.serviceWorker?.removeEventListener('message', swMessageHandler);
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('storage', onWarningStorage);
      if (dirtyRef.current) saveTodayStrikes(todayStrikesRef.current);
    };
  }, [leafletReady, handleStrike, renderStormPolygons, loadRadar, doMidnightSnapshot, paintStrikes]); // eslint-disable-line

  useEffect(() => {
  const flushAll = () => {
    // Write synchronously — beforeunload has no async budget
    try {
      saveTodayStrikes(todayStrikesRef.current);
      newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
    } catch (_) {}
    broadcastWarnings(stormPolys);
  };
  window.addEventListener('beforeunload', flushAll);
  window.addEventListener('pagehide', flushAll);
  // Also flush on visibility hidden (mobile backgrounding)
  const onHide = () => {
    if (document.visibilityState === 'hidden') flushAll();
  };
  document.addEventListener('visibilitychange', onHide);
  return () => {
    window.removeEventListener('beforeunload', flushAll);
    window.removeEventListener('pagehide', flushAll);
    document.removeEventListener('visibilitychange', onHide);
  };
}, [stormPolys]);

  const toggleLayer = (id) => setActiveLayers(prev => prev.includes(id) ? prev.filter(l => l!==id) : [...prev, id]);
  const fmt = (d) => d.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
  const sc = { live: { color: '#22c55e', label: 'BLITZORTUNG LIVE' }, connecting: { color: '#facc15', label: 'CONNECTING…' } }[wsStatus] || { color: '#facc15', label: 'CONNECTING…' };

  return (
    <>
      <style>{LIGHTNING_MAP_CSS}</style>

            <motion.div initial={{ opacity:0,y:20 }} animate={{ opacity:1,y:0 }} transition={{ duration:0.6 }} className="mx-auto max-w-6xl px-6 mb-6">
        {/* Hero header */}
        <div className="tcm-hero-header" style={{
  position:'relative', borderRadius:18, overflow:'hidden',
  background:'linear-gradient(135deg, rgba(250,204,21,0.10) 0%, rgba(239,68,68,0.06) 50%, rgba(167,139,250,0.08) 100%)',
  border:'1px solid rgba(250,204,21,0.22)',
  padding:'14px 16px', marginBottom:14,
  boxShadow:'0 4px 24px rgba(0,0,0,0.3)',
}}>
          {/* Animated top line */}
          <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:'linear-gradient(90deg, transparent, #facc15, #f97316, #ef4444, transparent)', backgroundSize:'200% 100%', animation:'shimmer 4s linear infinite' }} />
          <div style={{ display:'flex', alignItems:'center', gap:18, flexWrap:'wrap' }}>
            <div style={{
              width:54, height:54, borderRadius:15, flexShrink:0,
              background:'radial-gradient(circle, rgba(250,204,21,0.35), rgba(239,68,68,0.15))',
              border:'1.5px solid rgba(250,204,21,0.5)',
              display:'flex', alignItems:'center', justifyContent:'center',
              boxShadow:'inset 0 0 18px rgba(250,204,21,0.3), 0 0 24px rgba(250,204,21,0.2)',
            }}>
              <CloudLightning style={{ width:28, height:28, color:'#facc15', filter:'drop-shadow(0 0 6px #facc15)' }} />
            </div>
            <div style={{ flex:1, minWidth:0 }}>
              <h2 style={{
                fontSize:'1.55rem', fontWeight:800, margin:0, letterSpacing:'-0.025em',
                background:'linear-gradient(135deg, #facc15 0%, #f97316 50%, #ef4444 100%)',
                WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text',
              }}>
                Live Lightning & Storm Tracker
              </h2>
              <p style={{ fontSize:'0.78rem', color:'#94a3b8', margin:'3px 0 0', fontWeight:500 }}>
                Direct Blitzortung WebSocket · Render 24/7 fallback · Strict warning rules · Auto-snapshot 23:59
              </p>
            </div>
            <div style={{
              display:'flex', alignItems:'center', gap:9, padding:'8px 14px', borderRadius:20,
              background: wsStatus === 'live' ? 'rgba(34,197,94,0.12)' : 'rgba(249,115,22,0.12)',
              border: `1px solid ${wsStatus === 'live' ? 'rgba(34,197,94,0.35)' : 'rgba(249,115,22,0.35)'}`,
            }}>
              <div className={wsStatus === 'live' ? 'live-dot-green' : 'live-dot-amber'} />
              <span style={{ fontSize:'0.72rem', fontWeight:800, color:sc.color, fontFamily:'monospace', letterSpacing:'0.08em' }}>{sc.label}</span>
            </div>
          </div>
        </div>

        {/* Stat strip — bigger, individual cards */}
        <div className="tcm-stat-strip" style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(140px, 1fr))', gap:10 }}>
          {[
            { icon:<CloudLightning style={{width:15,height:15}}/>, label:'Last min 🇬🇧', value:lastMinUkCount.toLocaleString(), color:'#facc15' },
{ icon:<CloudLightning style={{width:15,height:15}}/>, label:'Last min EU', value:lastMinEuCount.toLocaleString(), color:'#a78bfa' },
            { icon:<CloudLightning style={{width:15,height:15}}/>, label:'UK today',    value:ukCount.toLocaleString(),      color:'#38bdf8' },
            { icon:<CloudLightning style={{width:15,height:15}}/>, label:'EU today',    value:euCount.toLocaleString(),      color:'#a78bfa' },
           { icon:<AlertTriangle  style={{width:15,height:15}}/>, label:'Warnings',    value:stormPolys.filter(p => warningInRegion(p, view === 'europe' ? 'europe' : 'uk')).length, color:'#f97316' },
            { icon:<Clock          style={{width:15,height:15}}/>, label:'Updated',     value:fmt(lastUpdate),               color:'#64748b' },
          ].map(({ icon, label, value, color }) => (
            <div key={label} style={{
              padding:'10px 14px', borderRadius:12,
              background:`linear-gradient(135deg, rgba(${hexToRgb(color)},0.10), rgba(${hexToRgb(color)},0.02))`,
              border:`1px solid rgba(${hexToRgb(color)},0.25)`,
              display:'flex', alignItems:'center', gap:10,
            }}>
              <div style={{ color, flexShrink:0 }}>{icon}</div>
              <div style={{ minWidth:0 }}>
                <p style={{ margin:0, fontSize:'0.6rem', color:'#64748b', fontWeight:700, letterSpacing:'0.08em', textTransform:'uppercase' }}>{label}</p>
                <p style={{ margin:0, fontSize:'1.05rem', fontWeight:800, color, fontFamily:'monospace', letterSpacing:'-0.02em' }}>{value}</p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div initial={{ opacity:0,scale:0.99 }} animate={{ opacity:1,scale:1 }} transition={{ duration:0.7, delay:0.1 }} className="mx-auto max-w-6xl px-6 mb-6">
        <div style={{ position: mapFullscreen ? 'fixed' : 'relative', inset: mapFullscreen ? 0 : undefined, zIndex: mapFullscreen ? 9997 : undefined, borderRadius: mapFullscreen ? 0 : 22, overflow:'hidden', border:'1px solid rgba(255,255,255,0.07)', boxShadow:'0 0 80px rgba(0,0,0,0.55)' }}>

          <div className="tcm-map-topbar" style={{
  position:'absolute', top:0, left:0, right:0, zIndex:1000,
  padding:'10px 12px',
  background:'linear-gradient(to bottom, rgba(6,13,26,0.97) 0%, rgba(6,13,26,0.85) 80%, transparent 100%)',
  pointerEvents:'none',
  display:'flex', flexDirection:'column', gap:8,
}}>
  {/* Row 1 — view toggle + status */}
  <div className="tcm-map-row1" style={{ display:'flex', alignItems:'center', gap:8, pointerEvents:'all', flexWrap:'wrap' }}>
    <div className="tcm-view-toggle" style={{
  display:'flex', borderRadius:10, overflow:'hidden',
  border:'1px solid rgba(255,255,255,0.1)',
  background:'rgba(6,13,26,0.95)',
  backdropFilter:'blur(14px)',
}}>
      {[['uk','🇬🇧 UK'],['europe','🌍 Europe']].map(([id,lbl]) => (
        <button key={id} onClick={() => {
          setView(id);
          const v = MAP_VIEWS[id];
          if (mapInst.current) try { mapInst.current.flyTo(v.center, v.zoom, { animate:true, duration:1.2 }); } catch(_){}
        }} style={{
          padding:'7px 16px', fontSize:'0.73rem', fontWeight:700,
          color: view===id ? '#0a0f1e' : '#64748b',
          background: view===id ? 'linear-gradient(135deg,#facc15,#f97316)' : 'transparent',
          border:'none', cursor:'pointer', transition:'all 0.2s',
          letterSpacing:'0.03em',
        }}>{lbl}</button>
      ))}
      <AnimatePresence>

</AnimatePresence>
    </div>

    {/* live status pill */}
    <div style={{
      display:'flex', alignItems:'center', gap:7, padding:'6px 14px',
      borderRadius:20,
      background: wsStatus==='live' ? 'rgba(34,197,94,0.12)' : 'rgba(249,115,22,0.12)',
      border:`1px solid ${wsStatus==='live' ? 'rgba(34,197,94,0.4)' : 'rgba(249,115,22,0.4)'}`,
      backdropFilter:'blur(14px)',
    }}>
      <div className={wsStatus==='live' ? 'live-dot-green' : 'live-dot-amber'} />
      <span style={{ fontSize:'0.68rem', fontWeight:800, color:sc.color, fontFamily:'monospace', letterSpacing:'0.1em' }}>{sc.label}</span>
    </div>

    {/* spacer */}
    <div style={{ flex:1 }} />

    {/* sound/tts toggles */}
    <div className="tcm-sound-toggles" style={{ display:'flex', gap:5, pointerEvents:'all', flexWrap:'wrap' }}>
      {[
        { key:'strike', label:'⚡', title:'Strike Sound', state:soundEnabled,     set:setSoundEnabled },
        { key:'warn',   label:'🚨', title:'Alert Sound',  state:warnSoundEnabled, set:setWarnSoundEnabled },
        { key:'tts',    label:'🗣', title:'Voice',        state:ttsEnabled,       set:setTtsEnabled },
      ].map(({ key, label, title, state, set }) => (
        <button key={key} onClick={() => set(v => !v)} title={title}
          style={{
            display:'flex', alignItems:'center', gap:4, padding:'6px 11px', borderRadius:9,
            background: state ? 'rgba(34,197,94,0.14)' : 'rgba(255,255,255,0.04)',
            border:`1px solid ${state ? 'rgba(34,197,94,0.45)' : 'rgba(255,255,255,0.09)'}`,
            color: state ? '#22c55e' : '#475569',
            fontSize:'0.78rem', cursor:'pointer', backdropFilter:'blur(14px)',
            transition:'all 0.2s',
          }}>
          {label}
          <span style={{ fontSize:'0.62rem', fontWeight:700, color: state ? '#22c55e' : '#475569' }}>
            {state ? 'ON' : 'OFF'}
          </span>
        </button>
      ))}
    </div>

    <button onClick={() => { setTimeTravelMode(v => !v); if (timeTravelMode) exitTimeTravel(); }}
      style={{
        display:'flex', alignItems:'center', gap:5, padding:'6px 11px', borderRadius:9,
        background: timeTravelMode ? 'rgba(167,139,250,0.18)' : 'rgba(255,255,255,0.04)',
        border:`1px solid ${timeTravelMode ? '#a78bfa' : 'rgba(255,255,255,0.09)'}`,
        color: timeTravelMode ? '#a78bfa' : '#64748b',
        fontSize:'0.71rem', cursor:'pointer', backdropFilter:'blur(14px)',
        pointerEvents:'all',
      }}>
      <Clock style={{width:11,height:11}}/> Archive
    </button>
    <button onClick={() => setMapFullscreen(v => !v)}
  style={{
    display:'flex', alignItems:'center', gap:5, padding:'6px 11px', borderRadius:9,
    background: mapFullscreen ? 'rgba(56,189,248,0.18)' : 'rgba(255,255,255,0.04)',
    border:`1px solid ${mapFullscreen ? '#38bdf8' : 'rgba(255,255,255,0.09)'}`,
    color: mapFullscreen ? '#38bdf8' : '#64748b',
    fontSize:'0.71rem', cursor:'pointer', backdropFilter:'blur(14px)',
    pointerEvents:'all',
  }}>
  {mapFullscreen ? '✕ Exit' : '⛶ Full'}
</button>
    <button onClick={() => { loadRadar(); setLastUpdate(new Date()); }}
      style={{
        display:'flex', alignItems:'center', gap:5, padding:'6px 11px', borderRadius:9,
        background:'rgba(255,255,255,0.04)',
        border:'1px solid rgba(255,255,255,0.09)',
        color:'#64748b', fontSize:'0.71rem', cursor:'pointer',
        backdropFilter:'blur(14px)', pointerEvents:'all',
      }}>
      <RefreshCw style={{width:11,height:11}}/>
    </button>
  </div>

  {/* Row 2 — layer toggles */}
  <div className="tcm-map-row2" style={{ display:'flex', gap:6, flexWrap:'wrap', pointerEvents:'all' }}>
    {LAYER_DEFS.map(layer => {
      const active = activeLayers.includes(layer.id);
      const Icon = layer.icon;
      return (
        <button key={layer.id} onClick={() => toggleLayer(layer.id)}
          style={{
            display:'flex', alignItems:'center', gap:6, padding:'5px 12px', borderRadius:8,
            background: active ? `rgba(${hexToRgb(layer.color)},0.15)` : 'rgba(6,13,26,0.85)',
            border:`1px solid ${active ? `rgba(${hexToRgb(layer.color)},0.5)` : 'rgba(255,255,255,0.07)'}`,
            color: active ? layer.color : '#475569',
            fontSize:'0.69rem', fontWeight:700, cursor:'pointer',
            backdropFilter:'blur(14px)', transition:'all 0.2s',
          }}>
          <Icon style={{width:11,height:11}}/>
          {layer.label}
          {layer.id==='strikes' && (
            <span style={{
              background:`rgba(${hexToRgb(layer.color)},0.2)`, borderRadius:4,
              padding:'0 5px', fontSize:'0.62rem', color:layer.color, fontFamily:'monospace',
            }}>{todayCount.toLocaleString()}</span>
          )}
          {layer.id==='storms' && stormPolys.filter(p => warningInRegion(p, view === 'europe' ? 'europe' : 'uk')).length > 0 && (
  <span style={{
    background:`rgba(${hexToRgb(layer.color)},0.2)`, borderRadius:4,
    padding:'0 5px', fontSize:'0.62rem', color:layer.color, fontFamily:'monospace',
  }}>{stormPolys.filter(p => warningInRegion(p, view === 'europe' ? 'europe' : 'uk')).length}</span>
)}
        </button>
      );
    })}
  </div>
</div>
{mapFullscreen && (
  <div style={{ display:'flex', alignItems:'center', gap:10, pointerEvents:'all', marginTop:4 }}>
    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@800;900&display=swap');`}</style>
      <span style={{ fontFamily:"'Orbitron',sans-serif", fontWeight:900, fontSize:'1.1rem', letterSpacing:'0.2em', background:'linear-gradient(135deg,#a78bfa 0%,#818cf8 25%,#38bdf8 60%,#34d399 100%)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>TCM</span>
      <span style={{ fontFamily:"'Orbitron',sans-serif", fontWeight:800, fontSize:'0.45rem', letterSpacing:'0.18em', background:'linear-gradient(135deg,#a78bfa,#38bdf8)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text' }}>V2.0</span>
    </div>
  </div>
)}

          <div ref={mapRef} style={{ width:'100%', height: mapFullscreen ? '100vh' : 'min(580px, 60vh)', minHeight:320, background:'#060d1a' }} />

          {timeTravelMode && (
            <div style={{ position:'absolute', top:56, left:'50%', transform:'translateX(-50%)', zIndex:1001, background:'rgba(6,13,26,0.97)', border:'1px solid rgba(167,139,250,0.4)', borderRadius:14, padding:'14px 18px', backdropFilter:'blur(18px)', display:'flex', flexDirection:'column', gap:10, minWidth:340 }}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                <span style={{ fontSize:'0.78rem', fontWeight:700, color:'#a78bfa' }}>⏪ Time Travel — Archive View</span>
                <button onClick={exitTimeTravel} style={{ background:'rgba(255,255,255,0.06)', border:'none', borderRadius:6, width:24, height:24, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}><X style={{width:11,height:11}}/></button>
              </div>
              <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
                <input type="date" value={timeTravelDate} max={new Date().toISOString().slice(0,10)} min="2010-01-01"
                  onChange={e => setTimeTravelDate(e.target.value)}
                  style={{ padding:'5px 8px', borderRadius:7, background:'rgba(255,255,255,0.06)', border:'1px solid rgba(167,139,250,0.3)', color:'#f1f5f9', fontSize:'0.74rem', colorScheme:'dark' }}
                />
                <span style={{ fontSize:'0.65rem', color:'#64748b' }}>Hour: {String(timeTravelHour).padStart(2,'0')}:00</span>
                <input type="range" min={0} max={23} step={1} value={timeTravelHour}
                  onChange={e => setTimeTravelHour(Number(e.target.value))}
                  style={{ width:140, accentColor:'#a78bfa' }}
                />
                <button onClick={loadTimeTravelImage} disabled={!timeTravelDate || timeTravelLoading}
                  style={{ display:'flex', alignItems:'center', gap:5, padding:'8px 14px', borderRadius:9, background: !timeTravelDate ? 'rgba(167,139,250,0.05)' : 'rgba(167,139,250,0.18)', border:'1px solid rgba(167,139,250,0.35)', color: !timeTravelDate ? '#475569' : '#a78bfa', fontSize:'0.74rem', fontWeight:700, cursor: !timeTravelDate ? 'default' : 'pointer' }}>
                  {timeTravelLoading ? <Loader2 style={{width:11,height:11,animation:'spin 1s linear infinite'}}/> : <Clock style={{width:11,height:11}}/>}
                  Load
                </button>
              </div>
              {timeTravelImgUrl && (
                <button onClick={handleTimeTravelSnapshot}
                  style={{ display:'flex', alignItems:'center', gap:5, padding:'6px 12px', borderRadius:8, background:'rgba(245,158,11,0.15)', border:'1px solid rgba(245,158,11,0.35)', color:'#f59e0b', fontSize:'0.72rem', fontWeight:700, cursor:'pointer', alignSelf:'flex-start' }}>
                  <Camera style={{width:11,height:11}}/> Force Snapshot from this hour
                </button>
              )}
            </div>
          )}

          {!leafletReady && (
            <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', background:'#060d1a', zIndex:999 }}>
              <div style={{ textAlign:'center' }}>
                <div style={{ width:44, height:44, border:'2px solid #facc15', borderTopColor:'transparent', borderRadius:'50%', margin:'0 auto 12px', animation:'spin 1s linear infinite' }} />
                <p style={{ color:'#475569', fontSize:'0.82rem' }}>Loading map…</p>
              </div>
            </div>
          )}

          <div className="map-risk-legend" style={{
  position:'absolute', bottom:16, left:16, zIndex:1000,
  background:'rgba(6,13,26,0.94)',
  border:'1px solid rgba(255,255,255,0.09)',
  borderRadius:16, padding:'14px 16px',
  backdropFilter:'blur(18px)',
  maxHeight:'calc(100% - 100px)', overflowY:'auto',
  minWidth:190,
  boxShadow:'0 8px 32px rgba(0,0,0,0.5)',
}}>
  {/* Strike age */}
  <p style={{ fontSize:'0.58rem', fontWeight:800, color:'#facc15', margin:'0 0 8px', letterSpacing:'0.12em', textTransform:'uppercase' }}>
    ⚡ Strike Age
  </p>
  {[
    { label:'5 min',  color:'#ffffff' },
    { label:'10 min', color:'#facc15' },
    { label: '30 min', color:'#f97316' },
    { label:'1 h',    color:'#ef4444' },
    { label:'6 h',    color:'#7f1d1d' },
    { label:'12 h',   color:'#7c3aed' },
    { label:'24 h',   color:'#4c1d95' },
  ].map(k => (
    <div key={k.label} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:5 }}>
      <svg width="12" height="12" viewBox="0 0 12 12">
        <rect x="5" y="1" width="2" height="10" rx="1" fill={k.color} opacity="0.9"/>
        <rect x="1" y="5" width="10" height="2" rx="1" fill={k.color} opacity="0.9"/>
      </svg>
      <span style={{ fontSize:'0.67rem', color:'#94a3b8' }}>{k.label}</span>
    </div>
  ))}

  {/* Divider */}
  <div style={{ height:1, background:'rgba(255,255,255,0.07)', margin:'10px 0' }} />

  {/* Density heat */}
  <p style={{ fontSize:'0.58rem', fontWeight:800, color:'#a78bfa', margin:'0 0 8px', letterSpacing:'0.12em', textTransform:'uppercase' }}>
    🔥 Strike Density
  </p>
  {[
    { color:'#4c1d95', label:'1+' },
    { color:'#7c3aed', label:'3+' },
    { color:'#facc15', label:'8+' },
    { color:'#f97316', label:'20+' },
    { color:'#ef4444', label:'50+' },
  ].map(k => (
    <div key={k.label} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:5 }}>
      <div style={{
        width:11, height:11, borderRadius:'50%',
        background:k.color, opacity:0.9,
        boxShadow:`0 0 6px ${k.color}88`,
      }}/>
      <span style={{ fontSize:'0.67rem', color:'#94a3b8' }}>{k.label} per cell</span>
    </div>
  ))}

  {/* Divider */}
  <div style={{ height:1, background:'rgba(255,255,255,0.07)', margin:'10px 0' }} />

  {/* Warnings */}
  <p style={{ fontSize:'0.58rem', fontWeight:800, color:'#f97316', margin:'0 0 8px', letterSpacing:'0.12em', textTransform:'uppercase' }}>
    ⚠ Warnings
  </p>
  {Object.entries(STORM_RISK).map(([key, r]) => (
    <div key={key} style={{ display:'flex', alignItems:'center', gap:8, marginBottom:5 }}>
      <div style={{
        width:10, height:10, borderRadius:3,
        background:r.color,
        boxShadow:`0 0 6px ${r.color}88`,
      }}/>
      <span style={{ fontSize:'0.67rem', color:'#94a3b8' }}>{r.label}</span>
    </div>
  ))}
</div>

          {activeLayers.includes('radar') && (
            <div style={{ position:'absolute', bottom:16, right:16, zIndex:1000, background:'rgba(6,13,26,0.92)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:13, padding:'11px 15px', backdropFilter:'blur(16px)' }}>
              <p style={{ fontSize:'0.6rem', fontWeight:700, color:'#475569', margin:'0 0 7px', letterSpacing:'0.1em', textTransform:'uppercase' }}>Rainfall Intensity</p>
              <div style={{ display:'flex', gap:1.5, borderRadius:5, overflow:'hidden', marginBottom:5 }}>
                {RAINVIEWER_COLORS.map((c,i) => (<div key={i} style={{ flex:1, height:9, background:c }} />))}
              </div>
              <div style={{ display:'flex', justifyContent:'space-between' }}>
                <span style={{ fontSize:'0.6rem', color:'#64748b', fontFamily:'monospace' }}>Light</span>
                <span style={{ fontSize:'0.6rem', color:'#64748b', fontFamily:'monospace' }}>Heavy</span>
              </div>
            </div>
          )}
        </div>

               <AnimatePresence>
  {stormPolys.length > 0 && (() => {
    const regionFiltered = stormPolys.filter(p =>
      warningInRegion(p, view === 'europe' ? 'europe' : 'uk')
    );
    const countryFiltered = warningRegionFilter === 'all'
      ? regionFiltered
      : warningRegionFilter === 'uk'
        ? regionFiltered.filter(p => inBounds(p.centroid.lat, p.centroid.lon, 'uk'))
        : regionFiltered.filter(p => !inBounds(p.centroid.lat, p.centroid.lon, 'uk'));
    const CARDS_PER_ROW = Math.max(2, Math.floor((window.innerWidth - 48) / 302));
    const TWO_ROWS = CARDS_PER_ROW * 2;
    const visible = warningsExpanded ? countryFiltered : countryFiltered.slice(0, TWO_ROWS);
    const hasMore = countryFiltered.length > TWO_ROWS;
    return (
      <motion.div initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} exit={{ opacity:0,y:10 }}
        style={{ marginTop:14 }}>
        {/* Filter + count bar */}
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:10, flexWrap:'wrap' }}>
          <span style={{ fontSize:'0.7rem', fontWeight:700, color:'#64748b', letterSpacing:'0.08em', textTransform:'uppercase' }}>
            {countryFiltered.length} Warning{countryFiltered.length !== 1 ? 's' : ''}
          </span>
          <div style={{ display:'flex', gap:5 }}>
            {[
              { id:'all', label:'All' },
              { id:'uk',  label:'🇬🇧 UK' },
              { id:'eu',  label:'🌍 Europe' },
            ].map(({ id, label }) => (
              <button key={id} onClick={() => setWarningRegionFilter(id)}
                style={{
                  padding:'4px 10px', borderRadius:7, fontSize:'0.67rem', fontWeight:700,
                  cursor:'pointer', transition:'all 0.2s',
                  background: warningRegionFilter === id ? 'rgba(249,115,22,0.18)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${warningRegionFilter === id ? '#f97316' : 'rgba(255,255,255,0.09)'}`,
                  color: warningRegionFilter === id ? '#f97316' : '#475569',
                }}>
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Warning cards grid */}
        <div className="tcm-warning-cards" style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:10 }}>
          {visible.map(poly => {
            const cfg = STORM_RISK[poly.risk];
            const rgb = hexToRgb(cfg.color);
            const flashing = isFlashing[poly.id];
            const expiresIn = Math.max(0, Math.round((poly.expiresAt - Date.now()) / 60000));

            const handleCardClick = () => {
              if (mapInst.current) {
                try { mapInst.current.flyTo([poly.centroid.lat, poly.centroid.lon], 9, { animate:true, duration:1.4 }); } catch(_){}
              }
              const entry = stormPolygonMap.current[poly.id];
              if (entry?.core) {
                let fc = 0;
                const fi = setInterval(() => {
                  try { entry.core.setStyle({ weight: fc%2===0?6:2.5, fillOpacity: fc%2===0?0.55:0.22 }); } catch(_){}
                  if (++fc > 14) clearInterval(fi);
                }, 220);
              }
              setIsFlashing(prev => ({ ...prev, [poly.id]: true }));
              setTimeout(() => setIsFlashing(prev => { const n={...prev}; delete n[poly.id]; return n; }), 3200);
              setSelectedStorm(poly);
            };

            return (
              <motion.button
                key={poly.id}
                onClick={handleCardClick}
                whileHover={{ y:-2, scale:1.01 }}
                whileTap={{ scale:0.99 }}
                style={{
                  position:'relative', display:'flex', alignItems:'stretch', gap:0,
                  padding:0, borderRadius:16, textAlign:'left',
                  background:`linear-gradient(135deg, rgba(${rgb},0.18) 0%, rgba(${rgb},0.06) 60%, rgba(6,13,26,0.85) 100%)`,
                  border:`1.5px solid ${flashing ? cfg.color : `rgba(${rgb},0.45)`}`,
                  cursor:'pointer',
                  animation: flashing ? 'stormPulse 0.5s ease infinite' : 'none',
                  transition:'all 0.25s ease',
                  width:'100%', overflow:'hidden',
                  boxShadow: flashing ? `0 0 24px rgba(${rgb},0.5)` : `0 4px 16px rgba(0,0,0,0.4)`,
                }}
              >
                <div style={{ width:5, background:`linear-gradient(180deg, ${cfg.color}, rgba(${rgb},0.4))`, flexShrink:0 }} />
                <div style={{ flex:1, padding:'12px 14px', display:'flex', alignItems:'center', gap:11, minWidth:0 }}>
                  <div style={{
                    width:40, height:40, borderRadius:11, flexShrink:0,
                    background:`radial-gradient(circle, rgba(${rgb},0.35), rgba(${rgb},0.08))`,
                    border:`1px solid rgba(${rgb},0.5)`,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    boxShadow:`inset 0 0 12px rgba(${rgb},0.25)`,
                  }}>
                    <AlertTriangle style={{ width:20, height:20, color:cfg.color, filter:`drop-shadow(0 0 4px ${cfg.color})` }} />
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ margin:0, fontSize:'0.82rem', fontWeight:800, color:cfg.color, letterSpacing:'-0.01em', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
                      {cfg.fullLabel}
                    </p>
                    <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:3, flexWrap:'wrap' }}>
                      <span style={{ display:'inline-flex', alignItems:'center', gap:3, padding:'2px 7px', borderRadius:5, background:`rgba(${rgb},0.18)`, fontSize:'0.67rem', fontWeight:700, color:cfg.color, fontFamily:'monospace' }}>
                        ⚡ {poly.count}
                      </span>
                      <span style={{ fontSize:'0.63rem', color:'#94a3b8', fontWeight:600 }}>{poly.recentCount || 0} in 10m</span>
                      <span style={{ fontSize:'0.63rem', color:'#64748b' }}>· {expiresIn}m left</span>
                    </div>
                    <p style={{ margin:'4px 0 0', fontSize:'0.68rem', color:'#cbd5e1', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
                      📍 {poly.locationLabel}
                    </p>
                  </div>
                  <ChevronRight style={{ width:14, height:14, color:cfg.color, flexShrink:0, opacity:0.7 }}/>
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* See more / less */}
        {hasMore && (
          <button onClick={() => setWarningsExpanded(v => !v)}
            style={{
              display:'flex', alignItems:'center', gap:6, margin:'10px auto 0',
              padding:'8px 20px', borderRadius:10,
              background:'rgba(249,115,22,0.08)', border:'1px solid rgba(249,115,22,0.25)',
              color:'#f97316', fontSize:'0.74rem', fontWeight:700, cursor:'pointer',
            }}>
            {warningsExpanded
              ? <><ChevronUp style={{width:13,height:13}}/> Show less</>
              : <><ChevronDown style={{width:13,height:13}}/> See {countryFiltered.length - TWO_ROWS} more warnings</>
            }
          </button>
        )}
      </motion.div>
    );
  })()}
</AnimatePresence>
     
      {newStormAlert && (
        <div className="alert-banner" style={{ position:'fixed', top:80, right:20, zIndex:9999, width:340, padding:'14px 16px', borderRadius:15, background:'rgba(6,13,26,0.97)', border:`1px solid ${STORM_RISK[newStormAlert.risk].color}55`, backdropFilter:'blur(18px)', display:'flex', alignItems:'flex-start', gap:12 }}>
          <div style={{ width:38, height:38, borderRadius:11, flexShrink:0, background:`rgba(${hexToRgb(STORM_RISK[newStormAlert.risk].color)},0.18)`, display:'flex', alignItems:'center', justifyContent:'center', animation:'stormPulse 0.5s ease infinite' }}>
            <AlertTriangle style={{width:19,height:19,color:STORM_RISK[newStormAlert.risk].color}}/>
          </div>
          <div>
            <p style={{ margin:0, fontSize:'0.82rem', fontWeight:700, color:'#f1f5f9', marginBottom:3 }}>⚡ Thunderstorm Detected</p>
            <p style={{ margin:0, fontSize:'0.74rem', color:'#94a3b8' }}>{STORM_RISK[newStormAlert.risk].fullLabel} · {newStormAlert.count} strikes</p>
            <p style={{ margin:0, fontSize:'0.68rem', color:'#94a3b8', marginTop:2 }}>📍 {nearestCity(newStormAlert.centroid.lat, newStormAlert.centroid.lon)}</p>
          </div>
        </div>
      )}

    </motion.div>
    </>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION DIVIDER
   ═══════════════════════════════════════════════════════════════ */
function SectionDivider({ label, lightMode = false }) {
  return (
    <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ duration:0.5 }}
      className="mx-auto max-w-6xl px-6 mb-10" style={{ display:'flex', alignItems:'center', gap:16 }}>
      <div style={{ flex:1, height:1, background: lightMode?'linear-gradient(to right,transparent,rgba(0,0,0,0.1))':'linear-gradient(to right,transparent,rgba(255,255,255,0.07))' }} />
      <span style={{ fontSize:'0.68rem', fontWeight:700, letterSpacing:'0.14em', color: lightMode?'rgba(71,85,105,0.6)':'rgba(148,163,184,0.35)', textTransform:'uppercase', padding:'4px 14px', borderRadius:20, border:`1px solid ${lightMode?'rgba(0,0,0,0.1)':'rgba(255,255,255,0.06)'}`, background: lightMode?'rgba(0,0,0,0.04)':'rgba(255,255,255,0.02)', whiteSpace:'nowrap' }}>{label}</span>
      <div style={{ flex:1, height:1, background: lightMode?'linear-gradient(to left,transparent,rgba(0,0,0,0.1))':'linear-gradient(to left,transparent,rgba(255,255,255,0.07))' }} />
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ROOT PAGE
   ═══════════════════════════════════════════════════════════════ */
export default function TCM() {
  const queryClient = useQueryClient();
  const [archive, setArchive] = useState(loadArchive);

  const { data: outlooks = [], isLoading } = useQuery({
    queryKey: ['tcmOutlooks'],
    queryFn:  () => db.entities.TCMOutlook.list('-outlook_date'),
  });
  const { data: userMe } = useQuery({
    queryKey: ['me'],
    queryFn:  () => db.auth.me().catch(() => null),
  });
  const { data: settingsList = [] } = useQuery({
    queryKey: ['settings'],
    queryFn:  () => db.entities.SiteSettings.list(),
  });

  const tcmLogoUrl = settingsList[0]?.tcm_logo_url || null;
  const isAdmin    = userMe?.role === 'admin';
  const [region, setRegion] = useState(() => localStorage.getItem('tcm_region') || 'uk');
  const isEurope = region === 'europe';
  const isUSA    = region === 'usa';
  const [lightMode, setLightMode] = useState(() => localStorage.getItem('tcm_light_mode') === 'true');

  // Forced snapshots — combine SNAPSHOT_KEY + archive entries with isForced
  const [forcedSnaps, setForcedSnaps] = useState(() => loadSnapshots());
  useEffect(() => {
    const sync = () => setForcedSnaps(loadSnapshots());
    window.addEventListener('storage', sync);
    const iv = setInterval(sync, 5000);
    return () => { window.removeEventListener('storage', sync); clearInterval(iv); };
  }, []);

  const toggleLightMode = () => setLightMode(v => {
    const next = !v;
    localStorage.setItem('tcm_light_mode', String(next));
    return next;
  });
  const setRegionAndSave = (r) => { setRegion(r); localStorage.setItem('tcm_region', r); };

  useAutoArchive(outlooks, queryClient);
  const visibleOutlooks = outlooks.filter(o => !o.is_upcoming && !o.is_archived);

  const combinedForced = [
    ...forcedSnaps,
    ...archive.filter(a => a.isForced).map(a => ({
      capturedAt: a.capturedAt,
      strikes: a.strikes,
      stormWarnings: a.stormWarnings || [],
      isForced: true,
    })),
  ];

  const pageBg = lightMode
    ? 'linear-gradient(160deg, #e8edf5, #ffffff)'
    : 'linear-gradient(160deg, #0a0f1e, #1a1040)';

  return (
    <div className="min-h-screen" style={{ background: pageBg, backgroundColor: '#0a0f1e', transition: 'background 0.6s ease' }}>
      <TCMHamburger isAdmin={isAdmin} tcmLogoUrl={tcmLogoUrl} isEurope={isEurope} isUSA={isUSA} lightMode={lightMode} onToggleLightMode={toggleLightMode} />

      <div className="fixed top-4 right-4 z-50 flex" style={{ borderRadius:12, overflow:'hidden', border:`1px solid ${lightMode?'rgba(0,0,0,0.12)':'rgba(255,255,255,0.1)'}`, background: lightMode?'rgba(240,244,248,0.9)':'rgba(15,23,42,0.85)', backdropFilter:'blur(12px)' }}>
        {[{id:'uk',label:'🇬🇧 UK'},{id:'europe',label:'🌍 Europe'}].map(({id,label})=>(
          <button key={id} onClick={() => setRegionAndSave(id)}
            style={{ padding:'7px 14px', fontSize:'0.72rem', fontWeight:700, color:region===id?'#0a0f1e':'#64748b', background:region===id?'linear-gradient(135deg,#a78bfa,#38bdf8)':'transparent', border:'none', cursor:'pointer', transition:'all 0.2s' }}>
            {label}
          </button>
        ))}
      </div>

      <div className="pt-24" />
      <div id="tcm-main-content" style={{ transition: 'filter 0.3s ease' }}>
      <div id="tcm-title-block" style={{ position:'fixed', top:16, left:76, zIndex:9998 }}>
        <style>{`@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@800;900&display=swap');`}</style>
        <motion.div initial={{ opacity:0, y:-8 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.5 }} style={{ display:'flex', alignItems:'center', gap:14 }}>
          {tcmLogoUrl && <img src={tcmLogoUrl} alt="TCM" style={{ height:52, width:'auto', objectFit:'contain' }} />}
          <div style={{ display:'flex', flexDirection:'column', gap:2 }}>
            <span style={{ fontFamily:"'Orbitron',sans-serif", fontWeight:900, fontSize:'2rem', letterSpacing:'0.2em', background:'linear-gradient(135deg,#a78bfa 0%,#818cf8 25%,#38bdf8 60%,#34d399 100%)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text', lineHeight:1 }}>TCM</span>
            {isEurope && <span style={{ fontFamily:"'Orbitron',sans-serif", fontWeight:900, fontSize:'0.85rem', letterSpacing:'0.15em', background:'linear-gradient(135deg,#a78bfa,#38bdf8)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text', lineHeight:1 }}>Europe</span>}
            <span style={{ fontFamily:"'Orbitron',sans-serif", fontWeight:800, fontSize:'0.5rem', letterSpacing:'0.18em', background:'linear-gradient(135deg,#a78bfa,#38bdf8)', WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent', backgroundClip:'text', lineHeight:1 }}>V2.0</span>
          </div>
        </motion.div>
      </div>

      {isUSA ? (
        <motion.div key="usa" initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.5 }} className="mx-auto max-w-3xl">
          <USAMonitor isAdmin={isAdmin} lightMode={lightMode} />
        </motion.div>
      ) : (
        <>
          {(isLoading || visibleOutlooks.length > 0) && (
            <>
              <SectionDivider label="Published Outlooks" lightMode={lightMode} />
              {isLoading
                ? <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
                : <TCMSection outlooks={visibleOutlooks} isOwner={isAdmin} />
              }
            </>
          )}

          <SectionDivider label="Live Lightning, Storm Tracker & Risk Outlook" lightMode={lightMode} />
          <LightningMap region={region} isAdmin={isAdmin} archive={archive} setArchive={setArchive} />

          <SectionDivider label="Historical Lightning Activity" lightMode={lightMode} />
          <HistoricalLightningPanel
            lightMode={lightMode}
            archive={archive}
            forcedSnapshots={combinedForced}
          />
        </>
      )}
    </div>
    </div>
  );
}