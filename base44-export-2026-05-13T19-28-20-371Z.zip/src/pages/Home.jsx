const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useCallback } from 'react';

import { useQuery } from '@tanstack/react-query';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import {
  AlertTriangle, CloudSun, RefreshCw, Loader2,
  ExternalLink, Clock, Eye, EyeOff, Sun, Moon } from
'lucide-react';
import { Button } from "@/components/ui/button";
import WarningCard from '@/components/WarningCard';
import SocialLinks from '@/components/SocialLinks';
import ForecastSection from '@/components/ForecastSection';
import CombinedBannerStack from '@/components/CombinedBannerStack';
import SeverityFilter from '@/components/SeverityFilter';
import SectionNavigation from '@/components/SectionNavigation';
import PastWarningsModal from '@/components/PastWarningsModal';
import CountdownDisplay from '@/components/CountdownDisplay';
import WindyRadarEmbed from '@/components/WindyRadarEmbed';
import CookieConsent from '@/components/CookieConsent';
import { usePullToRefresh } from '@/hooks/usePullToRefresh';

// ─── Theme CSS injection ──────────────────────────────────────────────────────
const THEME_STYLES = `
  :root {
    /* Shared */
    --sky: #0ea5e9;
    --sky-dim: rgba(14,165,233,0.15);
    --sky-border: rgba(14,165,233,0.25);
    --amber: #f59e0b;
    --amber-dim: rgba(245,158,11,0.15);
    --blue: #3b82f6;
    --blue-dim: rgba(59,130,246,0.12);

    /* Dark (default) */
    --bg-base:      #0b1220;
    --bg-mid:       #0f1a2e;
    --bg-surface:   rgba(255,255,255,0.04);
    --bg-card:      rgba(255,255,255,0.05);
    --bg-card-hover:rgba(255,255,255,0.08);
    --bg-pill:      rgba(255,255,255,0.08);

    --border:       rgba(255,255,255,0.07);
    --border-hover: rgba(14,165,233,0.4);

    --text-primary:   #f1f5f9;
    --text-secondary: #94a3b8;
    --text-muted:     rgba(148,163,184,0.45);
    --text-link:      #38bdf8;

    --section-icon-bg:  rgba(14,165,233,0.1);
    --divider:          rgba(255,255,255,0.06);
    --hero-glow-a:      rgba(14,165,233,0.12);
    --hero-glow-b:      rgba(99,102,241,0.08);
    --particle-color:   rgba(255,255,255,0.04);
    --refresh-bg:       rgba(15,26,46,0.95);
    --empty-bg:         rgba(255,255,255,0.03);
    --empty-border:     rgba(255,255,255,0.07);
    --hidden-bg:        rgba(255,255,255,0.02);
    --hidden-border:    rgba(148,163,184,0.15);
    --footer-border:    rgba(255,255,255,0.06);

    --gradient-hero:    linear-gradient(135deg, #0b1220 0%, #0f1a2e 50%, #0c1a30 100%);
    --gradient-hero-overlay: linear-gradient(to bottom, transparent 0%, #0b1220 100%);
    --gradient-title:   linear-gradient(135deg, #f1f5f9 0%, #bae6fd 50%, #cbd5e1 100%);

    --toggle-bg:        rgba(255,255,255,0.07);
    --toggle-border:    rgba(255,255,255,0.12);
  }

  .light-mode {
    --bg-base:      #f0f6ff;
    --bg-mid:       #e8f2ff;
    --bg-surface:   rgba(255,255,255,0.7);
    --bg-card:      rgba(255,255,255,0.85);
    --bg-card-hover:rgba(255,255,255,1);
    --bg-pill:      rgba(14,165,233,0.08);

    --border:       rgba(14,165,233,0.15);
    --border-hover: rgba(14,165,233,0.5);

    --text-primary:   #0f172a;
    --text-secondary: #334155;
    --text-muted:     rgba(51,65,85,0.5);
    --text-link:      #0284c7;

    --section-icon-bg:  rgba(14,165,233,0.12);
    --divider:          rgba(14,165,233,0.1);
    --hero-glow-a:      rgba(14,165,233,0.2);
    --hero-glow-b:      rgba(99,102,241,0.1);
    --particle-color:   rgba(14,165,233,0.06);
    --refresh-bg:       rgba(240,246,255,0.97);
    --empty-bg:         rgba(255,255,255,0.6);
    --empty-border:     rgba(14,165,233,0.15);
    --hidden-bg:        rgba(255,255,255,0.5);
    --hidden-border:    rgba(14,165,233,0.2);
    --footer-border:    rgba(14,165,233,0.12);

    --gradient-hero:    linear-gradient(135deg, #dbeafe 0%, #eff6ff 50%, #e0f2fe 100%);
    --gradient-hero-overlay: linear-gradient(to bottom, transparent 0%, #f0f6ff 100%);
    --gradient-title:   linear-gradient(135deg, #0f172a 0%, #0369a1 50%, #1e3a5f 100%);

    --toggle-bg:        rgba(14,165,233,0.08);
    --toggle-border:    rgba(14,165,233,0.2);
  }
`;

function injectThemeStyles() {
  if (document.getElementById('home-theme-vars')) return;
  const el = document.createElement('style');
  el.id = 'home-theme-vars';
  el.textContent = THEME_STYLES;
  document.head.appendChild(el);
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function classifyWarnings(allWarnings) {
  const now = new Date();
  const active = [],upcoming = [],past = [];
  for (const w of allWarnings) {
    const from = w.validFrom ? new Date(w.validFrom) : null;
    const to = w.validTo ? new Date(w.validTo) : null;
    if (to && to < now) past.push(w);else
    if (from && from > now) upcoming.push(w);else
    active.push(w);
  }
  return { active, upcoming, past };
}

function getNextHourTime() {
  const next = new Date();
  next.setHours(next.getHours() + 1, 0, 0, 0);
  return next;
}

function normaliseManualWarning(w) {
  return {
    ...w,
    validFrom: w.valid_from ?? null,
    validTo: w.valid_to ?? null,
    affectedAreas: w.areas ?? [],
    isManual: true
  };
}

function classifyManualWarnings(warnings, now) {
  const active = [],upcoming = [],past = [];
  for (const w of warnings) {
    const from = w.validFrom ? new Date(w.validFrom) : null;
    const to = w.validTo ? new Date(w.validTo) : null;
    if (to && to <= now) past.push(w);else
    if (from && from > now) upcoming.push(w);else
    active.push(w);
  }
  return { active, upcoming, past };
}

// ─── Theme toggle ─────────────────────────────────────────────────────────────

function ThemeToggle({ isDark, onToggle }) {
  return null;

}

// ─── Particles ────────────────────────────────────────────────────────────────

const particleData = Array.from({ length: 16 }, (_, i) => ({
  id: i,
  x: Math.random() * 100,
  y: Math.random() * 100,
  size: Math.random() * 50 + 12,
  duration: Math.random() * 6 + 5,
  delay: Math.random() * 4
}));

function Particle({ x, y, size, duration, delay }) {
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        left: `${x}%`, top: `${y}%`,
        width: size, height: size,
        background: 'var(--particle-color)'
      }}
      animate={{ y: [0, -28, 0], opacity: [0.4, 0.8, 0.4], scale: [1, 1.15, 1] }}
      transition={{ duration, delay, repeat: Infinity, ease: 'easeInOut' }} />);

}

// ─── Section header ──────────────────────────────────────────────────────────

function SectionHeader({ icon: Icon, iconColor, title, subtitle, mobileSubtitle, mobileTitleRight, children }) {
  return (
    <motion.div
      className="flex items-center justify-between mb-8"
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}>
      
      <div className="flex items-center gap-3">
        <motion.div
          className="p-3 rounded-2xl backdrop-blur-sm"
          style={{ background: 'var(--section-icon-bg)', border: '1px solid var(--border)' }}
          whileHover={{ scale: 1.1, rotate: 5 }}
          transition={{ type: 'spring', stiffness: 300 }}>
          
          <Icon className={`w-6 h-6 ${iconColor}`} />
        </motion.div>
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>{title}</h2>
            {mobileTitleRight && <div className="sm:hidden">{mobileTitleRight}</div>}
          </div>
          {subtitle &&
          <p className="hidden sm:block text-sm mt-0.5" style={{ color: 'var(--text-secondary)' }}>{subtitle}</p>
          }
          {(subtitle || mobileSubtitle) &&
          <div className="sm:hidden">
              {subtitle && <p className="text-sm mt-0.5" style={{ color: 'var(--text-secondary)' }}>{subtitle}</p>}
              {mobileSubtitle &&
            <p className="text-xs mt-0.5 flex items-center gap-1" style={{ color: 'var(--text-muted)' }}>
                  <Clock className="w-3 h-3" />{mobileSubtitle}
                </p>
            }
            </div>
          }
        </div>
      </div>
      {children}
    </motion.div>);

}

// ─── Visibility toggle ────────────────────────────────────────────────────────

function SectionVisibilityToggle({ sectionName, isOwner, isHidden, onToggle }) {
  if (!isOwner) return null;
  return (
    <motion.button
      whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
      onClick={() => onToggle(sectionName)}
      title={isHidden ? 'Show section' : 'Hide section'}
      className={`p-2 rounded-lg transition-colors ${
      isHidden ?
      'bg-red-500/20 text-red-400 hover:bg-red-500/30' :
      'text-slate-400 hover:text-slate-200'}`
      }
      style={isHidden ? {} : { background: 'var(--bg-surface)', border: '1px solid var(--border)' }}>
      
      {isHidden ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
    </motion.button>);

}

// ─── Hidden placeholder ───────────────────────────────────────────────────────

function HiddenPlaceholder({ label, sectionName, isOwner, isHidden, onToggle }) {
  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }}
      className="max-w-6xl mx-auto px-4 py-4">
      
      <div
        className="flex items-center justify-between rounded-2xl px-5 py-4"
        style={{ background: 'var(--hidden-bg)', border: '1.5px dashed var(--hidden-border)' }}>
        
        <span style={{ color: 'var(--text-secondary)' }}>{label}</span>
        <SectionVisibilityToggle sectionName={sectionName} isOwner={isOwner} isHidden={isHidden} onToggle={onToggle} />
      </div>
    </motion.div>);

}

// ─── Divider ──────────────────────────────────────────────────────────────────

function Divider() {
  return (
    <motion.div
      className="max-w-6xl mx-auto px-4"
      initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }}
      viewport={{ once: true }} transition={{ duration: 0.8 }}>
      
      <div className="h-px" style={{ background: `linear-gradient(to right, transparent, var(--divider) 30%, var(--border) 50%, var(--divider) 70%, transparent)` }} />
    </motion.div>);

}

// ─── Empty state ──────────────────────────────────────────────────────────────

function EmptyState({ icon: Icon, iconColor, title, body }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="text-center py-20 rounded-3xl backdrop-blur-sm"
      style={{ background: 'var(--empty-bg)', border: '1px solid var(--empty-border)' }}>
      
      <motion.div animate={{ y: [0, -8, 0] }} transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}>
        <Icon className={`w-16 h-16 ${iconColor} mx-auto mb-4`} />
      </motion.div>
      <h3 className="text-xl font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>{title}</h3>
      <p style={{ color: 'var(--text-secondary)' }}>{body}</p>
    </motion.div>);

}

// ─── Loading spinner ──────────────────────────────────────────────────────────

function LoadingSpinner({ label }) {
  return (
    <motion.div
      key="loading"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center py-20 gap-4"
      style={{ color: 'var(--text-secondary)' }}>
      
      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}>
        <Loader2 className="w-10 h-10" />
      </motion.div>
      {label &&
      <motion.p animate={{ opacity: [0.5, 1, 0.5] }} transition={{ duration: 2, repeat: Infinity }}>
          {label}
        </motion.p>
      }
    </motion.div>);

}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function Home() {
  // ── Theme ──
  const [isDark, setIsDark] = useState(() => {
    try {return localStorage.getItem('theme') !== 'light';}
    catch {return true;}
  });

  useEffect(() => {
    injectThemeStyles();
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.remove('light-mode');
    } else {
      root.classList.add('light-mode');
    }
    try {localStorage.setItem('theme', isDark ? 'dark' : 'light');}
    catch {}
  }, [isDark]);

  // ── Met Office warnings ──
  const [warnings, setWarnings] = useState([]);
  const [upcomingWarnings, setUpcomingWarnings] = useState([]);
  const [pastWarnings, setPastWarnings] = useState([]);
  const [allWarnings, setAllWarnings] = useState([]);
  const [loadingWarnings, setLoadingWarnings] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [nextUpdate, setNextUpdate] = useState(null);
  const [timeUntilUpdate, setTimeUntilUpdate] = useState('');

  // ── UI ──
  const [isOwner, setIsOwner] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [severityFilter, setSeverityFilter] = useState(null);
  const [showPastWarnings, setShowPastWarnings] = useState(false);
  const [showBanners, setShowBanners] = useState(false);
  const [cookieConsentReady, setCookieConsentReady] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [scrollDirection, setScrollDirection] = useState('down');

  const [hiddenSections, setHiddenSections] = useState(() => {
    try {const s = localStorage.getItem('hiddenSections');return s ? JSON.parse(s) : {};}
    catch {return {};}
  });

  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);

  const toggleSectionVisibility = (name) => {
    setHiddenSections((prev) => {
      const updated = { ...prev, [name]: !prev[name] };
      localStorage.setItem('hiddenSections', JSON.stringify(updated));
      return updated;
    });
  };

  // ── Scroll direction ──
  useEffect(() => {
    const handle = () => {
      const cur = window.scrollY;
      setScrollDirection(cur > lastScrollY ? 'down' : 'up');
      setLastScrollY(cur);
    };
    window.addEventListener('scroll', handle);
    return () => window.removeEventListener('scroll', handle);
  }, [lastScrollY]);

  const { scrollY } = useScroll();
  const heroOpacity = useTransform(scrollY, [0, 300], [1, 0]);
  const heroScale = useTransform(scrollY, [0, 300], [1, 0.95]);
  const heroY = useTransform(scrollY, [0, 300], [0, 50]);

  // ── Auth bootstrap ──
  useEffect(() => {
    db.auth.me().
    then((user) => {setIsOwner(user?.role === 'admin');setUserRole(user?.role);}).
    catch(() => setIsOwner(false));
    localStorage.removeItem('warnings_cache');
    localStorage.removeItem('upcoming_warnings_cache');
    localStorage.removeItem('warnings_last_fetch_hour');
    const shownThisSession = sessionStorage.getItem('bannersShown');
    if (!shownThisSession) {
      setShowBanners(true);
      sessionStorage.setItem('bannersShown', 'true');
    } else {
      if (!localStorage.getItem('cookie_consent')) setCookieConsentReady(true);
    }
  }, []);

  useEffect(() => {
    if (document.querySelector('script[src="https://elfsightcdn.com/platform.js"]')) return;
    const s = document.createElement('script');
    s.src = 'https://elfsightcdn.com/platform.js';
    s.async = true;
    document.head.appendChild(s);
  }, []);

  useEffect(() => {
    if (!nextUpdate) return;
    const tick = setInterval(() => {
      const diff = nextUpdate - new Date();
      if (diff <= 0) {
        setTimeUntilUpdate('Updating...');
      } else {
        const mins = Math.floor(diff % (1000 * 3600) / 60000);
        const secs = Math.floor(diff % 60000 / 1000);
        setTimeUntilUpdate(`${nextUpdate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} (${mins}m ${secs}s)`);
      }
    }, 1000);
    return () => clearInterval(tick);
  }, [nextUpdate]);

  const loadWarningsFromDB = useCallback(async (retries = 2) => {
    setLoadingWarnings(true);
    try {
      const records = await db.entities.CachedWarnings.list();
      const record = records?.[0];
      if (record) {
        const all = Array.isArray(record.all_warnings) ? record.all_warnings : [];
        const { active, upcoming, past } = classifyWarnings(all);
        setWarnings(active);setUpcomingWarnings(upcoming);
        setPastWarnings(past);setAllWarnings(all);
        setLastUpdated(record.fetched_at ? new Date(record.fetched_at) : null);
      } else {
        setWarnings([]);setUpcomingWarnings([]);setPastWarnings([]);setAllWarnings([]);
      }
      setNextUpdate(getNextHourTime());
    } catch (error) {
      if (retries > 0) setTimeout(() => loadWarningsFromDB(retries - 1), 1500);else
      {console.error('Error loading warnings:', error);setWarnings([]);setUpcomingWarnings([]);}
    } finally {
      setLoadingWarnings(false);
    }
  }, []);

  const fetchWarnings = useCallback(async (retries = 2) => {
    setRefreshing(true);setLoadingWarnings(true);
    try {
      await db.functions.invoke('getMetOfficeWarnings', {});
      await loadWarningsFromDB();
    } catch (error) {
      if (retries > 0) setTimeout(() => fetchWarnings(retries - 1), 1500);else
      {console.error('Error fetching:', error);setLoadingWarnings(false);}
    } finally {
      setRefreshing(false);
    }
  }, [loadWarningsFromDB]);

  useEffect(() => {
    loadWarningsFromDB();
    const unsub = db.entities.CachedWarnings.subscribe((event) => {
      if (event.type === 'create' || event.type === 'update') {
        try {
          const all = Array.isArray(event.data?.all_warnings) ? event.data.all_warnings : [];
          const { active, upcoming, past } = classifyWarnings(all);
          setWarnings(active);setUpcomingWarnings(upcoming);
          setPastWarnings(past);setAllWarnings(all);
          setLastUpdated(event.data?.fetched_at ? new Date(event.data.fetched_at) : new Date());
          setNextUpdate(getNextHourTime());
        } catch (err) {console.error('Warning update error:', err);}
      }
    });
    return () => unsub();
  }, [loadWarningsFromDB]);

  const { isPulling, isRefreshing, onTouchStart, onTouchMove, onTouchEnd } =
  usePullToRefresh(loadWarningsFromDB);

  // ── Remote queries ──
  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {try {const l = await db.entities.SiteSettings.list();return l?.[0] || null;} catch {return null;}},
    refetchInterval: 5000, retry: 2, retryDelay: 1000
  });

  const { data: featuredGraphics = [] } = useQuery({
    queryKey: ['featuredGraphics'],
    queryFn: async () => {try {return (await db.entities.WeatherGraphic.filter({ is_featured: true, published: true }, '-created_date', 6)) || [];} catch {return [];}},
    retry: 2, retryDelay: 1000
  });

  const { data: forecasts = [] } = useQuery({
    queryKey: ['forecasts'],
    queryFn: async () => {try {return (await db.entities.WeatherGraphic.filter({ is_forecast: true }, '-created_date', 50)) || [];} catch {return [];}},
    initialData: [], retry: 2, retryDelay: 1000
  });

  const { data: announcements = [] } = useQuery({
    queryKey: ['announcements'],
    queryFn: async () => {try {return (await db.entities.Announcement.filter({ is_active: true }, '-created_date')) || [];} catch {return [];}},
    initialData: [], retry: 2, retryDelay: 1000
  });

  const { data: appUpdates = [] } = useQuery({
    queryKey: ['appUpdates'],
    queryFn: async () => {try {return (await db.entities.AppUpdate.filter({ is_published: true }, '-created_date')) || [];} catch {return [];}},
    initialData: [], retry: 2, retryDelay: 1000
  });

  const { data: publishedFeatures = [] } = useQuery({
    queryKey: ['publishedFeatures'],
    queryFn: async () => {try {return (await db.entities.PublishedFeatures.list()) || [];} catch {return [];}},
    initialData: [], retry: 2, retryDelay: 1000
  });

  const { data: rawManualWarnings = [] } = useQuery({
    queryKey: ['manualWarnings'],
    queryFn: async () => {try {return (await db.entities.ManualWarning.list('-valid_from')) || [];} catch {return [];}},
    refetchInterval: 30000, retry: 2, retryDelay: 1000
  });

  const normalisedManual = rawManualWarnings.filter((w) => w.is_published).map(normaliseManualWarning);
  const { active: manualActive, upcoming: manualUpcoming, past: manualPast } = classifyManualWarnings(normalisedManual, now);

  const mergedActive = [...warnings, ...manualActive];
  const mergedUpcoming = [...upcomingWarnings, ...manualUpcoming];
  const mergedPast = [...pastWarnings, ...manualPast];
  const mergedAll = [...allWarnings, ...normalisedManual];

  const filteredWarnings = severityFilter ? mergedActive.filter((w) => w.severity === severityFilter) : mergedActive;
  const filteredUpcoming = severityFilter ? mergedUpcoming.filter((w) => w.severity === severityFilter) : mergedUpcoming;
  const totalWarnings = mergedActive.length + mergedUpcoming.length;

  const isCountdownPublished = publishedFeatures.find((f) => f.feature_name === 'countdown')?.is_published ?? false;

  // ────────────────────────────────────────────────────────────────────────────

  return (
    <div
      className="min-h-screen scroll-smooth relative transition-colors duration-500"
      style={{ background: 'var(--bg-base)' }}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}>
      
      {/* Theme toggle */}
      <ThemeToggle isDark={isDark} onToggle={() => setIsDark((d) => !d)} />

      {/* Pull-to-refresh indicator */}
      {(isPulling || isRefreshing) &&
      <div
        className="fixed top-4 left-1/2 -translate-x-1/2 z-50 text-xs px-4 py-2 rounded-full flex items-center gap-2 shadow-lg"
        style={{
          background: 'var(--refresh-bg)',
          border: '1px solid var(--border)',
          color: 'var(--text-secondary)',
          backdropFilter: 'blur(12px)'
        }}>
        
          <Loader2 className="w-3 h-3 animate-spin" />
          {isRefreshing ? 'Refreshing...' : 'Release to refresh'}
        </div>
      }

      {/* Scroll-direction blur overlay */}
      <AnimatePresence mode="wait">
        {lastScrollY > 0 &&
        <motion.div
          key={scrollDirection}
          className={`fixed ${scrollDirection === 'down' ? 'top-0' : 'bottom-0'} left-0 right-0 h-20 pointer-events-none z-30`}
          style={{
            background: scrollDirection === 'down' ?
            `linear-gradient(to bottom, var(--bg-base), transparent)` :
            `linear-gradient(to top, var(--bg-base), transparent)`,
            opacity: 0.85
          }}
          initial={{ opacity: 0 }} animate={{ opacity: 0.85 }} exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }} />

        }
      </AnimatePresence>

      <CookieConsent triggerShow={cookieConsentReady} />
      <SectionNavigation />

      {showBanners &&
      <CombinedBannerStack
        announcements={announcements}
        updates={appUpdates}
        isRestricted={localStorage.getItem('site_access_granted') === 'true'}
        onAllDismissed={() => setCookieConsentReady(true)} />

      }

      {/* Version chip */}
      {settings?.version &&
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        className="fixed bottom-4 left-4 text-xs pointer-events-none"
        style={{ color: 'var(--text-muted)' }}>
        
          {settings.version}
        </motion.div>
      }

      {/* Countdown — homepage position */}
      {settings?.countdown_enabled && isCountdownPublished &&
      settings?.countdown_target && settings?.countdown_display === 'homepage' &&
      <CountdownDisplay
        target={settings.countdown_target}
        title={settings.countdown_title}
        description={settings.countdown_description} />

      }

      {/* ══ HERO ═══════════════════════════════════════════════════════════════ */}
      <header className="relative overflow-hidden min-h-[360px] flex items-center transition-colors duration-500" style={{ background: 'var(--gradient-hero)' }}>
        {particleData.map((p) => <Particle key={p.id} {...p} />)}

        {/* Glows */}
        <motion.div
          className="absolute top-10 left-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none"
          style={{ background: 'var(--hero-glow-a)' }}
          animate={{ scale: [1, 1.2, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }} />
        
        <motion.div
          className="absolute bottom-0 right-1/4 w-80 h-80 rounded-full blur-3xl pointer-events-none"
          style={{ background: 'var(--hero-glow-b)' }}
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.4, 0.7, 0.4] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 2 }} />
        

        {/* Banner image */}
        {settings?.banner_url &&
        <motion.div className="absolute inset-0 overflow-hidden" style={{ opacity: heroOpacity }}>
            <img src={settings.banner_url} alt="Banner" className="absolute inset-0 w-full h-full object-cover object-center" style={{ opacity: isDark ? 0.3 : 0.15 }} />
            <div className="absolute inset-0" style={{ background: 'var(--gradient-hero-overlay)' }} />
          </motion.div>
        }

        <motion.div
          className="relative w-full max-w-6xl mx-auto px-4 pt-0 pb-12 md:pb-20"
          style={{ opacity: heroOpacity, scale: heroScale, y: heroY }}>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] }}
            className="text-center">
            
            {settings?.logo_url &&
            <motion.img
              src={settings.logo_url} alt="Logo"
              className="h-20 md:h-28 mx-auto mb-6 object-contain drop-shadow-2xl"
              initial={{ opacity: 0, scale: 0.7, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.7, type: 'spring', stiffness: 120 }}
              whileHover={{ scale: 1.05, transition: { duration: 0.2 } }} />

            }

            <motion.h1
  className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent"
  style={{ 
    backgroundImage: 'var(--gradient-title)',
    lineHeight: '1.2',
    paddingBottom: '0.15em',
    overflow: 'visible',
    WebkitBoxDecorationBreak: 'clone',
    boxDecorationBreak: 'clone',
  }}
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}>
              
              {settings?.site_name || 'UK Weather Warnings'}
            </motion.h1>

            {settings?.description &&
            <motion.p
              className="text-lg md:text-xl max-w-2xl mx-auto mb-6"
              style={{ color: 'var(--text-secondary)' }}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}>
              
                {settings.description}
              </motion.p>
            }

            {/* Countdown inside hero */}
            {settings?.countdown_enabled && isCountdownPublished &&
            settings?.countdown_target && settings?.countdown_display === 'homepage' &&
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }} className="mb-8">
                <CountdownDisplay target={settings.countdown_target} title={settings.countdown_title} description={settings.countdown_description} />
              </motion.div>
            }

            {/* Live stats pill */}
            <AnimatePresence>
              {!loadingWarnings &&
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
                transition={{ delay: 0.6, duration: 0.4 }}
                className="inline-flex items-center gap-3 rounded-full px-5 py-2 mb-6 text-sm"
                style={{
                  background: 'var(--bg-pill)',
                  border: '1px solid var(--border)',
                  backdropFilter: 'blur(12px)',
                  color: 'var(--text-primary)'
                }}>
                
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-400" />
                  </span>
                  <span style={{ color: 'var(--text-secondary)' }}>
                    {totalWarnings === 0 ? 'No active warnings' : `${totalWarnings} warning${totalWarnings > 1 ? 's' : ''} in effect`}
                  </span>
                  {mergedActive.length > 0 &&
                <span className="bg-amber-500 text-slate-900 text-xs font-bold px-2 py-0.5 rounded-full">
                      {mergedActive.length} active
                    </span>
                }
                </motion.div>
              }
            </AnimatePresence>

            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
              <SocialLinks settings={settings} className="justify-center" />
            </motion.div>
          </motion.div>
        </motion.div>
      </header>

      {/* Elfsight placeholder */}
      <div className="max-w-6xl mx-auto px-4 py-8" />

      {/* ══ FORECASTS (top) ══════════════════════════════════════════════════ */}
      {forecasts.length > 0 &&
      <div id="forecasts">
          {!hiddenSections.forecasts ?
        <ForecastSection forecasts={forecasts} isOwner={isOwner} /> :
        isOwner && <HiddenPlaceholder label="Forecasts section is hidden from users" sectionName="forecasts" isOwner={isOwner} isHidden={hiddenSections.forecasts} onToggle={toggleSectionVisibility} />
        }
        </div>
      }

      {/* ══ ACTIVE WARNINGS ══════════════════════════════════════════════════ */}
      {!hiddenSections.activeWarnings ?
      <motion.section
        id="activeWarnings"
        className="max-w-6xl mx-auto px-4 py-12"
        initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-80px' }}
        transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}>
        
          <SectionHeader
          icon={AlertTriangle} iconColor="text-amber-400"
          title="Active Warnings"
          subtitle={lastUpdated ? `Updated ${lastUpdated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : undefined}
          mobileSubtitle={timeUntilUpdate ? `Next: ${timeUntilUpdate}` : undefined}
          mobileTitleRight={<SeverityFilter value={severityFilter} onChange={setSeverityFilter} />}>
          
            <div className="flex items-center gap-3">
              <div className="hidden sm:block">
                <SeverityFilter value={severityFilter} onChange={setSeverityFilter} />
              </div>
              {isOwner &&
            <>
                  <SectionVisibilityToggle sectionName="activeWarnings" isOwner={isOwner} isHidden={hiddenSections.activeWarnings} onToggle={toggleSectionVisibility} />
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                  variant="outline" size="sm"
                  onClick={fetchWarnings} disabled={loadingWarnings}
                  className="px-3 text-xs font-medium rounded-3xl gap-2 h-8 transition-all duration-300"
                  style={{
                    background: 'var(--bg-surface)',
                    border: '1px solid var(--border)',
                    color: 'var(--text-secondary)'
                  }}>
                  
                      <motion.div
                    animate={refreshing ? { rotate: 360 } : {}}
                    transition={{ duration: 0.8, repeat: refreshing ? Infinity : 0, ease: 'linear' }}>
                    
                        {loadingWarnings ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                      </motion.div>
                      <span className="hidden sm:inline">Refresh</span>
                    </Button>
                  </motion.div>
                </>
            }
            </div>
          </SectionHeader>

          <AnimatePresence mode="wait">
            {loadingWarnings ?
          <LoadingSpinner key="loading" label="Fetching latest Met Office warnings..." /> :
          filteredWarnings.length > 0 ?

          <motion.div key={`warnings-${severityFilter}`} className="grid md:grid-cols-2 gap-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    {filteredWarnings.map((warning, index) =>
            <div key={index} className="relative"><WarningCard warning={warning} index={index} /></div>
            )}
                  </motion.div> :

          <EmptyState
            key={`empty-${severityFilter}`}
            icon={CloudSun} iconColor="text-sky-400"
            title={severityFilter ? `No ${severityFilter} Warnings Currently` : 'No Active Warnings'}
            body={severityFilter ? `No ${severityFilter} warnings are currently in force.` : 'The Met Office has no weather warnings in force for the UK.'} />

          }
          </AnimatePresence>

          <motion.a
          href="https://www.metoffice.gov.uk/weather/warnings-and-advice/uk-warnings"
          target="_blank" rel="noopener noreferrer"
          whileHover={{ scale: 1.02 }}
          className="flex items-center justify-center gap-2 mt-8 text-sm transition-colors duration-200"
          style={{ color: 'var(--text-muted)' }}
          onMouseEnter={(e) => e.currentTarget.style.color = 'var(--text-link)'}
          onMouseLeave={(e) => e.currentTarget.style.color = 'var(--text-muted)'}>
          
            View official Met Office warnings <ExternalLink className="w-4 h-4" />
          </motion.a>
        </motion.section> :

      isOwner && <HiddenPlaceholder label="Active Warnings section is hidden from users" sectionName="activeWarnings" isOwner={isOwner} isHidden={hiddenSections.activeWarnings} onToggle={toggleSectionVisibility} />
      }

      <Divider />

      {/* ══ UPCOMING WARNINGS ════════════════════════════════════════════════ */}
      {!hiddenSections.upcomingWarnings ?
      <motion.section
        id="upcomingWarnings"
        className="max-w-6xl mx-auto px-4 py-12"
        initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }}
        viewport={{ margin: '-80px' }} transition={{ duration: 0.6 }}>
        
          <SectionHeader
          icon={({ className }) =>
          <div className="relative">
                <AlertTriangle className={className} />
                <Clock className="absolute -bottom-0.5 -right-0.5 w-3 h-3 text-blue-400 rounded-full p-0.5" style={{ background: 'var(--bg-base)' }} />
              </div>
          }
          iconColor="text-blue-400"
          title="Upcoming Warnings"
          subtitle="Issued but not yet in effect — prepare ahead of time">
          
            {isOwner && <SectionVisibilityToggle sectionName="upcomingWarnings" isOwner={isOwner} isHidden={hiddenSections.upcomingWarnings} onToggle={toggleSectionVisibility} />}
          </SectionHeader>

          <AnimatePresence mode="wait">
            {loadingWarnings ?
          <LoadingSpinner key="loading" /> :
          filteredUpcoming.length > 0 ?

          <motion.div key={`upcoming-${severityFilter}`} className="grid md:grid-cols-2 gap-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    {filteredUpcoming.map((warning, index) =>
            <div key={index} className="relative"><WarningCard warning={warning} index={index} isUpcoming={true} /></div>
            )}
                  </motion.div> :

          <EmptyState
            key={`empty-upcoming-${severityFilter}`}
            icon={CloudSun} iconColor="text-blue-400"
            title={severityFilter ? `No ${severityFilter} Warnings Upcoming` : 'No Upcoming Warnings'}
            body={severityFilter ? `No upcoming ${severityFilter} warnings issued.` : 'There are no upcoming weather warnings issued by the Met Office.'} />

          }
          </AnimatePresence>
        </motion.section> :

      isOwner && <HiddenPlaceholder label="Upcoming Warnings section is hidden from users" sectionName="upcomingWarnings" isOwner={isOwner} isHidden={hiddenSections.upcomingWarnings} onToggle={toggleSectionVisibility} />
      }

      {/* Past warnings button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }} transition={{ duration: 0.5 }}
        className="max-w-6xl mx-auto px-4 py-8">
        
        <div className="flex justify-center">
          <motion.button
            whileHover={{ scale: 1.04, boxShadow: '0 8px 32px rgba(14,165,233,0.2)' }}
            whileTap={{ scale: 0.96 }}
            onClick={() => setShowPastWarnings(true)}
            className="px-6 py-3 font-medium rounded-full select-none text-sm transition-all duration-300"
            style={{
              background: 'var(--bg-surface)',
              border: '1px solid var(--border)',
              color: 'var(--text-secondary)',
              backdropFilter: 'blur(8px)'
            }}
            onMouseEnter={(e) => {e.currentTarget.style.borderColor = 'var(--border-hover)';e.currentTarget.style.color = 'var(--text-link)';}}
            onMouseLeave={(e) => {e.currentTarget.style.borderColor = 'var(--border)';e.currentTarget.style.color = 'var(--text-secondary)';}}>
            
            View Past Weather Warnings
          </motion.button>
        </div>
      </motion.div>

      <Divider />

      {/* ══ LIVE RADAR ═══════════════════════════════════════════════════════ */}
      {!hiddenSections.liveRadar ?
      <motion.section
        id="liveRadar"
        className="max-w-6xl mx-auto px-4 py-12"
        initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-80px' }} transition={{ duration: 0.6 }}>
        
          <WindyRadarEmbed userRole={userRole} />
        </motion.section> :

      isOwner && <HiddenPlaceholder label="Live Radar section is hidden from users" sectionName="liveRadar" isOwner={isOwner} isHidden={hiddenSections.liveRadar} onToggle={toggleSectionVisibility} />
      }

      {/* ══ FORECASTS (bottom fallback) ══════════════════════════════════════ */}
      {forecasts.length === 0 &&
      <div id="forecasts">
          {!hiddenSections.forecasts ?
        <ForecastSection forecasts={forecasts} isOwner={isOwner} /> :
        isOwner && <HiddenPlaceholder label="Forecasts section is hidden from users" sectionName="forecasts" isOwner={isOwner} isHidden={hiddenSections.forecasts} onToggle={toggleSectionVisibility} />
        }
        </div>
      }

      {/* ══ FEATURED GRAPHICS ════════════════════════════════════════════════ */}
      {!hiddenSections.graphics && featuredGraphics?.length > 0 &&
      <motion.section
        id="graphics"
        className="max-w-6xl mx-auto px-4 py-12"
        initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-80px' }} transition={{ duration: 0.6 }}>
        
          <SectionHeader icon={CloudSun} iconColor="text-sky-400" title="Latest Graphics">
            {isOwner && <SectionVisibilityToggle sectionName="graphics" isOwner={isOwner} isHidden={hiddenSections.graphics} onToggle={toggleSectionVisibility} />}
          </SectionHeader>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredGraphics.map((graphic, index) =>
          <motion.div
            key={graphic.id}
            initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }} transition={{ delay: index * 0.1, duration: 0.5 }}
            whileHover={{ y: -6, scale: 1.02, transition: { duration: 0.25 } }}
            className="group relative rounded-3xl overflow-hidden cursor-pointer"
            style={{
              background: 'var(--bg-card)',
              border: '1px solid var(--border)',
              boxShadow: '0 4px 24px rgba(0,0,0,0.12)'
            }}>
            
                <img src={graphic.image_url} alt={graphic.title} className="w-full aspect-video object-cover group-hover:scale-110 transition-transform duration-700 ease-out" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <h3 className="font-semibold text-white text-lg">{graphic.title}</h3>
                  {graphic.description &&
              <p className="text-sm text-slate-300 mt-1 line-clamp-2 opacity-80">{graphic.description}</p>
              }
                </div>
              </motion.div>
          )}
          </div>
        </motion.section>
      }

      {isOwner && hiddenSections.graphics &&
      <HiddenPlaceholder label="Latest Graphics section is hidden from users" sectionName="graphics" isOwner={isOwner} isHidden={hiddenSections.graphics} onToggle={toggleSectionVisibility} />
      }

      {/* Past warnings modal */}
      <PastWarningsModal isOpen={showPastWarnings} onClose={() => setShowPastWarnings(false)} warnings={mergedAll} />

      {/* ══ FOOTER ═══════════════════════════════════════════════════════════ */}
      <motion.footer
        className="mt-12 transition-colors duration-500"
        style={{ borderTop: '1px solid var(--footer-border)' }}
        initial={{ opacity: 0 }} whileInView={{ opacity: 1 }}
        viewport={{ once: true }} transition={{ duration: 0.5 }}>
        
        <div className="max-w-6xl mx-auto px-4 py-8 text-center text-sm" style={{ color: 'var(--text-muted)' }}>
          <p>© {new Date().getFullYear()} {settings?.site_name || 'MyWeatherUK'}</p>
          <p className="mt-1 text-xs" style={{ color: 'var(--text-muted)', opacity: 0.6 }}>
            Weather data sourced from the Met Office
          </p>
        </div>
      </motion.footer>
    </div>);

}