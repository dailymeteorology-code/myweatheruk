const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { motion } from 'framer-motion';
import { Loader2, Trash2, User, Ruler } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useUnits } from '@/components/useUnits';

const UNIT_OPTIONS = [
  {
    key: 'temperature',
    label: 'Temperature',
    options: [{ value: 'celsius', label: '°C — Celsius' }, { value: 'fahrenheit', label: '°F — Fahrenheit' }],
  },
  {
    key: 'windSpeed',
    label: 'Wind Speed',
    options: [{ value: 'mph', label: 'mph' }, { value: 'kmh', label: 'km/h' }],
  },
  {
    key: 'precipitation',
    label: 'Rainfall / Snow',
    options: [{ value: 'mm', label: 'mm' }, { value: 'inches', label: 'inches' }],
  },
  {
    key: 'hail',
    label: 'Hail Diameter',
    options: [{ value: 'mm', label: 'mm' }, { value: 'inches', label: 'inches' }],
  },
];

export default function Settings() {
  const [user, setUser] = useState(null);
  const [deletingAccount, setDeletingAccount] = useState(false);
  const { units, updateUnit } = useUnits();

  useEffect(() => {
    db.auth.me().then(setUser).catch(() => {});
  }, []);

  const handleDeleteAccount = async () => {
    if (!window.confirm('Are you sure you want to delete your account? This cannot be undone.')) return;
    setDeletingAccount(true);
    const me = await db.auth.me();
    await db.entities.User.delete(me.id);
    db.auth.logout('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-sky-50">
      <div className="max-w-xl mx-auto px-4 py-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-800">Settings</h1>
            <p className="text-slate-500 mt-1">Manage your account</p>
          </div>

          {/* Account Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5 text-sky-600" />
                Your Account
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-slate-600">
              {user ? (
                <>
                  <p><span className="font-medium text-slate-800">Name:</span> {user.full_name || '—'}</p>
                  <p><span className="font-medium text-slate-800">Email:</span> {user.email}</p>
                  <p><span className="font-medium text-slate-800">Role:</span> {user.role}</p>
                </>
              ) : (
                <Loader2 className="w-5 h-5 animate-spin text-slate-400" />
              )}
            </CardContent>
          </Card>

          {/* Units of Measurement */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Ruler className="w-5 h-5 text-sky-600" />
                Units of Measurement
              </CardTitle>
              <CardDescription>Choose your preferred units — changes apply everywhere instantly</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {UNIT_OPTIONS.map(({ key, label, options }) => (
                <div key={key} className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-700">{label}</span>
                  <div className="flex rounded-lg border border-slate-200 overflow-hidden">
                    {options.map(opt => (
                      <button
                        key={opt.value}
                        onClick={() => updateUnit(key, opt.value)}
                        className={`px-3 py-1.5 text-xs font-semibold transition-colors ${
                          units[key] === opt.value
                            ? 'bg-sky-600 text-white'
                            : 'bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Danger Zone */}
          <Card className="border-red-200">
            <CardHeader>
              <CardTitle className="text-red-600 flex items-center gap-2">
                <Trash2 className="w-5 h-5" />
                Danger Zone
              </CardTitle>
              <CardDescription>Irreversible actions — proceed with caution</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                variant="destructive"
                className="select-none"
                onClick={handleDeleteAccount}
                disabled={deletingAccount}
              >
                {deletingAccount ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Trash2 className="w-4 h-4 mr-2" />}
                Delete My Account
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}