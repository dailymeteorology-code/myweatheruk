const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useCallback, useEffect } from "react";

import { useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Wind, Droplets, Eye, Gauge, Thermometer, Sun, ChevronDown, ChevronUp, ArrowLeft } from "lucide-react";
import { weatherIcons } from "@/components/WeatherIcons";
import { CloudyIcon } from "@/components/icons/CloudIcons";

const WEATHER_CODES = {
  0:  { desc: "Clear night",          icon: "clear night" },
  1:  { desc: "Sunny",                 icon: "sunny" },
  2:  { desc: "Partly cloudy",         icon: "partly cloudy" },
  3:  { desc: "Partly cloudy",         icon: "partly cloudy" },
  5:  { desc: "Mist",                  icon: "mist" },
  6:  { desc: "Fog",                   icon: "fog" },
  7:  { desc: "Cloudy",                icon: "cloudy" },
  8:  { desc: "Overcast",              icon: "overcast" },
  9:  { desc: "Light rain shower",     icon: "light rain shower" },
  10: { desc: "Light rain shower",     icon: "light rain shower" },
  11: { desc: "Drizzle",               icon: "drizzle" },
  12: { desc: "Light rain",            icon: "light rain" },
  13: { desc: "Heavy rain shower",     icon: "heavy rain shower" },
  14: { desc: "Heavy rain shower",     icon: "heavy rain shower" },
  15: { desc: "Heavy rain",            icon: "heavy rain" },
  16: { desc: "Sleet shower",          icon: "sleet" },
  17: { desc: "Sleet shower",          icon: "sleet" },
  18: { desc: "Sleet",                 icon: "sleet" },
  19: { desc: "Hail shower",           icon: "hail" },
  20: { desc: "Hail shower",           icon: "hail" },
  21: { desc: "Hail",                  icon: "hail" },
  22: { desc: "Light snow shower",     icon: "light snow shower" },
  23: { desc: "Light snow shower",     icon: "light snow shower" },
  24: { desc: "Light snow",            icon: "light snow" },
  25: { desc: "Heavy snow shower",     icon: "heavy snow shower" },
  26: { desc: "Heavy snow shower",     icon: "heavy snow shower" },
  27: { desc: "Heavy snow",            icon: "heavy snow" },
  28: { desc: "Thunder shower",        icon: "thunderstorm" },
  29: { desc: "Thunder shower",        icon: "thunderstorm" },
  30: { desc: "Thunder",               icon: "thunderstorm" },
};

function degToCompass(deg) {
  if (deg == null) return "";
  const dirs = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];
  return dirs[Math.round(deg / 22.5) % 16];
}

function transformMetOfficeData(apiData, locationName) {
  const feature = apiData.features?.[0];
  if (!feature) throw new Error("No forecast data returned from Met Office");
  const timeSeries = feature.properties.timeSeries || [];
  const detectedName = feature.properties.location?.name || locationName;
  const byDate = {};
  timeSeries.forEach(h => {
    const date = h.time.slice(0, 10);
    if (!byDate[date]) byDate[date] = [];
    byDate[date].push(h);
  });
  const forecast = Object.entries(byDate).slice(0, 7).map(([date, hours]) => {
    const temps = hours.map(h => h.screenTemperature).filter(t => t != null);
    const minTemp = temps.length ? Math.round(Math.min(...temps)) : null;
    const maxTemp = temps.length ? Math.round(Math.max(...temps)) : null;
    const midHour = hours[Math.floor(hours.length / 2)] || hours[0];
    const firstHour = hours[0];
    const codeInfo = WEATHER_CODES[midHour.significantWeatherCode] || { desc: "Unknown", icon: "cloudy" };
    const maxRain = Math.max(...hours.map(h => h.probOfPrecipitation ?? 0));
    return {
      date,
      description: codeInfo.desc,
      iconKey: codeInfo.icon,
      temperature: { min: minTemp, max: maxTemp },
      feelsLike: firstHour.feelsLikeTemperature != null ? Math.round(firstHour.feelsLikeTemperature) : null,
      windSpeed: firstHour.windSpeed10m != null ? Math.round(firstHour.windSpeed10m * 2.237) : null,
      windGust: firstHour.windGustSpeed10m != null ? Math.round(firstHour.windGustSpeed10m * 2.237) : null,
      windDirection: degToCompass(firstHour.windDirectionFrom10m),
      rainChance: maxRain,
      humidity: firstHour.screenRelativeHumidity != null ? Math.round(firstHour.screenRelativeHumidity) : null,
      visibility: firstHour.visibility,
      pressure: firstHour.mslp != null ? Math.round(firstHour.mslp / 100) : null,
      uvIndex: firstHour.uvIndex,
      hourly: hours.map(h => {
        const hInfo = WEATHER_CODES[h.significantWeatherCode] || { desc: "Unknown", icon: "cloudy" };
        return {
          time: h.time,
          iconKey: hInfo.icon,
          temp: h.screenTemperature != null ? Math.round(h.screenTemperature) : null,
          rainChance: h.probOfPrecipitation ?? 0,
          windSpeed: h.windSpeed10m != null ? Math.round(h.windSpeed10m * 2.237) : null,
          windGust: h.windGustSpeed10m != null ? Math.round(h.windGustSpeed10m * 2.237) : null,
          windDirection: degToCompass(h.windDirectionFrom10m),
          humidity: h.screenRelativeHumidity != null ? Math.round(h.screenRelativeHumidity) : null,
          visibility: h.visibility,
        };
      }),
    };
  });
  return { location: { name: detectedName }, forecast };
}

// ─── Background gradients by weather category ────────────────────────────────
function bgFromIconKey(iconKey = "") {
  if (!iconKey) return "from-slate-900 to-slate-800";
  const k = iconKey.toLowerCase();
  if (k.includes("thunder"))   return "from-purple-950 via-slate-900 to-indigo-950";
  if (k.includes("heavy snow") || k.includes("blizzard")) return "from-blue-500 via-indigo-400 to-sky-500";
  if (k.includes("snow") || k.includes("flurry")) return "from-blue-300 via-sky-300 to-indigo-300";
  if (k.includes("heavy rain") || k.includes("heavy shower")) return "from-blue-800 via-blue-700 to-slate-800";
  if (k.includes("rain") || k.includes("shower") || k.includes("drizzle")) return "from-blue-600 via-blue-500 to-slate-600";
  if (k.includes("sleet") || k.includes("hail")) return "from-sky-700 via-slate-600 to-blue-700";
  if (k.includes("fog") || k.includes("mist")) return "from-gray-500 via-gray-400 to-slate-300";
  if (k.includes("overcast")) return "from-slate-600 via-slate-500 to-gray-500";
  if (k.includes("cloudy")) return "from-slate-500 via-slate-400 to-gray-300";
  if (k.includes("night")) return "from-indigo-950 via-slate-900 to-black";
  if (k.includes("sunny") || k.includes("sunny interval")) return "from-amber-400 via-orange-300 to-yellow-200";
  if (k.includes("clear")) return "from-indigo-950 via-slate-900 to-black";
  return "from-sky-600 via-blue-500 to-cyan-400";
}

// ─── Weather icon renderer ────────────────────────────────────────────────────
function WeatherIcon({ iconKey, className = "w-10 h-10" }) {
  const Icon = weatherIcons[iconKey] || CloudyIcon;
  return <Icon className={className} />;
}

// ─── Helper utils ─────────────────────────────────────────────────────────────
function getVisLabel(m) {
  if (!m) return "—";
  if (m >= 40000) return "Excellent";
  if (m >= 10000) return "Good";
  if (m >= 4000)  return "Moderate";
  if (m >= 1000)  return "Poor";
  return "Very Poor";
}
function formatTime(isoStr) {
  return new Date(isoStr).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/London" });
}
function formatDay(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr + "T12:00:00");
  const today = new Date();
  const tomorrow = new Date(today); tomorrow.setDate(tomorrow.getDate() + 1);
  if (d.toDateString() === today.toDateString()) return "Today";
  if (d.toDateString() === tomorrow.toDateString()) return "Tomorrow";
  return d.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
}
function formatFullDate(dateStr) {
  if (!dateStr) return "";
  return new Date(dateStr + "T12:00:00").toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" });
}

// Stat pill component
function StatPill({ icon: Icon, label, value, sub }) {
  return (
    <div className="flex flex-col items-center bg-white/10 backdrop-blur-sm rounded-2xl px-3 py-3 min-w-[72px]">
      <Icon className="w-4 h-4 mb-1 opacity-70" />
      <span className="text-xs opacity-60 mb-0.5">{label}</span>
      <span className="font-semibold text-sm">{value}</span>
      {sub && <span className="text-xs opacity-50">{sub}</span>}
    </div>
  );
}

export default function LocationWeather() {
  const routerLocation = useLocation();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setData] = useState(null);
  const [selectedDay, setSelectedDay] = useState(0);
  const [unit, setUnit] = useState("C");
  const [metApiKey, setMetApiKey] = useState("eyJ4NXQjUzI1NiI6Ik5XVTVZakUxTkRjeVl6a3hZbUl4TkdSaFpqSmpOV1l6T1dGaE9XWXpNMk0yTWpRek5USm1OVEE0TXpOaU9EaG1NVFJqWVdNellXUm1ZalUyTTJJeVpBPT0iLCJraWQiOiJnYXRld2F5X2NlcnRpZmljYXRlX2FsaWFzIiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ==.eyJzdWIiOiJvbGFmX3d5QGljbG91ZC5jb21AY2FyYm9uLnN1cGVyIiwiYXBwbGljYXRpb24iOnsib3duZXIiOiJvbGFmX3d5QGljbG91ZC5jb20iLCJ0aWVyUXVvdGFUeXBlIjpudWxsLCJ0aWVyIjoiVW5saW1pdGVkIiwibmFtZSI6InNpdGVfc3BlY2lmaWMtZjMwMjg4YWItMjFmYi00NTBiLTliNTgtYWM0MWQ2M2E0YWU2IiwiaWQiOjQ1MzMxLCJ1dWlkIjoiOTAwYmEyYzItZTkwMC00MzNhLWFjYmYtOGZmNjMwN2JhMjI1In0sImlzcyI6Imh0dHBzOlwvXC9hcGktbWFuYWdlci5hcGktbWFuYWdlbWVudC5tZXRvZmZpY2UuY2xvdWQ6NDQzXC9vYXV0aDJcL3Rva2VuIiwidGllckluZm8iOnsid2RoX3NpdGVfc3BlY2lmaWNfZnJlZSI6eyJ0aWVyUXVvdGFUeXBlIjoicmVxdWVzdENvdW50IiwiZ3JhcGhRTE1heENvbXBsZXhpdHkiOjAsImdyYXBoUUxNYXhEZXB0aCI6MCwic3RvcE9uUXVvdGFSZWFjaCI6dHJ1ZSwic3Bpa2VBcnJlc3RMaW1pdCI6MCwic3Bpa2VBcnJlc3RVbml0Ijoic2VjIn19LCJrZXl0eXBlIjoiUFJPRFVDVElPTiIsInN1YnNjcmliZWRBUElzIjpbeyJzdWJzY3JpYmVyVGVuYW50RG9tYWluIjoiY2FyYm9uLnN1cGVyIiwibmFtZSI6IlNpdGVTcGVjaWZpY0ZvcmVjYXN0IiwiY29udGV4dCI6Ilwvc2l0ZXNwZWNpZmljXC92MCIsInB1Ymxpc2hlciI6IkphZ3Vhcl9DSSIsInZlcnNpb24iOiJ2MCIsInN1YnNjcmlwdGlvblRpZXIiOiJ3ZGhfc2l0ZV9zcGVjaWZpY19mcmVlIn1dLCJ0b2tlbl90eXBlIjoiYXBpS2V5IiwiaWF0IjoxNzc2MTgyNDM1LCJqdGkiOiI5ZTc4OWI3Ny0xN2FkLTQyYjctODc2OS1hZDcwYzg4ZGY1NGEifQ==.La0dgE5IkKLhVwRci409CjAhTFfmE-HRf3Exo8mHJlTxoRv4USdD0qmoYppLxgz9cJy_gGcblAsouygok3spx5AWHt6flBV01o-UcgZJw5-JOkjsfi0Lz8WuxsREEWgH8cLF8D3_mF_suYWHc3dXIaCP3ZwwkBZQM87PX8ZjjuybvbGNWLbOhH--Md02iJGB5BTVnw9CNrfX4pD2VzQvamkc5UZgyVCbigKx9Pw1dN3ZV7YiaLrJFTMVZmPorDG3aQcP1iPKyhe_zw_6NegG7r7fnrKkrXfwqwxAmHwLVyuEhovJ2-Hx0F6eR4TkTczowmgUfeIXUoHY-CFxY4VbzQ==");

  useEffect(() => {
    // Also check admin settings for an override key
    db.entities.SiteSettings.list().then(list => {
      const s = list[0];
      if (s?.met_office_api_key) setMetApiKey(s.met_office_api_key);
    }).catch(() => {});
  }, []);
  const [expanded, setExpanded] = useState(false);

  const toF = c => Math.round(c * 9 / 5 + 32);
  const temp = c => (c == null ? "—" : unit === "C" ? `${Math.round(c)}°C` : `${toF(c)}°F`);
  const tempNum = c => (c == null ? "—" : unit === "C" ? Math.round(c) : toF(c));

  const fetchWeather = useCallback(async (location) => {
    if (!location.trim()) return;
    if (!metApiKey) { setError("No Met Office API key configured. Please add it in Admin Settings → Site Control."); return; }
    setLoading(true);
    setError(null);
    setData(null);
    setSelectedDay(0);
    setExpanded(false);
    // 1. Geocode via Nominatim
    const geoRes = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(location + ", UK")}&format=json&limit=1`);
    const geoData = await geoRes.json();
    if (!geoData.length) { setError(`Location "${location}" not found. Try a UK town or city.`); setLoading(false); return; }
    const { lat, lon } = geoData[0];
    // 2. Call Met Office SiteSpecific hourly via CORS proxy
    const metUrl = `https://api-manager.api-management.metoffice.cloud/sitespecific/v0/point/hourly?latitude=${lat}&longitude=${lon}&apikey=${encodeURIComponent(metApiKey)}`;
    const proxyUrl = `https://corsproxy.io/?url=${encodeURIComponent(metUrl)}`;
    const metRes = await fetch(proxyUrl);
    if (!metRes.ok) { setError(`Met Office error (${metRes.status}). Please try again shortly.`); setLoading(false); return; }
    const metData = await metRes.json();
    setData(transformMetOfficeData(metData, location));
    setLoading(false);
  }, [metApiKey]);

  // Auto-fetch from URL param
  useEffect(() => {
    const params = new URLSearchParams(routerLocation.search);
    const loc = params.get("location");
    if (loc) {
      setQuery(loc);
      fetchWeather(loc);
    }
  }, [routerLocation.search]);

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchWeather(query);
  };

  const forecast = data?.forecast ?? [];
  const locationName = data?.location?.name ?? "";
  const selectedDayData = forecast[selectedDay];
  const todayData = forecast[0];
  const bgGradient = bgFromIconKey(selectedDayData?.iconKey);

  return (
    <div className={`min-h-screen text-white font-sans transition-all duration-700 bg-gradient-to-br ${bgGradient}`}>
      {/* Atmospheric orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-white/5 blur-3xl" />
        <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-white/5 blur-3xl" />
      </div>

      {/* Header */}
      <div className="relative z-10 bg-black/20 backdrop-blur-md border-b border-white/10 px-4 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-3">
            <button
              onClick={() => navigate(-1)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h1 className="text-lg font-bold">📍 Location Weather</h1>
          </div>
          <form onSubmit={handleSubmit} className="flex gap-2">
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Enter a UK town or city..."
              className="flex-1 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-4 py-2.5 text-white placeholder-white/40 focus:outline-none focus:border-white/50 focus:bg-white/15"
            />
            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="bg-white/20 hover:bg-white/30 disabled:bg-white/5 disabled:text-white/30 text-white font-semibold px-5 py-2.5 rounded-xl transition-colors backdrop-blur-sm border border-white/20"
            >
              {loading ? "..." : "Search"}
            </button>
          </form>
        </div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 py-6">
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="bg-red-500/20 border border-red-400/40 rounded-2xl p-4 text-red-200 mb-4"
          >
            ⚠️ {error}
          </motion.div>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center py-24 gap-4">
            <div className="w-14 h-14 border-4 border-white/30 border-t-white rounded-full animate-spin" />
            <p className="text-white/60 text-lg">Fetching forecast...</p>
          </div>
        )}

        {!loading && !data && !error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="text-center py-24"
          >
            <div className="text-8xl mb-6">🌤️</div>
            <p className="text-white/70 text-xl mb-6">Search for any UK location for a detailed Met Office forecast</p>
            <div className="flex flex-wrap justify-center gap-2">
              {["London", "Manchester", "Edinburgh", "Cardiff", "Belfast"].map(city => (
                <button
                  key={city}
                  onClick={() => { setQuery(city); fetchWeather(city); }}
                  className="bg-white/10 hover:bg-white/20 border border-white/20 text-white/80 px-4 py-2 rounded-full text-sm transition-colors"
                >
                  {city}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {!loading && data && forecast.length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">

            {/* ── MAIN CARD ── */}
            <motion.div
              layout
              className="rounded-3xl bg-black/20 backdrop-blur-md border border-white/20 overflow-hidden cursor-pointer select-none"
              onClick={() => setExpanded(e => !e)}
            >
              {/* Day selector tabs */}
              <div className="flex gap-1 p-3 overflow-x-auto border-b border-white/10" onClick={e => e.stopPropagation()}>
                {forecast.map((day, idx) => (
                  <button
                    key={idx}
                    onClick={() => { setSelectedDay(idx); setExpanded(true); }}
                    className={`flex-shrink-0 rounded-xl px-3 py-2 text-center transition-all min-w-[72px] border ${
                      selectedDay === idx
                        ? "bg-white/25 border-white/40 text-white"
                        : "bg-white/5 border-white/10 text-white/60 hover:bg-white/15"
                    }`}
                  >
                    <div className="text-[11px] font-medium">{formatDay(day.date)}</div>
                    <div className="flex justify-center my-1">
                      <WeatherIcon iconKey={day.iconKey} className="w-8 h-8" />
                    </div>
                    <div className="text-[11px]">
                      <span className="text-blue-200">{tempNum(day.temperature?.min)}°</span>
                      <span className="opacity-40 mx-0.5">/</span>
                      <span className="font-semibold">{tempNum(day.temperature?.max)}°</span>
                    </div>
                  </button>
                ))}
              </div>

              {/* Current conditions */}
              <div className="p-5">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <WeatherIcon iconKey={selectedDayData?.iconKey} className="w-16 h-16 flex-shrink-0" />
                    <div>
                      <p className="text-2xl font-bold leading-tight">{locationName}</p>
                      <p className="text-white/60 text-sm">{selectedDayData?.description}</p>
                      <p className="text-white/40 text-xs mt-0.5">{formatFullDate(selectedDayData?.date)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-5xl font-thin">
                      {selectedDay === 0
                        ? temp(todayData?.feelsLike ?? todayData?.temperature?.max)
                        : temp(selectedDayData?.temperature?.max)}
                    </div>
                    {selectedDay === 0 && todayData?.feelsLike != null && (
                      <div className="text-white/60 text-sm">Feels {temp(todayData.feelsLike)}</div>
                    )}
                    <div className="text-white/60 text-sm">
                      <span className="text-blue-200">{tempNum(selectedDayData?.temperature?.min)}°</span>
                      <span className="opacity-40 mx-1">–</span>
                      <span>{tempNum(selectedDayData?.temperature?.max)}°</span>
                    </div>
                    <div className="flex gap-1 mt-1 justify-end">
                      <button onClick={e => { e.stopPropagation(); setUnit("C"); }} className={`px-2 py-0.5 rounded text-xs font-medium ${unit === "C" ? "bg-white/30" : "bg-white/10 hover:bg-white/20"}`}>°C</button>
                      <button onClick={e => { e.stopPropagation(); setUnit("F"); }} className={`px-2 py-0.5 rounded text-xs font-medium ${unit === "F" ? "bg-white/30" : "bg-white/10 hover:bg-white/20"}`}>°F</button>
                    </div>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex gap-2 overflow-x-auto pb-1">
                  <StatPill icon={Wind} label="Wind" value={`${selectedDayData?.windSpeed ?? "—"} mph`} sub={selectedDayData?.windDirection} />
                  <StatPill icon={Wind} label="Gusts" value={`${selectedDayData?.windGust ?? "—"} mph`} />
                  <StatPill icon={Droplets} label="Rain%" value={`${selectedDayData?.rainChance ?? "—"}%`} />
                  {selectedDayData?.humidity != null && (
                    <StatPill icon={Droplets} label="Humid" value={`${selectedDayData.humidity}%`} />
                  )}
                  {selectedDayData?.visibility != null && (
                    <StatPill icon={Eye} label="Vis" value={getVisLabel(selectedDayData.visibility)} />
                  )}
                  {selectedDayData?.pressure != null && (
                    <StatPill icon={Gauge} label="Pressure" value={`${selectedDayData.pressure}`} sub="hPa" />
                  )}
                  {selectedDayData?.uvIndex != null && (
                    <StatPill icon={Sun} label="UV" value={selectedDayData.uvIndex} />
                  )}
                </div>

                {/* Expand hint */}
                <div className="flex items-center justify-center mt-4 gap-1 text-white/40 text-xs">
                  {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  <span>{expanded ? "Hide" : "Show"} hourly forecast for {formatDay(selectedDayData?.date)}</span>
                </div>
              </div>

              {/* ── EXPANDED: Hourly ── */}
              <AnimatePresence>
                {expanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
                    className="overflow-hidden"
                    onClick={e => e.stopPropagation()}
                  >
                    <div className="border-t border-white/10 px-4 py-3">
                      <h3 className="text-sm font-semibold text-white/70 mb-3 uppercase tracking-wide">
                        {formatFullDate(selectedDayData?.date)} — Hourly Forecast
                      </h3>
                      {selectedDayData?.hourly?.length > 0 ? (
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="text-white/40 text-xs border-b border-white/10">
                                <th className="text-left pb-2 pr-3">Time</th>
                                <th className="pb-2 px-2">Wx</th>
                                <th className="pb-2 px-2">Temp</th>
                                <th className="pb-2 px-2">Rain%</th>
                                <th className="pb-2 px-2">Wind</th>
                                <th className="pb-2 px-2">Gust</th>
                                <th className="pb-2 px-2 hidden sm:table-cell">Humid</th>
                                <th className="pb-2 px-2 hidden sm:table-cell">Vis</th>
                              </tr>
                            </thead>
                            <tbody>
                              {selectedDayData.hourly.map((h, i) => (
                                <tr key={h.time || i} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                                  <td className="py-2.5 pr-3 text-white/80 font-medium whitespace-nowrap">
                                    {h.time ? formatTime(h.time) : h.hour}
                                  </td>
                                  <td className="py-2.5 px-2">
                                    <WeatherIcon iconKey={h.iconKey} className="w-7 h-7" />
                                  </td>
                                  <td className="py-2.5 px-2 text-center font-semibold">{temp(h.temp)}</td>
                                  <td className={`py-2.5 px-2 text-center ${h.rainChance > 50 ? "text-blue-300 font-semibold" : "text-white/60"}`}>
                                    {h.rainChance}%
                                  </td>
                                  <td className="py-2.5 px-2 text-center text-white/80 whitespace-nowrap">
                                    {h.windSpeed} <span className="text-white/40 text-xs">{h.windDirection}</span>
                                  </td>
                                  <td className={`py-2.5 px-2 text-center whitespace-nowrap ${h.windGust >= 45 ? "text-orange-300 font-semibold" : "text-white/60"}`}>
                                    {h.windGust}
                                  </td>
                                  <td className="py-2.5 px-2 text-center text-white/60 hidden sm:table-cell">
                                    {h.humidity != null ? `${h.humidity}%` : "—"}
                                  </td>
                                  <td className="py-2.5 px-2 text-center text-white/60 hidden sm:table-cell">
                                    {h.visibility != null ? getVisLabel(h.visibility) : "—"}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p className="text-white/40 text-sm text-center py-4">No hourly data available for this day</p>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* ── DAILY SUMMARY ── */}
            <div className="bg-black/20 backdrop-blur-md border border-white/20 rounded-3xl p-4">
              <h2 className="font-semibold text-white/70 mb-3 text-xs uppercase tracking-widest">
                {forecast.length}-Day Forecast
              </h2>
              <div className="space-y-1">
                {forecast.map((day, idx) => {
                  const precipBar = Math.min(100, day.rainChance ?? 0);
                  return (
                    <button
                      key={idx}
                      onClick={() => { setSelectedDay(idx); setExpanded(true); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                      className={`w-full flex items-center gap-3 rounded-xl px-2 py-1.5 transition-colors ${selectedDay === idx ? "bg-white/15" : "hover:bg-white/10"}`}
                    >
                      <div className="w-16 text-sm text-white/70 text-left flex-shrink-0">{formatDay(day.date)}</div>
                      <div className="flex-shrink-0">
                        <WeatherIcon iconKey={day.iconKey} className="w-8 h-8" />
                      </div>
                      <div className="text-xs text-white/40 w-24 flex-shrink-0 truncate text-left hidden sm:block">{day.description}</div>
                      <div className="flex-1 bg-white/10 rounded-full h-1.5">
                        <div className="bg-blue-400 h-1.5 rounded-full" style={{ width: `${precipBar}%` }} />
                      </div>
                      <div className="text-xs text-blue-300 w-8 text-right flex-shrink-0">{day.rainChance ?? 0}%</div>
                      <div className="text-sm w-20 text-right flex-shrink-0">
                        <span className="text-blue-300">{tempNum(day.temperature?.min)}°</span>
                        <span className="text-white/30 mx-1">–</span>
                        <span className="text-white font-semibold">{tempNum(day.temperature?.max)}°</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <p className="text-center text-white/30 text-xs pb-2">
              Powered by Met Office DataHub · Data updated hourly
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}