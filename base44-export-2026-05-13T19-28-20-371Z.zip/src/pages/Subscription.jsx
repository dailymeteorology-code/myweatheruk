const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

import TCMSection from '@/components/TCMSection';import ForcedSnapshotMap from '@/components/tcm/ForcedSnapshotMap';
import {
  Loader2, Menu, X, Home, ShieldAlert, CloudLightning,
  ChevronDown, ChevronUp, AlertTriangle, Radio, Clock,
  Wind, RefreshCw, ChevronRight, Archive, Calendar,
  Zap, Edit2, Trash2, Camera,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';

/* ═══════════════════════════════════════════════════════════════
   RISK LEVEL GUIDE
   ═══════════════════════════════════════════════════════════════ */
const RISK_LEVEL_GUIDE = [
  { level: 'No Risk',  color: '#64748b', bgColor: 'rgba(100,116,139,0.10)', borderColor: 'rgba(100,116,139,0.30)', description: 'No thunderstorm activity is expected. Conditions are stable with no significant convective triggers anticipated across the region.' },
  { level: 'Very Low', color: '#16a34a', bgColor: 'rgba(22,163,74,0.10)',   borderColor: 'rgba(22,163,74,0.30)',   description: 'Isolated, short-lived showers may develop, but the lack of atmospheric energy means lightning is unlikely and impacts will be negligible.' },
  { level: 'Low',      color: '#15803d', bgColor: 'rgba(21,128,61,0.10)',   borderColor: 'rgba(21,128,61,0.30)',   description: 'Scattered thundery showers are expected across the region; however, they will remain unorganised and are unlikely to meet the Met Office "severe" criteria for wind or hail.' },
  { level: 'Marginal', color: '#ca8a04', bgColor: 'rgba(202,138,4,0.10)',   borderColor: 'rgba(202,138,4,0.30)',   description: 'A few intense cells could produce localized "severe" conditions, such as sudden flooding or small hail, requiring residents to keep an eye on evolving radar images.' },
  { level: 'Moderate', color: '#ea580c', bgColor: 'rgba(234,88,12,0.10)',   borderColor: 'rgba(234,88,12,0.30)',   description: 'Organised storm systems, such as squall lines, are likely to cause more widespread disruptions, including frequent lightning and structural damage from strong gusts.' },
  { level: 'High',     color: '#dc2626', bgColor: 'rgba(220,38,38,0.10)',   borderColor: 'rgba(220,38,38,0.30)',   description: 'A significant and dangerous weather event is expected, with a high likelihood of widespread power outages, structural damage, and major travel cancellations across the UK.' },
];

const RISK_ORDER     = ['No Risk', 'Very Low', 'Low', 'Marginal', 'Moderate', 'High'];
const RISK_COLOR_MAP = { 'No Risk': '#64748b', 'Very Low': '#16a34a', 'Low': '#15803d', 'Marginal': '#ca8a04', 'Moderate': '#ea580c', 'High': '#dc2626' };

const RISK_TYPES = [
  { id: 'thunderstorm', label: 'Thunderstorm', icon: CloudLightning, color: '#facc15' },
  { id: 'hail',         label: 'Hail',         icon: CloudLightning, color: '#38bdf8' },
  { id: 'tornado',      label: 'Tornado',       icon: Wind,           color: '#f97316' },
  { id: 'lightning',    label: 'Lightning',     icon: Zap,            color: '#a78bfa' },
];

/* ═══════════════════════════════════════════════════════════════
   ENHANCED CITY DATABASE — ~350 UK towns for accuracy
   ═══════════════════════════════════════════════════════════════ */
const CITY_DB = [
  // ── England ────────────────────────────────────────────────
  { name: 'London',              country: 'England', lat: 51.507, lon: -0.128 },
  { name: 'Birmingham',          country: 'England', lat: 52.480, lon: -1.903 },
  { name: 'Manchester',          country: 'England', lat: 53.483, lon: -2.244 },
  { name: 'Leeds',               country: 'England', lat: 53.800, lon: -1.549 },
  { name: 'Liverpool',           country: 'England', lat: 53.408, lon: -2.978 },
  { name: 'Sheffield',           country: 'England', lat: 53.381, lon: -1.470 },
  { name: 'Newcastle upon Tyne', country: 'England', lat: 54.978, lon: -1.618 },
  { name: 'Bristol',             country: 'England', lat: 51.455, lon: -2.588 },
  { name: 'Nottingham',          country: 'England', lat: 52.954, lon: -1.158 },
  { name: 'Leicester',           country: 'England', lat: 52.636, lon: -1.131 },
  { name: 'Coventry',            country: 'England', lat: 52.408, lon: -1.510 },
  { name: 'Bradford',            country: 'England', lat: 53.795, lon: -1.752 },
  { name: 'Stoke-on-Trent',      country: 'England', lat: 53.002, lon: -2.180 },
  { name: 'Derby',               country: 'England', lat: 52.922, lon: -1.476 },
  { name: 'Plymouth',            country: 'England', lat: 50.376, lon: -4.142 },
  { name: 'Southampton',         country: 'England', lat: 50.904, lon: -1.404 },
  { name: 'Portsmouth',          country: 'England', lat: 50.800, lon: -1.091 },
  { name: 'Norwich',             country: 'England', lat: 52.628, lon:  1.299 },
  { name: 'Ipswich',             country: 'England', lat: 52.059, lon:  1.155 },
  { name: 'Oxford',              country: 'England', lat: 51.752, lon: -1.257 },
  { name: 'Cambridge',           country: 'England', lat: 52.205, lon:  0.119 },
  { name: 'Exeter',              country: 'England', lat: 50.718, lon: -3.534 },
  { name: 'Gloucester',          country: 'England', lat: 51.865, lon: -2.244 },
  { name: 'York',                country: 'England', lat: 53.959, lon: -1.082 },
  { name: 'Sunderland',          country: 'England', lat: 54.906, lon: -1.381 },
  { name: 'Middlesbrough',       country: 'England', lat: 54.576, lon: -1.235 },
  { name: 'Preston',             country: 'England', lat: 53.763, lon: -2.703 },
  { name: 'Blackpool',           country: 'England', lat: 53.817, lon: -3.036 },
  { name: 'Carlisle',            country: 'England', lat: 54.896, lon: -2.937 },
  { name: 'Brighton',            country: 'England', lat: 50.827, lon: -0.137 },
  { name: 'Hove',                country: 'England', lat: 50.832, lon: -0.168 },
  { name: 'Reading',             country: 'England', lat: 51.455, lon: -0.970 },
  { name: 'Milton Keynes',       country: 'England', lat: 52.041, lon: -0.760 },
  { name: 'Luton',               country: 'England', lat: 51.879, lon: -0.417 },
  { name: 'Peterborough',        country: 'England', lat: 52.573, lon: -0.240 },
  { name: 'Hull',                country: 'England', lat: 53.745, lon: -0.333 },
  { name: 'Wolverhampton',       country: 'England', lat: 52.587, lon: -2.128 },
  { name: 'Wigan',               country: 'England', lat: 53.542, lon: -2.634 },
  { name: 'Bolton',              country: 'England', lat: 53.577, lon: -2.429 },
  { name: 'Stockport',           country: 'England', lat: 53.408, lon: -2.157 },
  { name: 'Salford',             country: 'England', lat: 53.488, lon: -2.290 },
  { name: 'Oldham',              country: 'England', lat: 53.541, lon: -2.117 },
  { name: 'Rochdale',            country: 'England', lat: 53.615, lon: -2.161 },
  { name: 'Warrington',          country: 'England', lat: 53.390, lon: -2.597 },
  { name: 'Birkenhead',          country: 'England', lat: 53.393, lon: -3.014 },
  { name: 'Blackburn',           country: 'England', lat: 53.748, lon: -2.482 },
  { name: 'Burnley',             country: 'England', lat: 53.789, lon: -2.248 },
  { name: 'Halifax',             country: 'England', lat: 53.725, lon: -1.862 },
  { name: 'Huddersfield',        country: 'England', lat: 53.645, lon: -1.785 },
  { name: 'Wakefield',           country: 'England', lat: 53.683, lon: -1.506 },
  { name: 'Rotherham',           country: 'England', lat: 53.430, lon: -1.357 },
  { name: 'Barnsley',            country: 'England', lat: 53.552, lon: -1.479 },
  { name: 'Doncaster',           country: 'England', lat: 53.523, lon: -1.128 },
  { name: 'Grimsby',             country: 'England', lat: 53.567, lon: -0.082 },
  { name: 'Lincoln',             country: 'England', lat: 53.228, lon: -0.540 },
  { name: 'Northampton',         country: 'England', lat: 52.237, lon: -0.898 },
  { name: 'Watford',             country: 'England', lat: 51.655, lon: -0.396 },
  { name: 'Slough',              country: 'England', lat: 51.511, lon: -0.594 },
  { name: 'Basildon',            country: 'England', lat: 51.574, lon:  0.451 },
  { name: 'Chelmsford',          country: 'England', lat: 51.736, lon:  0.471 },
  { name: 'Southend-on-Sea',     country: 'England', lat: 51.536, lon:  0.714 },
  { name: 'Colchester',          country: 'England', lat: 51.895, lon:  0.891 },
  { name: 'Canterbury',          country: 'England', lat: 51.279, lon:  1.076 },
  { name: 'Maidstone',           country: 'England', lat: 51.272, lon:  0.522 },
  { name: 'Medway',              country: 'England', lat: 51.405, lon:  0.542 },
  { name: 'Guildford',           country: 'England', lat: 51.236, lon: -0.570 },
  { name: 'Crawley',             country: 'England', lat: 51.110, lon: -0.188 },
  { name: 'Worthing',            country: 'England', lat: 50.815, lon: -0.373 },
  { name: 'Hastings',            country: 'England', lat: 50.855, lon:  0.573 },
  { name: 'Eastbourne',          country: 'England', lat: 50.769, lon:  0.284 },
  { name: 'Folkestone',          country: 'England', lat: 51.082, lon:  1.170 },
  { name: 'Dover',               country: 'England', lat: 51.130, lon:  1.310 },
  { name: 'Margate',             country: 'England', lat: 51.385, lon:  1.384 },
  { name: 'Ramsgate',            country: 'England', lat: 51.336, lon:  1.416 },
  { name: 'Winchester',          country: 'England', lat: 51.063, lon: -1.308 },
  { name: 'Bournemouth',         country: 'England', lat: 50.720, lon: -1.880 },
  { name: 'Poole',               country: 'England', lat: 50.714, lon: -1.987 },
  { name: 'Weymouth',            country: 'England', lat: 50.614, lon: -2.459 },
  { name: 'Torquay',             country: 'England', lat: 50.462, lon: -3.525 },
  { name: 'Paignton',            country: 'England', lat: 50.436, lon: -3.562 },
  { name: 'Penzance',            country: 'England', lat: 50.119, lon: -5.537 },
  { name: 'Truro',               country: 'England', lat: 50.263, lon: -5.051 },
  { name: 'St Austell',          country: 'England', lat: 50.340, lon: -4.791 },
  { name: 'Bodmin',              country: 'England', lat: 50.472, lon: -4.718 },
  { name: 'Newquay',             country: 'England', lat: 50.412, lon: -5.075 },
  { name: 'Falmouth',            country: 'England', lat: 50.153, lon: -5.066 },
  { name: 'Barnstaple',          country: 'England', lat: 51.082, lon: -4.059 },
  { name: 'Taunton',             country: 'England', lat: 51.015, lon: -3.106 },
  { name: 'Yeovil',              country: 'England', lat: 50.945, lon: -2.637 },
  { name: 'Bath',                country: 'England', lat: 51.381, lon: -2.359 },
  { name: 'Swindon',             country: 'England', lat: 51.559, lon: -1.783 },
  { name: 'Cheltenham',          country: 'England', lat: 51.900, lon: -2.074 },
  { name: 'Hereford',            country: 'England', lat: 52.055, lon: -2.716 },
  { name: 'Worcester',           country: 'England', lat: 52.192, lon: -2.220 },
  { name: 'Shrewsbury',          country: 'England', lat: 52.708, lon: -2.754 },
  { name: 'Telford',             country: 'England', lat: 52.678, lon: -2.447 },
  { name: 'Walsall',             country: 'England', lat: 52.586, lon: -1.983 },
  { name: 'West Bromwich',       country: 'England', lat: 52.519, lon: -1.995 },
  { name: 'Solihull',            country: 'England', lat: 52.413, lon: -1.778 },
  { name: 'Dudley',              country: 'England', lat: 52.509, lon: -2.082 },
  { name: 'Nuneaton',            country: 'England', lat: 52.523, lon: -1.465 },
  { name: 'Tamworth',            country: 'England', lat: 52.634, lon: -1.696 },
  { name: 'Burton upon Trent',   country: 'England', lat: 52.801, lon: -1.637 },
  { name: 'Stafford',            country: 'England', lat: 52.806, lon: -2.117 },
  { name: 'Crewe',               country: 'England', lat: 53.099, lon: -2.441 },
  { name: 'Chester',             country: 'England', lat: 53.190, lon: -2.890 },
  { name: 'Lancaster',           country: 'England', lat: 54.048, lon: -2.799 },
  { name: 'Kendal',              country: 'England', lat: 54.323, lon: -2.743 },
  { name: 'Barrow-in-Furness',   country: 'England', lat: 54.110, lon: -3.226 },
  { name: 'Workington',          country: 'England', lat: 54.643, lon: -3.546 },
  { name: 'Penrith',             country: 'England', lat: 54.666, lon: -2.754 },
  { name: 'Darlington',          country: 'England', lat: 54.524, lon: -1.554 },
  { name: 'Stockton-on-Tees',    country: 'England', lat: 54.570, lon: -1.320 },
  { name: 'Hartlepool',          country: 'England', lat: 54.686, lon: -1.213 },
  { name: 'Scarborough',         country: 'England', lat: 54.280, lon: -0.400 },
  { name: 'Harrogate',           country: 'England', lat: 53.993, lon: -1.541 },
  { name: 'Ripon',               country: 'England', lat: 54.138, lon: -1.524 },
  { name: 'Skipton',             country: 'England', lat: 53.962, lon: -2.016 },
  { name: 'Keighley',            country: 'England', lat: 53.867, lon: -1.907 },
  { name: 'Dewsbury',            country: 'England', lat: 53.692, lon: -1.633 },
  { name: 'Scunthorpe',          country: 'England', lat: 53.590, lon: -0.651 },
  { name: 'Cleethorpes',         country: 'England', lat: 53.556, lon: -0.025 },
  { name: 'Loughborough',        country: 'England', lat: 52.766, lon: -1.204 },
  { name: 'Grantham',            country: 'England', lat: 52.913, lon: -0.641 },
  { name: 'Boston',              country: 'England', lat: 52.975, lon: -0.022 },
  { name: 'Spalding',            country: 'England', lat: 52.788, lon: -0.153 },
  { name: 'Kings Lynn',          country: 'England', lat: 52.753, lon:  0.400 },
  { name: 'Wisbech',             country: 'England', lat: 52.664, lon:  0.160 },
  { name: 'Ely',                 country: 'England', lat: 52.399, lon:  0.263 },
  { name: 'Huntingdon',          country: 'England', lat: 52.336, lon: -0.187 },
  { name: 'Bedford',             country: 'England', lat: 52.136, lon: -0.468 },
  { name: 'Stevenage',           country: 'England', lat: 51.902, lon: -0.202 },
  { name: 'Hemel Hempstead',     country: 'England', lat: 51.753, lon: -0.443 },
  { name: 'St Albans',           country: 'England', lat: 51.752, lon: -0.336 },
  { name: 'Hatfield',            country: 'England', lat: 51.764, lon: -0.226 },
  { name: 'Harlow',              country: 'England', lat: 51.770, lon:  0.106 },
  { name: 'Brentwood',           country: 'England', lat: 51.621, lon:  0.305 },
  { name: 'Thurrock',            country: 'England', lat: 51.495, lon:  0.348 },
  { name: 'Dartford',            country: 'England', lat: 51.447, lon:  0.217 },
  { name: 'Sevenoaks',           country: 'England', lat: 51.270, lon:  0.189 },
  { name: 'Tonbridge',           country: 'England', lat: 51.200, lon:  0.274 },
  { name: 'Tunbridge Wells',     country: 'England', lat: 51.132, lon:  0.263 },
  { name: 'Lewes',               country: 'England', lat: 50.874, lon:  0.014 },
  { name: 'Chichester',          country: 'England', lat: 50.836, lon: -0.779 },
  { name: 'Horsham',             country: 'England', lat: 51.063, lon: -0.326 },
  { name: 'Reigate',             country: 'England', lat: 51.237, lon: -0.206 },
  { name: 'Aldershot',           country: 'England', lat: 51.248, lon: -0.759 },
  { name: 'Basingstoke',         country: 'England', lat: 51.263, lon: -1.088 },
  { name: 'Andover',             country: 'England', lat: 51.208, lon: -1.483 },
  { name: 'Salisbury',           country: 'England', lat: 51.069, lon: -1.797 },
  { name: 'Chippenham',          country: 'England', lat: 51.458, lon: -2.116 },
  { name: 'Weston-super-Mare',   country: 'England', lat: 51.347, lon: -2.977 },
  { name: 'Bridgwater',          country: 'England', lat: 51.128, lon: -2.996 },
  { name: 'Minehead',            country: 'England', lat: 51.204, lon: -3.474 },
  { name: 'Bridport',            country: 'England', lat: 50.734, lon: -2.758 },
  { name: 'Dorchester',          country: 'England', lat: 50.715, lon: -2.438 },
  { name: 'Swanage',             country: 'England', lat: 50.607, lon: -1.958 },
  { name: 'Bognor Regis',        country: 'England', lat: 50.782, lon: -0.673 },
  { name: 'Littlehampton',       country: 'England', lat: 50.810, lon: -0.541 },
  { name: 'Shoreham-by-Sea',     country: 'England', lat: 50.833, lon: -0.272 },
  { name: 'Newhaven',            country: 'England', lat: 50.795, lon:  0.054 },
  { name: 'Sittingbourne',       country: 'England', lat: 51.341, lon:  0.736 },
  { name: 'Ashford',             country: 'England', lat: 51.146, lon:  0.874 },
  { name: 'Herne Bay',           country: 'England', lat: 51.372, lon:  1.128 },
  { name: 'Whitstable',          country: 'England', lat: 51.360, lon:  1.026 },
  { name: 'Deal',                country: 'England', lat: 51.222, lon:  1.401 },
  { name: 'Hythe',               country: 'England', lat: 51.071, lon:  1.083 },
  { name: 'Lyme Regis',          country: 'England', lat: 50.727, lon: -2.936 },
  { name: 'Sherborne',           country: 'England', lat: 50.947, lon: -2.516 },
  { name: 'Shaftesbury',         country: 'England', lat: 51.005, lon: -2.196 },
  { name: 'Blandford Forum',     country: 'England', lat: 50.856, lon: -2.165 },
  { name: 'Wareham',             country: 'England', lat: 50.688, lon: -2.113 },
  { name: 'Christchurch',        country: 'England', lat: 50.736, lon: -1.781 },
  { name: 'Ringwood',            country: 'England', lat: 50.845, lon: -1.789 },
  { name: 'Romsey',              country: 'England', lat: 51.000, lon: -1.499 },
  { name: 'Eastleigh',           country: 'England', lat: 50.967, lon: -1.351 },
  { name: 'Fareham',             country: 'England', lat: 50.852, lon: -1.180 },
  { name: 'Gosport',             country: 'England', lat: 50.795, lon: -1.124 },
  { name: 'Havant',              country: 'England', lat: 50.851, lon: -0.983 },
  { name: 'Petersfield',         country: 'England', lat: 51.004, lon: -0.934 },
  { name: 'Farnham',             country: 'England', lat: 51.214, lon: -0.799 },
  { name: 'Woking',              country: 'England', lat: 51.319, lon: -0.556 },
  { name: 'Epsom',               country: 'England', lat: 51.337, lon: -0.269 },
  { name: 'Croydon',             country: 'England', lat: 51.374, lon: -0.098 },
  { name: 'Kingston upon Thames',country: 'England', lat: 51.412, lon: -0.300 },
  { name: 'Richmond',            country: 'England', lat: 51.461, lon: -0.306 },
  { name: 'Twickenham',          country: 'England', lat: 51.449, lon: -0.337 },
  { name: 'Uxbridge',            country: 'England', lat: 51.546, lon: -0.479 },
  { name: 'Enfield',             country: 'England', lat: 51.652, lon: -0.083 },
  { name: 'Barnet',              country: 'England', lat: 51.651, lon: -0.199 },
  { name: 'Romford',             country: 'England', lat: 51.575, lon:  0.184 },
  { name: 'Ilford',              country: 'England', lat: 51.558, lon:  0.075 },
  { name: 'Stratford-upon-Avon', country: 'England', lat: 52.192, lon: -1.708 },
  { name: 'Leamington Spa',      country: 'England', lat: 52.291, lon: -1.536 },
  { name: 'Rugby',               country: 'England', lat: 52.370, lon: -1.265 },
  { name: 'Kenilworth',          country: 'England', lat: 52.341, lon: -1.574 },
  { name: 'Redditch',            country: 'England', lat: 52.306, lon: -1.945 },
  { name: 'Kidderminster',       country: 'England', lat: 52.388, lon: -2.249 },
  { name: 'Stourbridge',         country: 'England', lat: 52.457, lon: -2.148 },
  { name: 'Cannock',             country: 'England', lat: 52.690, lon: -2.029 },
  { name: 'Lichfield',           country: 'England', lat: 52.683, lon: -1.827 },
  { name: 'Sutton Coldfield',    country: 'England', lat: 52.563, lon: -1.824 },
  { name: 'Halesowen',           country: 'England', lat: 52.449, lon: -2.051 },
  { name: 'Smethwick',           country: 'England', lat: 52.493, lon: -1.968 },
  { name: 'Tipton',              country: 'England', lat: 52.529, lon: -2.065 },
  { name: 'Sandwell',            country: 'England', lat: 52.536, lon: -2.010 },
  { name: 'Wolverhampton',       country: 'England', lat: 52.587, lon: -2.128 },
  { name: 'Newcastle-under-Lyme',country: 'England', lat: 53.012, lon: -2.228 },
  { name: 'Leek',                country: 'England', lat: 53.107, lon: -2.023 },
  { name: 'Macclesfield',        country: 'England', lat: 53.259, lon: -2.127 },
  { name: 'Altrincham',          country: 'England', lat: 53.387, lon: -2.347 },
  { name: 'Sale',                country: 'England', lat: 53.424, lon: -2.322 },
  { name: 'Stretford',           country: 'England', lat: 53.448, lon: -2.309 },
  { name: 'Eccles',              country: 'England', lat: 53.483, lon: -2.334 },
  { name: 'Leigh',               country: 'England', lat: 53.497, lon: -2.520 },
  { name: 'Bury',                country: 'England', lat: 53.594, lon: -2.298 },
  { name: 'Accrington',          country: 'England', lat: 53.753, lon: -2.364 },
  { name: 'Nelson',              country: 'England', lat: 53.836, lon: -2.218 },
  { name: 'Clitheroe',           country: 'England', lat: 53.873, lon: -2.392 },
  { name: 'Morecambe',           country: 'England', lat: 54.073, lon: -2.862 },
  { name: 'Fleetwood',           country: 'England', lat: 53.921, lon: -3.018 },
  { name: 'Southport',           country: 'England', lat: 53.645, lon: -3.005 },
  { name: 'Bootle',              country: 'England', lat: 53.444, lon: -2.989 },
  { name: 'St Helens',           country: 'England', lat: 53.452, lon: -2.737 },
  { name: 'Runcorn',             country: 'England', lat: 53.343, lon: -2.728 },
  { name: 'Widnes',              country: 'England', lat: 53.362, lon: -2.729 },
  { name: 'Ellesmere Port',      country: 'England', lat: 53.278, lon: -2.898 },
  { name: 'Nantwich',            country: 'England', lat: 53.067, lon: -2.523 },
  { name: 'Congleton',           country: 'England', lat: 53.163, lon: -2.216 },
  { name: 'Wilmslow',            country: 'England', lat: 53.329, lon: -2.234 },
  { name: 'Knutsford',           country: 'England', lat: 53.302, lon: -2.371 },
  { name: 'Northwich',           country: 'England', lat: 53.259, lon: -2.523 },
  { name: 'Winsford',            country: 'England', lat: 53.193, lon: -2.523 },
  { name: 'Middlewich',          country: 'England', lat: 53.192, lon: -2.443 },
  { name: 'Kidsgrove',           country: 'England', lat: 53.088, lon: -2.241 },
  { name: 'Biddulph',            country: 'England', lat: 53.120, lon: -2.173 },
  { name: 'Uttoxeter',           country: 'England', lat: 52.899, lon: -1.862 },
  { name: 'Ashby-de-la-Zouch',   country: 'England', lat: 52.746, lon: -1.473 },
  { name: 'Hinckley',            country: 'England', lat: 52.541, lon: -1.375 },
  { name: 'Coalville',           country: 'England', lat: 52.724, lon: -1.370 },
  { name: 'Melton Mowbray',      country: 'England', lat: 52.765, lon: -0.887 },
  { name: 'Market Harborough',   country: 'England', lat: 52.478, lon: -0.921 },
  { name: 'Corby',               country: 'England', lat: 52.496, lon: -0.703 },
  { name: 'Kettering',           country: 'England', lat: 52.397, lon: -0.722 },
  { name: 'Wellingborough',      country: 'England', lat: 52.300, lon: -0.694 },
  { name: 'Daventry',            country: 'England', lat: 52.259, lon: -1.162 },
  { name: 'Towcester',           country: 'England', lat: 52.132, lon: -0.993 },
  { name: 'Buckingham',          country: 'England', lat: 52.000, lon: -0.987 },
  { name: 'Aylesbury',           country: 'England', lat: 51.815, lon: -0.812 },
  { name: 'High Wycombe',        country: 'England', lat: 51.629, lon: -0.748 },
  { name: 'Maidenhead',          country: 'England', lat: 51.524, lon: -0.718 },
  { name: 'Windsor',             country: 'England', lat: 51.481, lon: -0.614 },
  { name: 'Bracknell',           country: 'England', lat: 51.414, lon: -0.749 },
  { name: 'Wokingham',           country: 'England', lat: 51.411, lon: -0.835 },
  { name: 'Newbury',             country: 'England', lat: 51.401, lon: -1.323 },
  { name: 'Thatcham',            country: 'England', lat: 51.399, lon: -1.262 },
  { name: 'Abingdon',            country: 'England', lat: 51.671, lon: -1.282 },
  { name: 'Didcot',              country: 'England', lat: 51.606, lon: -1.243 },
  { name: 'Witney',              country: 'England', lat: 51.785, lon: -1.485 },
  { name: 'Banbury',             country: 'England', lat: 52.062, lon: -1.340 },
  { name: 'Bicester',            country: 'England', lat: 51.900, lon: -1.153 },
  { name: 'Chipping Norton',     country: 'England', lat: 51.939, lon: -1.545 },
  { name: 'Cirencester',         country: 'England', lat: 51.718, lon: -1.966 },
  { name: 'Stroud',              country: 'England', lat: 51.745, lon: -2.218 },
  { name: 'Tewkesbury',          country: 'England', lat: 51.987, lon: -2.160 },
  { name: 'Evesham',             country: 'England', lat: 52.092, lon: -1.947 },
  { name: 'Pershore',            country: 'England', lat: 52.107, lon: -2.078 },
  { name: 'Droitwich',           country: 'England', lat: 52.267, lon: -2.153 },
  { name: 'Malvern',             country: 'England', lat: 52.112, lon: -2.320 },
  { name: 'Ledbury',             country: 'England', lat: 52.038, lon: -2.425 },
  { name: 'Ross-on-Wye',         country: 'England', lat: 51.915, lon: -2.582 },
  { name: 'Monmouth',            country: 'England', lat: 51.812, lon: -2.716 },
  { name: 'Ludlow',              country: 'England', lat: 52.368, lon: -2.717 },
  { name: 'Oswestry',            country: 'England', lat: 52.861, lon: -3.055 },
  { name: 'Whitchurch',          country: 'England', lat: 52.969, lon: -2.682 },
  { name: 'Market Drayton',      country: 'England', lat: 52.904, lon: -2.484 },
  { name: 'Bridgnorth',          country: 'England', lat: 52.535, lon: -2.419 },
  { name: 'Much Wenlock',        country: 'England', lat: 52.597, lon: -2.559 },
  { name: 'Gateshead',           country: 'England', lat: 54.963, lon: -1.601 },
  { name: 'South Shields',       country: 'England', lat: 54.995, lon: -1.431 },
  { name: 'Tynemouth',           country: 'England', lat: 55.017, lon: -1.423 },
  { name: 'Whitley Bay',         country: 'England', lat: 55.046, lon: -1.444 },
  { name: 'Blyth',               country: 'England', lat: 55.126, lon: -1.512 },
  { name: 'Morpeth',             country: 'England', lat: 55.168, lon: -1.688 },
  { name: 'Hexham',              country: 'England', lat: 54.971, lon: -2.100 },
  { name: 'Consett',             country: 'England', lat: 54.855, lon: -1.831 },
  { name: 'Durham',              country: 'England', lat: 54.776, lon: -1.576 },
  { name: 'Chester-le-Street',   country: 'England', lat: 54.858, lon: -1.570 },
  { name: 'Stanley',             country: 'England', lat: 54.870, lon: -1.696 },
  { name: 'Bishop Auckland',     country: 'England', lat: 54.662, lon: -1.674 },
  { name: 'Newton Aycliffe',     country: 'England', lat: 54.617, lon: -1.582 },
  { name: 'Spennymoor',          country: 'England', lat: 54.700, lon: -1.590 },
  { name: 'Shildon',             country: 'England', lat: 54.629, lon: -1.649 },
  { name: 'Richmond',            country: 'England', lat: 54.404, lon: -1.742 },
  { name: 'Northallerton',       country: 'England', lat: 54.336, lon: -1.435 },
  { name: 'Thirsk',              country: 'England', lat: 54.233, lon: -1.342 },
  { name: 'Malton',              country: 'England', lat: 54.136, lon: -0.800 },
  { name: 'Bridlington',         country: 'England', lat: 54.083, lon: -0.192 },
  { name: 'Filey',               country: 'England', lat: 54.209, lon: -0.289 },
  { name: 'Whitby',              country: 'England', lat: 54.486, lon: -0.614 },
  { name: 'Selby',               country: 'England', lat: 53.782, lon: -1.070 },
  { name: 'Pontefract',          country: 'England', lat: 53.692, lon: -1.311 },
  { name: 'Castleford',          country: 'England', lat: 53.726, lon: -1.358 },
  { name: 'Wetherby',            country: 'England', lat: 53.927, lon: -1.386 },
  { name: 'Otley',               country: 'England', lat: 53.905, lon: -1.691 },
  { name: 'Ilkley',              country: 'England', lat: 53.924, lon: -1.822 },
  { name: 'Bingley',             country: 'England', lat: 53.847, lon: -1.835 },
  { name: 'Shipley',             country: 'England', lat: 53.833, lon: -1.776 },
  { name: 'Batley',              country: 'England', lat: 53.714, lon: -1.629 },
  { name: 'Morley',              country: 'England', lat: 53.745, lon: -1.597 },
  { name: 'Ossett',              country: 'England', lat: 53.681, lon: -1.577 },
  { name: 'Hemsworth',           country: 'England', lat: 53.614, lon: -1.353 },
  { name: 'Penistone',           country: 'England', lat: 53.524, lon: -1.630 },
  { name: 'Worksop',             country: 'England', lat: 53.304, lon: -1.127 },
  { name: 'Retford',             country: 'England', lat: 53.322, lon: -0.941 },
  { name: 'Newark-on-Trent',     country: 'England', lat: 53.076, lon: -0.812 },
  { name: 'Mansfield',           country: 'England', lat: 53.148, lon: -1.196 },
  { name: 'Kirkby in Ashfield',  country: 'England', lat: 53.101, lon: -1.247 },
  { name: 'Hucknall',            country: 'England', lat: 53.038, lon: -1.197 },
  { name: 'Arnold',              country: 'England', lat: 53.000, lon: -1.128 },
  { name: 'Long Eaton',          country: 'England', lat: 52.899, lon: -1.271 },
  { name: 'Ilkeston',            country: 'England', lat: 52.971, lon: -1.309 },
  { name: 'Belper',              country: 'England', lat: 53.022, lon: -1.484 },
  { name: 'Ripley',              country: 'England', lat: 53.052, lon: -1.407 },
  { name: 'Swadlincote',         country: 'England', lat: 52.774, lon: -1.557 },
  { name: 'Matlock',             country: 'England', lat: 53.143, lon: -1.554 },
  { name: 'Buxton',              country: 'England', lat: 53.259, lon: -1.912 },
  { name: 'Chesterfield',        country: 'England', lat: 53.235, lon: -1.421 },
  { name: 'Staveley',            country: 'England', lat: 53.267, lon: -1.348 },
  { name: 'Clowne',              country: 'England', lat: 53.310, lon: -1.243 },
  { name: 'Alfreton',            country: 'England', lat: 53.098, lon: -1.384 },
  { name: 'Heanor',              country: 'England', lat: 53.013, lon: -1.355 },
  { name: 'Haywards Heath',      country: 'England', lat: 50.999, lon: -0.102 },
  { name: 'Burgess Hill',        country: 'England', lat: 50.955, lon: -0.125 },
  { name: 'Shoreham',            country: 'England', lat: 50.833, lon: -0.272 },
  { name: 'Bexhill-on-Sea',      country: 'England', lat: 50.842, lon:  0.470 },
  { name: 'St Leonards-on-Sea',  country: 'England', lat: 50.852, lon:  0.547 },
  { name: 'Rye',                 country: 'England', lat: 50.951, lon:  0.730 },
  { name: 'Tenterden',           country: 'England', lat: 51.068, lon:  0.688 },
  { name: 'Saffron Walden',      country: 'England', lat: 52.022, lon:  0.244 },
  { name: 'Braintree',           country: 'England', lat: 51.878, lon:  0.551 },
  { name: 'Halstead',            country: 'England', lat: 51.944, lon:  0.640 },
  { name: 'Clacton-on-Sea',      country: 'England', lat: 51.790, lon:  1.156 },
  { name: 'Harwich',             country: 'England', lat: 51.940, lon:  1.262 },
  { name: 'Felixstowe',          country: 'England', lat: 51.963, lon:  1.352 },
  { name: 'Lowestoft',           country: 'England', lat: 52.480, lon:  1.750 },
  { name: 'Great Yarmouth',      country: 'England', lat: 52.608, lon:  1.730 },
  { name: 'Thetford',            country: 'England', lat: 52.415, lon:  0.743 },
  { name: 'Attleborough',        country: 'England', lat: 52.518, lon:  1.011 },
  { name: 'Diss',                country: 'England', lat: 52.377, lon:  1.107 },
  { name: 'Downham Market',      country: 'England', lat: 52.606, lon:  0.380 },
  { name: 'Fakenham',            country: 'England', lat: 52.831, lon:  0.847 },
  { name: 'Cromer',              country: 'England', lat: 52.932, lon:  1.298 },
  { name: 'Sheringham',          country: 'England', lat: 52.943, lon:  1.214 },
  { name: 'North Walsham',       country: 'England', lat: 52.822, lon:  1.387 },
  { name: 'Wymondham',           country: 'England', lat: 52.572, lon:  1.115 },
  // ── Scotland ───────────────────────────────────────────────
  { name: 'Edinburgh',           country: 'Scotland', lat: 55.953, lon: -3.189 },
  { name: 'Glasgow',             country: 'Scotland', lat: 55.864, lon: -4.252 },
  { name: 'Aberdeen',            country: 'Scotland', lat: 57.150, lon: -2.110 },
  { name: 'Dundee',              country: 'Scotland', lat: 56.462, lon: -2.970 },
  { name: 'Inverness',           country: 'Scotland', lat: 57.478, lon: -4.224 },
  { name: 'Perth',               country: 'Scotland', lat: 56.396, lon: -3.474 },
  { name: 'Stirling',            country: 'Scotland', lat: 56.116, lon: -3.937 },
  { name: 'Falkirk',             country: 'Scotland', lat: 56.001, lon: -3.784 },
  { name: 'Livingston',          country: 'Scotland', lat: 55.905, lon: -3.523 },
  { name: 'Kirkcaldy',           country: 'Scotland', lat: 56.112, lon: -3.165 },
  { name: 'Dunfermline',         country: 'Scotland', lat: 56.071, lon: -3.453 },
  { name: 'Ayr',                 country: 'Scotland', lat: 55.459, lon: -4.629 },
  { name: 'Dumfries',            country: 'Scotland', lat: 55.070, lon: -3.606 },
  { name: 'Fort William',        country: 'Scotland', lat: 56.820, lon: -5.105 },
  { name: 'Oban',                country: 'Scotland', lat: 56.413, lon: -5.471 },
  { name: 'Elgin',               country: 'Scotland', lat: 57.649, lon: -3.315 },
  { name: 'Aviemore',            country: 'Scotland', lat: 57.195, lon: -3.830 },
  { name: 'Wick',                country: 'Scotland', lat: 58.440, lon: -3.089 },
  { name: 'Thurso',              country: 'Scotland', lat: 58.594, lon: -3.522 },
  { name: 'Paisley',             country: 'Scotland', lat: 55.845, lon: -4.424 },
  { name: 'East Kilbride',       country: 'Scotland', lat: 55.764, lon: -4.177 },
  { name: 'Hamilton',            country: 'Scotland', lat: 55.777, lon: -4.038 },
  { name: 'Cumbernauld',         country: 'Scotland', lat: 55.946, lon: -3.994 },
  { name: 'Kilmarnock',          country: 'Scotland', lat: 55.611, lon: -4.496 },
  { name: 'Coatbridge',          country: 'Scotland', lat: 55.862, lon: -4.027 },
  { name: 'Greenock',            country: 'Scotland', lat: 55.947, lon: -4.763 },
  { name: 'Motherwell',          country: 'Scotland', lat: 55.793, lon: -3.988 },
  { name: 'Glenrothes',          country: 'Scotland', lat: 56.196, lon: -3.177 },
  { name: 'Dumbarton',           country: 'Scotland', lat: 55.943, lon: -4.571 },
  { name: 'Airdrie',             country: 'Scotland', lat: 55.864, lon: -3.983 },
  { name: 'Irvine',              country: 'Scotland', lat: 55.611, lon: -4.659 },
  { name: 'Beith',               country: 'Scotland', lat: 55.752, lon: -4.634 },
  { name: 'Largs',               country: 'Scotland', lat: 55.793, lon: -4.869 },
  { name: 'Ardrossan',           country: 'Scotland', lat: 55.641, lon: -4.815 },
  { name: 'Saltcoats',           country: 'Scotland', lat: 55.634, lon: -4.788 },
  { name: 'Troon',               country: 'Scotland', lat: 55.542, lon: -4.656 },
  { name: 'Prestwick',           country: 'Scotland', lat: 55.495, lon: -4.614 },
  { name: 'Girvan',              country: 'Scotland', lat: 55.243, lon: -4.860 },
  { name: 'Stranraer',           country: 'Scotland', lat: 54.901, lon: -5.026 },
  { name: 'Newton Stewart',      country: 'Scotland', lat: 54.955, lon: -4.488 },
  { name: 'Castle Douglas',      country: 'Scotland', lat: 54.934, lon: -3.939 },
  { name: 'Kirkcudbright',       country: 'Scotland', lat: 54.834, lon: -3.964 },
  { name: 'Lockerbie',           country: 'Scotland', lat: 55.122, lon: -3.359 },
  { name: 'Annan',               country: 'Scotland', lat: 54.988, lon: -3.257 },
  { name: 'Jedburgh',            country: 'Scotland', lat: 55.477, lon: -2.555 },
  { name: 'Hawick',              country: 'Scotland', lat: 55.423, lon: -2.790 },
  { name: 'Galashiels',          country: 'Scotland', lat: 55.617, lon: -2.808 },
  { name: 'Peebles',             country: 'Scotland', lat: 55.653, lon: -3.188 },
  { name: 'Bathgate',            country: 'Scotland', lat: 55.903, lon: -3.643 },
  { name: 'Bonnyrigg',           country: 'Scotland', lat: 55.874, lon: -3.101 },
  { name: 'Musselburgh',         country: 'Scotland', lat: 55.942, lon: -3.054 },
  { name: 'Haddington',          country: 'Scotland', lat: 55.957, lon: -2.778 },
  { name: 'Dunbar',              country: 'Scotland', lat: 56.000, lon: -2.519 },
  { name: 'North Berwick',       country: 'Scotland', lat: 56.059, lon: -2.723 },
  { name: 'Arbroath',            country: 'Scotland', lat: 56.559, lon: -2.588 },
  { name: 'Montrose',            country: 'Scotland', lat: 56.708, lon: -2.467 },
  { name: 'Brechin',             country: 'Scotland', lat: 56.730, lon: -2.659 },
  { name: 'Forfar',              country: 'Scotland', lat: 56.648, lon: -2.888 },
  { name: 'Kirriemuir',          country: 'Scotland', lat: 56.671, lon: -3.008 },
  { name: 'Blairgowrie',         country: 'Scotland', lat: 56.588, lon: -3.338 },
  { name: 'Pitlochry',           country: 'Scotland', lat: 56.705, lon: -3.733 },
  { name: 'Aberfeldy',           country: 'Scotland', lat: 56.621, lon: -3.868 },
  { name: 'Crieff',              country: 'Scotland', lat: 56.373, lon: -3.840 },
  { name: 'Dunblane',            country: 'Scotland', lat: 56.188, lon: -3.967 },
  { name: 'Alloa',               country: 'Scotland', lat: 56.117, lon: -3.791 },
  { name: 'Clackmannan',         country: 'Scotland', lat: 56.106, lon: -3.751 },
  { name: 'Cupar',               country: 'Scotland', lat: 56.320, lon: -3.012 },
  { name: 'St Andrews',          country: 'Scotland', lat: 56.340, lon: -2.795 },
  { name: 'Leven',               country: 'Scotland', lat: 56.197, lon: -3.000 },
  { name: 'Methil',              country: 'Scotland', lat: 56.182, lon: -3.006 },
  { name: 'Burntisland',         country: 'Scotland', lat: 56.057, lon: -3.239 },
  { name: 'Inverkeithing',       country: 'Scotland', lat: 56.033, lon: -3.395 },
  { name: 'Rosyth',              country: 'Scotland', lat: 56.033, lon: -3.441 },
  { name: 'Cowdenbeath',         country: 'Scotland', lat: 56.109, lon: -3.343 },
  { name: 'Lochgelly',           country: 'Scotland', lat: 56.130, lon: -3.305 },
  { name: 'Markinch',            country: 'Scotland', lat: 56.198, lon: -3.140 },
  { name: 'Stonehaven',          country: 'Scotland', lat: 56.964, lon: -2.211 },
  { name: 'Peterhead',           country: 'Scotland', lat: 57.509, lon: -1.782 },
  { name: 'Fraserburgh',         country: 'Scotland', lat: 57.692, lon: -2.005 },
  { name: 'Banff',               country: 'Scotland', lat: 57.664, lon: -2.527 },
  { name: 'Huntly',              country: 'Scotland', lat: 57.448, lon: -2.780 },
  { name: 'Keith',               country: 'Scotland', lat: 57.544, lon: -2.952 },
  { name: 'Forres',              country: 'Scotland', lat: 57.610, lon: -3.619 },
  { name: 'Nairn',               country: 'Scotland', lat: 57.586, lon: -3.875 },
  { name: 'Dingwall',            country: 'Scotland', lat: 57.597, lon: -4.427 },
  { name: 'Tain',                country: 'Scotland', lat: 57.811, lon: -4.055 },
  { name: 'Invergordon',         country: 'Scotland', lat: 57.692, lon: -4.168 },
  { name: 'Alness',              country: 'Scotland', lat: 57.698, lon: -4.222 },
  { name: 'Bonar Bridge',        country: 'Scotland', lat: 57.889, lon: -4.360 },
  { name: 'Brora',               country: 'Scotland', lat: 58.012, lon: -3.852 },
  { name: 'Golspie',             country: 'Scotland', lat: 57.972, lon: -3.974 },
  { name: 'Helmsdale',           country: 'Scotland', lat: 58.114, lon: -3.650 },
  { name: 'Lairg',               country: 'Scotland', lat: 58.016, lon: -4.406 },
  { name: 'Ullapool',            country: 'Scotland', lat: 57.895, lon: -5.160 },
  { name: 'Gairloch',            country: 'Scotland', lat: 57.723, lon: -5.681 },
  { name: 'Kyle of Lochalsh',    country: 'Scotland', lat: 57.274, lon: -5.716 },
  { name: 'Portree',             country: 'Scotland', lat: 57.413, lon: -6.196 },
  { name: 'Broadford',           country: 'Scotland', lat: 57.238, lon: -5.906 },
  { name: 'Mallaig',             country: 'Scotland', lat: 57.006, lon: -5.828 },
  { name: 'Campbeltown',         country: 'Scotland', lat: 55.426, lon: -5.596 },
  { name: 'Rothesay',            country: 'Scotland', lat: 55.837, lon: -5.054 },
  { name: 'Lochgilphead',        country: 'Scotland', lat: 56.038, lon: -5.437 },
  { name: 'Inveraray',           country: 'Scotland', lat: 56.228, lon: -5.077 },
  { name: 'Tobermory',           country: 'Scotland', lat: 56.623, lon: -6.068 },
  { name: 'Stornoway',           country: 'Scotland', lat: 58.209, lon: -6.389 },
  { name: 'Kirkwall',            country: 'Scotland', lat: 58.982, lon: -2.960 },
  { name: 'Lerwick',             country: 'Scotland', lat: 60.155, lon: -1.145 },
  // ── Wales ──────────────────────────────────────────────────
  { name: 'Cardiff',             country: 'Wales', lat: 51.481, lon: -3.180 },
  { name: 'Swansea',             country: 'Wales', lat: 51.621, lon: -3.943 },
  { name: 'Newport',             country: 'Wales', lat: 51.588, lon: -2.998 },
  { name: 'Rhondda',             country: 'Wales', lat: 51.659, lon: -3.429 },
  { name: 'Bridgend',            country: 'Wales', lat: 51.505, lon: -3.577 },
  { name: 'Barry',               country: 'Wales', lat: 51.406, lon: -3.284 },
  { name: 'Neath',               country: 'Wales', lat: 51.659, lon: -3.808 },
  { name: 'Port Talbot',         country: 'Wales', lat: 51.591, lon: -3.787 },
  { name: 'Merthyr Tydfil',      country: 'Wales', lat: 51.747, lon: -3.378 },
  { name: 'Caerphilly',          country: 'Wales', lat: 51.578, lon: -3.219 },
  { name: 'Pontypool',           country: 'Wales', lat: 51.700, lon: -3.039 },
  { name: 'Cwmbran',             country: 'Wales', lat: 51.655, lon: -3.003 },
  { name: 'Llanelli',            country: 'Wales', lat: 51.685, lon: -4.163 },
  { name: 'Haverfordwest',       country: 'Wales', lat: 51.802, lon: -4.972 },
  { name: 'Aberystwyth',         country: 'Wales', lat: 52.415, lon: -4.082 },
  { name: 'Bangor',              country: 'Wales', lat: 53.228, lon: -4.129 },
  { name: 'Caernarfon',          country: 'Wales', lat: 53.139, lon: -4.271 },
  { name: 'Rhyl',                country: 'Wales', lat: 53.319, lon: -3.490 },
  { name: 'Colwyn Bay',          country: 'Wales', lat: 53.293, lon: -3.725 },
  { name: 'Llandudno',           country: 'Wales', lat: 53.325, lon: -3.827 },
  { name: 'Wrexham',             country: 'Wales', lat: 53.046, lon: -2.995 },
  { name: 'Flint',               country: 'Wales', lat: 53.248, lon: -3.135 },
  { name: 'Mold',                country: 'Wales', lat: 53.166, lon: -3.141 },
  { name: 'Ruthin',              country: 'Wales', lat: 53.116, lon: -3.310 },
  { name: 'Denbigh',             country: 'Wales', lat: 53.174, lon: -3.419 },
  { name: 'Abergele',            country: 'Wales', lat: 53.285, lon: -3.581 },
  { name: 'Prestatyn',           country: 'Wales', lat: 53.335, lon: -3.405 },
  { name: 'Holyhead',            country: 'Wales', lat: 53.309, lon: -4.632 },
  { name: 'Llangefni',           country: 'Wales', lat: 53.256, lon: -4.310 },
  { name: 'Pwllheli',            country: 'Wales', lat: 52.890, lon: -4.416 },
  { name: 'Porthmadog',          country: 'Wales', lat: 52.929, lon: -4.131 },
  { name: 'Blaenau Ffestiniog',  country: 'Wales', lat: 52.996, lon: -3.943 },
  { name: 'Dolgellau',           country: 'Wales', lat: 52.744, lon: -3.885 },
  { name: 'Machynlleth',         country: 'Wales', lat: 52.593, lon: -3.854 },
  { name: 'Cardigan',            country: 'Wales', lat: 52.083, lon: -4.659 },
  { name: 'Lampeter',            country: 'Wales', lat: 52.113, lon: -4.075 },
  { name: 'Llandeilo',           country: 'Wales', lat: 51.888, lon: -3.987 },
  { name: 'Llandovery',          country: 'Wales', lat: 51.996, lon: -3.797 },
  { name: 'Brecon',              country: 'Wales', lat: 51.946, lon: -3.391 },
  { name: 'Builth Wells',        country: 'Wales', lat: 52.149, lon: -3.408 },
  { name: 'Welshpool',           country: 'Wales', lat: 52.659, lon: -3.146 },
  { name: 'Newtown',             country: 'Wales', lat: 52.514, lon: -3.315 },
  { name: 'Llandrindod Wells',   country: 'Wales', lat: 52.245, lon: -3.378 },
  { name: 'Knighton',            country: 'Wales', lat: 52.343, lon: -3.046 },
  { name: 'Pembroke',            country: 'Wales', lat: 51.674, lon: -4.915 },
  { name: 'Milford Haven',       country: 'Wales', lat: 51.714, lon: -5.042 },
  { name: 'Tenby',               country: 'Wales', lat: 51.673, lon: -4.702 },
  { name: 'Carmarthen',          country: 'Wales', lat: 51.856, lon: -4.312 },
  { name: 'Ammanford',           country: 'Wales', lat: 51.797, lon: -3.993 },
  { name: 'Pontardawe',          country: 'Wales', lat: 51.723, lon: -3.851 },
  { name: 'Maesteg',             country: 'Wales', lat: 51.608, lon: -3.658 },
  { name: 'Porthcawl',           country: 'Wales', lat: 51.481, lon: -3.698 },
  { name: 'Penarth',             country: 'Wales', lat: 51.436, lon: -3.176 },
  { name: 'Pontypridd',          country: 'Wales', lat: 51.601, lon: -3.343 },
  { name: 'Aberdare',            country: 'Wales', lat: 51.715, lon: -3.447 },
  { name: 'Treorchy',            country: 'Wales', lat: 51.660, lon: -3.501 },
  { name: 'Bargoed',             country: 'Wales', lat: 51.693, lon: -3.237 },
  { name: 'Blackwood',           country: 'Wales', lat: 51.669, lon: -3.195 },
  { name: 'Ebbw Vale',           country: 'Wales', lat: 51.777, lon: -3.204 },
  { name: 'Tredegar',            country: 'Wales', lat: 51.778, lon: -3.240 },
  { name: 'Abergavenny',         country: 'Wales', lat: 51.823, lon: -3.017 },
  { name: 'Monmouth',            country: 'Wales', lat: 51.812, lon: -2.716 },
  // ── Northern Ireland ───────────────────────────────────────
  { name: 'Belfast',             country: 'Northern Ireland', lat: 54.597, lon: -5.930 },
  { name: 'Derry',               country: 'Northern Ireland', lat: 54.997, lon: -7.309 },
  { name: 'Lisburn',             country: 'Northern Ireland', lat: 54.516, lon: -6.058 },
  { name: 'Newry',               country: 'Northern Ireland', lat: 54.176, lon: -6.339 },
  { name: 'Armagh',              country: 'Northern Ireland', lat: 54.350, lon: -6.654 },
  { name: 'Ballymena',           country: 'Northern Ireland', lat: 54.864, lon: -6.276 },
  { name: 'Antrim',              country: 'Northern Ireland', lat: 54.719, lon: -6.207 },
  { name: 'Coleraine',           country: 'Northern Ireland', lat: 55.133, lon: -6.666 },
  { name: 'Omagh',               country: 'Northern Ireland', lat: 54.598, lon: -7.301 },
  { name: 'Enniskillen',         country: 'Northern Ireland', lat: 54.344, lon: -7.632 },
  { name: 'Bangor',              country: 'Northern Ireland', lat: 54.659, lon: -5.668 },
  { name: 'Newtownabbey',        country: 'Northern Ireland', lat: 54.670, lon: -5.909 },
  { name: 'Castlereagh',         country: 'Northern Ireland', lat: 54.566, lon: -5.882 },
  { name: 'Ballymoney',          country: 'Northern Ireland', lat: 55.072, lon: -6.515 },
  { name: 'Larne',               country: 'Northern Ireland', lat: 54.858, lon: -5.824 },
  { name: 'Carrickfergus',       country: 'Northern Ireland', lat: 54.716, lon: -5.808 },
  { name: 'Newtownards',         country: 'Northern Ireland', lat: 54.591, lon: -5.691 },
  { name: 'Downpatrick',         country: 'Northern Ireland', lat: 54.328, lon: -5.713 },
  { name: 'Portadown',           country: 'Northern Ireland', lat: 54.418, lon: -6.454 },
  { name: 'Lurgan',              country: 'Northern Ireland', lat: 54.467, lon: -6.332 },
  { name: 'Craigavon',           country: 'Northern Ireland', lat: 54.450, lon: -6.389 },
  { name: 'Magherafelt',         country: 'Northern Ireland', lat: 54.756, lon: -6.606 },
  { name: 'Cookstown',           country: 'Northern Ireland', lat: 54.644, lon: -6.744 },
  { name: 'Dungannon',           country: 'Northern Ireland', lat: 54.508, lon: -6.769 },
  { name: 'Strabane',            country: 'Northern Ireland', lat: 54.828, lon: -7.464 },
  { name: 'Limavady',            country: 'Northern Ireland', lat: 55.052, lon: -6.950 },
  { name: 'Portrush',            country: 'Northern Ireland', lat: 55.205, lon: -6.658 },
  { name: 'Ballycastle',         country: 'Northern Ireland', lat: 55.202, lon: -6.244 },
  { name: 'Cushendall',          country: 'Northern Ireland', lat: 55.072, lon: -6.059 },
  { name: 'Newcastle',           country: 'Northern Ireland', lat: 54.201, lon: -5.893 },
  { name: 'Warrenpoint',         country: 'Northern Ireland', lat: 54.100, lon: -6.249 },
  // ── Ireland ────────────────────────────────────────────────
  { name: 'Dublin',              country: 'Ireland', lat: 53.333, lon: -6.249 },
  { name: 'Cork',                country: 'Ireland', lat: 51.897, lon: -8.471 },
  { name: 'Galway',              country: 'Ireland', lat: 53.274, lon: -9.050 },
  { name: 'Limerick',            country: 'Ireland', lat: 52.668, lon: -8.630 },
  { name: 'Waterford',           country: 'Ireland', lat: 52.260, lon: -7.110 },
  { name: 'Drogheda',            country: 'Ireland', lat: 53.719, lon: -6.349 },
  { name: 'Dundalk',             country: 'Ireland', lat: 54.000, lon: -6.419 },
  { name: 'Bray',                country: 'Ireland', lat: 53.203, lon: -6.099 },
  { name: 'Navan',               country: 'Ireland', lat: 53.653, lon: -6.682 },
  { name: 'Kilkenny',            country: 'Ireland', lat: 52.654, lon: -7.252 },
  { name: 'Ennis',               country: 'Ireland', lat: 52.843, lon: -8.986 },
  { name: 'Carlow',              country: 'Ireland', lat: 52.836, lon: -6.927 },
  { name: 'Tralee',              country: 'Ireland', lat: 52.271, lon: -9.701 },
  { name: 'Newbridge',           country: 'Ireland', lat: 53.180, lon: -6.796 },
  { name: 'Portlaoise',          country: 'Ireland', lat: 53.036, lon: -7.300 },
  { name: 'Mullingar',           country: 'Ireland', lat: 53.525, lon: -7.338 },
  { name: 'Wexford',             country: 'Ireland', lat: 52.337, lon: -6.461 },
  { name: 'Letterkenny',         country: 'Ireland', lat: 54.953, lon: -7.737 },
  { name: 'Sligo',               country: 'Ireland', lat: 54.270, lon: -8.470 },
  { name: 'Clonmel',             country: 'Ireland', lat: 52.355, lon: -7.703 },
  { name: 'Athlone',             country: 'Ireland', lat: 53.433, lon: -7.940 },
  { name: 'Tullamore',           country: 'Ireland', lat: 53.274, lon: -7.491 },
  { name: 'Castlebar',           country: 'Ireland', lat: 53.854, lon: -9.297 },
  { name: 'Monaghan',            country: 'Ireland', lat: 54.249, lon: -6.968 },
  { name: 'Cavan',               country: 'Ireland', lat: 53.992, lon: -7.361 },
  { name: 'Longford',            country: 'Ireland', lat: 53.727, lon: -7.793 },
  { name: 'Roscommon',           country: 'Ireland', lat: 53.628, lon: -8.190 },
  { name: 'Ballina',             country: 'Ireland', lat: 54.116, lon: -9.155 },
  { name: 'Westport',            country: 'Ireland', lat: 53.800, lon: -9.517 },
  { name: 'Clifden',             country: 'Ireland', lat: 53.489, lon: -9.994 },
  { name: 'Killarney',           country: 'Ireland', lat: 52.059, lon: -9.507 },
  { name: 'Mallow',              country: 'Ireland', lat: 52.137, lon: -8.638 },
  { name: 'Youghal',             country: 'Ireland', lat: 51.953, lon: -7.843 },
  { name: 'Cobh',                country: 'Ireland', lat: 51.851, lon: -8.296 },
  { name: 'Fermoy',              country: 'Ireland', lat: 52.138, lon: -8.270 },
  { name: 'Bandon',              country: 'Ireland', lat: 51.748, lon: -8.742 },
  { name: 'Skibbereen',          country: 'Ireland', lat: 51.553, lon: -9.267 },
  // ── France ─────────────────────────────────────────────────
  { name: 'Paris',               country: 'France', lat: 48.853, lon:  2.349 },
  { name: 'Lyon',                country: 'France', lat: 45.750, lon:  4.850 },
  { name: 'Marseille',           country: 'France', lat: 43.297, lon:  5.381 },
  { name: 'Bordeaux',            country: 'France', lat: 44.837, lon: -0.580 },
  { name: 'Toulouse',            country: 'France', lat: 43.605, lon:  1.444 },
  { name: 'Nice',                country: 'France', lat: 43.710, lon:  7.262 },
  { name: 'Nantes',              country: 'France', lat: 47.218, lon: -1.553 },
  { name: 'Strasbourg',          country: 'France', lat: 48.573, lon:  7.752 },
  { name: 'Montpellier',         country: 'France', lat: 43.611, lon:  3.877 },
  { name: 'Rennes',              country: 'France', lat: 48.114, lon: -1.679 },
  { name: 'Lille',               country: 'France', lat: 50.629, lon:  3.057 },
  { name: 'Reims',               country: 'France', lat: 49.258, lon:  4.032 },
  { name: 'Le Havre',            country: 'France', lat: 49.494, lon:  0.108 },
  { name: 'Saint-Étienne',       country: 'France', lat: 45.440, lon:  4.387 },
  { name: 'Toulon',              country: 'France', lat: 43.124, lon:  5.928 },
  { name: 'Grenoble',            country: 'France', lat: 45.188, lon:  5.724 },
  { name: 'Dijon',               country: 'France', lat: 47.322, lon:  5.041 },
  { name: 'Angers',              country: 'France', lat: 47.478, lon: -0.563 },
  { name: 'Nîmes',               country: 'France', lat: 43.836, lon:  4.360 },
  { name: 'Villeurbanne',        country: 'France', lat: 45.771, lon:  4.889 },
  { name: 'Clermont-Ferrand',    country: 'France', lat: 45.779, lon:  3.087 },
  { name: 'Le Mans',             country: 'France', lat: 48.000, lon:  0.200 },
  { name: 'Aix-en-Provence',     country: 'France', lat: 43.530, lon:  5.447 },
  { name: 'Brest',               country: 'France', lat: 48.390, lon: -4.486 },
  { name: 'Tours',               country: 'France', lat: 47.394, lon:  0.690 },
  { name: 'Amiens',              country: 'France', lat: 49.894, lon:  2.296 },
  { name: 'Limoges',             country: 'France', lat: 45.833, lon:  1.262 },
  { name: 'Clermont',            country: 'France', lat: 45.779, lon:  3.087 },
  { name: 'Perpignan',           country: 'France', lat: 42.698, lon:  2.895 },
  { name: 'Besançon',            country: 'France', lat: 47.238, lon:  6.024 },
  { name: 'Orléans',             country: 'France', lat: 47.903, lon:  1.909 },
  { name: 'Rouen',               country: 'France', lat: 49.443, lon:  1.100 },
  { name: 'Mulhouse',            country: 'France', lat: 47.750, lon:  7.335 },
  { name: 'Caen',                country: 'France', lat: 49.182, lon: -0.371 },
  { name: 'Boulogne-sur-Mer',    country: 'France', lat: 50.727, lon:  1.614 },
  { name: 'Calais',              country: 'France', lat: 50.951, lon:  1.858 },
  { name: 'Dunkirk',             country: 'France', lat: 51.034, lon:  2.377 },
  { name: 'Valenciennes',        country: 'France', lat: 50.358, lon:  3.523 },
  { name: 'Metz',                country: 'France', lat: 49.120, lon:  6.177 },
  { name: 'Nancy',               country: 'France', lat: 48.693, lon:  6.184 },
  { name: 'Troyes',              country: 'France', lat: 48.300, lon:  4.083 },
  { name: 'Pau',                 country: 'France', lat: 43.300, lon: -0.367 },
  { name: 'Bayonne',             country: 'France', lat: 43.493, lon: -1.474 },
  { name: 'Biarritz',            country: 'France', lat: 43.480, lon: -1.560 },
  { name: 'La Rochelle',         country: 'France', lat: 46.160, lon: -1.152 },
  { name: 'Poitiers',            country: 'France', lat: 46.580, lon:  0.341 },
  { name: 'Niort',               country: 'France', lat: 46.325, lon: -0.457 },
  { name: 'Angoulême',           country: 'France', lat: 45.650, lon:  0.157 },
  { name: 'Périgueux',           country: 'France', lat: 45.187, lon:  0.720 },
  { name: 'Agen',                country: 'France', lat: 44.200, lon:  0.617 },
  { name: 'Tarbes',              country: 'France', lat: 43.233, lon:  0.083 },
  { name: 'Montauban',           country: 'France', lat: 44.017, lon:  1.350 },
  { name: 'Albi',                country: 'France', lat: 43.933, lon:  2.150 },
  { name: 'Béziers',             country: 'France', lat: 43.345, lon:  3.216 },
  { name: 'Sète',                country: 'France', lat: 43.402, lon:  3.697 },
  { name: 'Avignon',             country: 'France', lat: 43.950, lon:  4.808 },
  { name: 'Arles',               country: 'France', lat: 43.677, lon:  4.628 },
  { name: 'Cannes',              country: 'France', lat: 43.553, lon:  7.017 },
  { name: 'Antibes',             country: 'France', lat: 43.580, lon:  7.128 },
  { name: 'Grasse',              country: 'France', lat: 43.660, lon:  6.920 },
  { name: 'Fréjus',              country: 'France', lat: 43.433, lon:  6.737 },
  { name: 'Hyères',              country: 'France', lat: 43.120, lon:  6.128 },
  { name: 'Ajaccio',             country: 'France', lat: 41.926, lon:  8.739 },
  { name: 'Bastia',              country: 'France', lat: 42.697, lon:  9.451 },
  { name: 'Quimper',             country: 'France', lat: 47.996, lon: -4.099 },
  { name: 'Lorient',             country: 'France', lat: 47.750, lon: -3.367 },
  { name: 'Vannes',              country: 'France', lat: 47.658, lon: -2.761 },
  { name: 'Saint-Brieuc',        country: 'France', lat: 48.514, lon: -2.765 },
  { name: 'Lannion',             country: 'France', lat: 48.733, lon: -3.457 },
  { name: 'Cherbourg',           country: 'France', lat: 49.633, lon: -1.617 },
  { name: 'Saint-Malo',          country: 'France', lat: 48.650, lon: -2.017 },
  { name: 'Chartres',            country: 'France', lat: 48.447, lon:  1.487 },
  { name: 'Évreux',              country: 'France', lat: 49.020, lon:  1.151 },
  { name: 'Laval',               country: 'France', lat: 48.074, lon: -0.768 },
  { name: 'Alençon',             country: 'France', lat: 48.432, lon:  0.092 },
  { name: 'Auxerre',             country: 'France', lat: 47.798, lon:  3.568 },
  { name: 'Nevers',              country: 'France', lat: 46.988, lon:  3.159 },
  { name: 'Mâcon',               country: 'France', lat: 46.306, lon:  4.829 },
  { name: 'Chalon-sur-Saône',    country: 'France', lat: 46.780, lon:  4.853 },
  { name: 'Bourg-en-Bresse',     country: 'France', lat: 46.205, lon:  5.228 },
  { name: 'Annecy',              country: 'France', lat: 45.899, lon:  6.129 },
  { name: 'Chambéry',            country: 'France', lat: 45.564, lon:  5.917 },
  { name: 'Valence',             country: 'France', lat: 44.933, lon:  4.892 },
  { name: 'Montélimar',          country: 'France', lat: 44.558, lon:  4.752 },
  { name: 'Orange',              country: 'France', lat: 44.138, lon:  4.808 },
  { name: 'Draguignan',          country: 'France', lat: 43.538, lon:  6.465 },
  // ── Spain ──────────────────────────────────────────────────
  { name: 'Madrid',              country: 'Spain', lat: 40.417, lon: -3.703 },
  { name: 'Barcelona',           country: 'Spain', lat: 41.385, lon:  2.173 },
  { name: 'Valencia',            country: 'Spain', lat: 39.470, lon: -0.376 },
  { name: 'Seville',             country: 'Spain', lat: 37.389, lon: -5.984 },
  { name: 'Zaragoza',            country: 'Spain', lat: 41.656, lon: -0.876 },
  { name: 'Málaga',              country: 'Spain', lat: 36.721, lon: -4.421 },
  { name: 'Murcia',              country: 'Spain', lat: 37.987, lon: -1.130 },
  { name: 'Palma',               country: 'Spain', lat: 39.569, lon:  2.650 },
  { name: 'Las Palmas',          country: 'Spain', lat: 28.124, lon: -15.436 },
  { name: 'Bilbao',              country: 'Spain', lat: 43.263, lon: -2.935 },
  { name: 'Alicante',            country: 'Spain', lat: 38.345, lon: -0.483 },
  { name: 'Córdoba',             country: 'Spain', lat: 37.888, lon: -4.779 },
  { name: 'Valladolid',          country: 'Spain', lat: 41.652, lon: -4.724 },
  { name: 'Vigo',                country: 'Spain', lat: 42.231, lon: -8.713 },
  { name: 'Gijón',               country: 'Spain', lat: 43.545, lon: -5.663 },
  { name: 'L\'Hospitalet',       country: 'Spain', lat: 41.360, lon:  2.099 },
  { name: 'A Coruña',            country: 'Spain', lat: 43.371, lon: -8.396 },
  { name: 'Granada',             country: 'Spain', lat: 37.177, lon: -3.598 },
  { name: 'Vitoria-Gasteiz',     country: 'Spain', lat: 42.850, lon: -2.674 },
  { name: 'Elche',               country: 'Spain', lat: 38.267, lon: -0.700 },
  { name: 'Oviedo',              country: 'Spain', lat: 43.361, lon: -5.850 },
  { name: 'Santa Cruz de Tenerife', country: 'Spain', lat: 28.463, lon: -16.252 },
  { name: 'Badalona',            country: 'Spain', lat: 41.450, lon:  2.247 },
  { name: 'Cartagena',           country: 'Spain', lat: 37.606, lon: -0.986 },
  { name: 'Terrassa',            country: 'Spain', lat: 41.563, lon:  2.009 },
  { name: 'Jerez de la Frontera',country: 'Spain', lat: 36.687, lon: -6.136 },
  { name: 'Sabadell',            country: 'Spain', lat: 41.543, lon:  2.108 },
  { name: 'Alcalá de Henares',   country: 'Spain', lat: 40.482, lon: -3.364 },
  { name: 'Fuenlabrada',         country: 'Spain', lat: 40.284, lon: -3.797 },
  { name: 'Móstoles',            country: 'Spain', lat: 40.322, lon: -3.864 },
  { name: 'Getafe',              country: 'Spain', lat: 40.305, lon: -3.733 },
  { name: 'Leganés',             country: 'Spain', lat: 40.328, lon: -3.764 },
  { name: 'Alcorcón',            country: 'Spain', lat: 40.345, lon: -3.824 },
  { name: 'Burgos',              country: 'Spain', lat: 42.343, lon: -3.699 },
  { name: 'Santander',           country: 'Spain', lat: 43.462, lon: -3.810 },
  { name: 'San Sebastián',       country: 'Spain', lat: 43.321, lon: -1.984 },
  { name: 'Pamplona',            country: 'Spain', lat: 42.812, lon: -1.645 },
  { name: 'Logroño',             country: 'Spain', lat: 42.466, lon: -2.445 },
  { name: 'León',                country: 'Spain', lat: 42.599, lon: -5.571 },
  { name: 'Salamanca',           country: 'Spain', lat: 40.965, lon: -5.664 },
  { name: 'Badajoz',             country: 'Spain', lat: 38.879, lon: -6.970 },
  { name: 'Huelva',              country: 'Spain', lat: 37.261, lon: -6.949 },
  { name: 'Almería',             country: 'Spain', lat: 36.840, lon: -2.466 },
  { name: 'Jaén',                country: 'Spain', lat: 37.779, lon: -3.790 },
  { name: 'Cádiz',               country: 'Spain', lat: 36.535, lon: -6.299 },
  { name: 'Algeciras',           country: 'Spain', lat: 36.140, lon: -5.453 },
  { name: 'Marbella',            country: 'Spain', lat: 36.510, lon: -4.882 },
  { name: 'Torremolinos',        country: 'Spain', lat: 36.621, lon: -4.500 },
  { name: 'Benidorm',            country: 'Spain', lat: 38.539, lon: -0.126 },
  { name: 'Castellón',           country: 'Spain', lat: 39.987, lon: -0.038 },
  { name: 'Tarragona',           country: 'Spain', lat: 41.118, lon:  1.245 },
  { name: 'Lleida',              country: 'Spain', lat: 41.615, lon:  0.624 },
  { name: 'Girona',              country: 'Spain', lat: 41.982, lon:  2.824 },
  { name: 'Manresa',             country: 'Spain', lat: 41.728, lon:  1.826 },
  { name: 'Mataró',              country: 'Spain', lat: 41.539, lon:  2.445 },
  { name: 'Reus',                country: 'Spain', lat: 41.155, lon:  1.108 },
  { name: 'Santiago de Compostela', country: 'Spain', lat: 42.878, lon: -8.544 },
  { name: 'Pontevedra',          country: 'Spain', lat: 42.433, lon: -8.650 },
  { name: 'Lugo',                country: 'Spain', lat: 43.012, lon: -7.556 },
  { name: 'Ourense',             country: 'Spain', lat: 42.336, lon: -7.864 },
  { name: 'Ferrol',              country: 'Spain', lat: 43.483, lon: -8.232 },
  { name: 'Albacete',            country: 'Spain', lat: 38.994, lon: -1.856 },
  { name: 'Ciudad Real',         country: 'Spain', lat: 38.986, lon: -3.920 },
  { name: 'Toledo',              country: 'Spain', lat: 39.857, lon: -4.024 },
  { name: 'Guadalajara',         country: 'Spain', lat: 40.634, lon: -3.166 },
  { name: 'Cuenca',              country: 'Spain', lat: 40.070, lon: -2.137 },
  { name: 'Cáceres',             country: 'Spain', lat: 39.476, lon: -6.372 },
  { name: 'Mérida',              country: 'Spain', lat: 38.918, lon: -6.343 },
  { name: 'Ibiza',               country: 'Spain', lat: 38.908, lon:  1.432 },
  { name: 'Mahón',               country: 'Spain', lat: 39.888, lon:  4.266 },
  // ── Portugal ───────────────────────────────────────────────
  { name: 'Lisbon',              country: 'Portugal', lat: 38.717, lon: -9.143 },
  { name: 'Porto',               country: 'Portugal', lat: 41.157, lon: -8.629 },
  { name: 'Braga',               country: 'Portugal', lat: 41.551, lon: -8.426 },
  { name: 'Amadora',             country: 'Portugal', lat: 38.753, lon: -9.228 },
  { name: 'Setúbal',             country: 'Portugal', lat: 38.524, lon: -8.894 },
  { name: 'Coimbra',             country: 'Portugal', lat: 40.211, lon: -8.429 },
  { name: 'Funchal',             country: 'Portugal', lat: 32.650, lon: -16.910 },
  { name: 'Almada',              country: 'Portugal', lat: 38.679, lon: -9.158 },
  { name: 'Agualva-Cacém',       country: 'Portugal', lat: 38.768, lon: -9.301 },
  { name: 'Vila Nova de Gaia',   country: 'Portugal', lat: 41.133, lon: -8.616 },
  { name: 'Queluz',              country: 'Portugal', lat: 38.754, lon: -9.255 },
  { name: 'Aveiro',              country: 'Portugal', lat: 40.641, lon: -8.654 },
  { name: 'Viseu',               country: 'Portugal', lat: 40.661, lon: -7.909 },
  { name: 'Leiria',              country: 'Portugal', lat: 39.744, lon: -8.807 },
  { name: 'Faro',                country: 'Portugal', lat: 37.020, lon: -7.935 },
  { name: 'Évora',               country: 'Portugal', lat: 38.571, lon: -7.908 },
  { name: 'Guimarães',           country: 'Portugal', lat: 41.443, lon: -8.291 },
  { name: 'Viana do Castelo',    country: 'Portugal', lat: 41.694, lon: -8.835 },
  { name: 'Beja',                country: 'Portugal', lat: 38.016, lon: -7.866 },
  { name: 'Bragança',            country: 'Portugal', lat: 41.806, lon: -6.757 },
  { name: 'Santarém',            country: 'Portugal', lat: 39.235, lon: -8.685 },
  { name: 'Castelo Branco',      country: 'Portugal', lat: 39.820, lon: -7.492 },
  { name: 'Portimão',            country: 'Portugal', lat: 37.136, lon: -8.538 },
  { name: 'Lagos',               country: 'Portugal', lat: 37.102, lon: -8.674 },
  { name: 'Albufeira',           country: 'Portugal', lat: 37.089, lon: -8.250 },
  { name: 'Quarteira',           country: 'Portugal', lat: 37.066, lon: -8.100 },
  { name: 'Olhão',               country: 'Portugal', lat: 37.026, lon: -7.841 },
  { name: 'Tavira',              country: 'Portugal', lat: 37.128, lon: -7.651 },
  { name: 'Caldas da Rainha',    country: 'Portugal', lat: 39.401, lon: -9.134 },
  { name: 'Peniche',             country: 'Portugal', lat: 39.356, lon: -9.381 },
  { name: 'Póvoa de Varzim',     country: 'Portugal', lat: 41.381, lon: -8.760 },
  { name: 'Vila do Conde',       country: 'Portugal', lat: 41.352, lon: -8.748 },
  { name: 'Matosinhos',          country: 'Portugal', lat: 41.184, lon: -8.696 },
  { name: 'Gondomar',            country: 'Portugal', lat: 41.141, lon: -8.532 },
  { name: 'Barcelos',            country: 'Portugal', lat: 41.537, lon: -8.618 },
  // ── Belgium ────────────────────────────────────────────────
  { name: 'Brussels',            country: 'Belgium', lat: 50.850, lon:  4.352 },
  { name: 'Antwerp',             country: 'Belgium', lat: 51.221, lon:  4.400 },
  { name: 'Ghent',               country: 'Belgium', lat: 51.054, lon:  3.717 },
  { name: 'Charleroi',           country: 'Belgium', lat: 50.411, lon:  4.444 },
  { name: 'Liège',               country: 'Belgium', lat: 50.633, lon:  5.567 },
  { name: 'Bruges',              country: 'Belgium', lat: 51.209, lon:  3.224 },
  { name: 'Namur',               country: 'Belgium', lat: 50.467, lon:  4.867 },
  { name: 'Leuven',              country: 'Belgium', lat: 50.879, lon:  4.700 },
  { name: 'Mons',                country: 'Belgium', lat: 50.454, lon:  3.952 },
  { name: 'Aalst',               country: 'Belgium', lat: 50.937, lon:  4.042 },
  { name: 'Mechelen',            country: 'Belgium', lat: 51.028, lon:  4.479 },
  { name: 'La Louvière',         country: 'Belgium', lat: 50.472, lon:  4.186 },
  { name: 'Kortrijk',            country: 'Belgium', lat: 50.823, lon:  3.264 },
  { name: 'Hasselt',             country: 'Belgium', lat: 50.931, lon:  5.338 },
  { name: 'Ostend',              country: 'Belgium', lat: 51.229, lon:  2.917 },
  { name: 'Sint-Niklaas',        country: 'Belgium', lat: 51.158, lon:  4.143 },
  { name: 'Tournai',             country: 'Belgium', lat: 50.605, lon:  3.389 },
  { name: 'Genk',                country: 'Belgium', lat: 50.966, lon:  5.499 },
  { name: 'Seraing',             country: 'Belgium', lat: 50.591, lon:  5.509 },
  { name: 'Roeselare',           country: 'Belgium', lat: 50.945, lon:  3.124 },
  { name: 'Mouscron',            country: 'Belgium', lat: 50.745, lon:  3.207 },
  { name: 'Verviers',            country: 'Belgium', lat: 50.589, lon:  5.866 },
  { name: 'Turnhout',            country: 'Belgium', lat: 51.323, lon:  4.944 },
  { name: 'Geel',                country: 'Belgium', lat: 51.162, lon:  4.989 },
  { name: 'Arlon',               country: 'Belgium', lat: 49.682, lon:  5.815 },
  { name: 'Dinant',              country: 'Belgium', lat: 50.261, lon:  4.912 },
  // ── Germany ────────────────────────────────────────────────
  { name: 'Berlin',              country: 'Germany', lat: 52.520, lon: 13.405 },
  { name: 'Hamburg',             country: 'Germany', lat: 53.551, lon:  9.993 },
  { name: 'Munich',              country: 'Germany', lat: 48.137, lon: 11.576 },
  { name: 'Cologne',             country: 'Germany', lat: 50.938, lon:  6.960 },
  { name: 'Frankfurt',           country: 'Germany', lat: 50.110, lon:  8.682 },
  { name: 'Stuttgart',           country: 'Germany', lat: 48.775, lon:  9.182 },
  { name: 'Düsseldorf',          country: 'Germany', lat: 51.228, lon:  6.773 },
  { name: 'Leipzig',             country: 'Germany', lat: 51.340, lon: 12.375 },
  { name: 'Dortmund',            country: 'Germany', lat: 51.514, lon:  7.465 },
  { name: 'Essen',               country: 'Germany', lat: 51.458, lon:  7.015 },
  { name: 'Bremen',              country: 'Germany', lat: 53.079, lon:  8.801 },
  { name: 'Dresden',             country: 'Germany', lat: 51.051, lon: 13.737 },
  { name: 'Hanover',             country: 'Germany', lat: 52.374, lon:  9.738 },
  { name: 'Nuremberg',           country: 'Germany', lat: 49.453, lon: 11.078 },
  { name: 'Duisburg',            country: 'Germany', lat: 51.435, lon:  6.762 },
  { name: 'Bochum',              country: 'Germany', lat: 51.482, lon:  7.218 },
  { name: 'Wuppertal',           country: 'Germany', lat: 51.257, lon:  7.151 },
  { name: 'Bielefeld',           country: 'Germany', lat: 52.021, lon:  8.532 },
  { name: 'Bonn',                country: 'Germany', lat: 50.735, lon:  7.099 },
  { name: 'Münster',             country: 'Germany', lat: 51.962, lon:  7.625 },
  { name: 'Mannheim',            country: 'Germany', lat: 49.487, lon:  8.466 },
  { name: 'Karlsruhe',           country: 'Germany', lat: 49.006, lon:  8.404 },
  { name: 'Augsburg',            country: 'Germany', lat: 48.371, lon: 10.898 },
  { name: 'Wiesbaden',           country: 'Germany', lat: 50.078, lon:  8.239 },
  { name: 'Gelsenkirchen',       country: 'Germany', lat: 51.517, lon:  7.087 },
  { name: 'Mönchengladbach',     country: 'Germany', lat: 51.200, lon:  6.436 },
  { name: 'Braunschweig',        country: 'Germany', lat: 52.267, lon: 10.519 },
  { name: 'Chemnitz',            country: 'Germany', lat: 50.833, lon: 12.917 },
  { name: 'Kiel',                country: 'Germany', lat: 54.323, lon: 10.123 },
  { name: 'Aachen',              country: 'Germany', lat: 50.776, lon:  6.084 },
  { name: 'Halle',               country: 'Germany', lat: 51.482, lon: 11.970 },
  { name: 'Magdeburg',           country: 'Germany', lat: 52.131, lon: 11.640 },
  { name: 'Freiburg',            country: 'Germany', lat: 47.999, lon:  7.842 },
  { name: 'Krefeld',             country: 'Germany', lat: 51.336, lon:  6.587 },
  { name: 'Lübeck',              country: 'Germany', lat: 53.870, lon: 10.687 },
  { name: 'Oberhausen',          country: 'Germany', lat: 51.471, lon:  6.861 },
  { name: 'Erfurt',              country: 'Germany', lat: 50.978, lon: 11.029 },
  { name: 'Mainz',               country: 'Germany', lat: 49.998, lon:  8.273 },
  { name: 'Rostock',             country: 'Germany', lat: 54.092, lon: 12.100 },
  { name: 'Kassel',              country: 'Germany', lat: 51.315, lon:  9.498 },
  { name: 'Hagen',               country: 'Germany', lat: 51.362, lon:  7.472 },
  { name: 'Hamm',                country: 'Germany', lat: 51.680, lon:  7.822 },
  { name: 'Saarbrücken',         country: 'Germany', lat: 49.234, lon:  7.000 },
  { name: 'Mülheim',             country: 'Germany', lat: 51.427, lon:  6.885 },
  { name: 'Potsdam',             country: 'Germany', lat: 52.399, lon: 13.066 },
  { name: 'Osnabrück',           country: 'Germany', lat: 52.279, lon:  8.048 },
  { name: 'Ludwigshafen',        country: 'Germany', lat: 49.477, lon:  8.445 },
  { name: 'Oldenburg',           country: 'Germany', lat: 53.144, lon:  8.214 },
  { name: 'Leverkusen',          country: 'Germany', lat: 51.045, lon:  6.984 },
  { name: 'Darmstadt',           country: 'Germany', lat: 49.878, lon:  8.653 },
  { name: 'Heidelberg',          country: 'Germany', lat: 49.398, lon:  8.672 },
  { name: 'Regensburg',          country: 'Germany', lat: 49.013, lon: 12.102 },
  { name: 'Ingolstadt',          country: 'Germany', lat: 48.765, lon: 11.424 },
  { name: 'Würzburg',            country: 'Germany', lat: 49.795, lon:  9.929 },
  { name: 'Ulm',                 country: 'Germany', lat: 48.401, lon:  9.994 },
  { name: 'Wolfsburg',           country: 'Germany', lat: 52.422, lon: 10.787 },
  { name: 'Göttingen',           country: 'Germany', lat: 51.534, lon:  9.932 },
  { name: 'Recklinghausen',      country: 'Germany', lat: 51.615, lon:  7.198 },
  { name: 'Paderborn',           country: 'Germany', lat: 51.719, lon:  8.753 },
  { name: 'Heilbronn',           country: 'Germany', lat: 49.142, lon:  9.218 },
  { name: 'Pforzheim',           country: 'Germany', lat: 48.895, lon:  8.695 },
  { name: 'Offenbach',           country: 'Germany', lat: 50.099, lon:  8.771 },
  { name: 'Bottrop',             country: 'Germany', lat: 51.522, lon:  6.929 },
  { name: 'Salzgitter',          country: 'Germany', lat: 52.153, lon: 10.342 },
  { name: 'Remscheid',           country: 'Germany', lat: 51.179, lon:  7.189 },
  { name: 'Solingen',            country: 'Germany', lat: 51.165, lon:  7.085 },
  { name: 'Koblenz',             country: 'Germany', lat: 50.359, lon:  7.598 },
  { name: 'Trier',               country: 'Germany', lat: 49.750, lon:  6.638 },
  { name: 'Jena',                country: 'Germany', lat: 50.927, lon: 11.586 },
  { name: 'Gera',                country: 'Germany', lat: 50.879, lon: 12.081 },
  { name: 'Zwickau',             country: 'Germany', lat: 50.720, lon: 12.496 },
  { name: 'Cottbus',             country: 'Germany', lat: 51.759, lon: 14.332 },
  { name: 'Schwerin',            country: 'Germany', lat: 53.629, lon: 11.417 },
  // ── Poland ─────────────────────────────────────────────────
  { name: 'Warsaw',              country: 'Poland', lat: 52.229, lon: 21.012 },
  { name: 'Kraków',              country: 'Poland', lat: 50.061, lon: 19.937 },
  { name: 'Łódź',                country: 'Poland', lat: 51.759, lon: 19.457 },
  { name: 'Wrocław',             country: 'Poland', lat: 51.107, lon: 17.038 },
  { name: 'Poznań',              country: 'Poland', lat: 52.407, lon: 16.934 },
  { name: 'Gdańsk',              country: 'Poland', lat: 54.352, lon: 18.647 },
  { name: 'Szczecin',            country: 'Poland', lat: 53.429, lon: 14.552 },
  { name: 'Bydgoszcz',           country: 'Poland', lat: 53.123, lon: 18.008 },
  { name: 'Lublin',              country: 'Poland', lat: 51.248, lon: 22.568 },
  { name: 'Katowice',            country: 'Poland', lat: 50.264, lon: 19.023 },
  { name: 'Białystok',           country: 'Poland', lat: 53.132, lon: 23.162 },
  { name: 'Gdynia',              country: 'Poland', lat: 54.519, lon: 18.531 },
  { name: 'Częstochowa',         country: 'Poland', lat: 50.811, lon: 19.120 },
  { name: 'Radom',               country: 'Poland', lat: 51.403, lon: 21.147 },
  { name: 'Sosnowiec',           country: 'Poland', lat: 50.286, lon: 19.104 },
  { name: 'Toruń',               country: 'Poland', lat: 53.014, lon: 18.611 },
  { name: 'Kielce',              country: 'Poland', lat: 50.866, lon: 20.628 },
  { name: 'Gliwice',             country: 'Poland', lat: 50.295, lon: 18.667 },
  { name: 'Zabrze',              country: 'Poland', lat: 50.325, lon: 18.786 },
  { name: 'Olsztyn',             country: 'Poland', lat: 53.778, lon: 20.480 },
  { name: 'Rzeszów',             country: 'Poland', lat: 50.041, lon: 21.999 },
  { name: 'Bielsko-Biała',       country: 'Poland', lat: 49.823, lon: 19.044 },
  { name: 'Ruda Śląska',         country: 'Poland', lat: 50.259, lon: 18.856 },
  { name: 'Rybnik',              country: 'Poland', lat: 50.097, lon: 18.541 },
  { name: 'Bytom',               country: 'Poland', lat: 50.348, lon: 18.918 },
  { name: 'Tychy',               country: 'Poland', lat: 50.157, lon: 18.993 },
  { name: 'Opole',               country: 'Poland', lat: 50.665, lon: 17.927 },
  { name: 'Gorzów Wlkp.',        country: 'Poland', lat: 52.735, lon: 15.228 },
  { name: 'Zielona Góra',        country: 'Poland', lat: 51.935, lon: 15.506 },
  { name: 'Dąbrowa Górnicza',    country: 'Poland', lat: 50.323, lon: 19.188 },
  { name: 'Płock',               country: 'Poland', lat: 52.546, lon: 19.707 },
  { name: 'Elbląg',              country: 'Poland', lat: 54.156, lon: 19.404 },
  { name: 'Wałbrzych',           country: 'Poland', lat: 50.784, lon: 16.285 },
  { name: 'Legnica',             country: 'Poland', lat: 51.207, lon: 16.156 },
  { name: 'Kalisz',              country: 'Poland', lat: 51.761, lon: 18.091 },
  { name: 'Grudziądz',           country: 'Poland', lat: 53.484, lon: 18.753 },
  { name: 'Jaworzno',            country: 'Poland', lat: 50.206, lon: 19.274 },
  { name: 'Jastrzębie-Zdrój',    country: 'Poland', lat: 49.960, lon: 18.596 },
  { name: 'Nowy Sącz',           country: 'Poland', lat: 49.624, lon: 20.692 },
  { name: 'Siedlce',             country: 'Poland', lat: 52.167, lon: 22.290 },
  { name: 'Słupsk',              country: 'Poland', lat: 54.464, lon: 17.029 },
  { name: 'Konin',               country: 'Poland', lat: 52.223, lon: 18.251 },
  // ── Italy ──────────────────────────────────────────────────
  { name: 'Rome',                country: 'Italy', lat: 41.903, lon: 12.496 },
  { name: 'Milan',               country: 'Italy', lat: 45.464, lon:  9.190 },
  { name: 'Naples',              country: 'Italy', lat: 40.851, lon: 14.268 },
  { name: 'Turin',               country: 'Italy', lat: 45.070, lon:  7.687 },
  { name: 'Palermo',             country: 'Italy', lat: 38.116, lon: 13.361 },
  { name: 'Genoa',               country: 'Italy', lat: 44.411, lon:  8.933 },
  { name: 'Bologna',             country: 'Italy', lat: 44.494, lon: 11.342 },
  { name: 'Florence',            country: 'Italy', lat: 43.769, lon: 11.256 },
  { name: 'Bari',                country: 'Italy', lat: 41.117, lon: 16.872 },
  { name: 'Catania',             country: 'Italy', lat: 37.502, lon: 15.087 },
  { name: 'Venice',              country: 'Italy', lat: 45.438, lon: 12.336 },
  { name: 'Verona',              country: 'Italy', lat: 45.438, lon: 10.992 },
  { name: 'Messina',             country: 'Italy', lat: 38.193, lon: 15.556 },
  { name: 'Padova',              country: 'Italy', lat: 45.408, lon: 11.875 },
  { name: 'Trieste',             country: 'Italy', lat: 45.649, lon: 13.777 },
  { name: 'Taranto',             country: 'Italy', lat: 40.464, lon: 17.248 },
  { name: 'Brescia',             country: 'Italy', lat: 45.539, lon: 10.220 },
  { name: 'Reggio Calabria',     country: 'Italy', lat: 38.109, lon: 15.648 },
  { name: 'Modena',              country: 'Italy', lat: 44.647, lon: 10.925 },
  { name: 'Reggio Emilia',       country: 'Italy', lat: 44.697, lon: 10.631 },
  { name: 'Perugia',             country: 'Italy', lat: 43.107, lon: 12.390 },
  { name: 'Livorno',             country: 'Italy', lat: 43.548, lon: 10.311 },
  { name: 'Ravenna',             country: 'Italy', lat: 44.416, lon: 12.200 },
  { name: 'Cagliari',            country: 'Italy', lat: 39.215, lon:  9.110 },
  { name: 'Foggia',              country: 'Italy', lat: 41.462, lon: 15.556 },
  { name: 'Rimini',              country: 'Italy', lat: 44.057, lon: 12.567 },
  { name: 'Salerno',             country: 'Italy', lat: 40.679, lon: 14.760 },
  { name: 'Ferrara',             country: 'Italy', lat: 44.835, lon: 11.620 },
  { name: 'Sassari',             country: 'Italy', lat: 40.727, lon:  8.560 },
  { name: 'Latina',              country: 'Italy', lat: 41.467, lon: 12.903 },
  { name: 'Giugliano in Campania', country: 'Italy', lat: 40.933, lon: 14.200 },
  { name: 'Monza',               country: 'Italy', lat: 45.584, lon:  9.274 },
  { name: 'Bergamo',             country: 'Italy', lat: 45.695, lon:  9.670 },
  { name: 'Trento',              country: 'Italy', lat: 46.069, lon: 11.121 },
  { name: 'Bolzano',             country: 'Italy', lat: 46.499, lon: 11.356 },
  { name: 'Vicenza',             country: 'Italy', lat: 45.547, lon: 11.545 },
  { name: 'Treviso',             country: 'Italy', lat: 45.667, lon: 12.242 },
  { name: 'Udine',               country: 'Italy', lat: 46.063, lon: 13.235 },
  { name: 'Como',                country: 'Italy', lat: 45.810, lon:  9.085 },
  { name: 'Varese',              country: 'Italy', lat: 45.820, lon:  8.826 },
  { name: 'Novara',              country: 'Italy', lat: 45.446, lon:  8.621 },
  { name: 'Parma',               country: 'Italy', lat: 44.801, lon: 10.328 },
  { name: 'Piacenza',            country: 'Italy', lat: 45.052, lon:  9.693 },
  { name: 'Ancona',              country: 'Italy', lat: 43.617, lon: 13.519 },
  { name: 'Pisa',                country: 'Italy', lat: 43.716, lon: 10.402 },
  { name: 'Arezzo',              country: 'Italy', lat: 43.465, lon: 11.881 },
  { name: 'Siena',               country: 'Italy', lat: 43.318, lon: 11.331 },
  { name: 'Grosseto',            country: 'Italy', lat: 42.760, lon: 11.113 },
  { name: 'Lucca',               country: 'Italy', lat: 43.843, lon: 10.508 },
  { name: 'Pistoia',             country: 'Italy', lat: 43.934, lon: 10.917 },
  { name: 'Prato',               country: 'Italy', lat: 43.880, lon: 11.097 },
  { name: 'Campobasso',          country: 'Italy', lat: 41.562, lon: 14.656 },
  { name: 'Isernia',             country: 'Italy', lat: 41.597, lon: 14.234 },
  { name: 'Pescara',             country: 'Italy', lat: 42.464, lon: 14.214 },
  { name: 'L\'Aquila',           country: 'Italy', lat: 42.351, lon: 13.400 },
  { name: 'Potenza',             country: 'Italy', lat: 40.642, lon: 15.799 },
  { name: 'Matera',              country: 'Italy', lat: 40.666, lon: 16.604 },
  { name: 'Cosenza',             country: 'Italy', lat: 39.300, lon: 16.251 },
  { name: 'Catanzaro',           country: 'Italy', lat: 38.910, lon: 16.587 },
  { name: 'Crotone',             country: 'Italy', lat: 39.082, lon: 17.119 },
  { name: 'Vibo Valentia',       country: 'Italy', lat: 38.676, lon: 16.100 },
  { name: 'Agrigento',           country: 'Italy', lat: 37.311, lon: 13.578 },
  { name: 'Caltanissetta',       country: 'Italy', lat: 37.490, lon: 14.062 },
  { name: 'Ragusa',              country: 'Italy', lat: 36.928, lon: 14.731 },
  { name: 'Syracuse',            country: 'Italy', lat: 37.075, lon: 15.287 },
  { name: 'Enna',                country: 'Italy', lat: 37.565, lon: 14.275 },
  { name: 'Trapani',             country: 'Italy', lat: 38.017, lon: 12.538 },
  { name: 'Lecce',               country: 'Italy', lat: 40.352, lon: 18.175 },
  { name: 'Brindisi',            country: 'Italy', lat: 40.637, lon: 17.944 },
  // ── Netherlands ─────────────────────────────────────────────
  { name: 'Amsterdam',           country: 'Netherlands', lat: 52.373, lon:  4.890 },
  { name: 'Rotterdam',           country: 'Netherlands', lat: 51.924, lon:  4.478 },
  { name: 'The Hague',           country: 'Netherlands', lat: 52.077, lon:  4.297 },
  { name: 'Utrecht',             country: 'Netherlands', lat: 52.092, lon:  5.104 },
  { name: 'Eindhoven',           country: 'Netherlands', lat: 51.441, lon:  5.478 },
  { name: 'Groningen',           country: 'Netherlands', lat: 53.219, lon:  6.567 },
  { name: 'Tilburg',             country: 'Netherlands', lat: 51.556, lon:  5.091 },
  { name: 'Almere',              country: 'Netherlands', lat: 52.370, lon:  5.217 },
  { name: 'Breda',               country: 'Netherlands', lat: 51.589, lon:  4.775 },
  { name: 'Nijmegen',            country: 'Netherlands', lat: 51.843, lon:  5.854 },
  { name: 'Enschede',            country: 'Netherlands', lat: 52.219, lon:  6.896 },
  { name: 'Haarlem',             country: 'Netherlands', lat: 52.382, lon:  4.637 },
  { name: 'Arnhem',              country: 'Netherlands', lat: 51.985, lon:  5.898 },
  { name: 'Zaandam',             country: 'Netherlands', lat: 52.438, lon:  4.819 },
  { name: 'Amersfoort',          country: 'Netherlands', lat: 52.156, lon:  5.387 },
  { name: 'Apeldoorn',           country: 'Netherlands', lat: 52.212, lon:  5.969 },
  { name: 'Dordrecht',           country: 'Netherlands', lat: 51.813, lon:  4.669 },
  { name: 'Leiden',              country: 'Netherlands', lat: 52.160, lon:  4.497 },
  { name: 'Zwolle',              country: 'Netherlands', lat: 52.512, lon:  6.100 },
  { name: 'Maastricht',          country: 'Netherlands', lat: 50.851, lon:  5.691 },
  // ── Switzerland ────────────────────────────────────────────
  { name: 'Zurich',              country: 'Switzerland', lat: 47.378, lon:  8.540 },
  { name: 'Geneva',              country: 'Switzerland', lat: 46.204, lon:  6.143 },
  { name: 'Basel',               country: 'Switzerland', lat: 47.559, lon:  7.588 },
  { name: 'Bern',                country: 'Switzerland', lat: 46.948, lon:  7.448 },
  { name: 'Lausanne',            country: 'Switzerland', lat: 46.520, lon:  6.633 },
  { name: 'Winterthur',          country: 'Switzerland', lat: 47.500, lon:  8.724 },
  { name: 'Lucerne',             country: 'Switzerland', lat: 47.051, lon:  8.307 },
  { name: 'St. Gallen',          country: 'Switzerland', lat: 47.423, lon:  9.377 },
  { name: 'Lugano',              country: 'Switzerland', lat: 46.005, lon:  8.951 },
  { name: 'Biel',                country: 'Switzerland', lat: 47.137, lon:  7.246 },
  // ── Austria ────────────────────────────────────────────────
  { name: 'Vienna',              country: 'Austria', lat: 48.208, lon: 16.374 },
  { name: 'Graz',                country: 'Austria', lat: 47.070, lon: 15.440 },
  { name: 'Linz',                country: 'Austria', lat: 48.306, lon: 14.286 },
  { name: 'Salzburg',            country: 'Austria', lat: 47.800, lon: 13.045 },
  { name: 'Innsbruck',           country: 'Austria', lat: 47.269, lon: 11.404 },
  { name: 'Klagenfurt',          country: 'Austria', lat: 46.624, lon: 14.308 },
  { name: 'Villach',             country: 'Austria', lat: 46.611, lon: 13.846 },
  { name: 'Wels',                country: 'Austria', lat: 48.158, lon: 14.029 },
  { name: 'Sankt Pölten',        country: 'Austria', lat: 48.204, lon: 15.625 },
  { name: 'Steyr',               country: 'Austria', lat: 48.040, lon: 14.421 },
  // ── Czechia ────────────────────────────────────────────────
  { name: 'Prague',              country: 'Czechia', lat: 50.075, lon: 14.438 },
  { name: 'Brno',                country: 'Czechia', lat: 49.195, lon: 16.608 },
  { name: 'Ostrava',             country: 'Czechia', lat: 49.835, lon: 18.292 },
  { name: 'Plzeň',               country: 'Czechia', lat: 49.738, lon: 13.374 },
  { name: 'Liberec',             country: 'Czechia', lat: 50.767, lon: 15.057 },
  { name: 'Olomouc',             country: 'Czechia', lat: 49.593, lon: 17.251 },
  { name: 'České Budějovice',    country: 'Czechia', lat: 48.975, lon: 14.474 },
  { name: 'Hradec Králové',      country: 'Czechia', lat: 50.209, lon: 15.832 },
  { name: 'Pardubice',           country: 'Czechia', lat: 50.034, lon: 15.781 },
  { name: 'Zlín',                country: 'Czechia', lat: 49.224, lon: 17.661 },
  // ── Hungary ────────────────────────────────────────────────
  { name: 'Budapest',            country: 'Hungary', lat: 47.498, lon: 19.040 },
  { name: 'Debrecen',            country: 'Hungary', lat: 47.530, lon: 21.626 },
  { name: 'Miskolc',             country: 'Hungary', lat: 48.104, lon: 20.778 },
  { name: 'Szeged',              country: 'Hungary', lat: 46.253, lon: 20.148 },
  { name: 'Pécs',                country: 'Hungary', lat: 46.076, lon: 18.228 },
  { name: 'Győr',                country: 'Hungary', lat: 47.685, lon: 17.635 },
  { name: 'Nyíregyháza',         country: 'Hungary', lat: 47.955, lon: 21.717 },
  { name: 'Kecskemét',           country: 'Hungary', lat: 46.906, lon: 19.691 },
  // ── Romania ────────────────────────────────────────────────
  { name: 'Bucharest',           country: 'Romania', lat: 44.426, lon: 26.102 },
  { name: 'Cluj-Napoca',         country: 'Romania', lat: 46.770, lon: 23.590 },
  { name: 'Timișoara',           country: 'Romania', lat: 45.749, lon: 21.209 },
  { name: 'Iași',                country: 'Romania', lat: 47.160, lon: 27.590 },
  { name: 'Constanța',           country: 'Romania', lat: 44.180, lon: 28.650 },
  { name: 'Craiova',             country: 'Romania', lat: 44.319, lon: 23.800 },
  { name: 'Brașov',              country: 'Romania', lat: 45.648, lon: 25.606 },
  { name: 'Galați',              country: 'Romania', lat: 45.436, lon: 28.050 },
  // ── Greece ─────────────────────────────────────────────────
  { name: 'Athens',              country: 'Greece', lat: 37.984, lon: 23.728 },
  { name: 'Thessaloniki',        country: 'Greece', lat: 40.629, lon: 22.960 },
  { name: 'Patras',              country: 'Greece', lat: 38.246, lon: 21.735 },
  { name: 'Heraklion',           country: 'Greece', lat: 35.339, lon: 25.133 },
  { name: 'Larissa',             country: 'Greece', lat: 39.637, lon: 22.419 },
  { name: 'Volos',               country: 'Greece', lat: 39.362, lon: 22.942 },
  { name: 'Ioannina',            country: 'Greece', lat: 39.668, lon: 20.853 },
  { name: 'Chania',              country: 'Greece', lat: 35.513, lon: 24.018 },
  // ── Denmark ────────────────────────────────────────────────
  { name: 'Copenhagen',          country: 'Denmark', lat: 55.676, lon: 12.568 },
  { name: 'Aarhus',              country: 'Denmark', lat: 56.156, lon: 10.211 },
  { name: 'Odense',              country: 'Denmark', lat: 55.396, lon: 10.389 },
  { name: 'Aalborg',             country: 'Denmark', lat: 57.048, lon:  9.919 },
  { name: 'Esbjerg',             country: 'Denmark', lat: 55.467, lon:  8.452 },
  { name: 'Frederiksberg',       country: 'Denmark', lat: 55.679, lon: 12.528 },
  { name: 'Kolding',             country: 'Denmark', lat: 55.490, lon:  9.472 },
  { name: 'Horsens',             country: 'Denmark', lat: 55.861, lon:  9.851 },
  // ── Sweden ─────────────────────────────────────────────────
  { name: 'Stockholm',           country: 'Sweden', lat: 59.333, lon: 18.065 },
  { name: 'Gothenburg',          country: 'Sweden', lat: 57.707, lon: 11.967 },
  { name: 'Malmö',               country: 'Sweden', lat: 55.605, lon: 13.000 },
  { name: 'Uppsala',             country: 'Sweden', lat: 59.858, lon: 17.645 },
  { name: 'Västerås',            country: 'Sweden', lat: 59.611, lon: 16.544 },
  { name: 'Örebro',              country: 'Sweden', lat: 59.275, lon: 15.214 },
  { name: 'Linköping',           country: 'Sweden', lat: 58.411, lon: 15.622 },
  { name: 'Helsingborg',         country: 'Sweden', lat: 56.046, lon: 12.694 },
  { name: 'Jönköping',           country: 'Sweden', lat: 57.781, lon: 14.162 },
  { name: 'Norrköping',          country: 'Sweden', lat: 58.595, lon: 16.188 },
  { name: 'Lund',                country: 'Sweden', lat: 55.703, lon: 13.193 },
  { name: 'Umeå',                country: 'Sweden', lat: 63.826, lon: 20.264 },
  // ── Norway ─────────────────────────────────────────────────
  { name: 'Oslo',                country: 'Norway', lat: 59.913, lon: 10.752 },
  { name: 'Bergen',              country: 'Norway', lat: 60.391, lon:  5.324 },
  { name: 'Trondheim',           country: 'Norway', lat: 63.431, lon: 10.395 },
  { name: 'Stavanger',           country: 'Norway', lat: 58.969, lon:  5.733 },
  { name: 'Drammen',             country: 'Norway', lat: 59.744, lon: 10.204 },
  { name: 'Fredrikstad',         country: 'Norway', lat: 59.218, lon: 10.930 },
  { name: 'Kristiansand',        country: 'Norway', lat: 58.147, lon:  7.995 },
  { name: 'Tromsø',              country: 'Norway', lat: 69.683, lon: 18.942 },
  // ── Finland ────────────────────────────────────────────────
  { name: 'Helsinki',            country: 'Finland', lat: 60.169, lon: 24.935 },
  { name: 'Espoo',               country: 'Finland', lat: 60.205, lon: 24.657 },
  { name: 'Tampere',             country: 'Finland', lat: 61.498, lon: 23.761 },
  { name: 'Vantaa',              country: 'Finland', lat: 60.294, lon: 25.041 },
  { name: 'Oulu',                country: 'Finland', lat: 65.014, lon: 25.472 },
  { name: 'Turku',               country: 'Finland', lat: 60.451, lon: 22.267 },
  { name: 'Jyväskylä',           country: 'Finland', lat: 62.242, lon: 25.748 },
  { name: 'Kuopio',              country: 'Finland', lat: 62.892, lon: 27.678 },
  // ── Other Europe ───────────────────────────────────────────
  { name: 'Kyiv',                country: 'Ukraine',    lat: 50.450, lon: 30.524 },
  { name: 'Kharkiv',             country: 'Ukraine',    lat: 49.992, lon: 36.230 },
  { name: 'Odessa',              country: 'Ukraine',    lat: 46.477, lon: 30.733 },
  { name: 'Dnipro',              country: 'Ukraine',    lat: 48.464, lon: 35.046 },
  { name: 'Warsaw',              country: 'Poland',     lat: 52.229, lon: 21.012 },
  { name: 'Minsk',               country: 'Belarus',    lat: 53.904, lon: 27.562 },
  { name: 'Vilnius',             country: 'Lithuania',  lat: 54.687, lon: 25.280 },
  { name: 'Riga',                country: 'Latvia',     lat: 56.946, lon: 24.106 },
  { name: 'Tallinn',             country: 'Estonia',    lat: 59.437, lon: 24.754 },
  { name: 'Ljubljana',           country: 'Slovenia',   lat: 46.051, lon: 14.506 },
  { name: 'Zagreb',              country: 'Croatia',    lat: 45.815, lon: 15.982 },
  { name: 'Split',               country: 'Croatia',    lat: 43.508, lon: 16.440 },
  { name: 'Sarajevo',            country: 'Bosnia',     lat: 43.848, lon: 18.356 },
  { name: 'Belgrade',            country: 'Serbia',     lat: 44.802, lon: 20.465 },
  { name: 'Skopje',              country: 'N. Macedonia', lat: 41.996, lon: 21.431 },
  { name: 'Sofia',               country: 'Bulgaria',   lat: 42.698, lon: 23.322 },
  { name: 'Tirana',              country: 'Albania',    lat: 41.330, lon: 19.820 },
  { name: 'Podgorica',           country: 'Montenegro', lat: 42.441, lon: 19.263 },
  { name: 'Bratislava',          country: 'Slovakia',   lat: 48.148, lon: 17.107 },
  { name: 'Košice',              country: 'Slovakia',   lat: 48.716, lon: 21.261 },
  { name: 'Luxembourg',          country: 'Luxembourg', lat: 49.612, lon:  6.130 },
  { name: 'Reykjavik',           country: 'Iceland',    lat: 64.135, lon: -21.895 },
  { name: 'Valletta',            country: 'Malta',      lat: 35.900, lon: 14.514 },
  { name: 'Nicosia',             country: 'Cyprus',     lat: 35.166, lon: 33.367 },
];

const BLITZORTUNG_DATE_IMAGES = {
  '2026-05-03': 'https://www.blitzortung.org/en/archive_data.php?stations_users=0&selected_numbers=&end_date=1777766400&end_time=0&start_date=1777680000&start_time=0&north=90&west=-180&east=180&south=-90&rawdata_image=1&map=10&width_orig=640&width_result=640&png_gif=0',
  '2026-05-02': 'https://www.blitzortung.org/en/archive_data.php?stations_users=0&selected_numbers=&end_date=1777680000&end_time=0&start_date=1777593600&start_time=0&north=90&west=-180&east=180&south=-90&rawdata_image=1&map=10&width_orig=640&width_result=640&png_gif=0',
};
async function fetchBlitzortungArchive(dateStr, hourEnd) {
  // dateStr = 'YYYY-MM-DD', hourEnd = 0-23
  const d = new Date(dateStr + 'T00:00:00Z');
  const endTs  = Math.floor(d.getTime() / 1000) + hourEnd * 3600;
  const startTs = endTs - 3600; // 1 hour window
  const url = `https://www.blitzortung.org/en/archive_data.php?stations_users=0&selected_numbers=&end_date=${endTs}&end_time=0&start_date=${startTs}&start_time=0&north=90&west=-180&east=180&south=-90&rawdata_image=1&map=10&width_orig=640&width_result=640&png_gif=0`;
  return url; // returns the image URL for that hour window
}

function tsToDateHour(ts) {
  const d = new Date(ts);
  return {
    dateStr: d.toISOString().slice(0, 10),
    hour: d.getUTCHours(),
  };
}

// Build a kdtree-like sorted lookup for speed
function nearestCityFull(lat, lon) {
  let best = null, bestDist = Infinity;
  CITY_DB.forEach(city => {
    const dLat = city.lat - lat;
    const dLon = (city.lon - lon) * Math.cos(lat * Math.PI / 180);
    const dist = dLat * dLat + dLon * dLon;
    if (dist < bestDist) { bestDist = dist; best = city; }
  });
  return best;
}

function nearestCity(lat, lon) {
  const city = nearestCityFull(lat, lon);
  if (!city) return 'Unknown location';
  // Use km distance to decide phrasing
  const dLat = city.lat - lat;
  const dLon = (city.lon - lon) * Math.cos(lat * Math.PI / 180);
  const km = Math.sqrt(dLat * dLat + dLon * dLon) * 111;
  if (km < 5) return `over ${city.name}, ${city.country}`;
  if (km < 15) return `near ${city.name}, ${city.country}`;
  if (km < 35) return `${Math.round(km)} km from ${city.name}, ${city.country}`;
  return `${Math.round(km)} km from ${city.name}, ${city.country}`;
}

function nearestCityShort(lat, lon) {
  const city = nearestCityFull(lat, lon);
  if (!city) return 'Unknown';
  const dLat = city.lat - lat;
  const dLon = (city.lon - lon) * Math.cos(lat * Math.PI / 180);
  const km = Math.sqrt(dLat * dLat + dLon * dLon) * 111;
  if (km < 5) return city.name;
  if (km < 20) return `nr ${city.name}`;
  return `${Math.round(km)}km from ${city.name}`;
}

/* ═══════════════════════════════════════════════════════════════
   PERSISTENT STRIKE STORE
   ═══════════════════════════════════════════════════════════════ */
const STORE_KEY              = 'tcm_today_strikes';
const DATE_KEY               = 'tcm_today_date';
const ARCHIVE_KEY            = 'tcm_lightning_archive';
const AUTO_FORECAST_KEY      = 'tcm_auto_forecasts';
const FORECAST_ARCHIVE_KEY   = 'tcm_forecast_archive';
const FORECAST_OVERRIDES_KEY = 'tcm_forecast_overrides';
const OM_HISTORY_KEY         = 'tcm_om_daily_history';
const MAX_TODAY = 500000; const MAX_MAP_MARKERS = 4000; const STORM_STORE_KEY = 'tcm_storm_warnings'; const SNAPSHOT_KEY = 'tcm_forced_snapshots'; function loadStoredWarnings() {
  try {
    const arr = JSON.parse(localStorage.getItem(STORM_STORE_KEY) || '[]');
    return arr.filter(w => w.expiresAt && w.expiresAt > Date.now());
  } catch (_) { return []; }
}

function saveWarnings(polys) {
  try {
    const live = (polys || []).filter(w => w.expiresAt && w.expiresAt > Date.now());
    localStorage.setItem(STORM_STORE_KEY, JSON.stringify(live));
  } catch (_) {}
}

function broadcastWarnings(polys) {
  try {
    const live = (polys || []).filter(w => w.expiresAt && w.expiresAt > Date.now());
    localStorage.setItem(STORM_STORE_KEY, JSON.stringify(live));
    // Trigger storage event for other tabs
    const evt = new StorageEvent('storage', {
      key: STORM_STORE_KEY,
      newValue: JSON.stringify(live),
      storageArea: localStorage,
    });
    window.dispatchEvent(evt);
  } catch (_) {}
} function loadSnapshots() { try { return JSON.parse(localStorage.getItem(SNAPSHOT_KEY) || '[]'); } catch (_) { return []; } } function saveSnapshot(snap) { try { const all = loadSnapshots(); all.push(snap); const cutoff = Date.now() - 90 * 24 * 60 * 60 * 1000; const trimmed = all.filter(s => s.capturedAt && s.capturedAt > cutoff); localStorage.setItem(SNAPSHOT_KEY, JSON.stringify(trimmed)); } catch (_) {} }
function todayDateStr() { return new Date().toISOString().slice(0, 10); }

function loadTodayStrikes() {
  try {
    const cutoff24h = Date.now() - 24 * 60 * 60 * 1000;
    const stored = JSON.parse(localStorage.getItem(STORE_KEY) || '[]');
    return stored.filter(s => s.time && s.time > cutoff24h);
  } catch (_) { return []; }
}

function saveTodayStrikes(strikes) {
  try {
    const cutoff24h = Date.now() - 24 * 60 * 60 * 1000;
    const filtered  = strikes.filter(s => s.time && s.time > cutoff24h);
    const toSave    = filtered.length > MAX_TODAY ? filtered.slice(-MAX_TODAY) : filtered;
    localStorage.setItem(DATE_KEY,  todayDateStr());
    localStorage.setItem(STORE_KEY, JSON.stringify(toSave));
    // Write a lightweight index so other sessions can see what's stored
    localStorage.setItem('tcm_strike_meta', JSON.stringify({
      count:     toSave.length,
      savedAt:   Date.now(),
      newestTs:  toSave.length ? toSave[toSave.length - 1].time : 0,
      oldestTs:  toSave.length ? toSave[0].time : 0,
    }));
  } catch (_) {}
}

// Returns only the strikes that are newer than what the caller already has
function loadNewStrikesSince(sinceTs) {
  try {
    const cutoff24h = Date.now() - 24 * 60 * 60 * 1000;
    const stored    = JSON.parse(localStorage.getItem(STORE_KEY) || '[]');
    return stored.filter(s => s.time && s.time > cutoff24h && s.time > sinceTs);
  } catch (_) { return []; }
}
function loadArchive()  { try { return JSON.parse(localStorage.getItem(ARCHIVE_KEY)  || '[]'); } catch (_) { return []; } }
function saveArchive(a) { try { localStorage.setItem(ARCHIVE_KEY,  JSON.stringify(a)); } catch (_) {} }
function loadAutoForecasts()    { try { return JSON.parse(localStorage.getItem(AUTO_FORECAST_KEY)    || 'null'); } catch (_) { return null; } }
function saveAutoForecasts(d)   { try { localStorage.setItem(AUTO_FORECAST_KEY,    JSON.stringify(d)); } catch (_) {} }
function loadForecastArchive()  { try { return JSON.parse(localStorage.getItem(FORECAST_ARCHIVE_KEY) || '[]');  } catch (_) { return []; } }
function saveForecastArchive(d) { try { localStorage.setItem(FORECAST_ARCHIVE_KEY, JSON.stringify(d)); } catch (_) {} }
function loadForecastOverrides(){ try { return JSON.parse(localStorage.getItem(FORECAST_OVERRIDES_KEY) || '{}'); } catch (_) { return {}; } }
function saveForecastOverrides(d){ try { localStorage.setItem(FORECAST_OVERRIDES_KEY, JSON.stringify(d)); } catch (_) {} }
function loadOMHistory()  { try { return JSON.parse(localStorage.getItem(OM_HISTORY_KEY) || '{}'); } catch (_) { return {}; } }
function saveOMHistory(d) { try { localStorage.setItem(OM_HISTORY_KEY, JSON.stringify(d)); } catch (_) {} }

/* ═══════════════════════════════════════════════════════════════
   SERVICE WORKER REGISTRATION
   Handles background strike collection & 23:59 snapshot
   ═══════════════════════════════════════════════════════════════ */
const SW_CODE = `
// sw-lightning.js — Background service worker for TCM
const STORE_KEY = 'tcm_today_strikes';
const DATE_KEY  = 'tcm_today_date';
const ARCH_KEY  = 'tcm_lightning_archive';

function todayStr() { return new Date().toISOString().slice(0,10); }

let bufferedStrikes = [];
let snapshotDoneToday = false;
let lastSnapshotDate = '';

// Check midnight snapshot every 60s even without page
setInterval(() => {
  const now = new Date();
  const dateKey = todayStr();
  if (now.getHours() === 23 && now.getMinutes() === 59 && lastSnapshotDate !== dateKey) {
    lastSnapshotDate = dateKey;
    snapshotDoneToday = true;
    // Notify any open clients to do snapshot
    self.clients.matchAll().then(clients => {
      if (clients.length > 0) {
        clients.forEach(c => c.postMessage({ type: 'DO_MIDNIGHT_SNAPSHOT' }));
      } else {
        // No clients — do it in SW context using IDB/cache
        // We can only postMessage back on reconnect; store a flag
        caches.open('tcm-snapshot-pending').then(cache => {
          cache.put('/tcm-snapshot-pending', new Response(JSON.stringify({ pending: true, date: dateKey, ts: Date.now() })));
        });
      }
    });
  }
}, 60000);

self.addEventListener('message', (event) => {
  if (event.data?.type === 'NEW_STRIKES') {
    bufferedStrikes.push(...(event.data.strikes || []));
    if (bufferedStrikes.length > 10000) bufferedStrikes = bufferedStrikes.slice(-10000);
  }
  if (event.data?.type === 'GET_BUFFERED_STRIKES') {
    const toSend = [...bufferedStrikes];
    bufferedStrikes = [];
    event.source?.postMessage({ type: 'BUFFERED_STRIKES', strikes: toSend });
  }
  if (event.data?.type === 'PING') {
    // Keepalive — do nothing
  }
});

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', () => self.clients.claim());
`;

function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  try {
    const blob = new Blob([SW_CODE], { type: 'application/javascript' });
    const url  = URL.createObjectURL(blob);
    navigator.serviceWorker.register(url, { scope: '/' }).catch(() => {});
  } catch (_) {}
}

/* ═══════════════════════════════════════════════════════════════
   ALERT QUEUE — ensures TTS/siren fires sequentially
   ═══════════════════════════════════════════════════════════════ */
class AlertQueue {
  constructor() {
    this._q = [];
    this._busy = false;
  }
  push(fn) {
    this._q.push(fn);
    if (!this._busy) this._next();
  }
  _next() {
    if (!this._q.length) { this._busy = false; return; }
    this._busy = true;
    const fn = this._q.shift();
    Promise.resolve().then(() => fn()).finally(() => {
      // Wait a bit between alerts
      setTimeout(() => this._next(), 500);
    });
  }
}

/* ═══════════════════════════════════════════════════════════════
   OPEN-METEO LIGHTNING GRID
   ═══════════════════════════════════════════════════════════════ */
const OM_GRID = [];
for (let lat = 50.0; lat <= 59.0; lat += 1.5) {
  for (let lon = -8.0; lon <= 2.0; lon += 1.5) {
    OM_GRID.push({ lat: parseFloat(lat.toFixed(1)), lon: parseFloat(lon.toFixed(1)) });
  }
}

async function fetchOMStrikesNow(grid = OM_GRID) {
  const now     = new Date();
  const dateStr = now.toISOString().slice(0, 10);
  const batchSize = 50;
  const results   = [];
  for (let i = 0; i < grid.length; i += batchSize) {
    const batch = grid.slice(i, i + batchSize);
    const lats  = batch.map(p => p.lat).join(',');
    const lons  = batch.map(p => p.lon).join(',');
    try {
      const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${lats}&longitude=${lons}` +
        `&hourly=lightning_strike_count&timezone=UTC&start_date=${dateStr}&end_date=${dateStr}`;
      const res  = await fetch(url, { signal: AbortSignal.timeout(15000) });
      if (!res.ok) continue;
      const data = await res.json();
      const items = Array.isArray(data) ? data : [data];
      items.forEach((d, gi) => {
        const g = batch[gi];
        if (!g) return;
        const counts = d.hourly?.lightning_strike_count || [];
        const times  = d.hourly?.time || [];
        const startIdx = Math.max(0, counts.length - 2);
        let recentCount = 0;
        for (let h = startIdx; h < counts.length; h++) recentCount += counts[h] || 0;
        const dayTotal = counts.reduce((s, c) => s + (c || 0), 0);
        const hourly = times.map((t, idx) => ({ time: t, count: counts[idx] || 0 }));
        if (recentCount > 0 || dayTotal > 0)
          results.push({ lat: g.lat, lon: g.lon, recentCount, dayTotal, hourly });
      });
    } catch (_) {}
    if (i + batchSize < grid.length) await new Promise(r => setTimeout(r, 300));
  }
  return results;
}

/* ─── 7-day historical — fetches Blitzortung daily totals via Open-Meteo ─── */
async function fetchOMHistoricalDays(days = 90, useEurope = false) {
  const end   = new Date();
  const start = new Date(end);
  start.setDate(start.getDate() - days);
  const startStr = start.toISOString().slice(0, 10);
  const endStr   = end.toISOString().slice(0, 10);

  const ukGrid = [
    { lat: 51.5, lon: -0.1 }, { lat: 52.5, lon: -1.8 },
    { lat: 53.8, lon: -2.5 }, { lat: 55.8, lon: -4.2 },
    { lat: 51.5, lon: -3.2 }, { lat: 52.0, lon: -0.5 },
    { lat: 50.7, lon: -3.5 }, { lat: 54.6, lon: -5.9 },
    { lat: 53.4, lon: -1.5 }, { lat: 52.9, lon:  1.3 },
    { lat: 51.1, lon:  1.1 }, { lat: 50.8, lon: -1.1 },
  ];
  const euGrid = [
    { lat: 51.5, lon: 0    }, { lat: 48.8, lon: 2.3  },
    { lat: 52.5, lon: 13.4 }, { lat: 40.4, lon: -3.7 },
    { lat: 41.9, lon: 12.5 }, { lat: 52.4, lon: 21.0 },
    { lat: 50.1, lon: 14.4 }, { lat: 45.8, lon: 15.9 },
    { lat: 47.5, lon: 19.0 }, { lat: 44.4, lon: 26.1 },
    { lat: 55.7, lon: 12.6 }, { lat: 59.3, lon: 18.1 },
    { lat: 60.2, lon: 24.9 }, { lat: 59.9, lon: 10.8 },
    { lat: 38.7, lon: -9.1 }, { lat: 50.1, lon:  8.7 },
  ];
  const repGrid = useEurope ? euGrid : ukGrid;

  const lats = repGrid.map(p => p.lat).join(',');
  const lons = repGrid.map(p => p.lon).join(',');
  try {
    const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${lats}&longitude=${lons}` +
      `&daily=lightning_strike_count_sum&timezone=UTC&start_date=${startStr}&end_date=${endStr}`;
    const res  = await fetch(url, { signal: AbortSignal.timeout(20000) });
    if (!res.ok) return null;
    const data = await res.json();
    const items = Array.isArray(data) ? data : [data];
    const dailyTotals = {};
    items.forEach((d, gi) => {
      const dates  = d.daily?.time || [];
      const counts = d.daily?.lightning_strike_count_sum || [];
      dates.forEach((date, i) => {
        dailyTotals[date] = (dailyTotals[date] || 0) + (counts[i] || 0);
      });
    });
    return dailyTotals;
  } catch (_) { return null; }
}

/* ─── Fetch strike detail for a specific past date (for map) ─── */
async function fetchOMStrikesForDate(dateStr, useEurope = false) {
  const grid = useEurope ? OM_GRID_EUROPE_COARSE : OM_GRID;
  const batchSize = 40;
  const results = [];
  for (let i = 0; i < grid.length; i += batchSize) {
    const batch = grid.slice(i, i + batchSize);
    const lats  = batch.map(p => p.lat).join(',');
    const lons  = batch.map(p => p.lon).join(',');
    try {
      const url = `https://archive-api.open-meteo.com/v1/archive?latitude=${lats}&longitude=${lons}` +
        `&daily=lightning_strike_count_sum&timezone=UTC&start_date=${dateStr}&end_date=${dateStr}`;
      const res = await fetch(url, { signal: AbortSignal.timeout(20000) });
      if (!res.ok) continue;
      const data = await res.json();
      const items = Array.isArray(data) ? data : [data];
      items.forEach((d, gi) => {
        const g = batch[gi];
        if (!g) return;
        const count = d.daily?.lightning_strike_count_sum?.[0] || 0;
        if (count > 0) results.push({ lat: g.lat, lon: g.lon, count });
      });
    } catch (_) {}
    if (i + batchSize < grid.length) await new Promise(r => setTimeout(r, 200));
  }
  return results;
}

const OM_GRID_EUROPE_COARSE = [];
for (let lat = 36.0; lat <= 70.0; lat += 2.0) {
  for (let lon = -12.0; lon <= 42.0; lon += 2.0) {
    OM_GRID_EUROPE_COARSE.push({ lat: parseFloat(lat.toFixed(1)), lon: parseFloat(lon.toFixed(1)) });
  }
}

async function fetchWindForPoint(lat, lon) {
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
      `&current=wind_speed_10m,wind_direction_10m&timezone=UTC`;
    const res  = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const data = await res.json();
    const speed = data.current?.wind_speed_10m ?? 0;
    const dir   = data.current?.wind_direction_10m ?? 0;
    const toRad = Math.PI / 180;
    const goDir = (dir + 180) % 360;
    const u = speed * Math.sin(goDir * toRad);
    const v = speed * Math.cos(goDir * toRad);
    return { u, v, speed, dir };
  } catch (_) { return null; }
}

/* ═══════════════════════════════════════════════════════════════
   HEATMAP COLORS
   ═══════════════════════════════════════════════════════════════ */
function heatmapColor(count) {
  if (count >= 300) return { fill: '#ef4444', stroke: '#dc2626', opacity: 0.90 };
  if (count >= 150) return { fill: '#f97316', stroke: '#ea580c', opacity: 0.82 };
  if (count >= 30)  return { fill: '#facc15', stroke: '#ca8a04', opacity: 0.72 };
  return null;
}
function heatmapRadius(count) {
  if (count >= 300) return 28000;
  if (count >= 150) return 22000;
  if (count >= 30)  return 16000;
  return 12000;
}

function buildStrikeDensityGrid(strikes, cellDeg = 0.15) {
  const bins = {};
  strikes.forEach(s => {
    const latKey = Math.round(s.lat / cellDeg) * cellDeg;
    const lonKey = Math.round(s.lon / cellDeg) * cellDeg;
    const key    = `${latKey.toFixed(3)}_${lonKey.toFixed(3)}`;
    if (!bins[key]) bins[key] = { lat: latKey, lon: lonKey, count: 0 };
    bins[key].count++;
  });
  return Object.values(bins);
}

function strikeDensityColor(count) {
  if (count >= 50)  return { fill: '#ef4444', opacity: 0.55 };
  if (count >= 20)  return { fill: '#f97316', opacity: 0.48 };
  if (count >= 8)   return { fill: '#facc15', opacity: 0.40 };
  if (count >= 3)   return { fill: '#a78bfa', opacity: 0.32 };
  return null;
}

function strikeDensityRadius(count) {
  if (count >= 50) return 18000;
  if (count >= 20) return 14000;
  if (count >= 8)  return 10000;
  return 7000;
}

/* ═══════════════════════════════════════════════════════════════
   RAINVIEWER ACCURATE COLOURS
   https://www.rainviewer.com/api/color-schemes.html — scheme 6 (original)
   ═══════════════════════════════════════════════════════════════ */
const RAINVIEWER_COLORS = [
  '#00d8ff', '#00b4ff', '#0090ff', '#0070f0', '#0050e0',
  '#00a000', '#00c000', '#00e000', '#80ff00', '#c0ff00',
  '#ffff00', '#ffe000', '#ffc000', '#ff9000', '#ff6000',
  '#ff3000', '#ff0000', '#d00000', '#a00000', '#ff00ff',
];

/* ═══════════════════════════════════════════════════════════════
   BLOB POLYGON HELPERS
   ═══════════════════════════════════════════════════════════════ */
const STORM_THRESHOLD = 30;

function buildBlobPolygon(centerLat, centerLon, count) {
  const pts = 12;
  const baseRadius = 0.25 + count * 0.02;
  const ring = [];
  for (let i = 0; i < pts; i++) {
    const angle  = (i / pts) * Math.PI * 2;
    const wobble = 1 + (Math.random() * 0.35 - 0.175);
    const r      = baseRadius * wobble;
    ring.push([centerLat + r * Math.cos(angle), centerLon + r * Math.sin(angle) * 1.6]);
  }
  ring.push(ring[0]);
  return ring;
}

function blobRiskLevel(count) {
  if (count >= 300) return { color: '#ef4444', label: 'Red — Severe Storm',  desc: 'Intense lightning activity. High risk of cloud-to-ground strikes. Seek shelter immediately.' };
  if (count >= 150) return { color: '#f97316', label: 'Amber — Active Storm', desc: 'Frequent lightning detected. Avoid exposed areas and elevated ground.' };
  return               { color: '#facc15', label: 'Yellow — Storm Cell',   desc: 'Lightning cell detected. Stay alert and monitor movement.' };
}

/* ═══════════════════════════════════════════════════════════════
   GEOGRAPHIC FILTER
   ═══════════════════════════════════════════════════════════════ */
const GEO_BOUNDS_UK = { latMin: 49.5, latMax: 61.0, lonMin: -10.8, lonMax: 2.5 };
const GEO_BOUNDS_EU = { latMin: 34.0, latMax: 72.0, lonMin: -25.0, lonMax: 45.0 };

function inBounds(lat, lon, region = 'europe') {
  const b = region === 'uk' ? GEO_BOUNDS_UK : GEO_BOUNDS_EU;
  return lat >= b.latMin && lat <= b.latMax &&
         lon >= b.lonMin && lon <= b.lonMax;
}

/* ═══════════════════════════════════════════════════════════════
   ENSEMBLE / FORECAST DATA
   ═══════════════════════════════════════════════════════════════ */
const UK_GRID = [
  { lat: 51.5, lon: -0.1,  name: 'London & SE England' },
  { lat: 52.5, lon: -1.8,  name: 'Midlands' },
  { lat: 53.8, lon: -2.5,  name: 'Northern England' },
  { lat: 55.8, lon: -4.2,  name: 'Scotland' },
  { lat: 51.5, lon: -3.2,  name: 'Wales' },
  { lat: 52.0, lon: -0.5,  name: 'East Anglia' },
  { lat: 50.7, lon: -3.5,  name: 'SW England' },
  { lat: 54.6, lon: -5.9,  name: 'N Ireland' },
];

async function fetchEnsembleForPoint(lat, lon) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&hourly=cape,lifted_index,precipitation_probability,relative_humidity_2m,wind_gusts_10m` +
    `&daily=cape_max,precipitation_probability_max,wind_gusts_10m_max,wind_speed_10m_max,precipitation_sum` +
    `&timezone=Europe%2FLondon&forecast_days=3`;
  const res = await fetch(url, { signal: AbortSignal.timeout(12000) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function aggregateHourlyByDay(data) {
  const hourly = data.hourly;
  const daily  = data.daily;
  if (!hourly || !daily) return null;
  const nDays = daily.time.length;
  const results = [];
  for (let d = 0; d < nDays; d++) {
    const s = d * 24, e = Math.min(s + 24, hourly.time.length);
    const capeV = [], liV = [], rhV = [], ppV = [], gustV = [];
    for (let h = s; h < e; h++) {
      if (hourly.cape?.[h]                      != null) capeV.push(hourly.cape[h]);
      if (hourly.lifted_index?.[h]              != null) liV.push(hourly.lifted_index[h]);
      if (hourly.relative_humidity_2m?.[h]      != null) rhV.push(hourly.relative_humidity_2m[h]);
      if (hourly.precipitation_probability?.[h] != null) ppV.push(hourly.precipitation_probability[h]);
      if (hourly.wind_gusts_10m?.[h]            != null) gustV.push(hourly.wind_gusts_10m[h]);
    }
    const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
    const max = a => a.length ? Math.max(...a) : 0;
    results.push({
      date:    daily.time[d],
      capeMax: daily.cape_max?.[d] ?? max(capeV),
      capeAvg: avg(capeV),
      liMin:   liV.length ? Math.min(...liV) : 5,
      rhAvg:   avg(rhV),
      ppMax:   daily.precipitation_probability_max?.[d] ?? max(ppV),
      gustMax: daily.wind_gusts_10m_max?.[d] ?? max(gustV),
    });
  }
  return results;
}

function computeRiskFromMetrics({ capeMax, capeAvg, liMin, rhAvg, ppMax, gustMax }, type) {
  let score = 0;
  if      (capeMax >= 2000) score += 45;
  else if (capeMax >= 1000) score += 35;
  else if (capeMax >= 500)  score += 25;
  else if (capeMax >= 200)  score += 15;
  else if (capeMax >= 50)   score += 7;
  else if (capeAvg >= 20)   score += 3;
  if      (liMin <= -8) score += 25;
  else if (liMin <= -6) score += 20;
  else if (liMin <= -4) score += 14;
  else if (liMin <= -2) score += 8;
  else if (liMin <= 0)  score += 3;
  if      (rhAvg >= 85) score += 15;
  else if (rhAvg >= 75) score += 10;
  else if (rhAvg >= 65) score += 6;
  else if (rhAvg >= 55) score += 2;
  if      (ppMax >= 80) score += 10;
  else if (ppMax >= 60) score += 7;
  else if (ppMax >= 40) score += 4;
  else if (ppMax >= 20) score += 1;
  if      (gustMax >= 80) score += 5;
  else if (gustMax >= 60) score += 3;
  else if (gustMax >= 45) score += 1;
  if (type === 'hail')    { if (capeMax < 500 || gustMax < 40) score = Math.max(0, score - 20); if (capeMax >= 1500 && gustMax >= 60) score += 10; }
  else if (type === 'tornado') { score = Math.max(0, score - 35); if (capeMax >= 1000 && liMin <= -6 && gustMax >= 70) score += 15; }
  else if (type === 'lightning') { if (capeMax >= 300 && rhAvg >= 60) score += 5; }
  score = Math.max(0, Math.min(100, score));
  if (score >= 75) return 'High';
  if (score >= 55) return 'Moderate';
  if (score >= 38) return 'Marginal';
  if (score >= 22) return 'Low';
  if (score >= 10) return 'Very Low';
  return 'No Risk';
}

const EUROPE_GRID = [
  { lat: 51.5, lon: 0,    name: 'UK' },
  { lat: 48.8, lon: 2.3,  name: 'France' },
  { lat: 52.5, lon: 13.4, name: 'Germany' },
  { lat: 40.4, lon: -3.7, name: 'Spain' },
  { lat: 41.9, lon: 12.5, name: 'Italy' },
  { lat: 52.4, lon: 21.0, name: 'Poland' },
  { lat: 50.1, lon: 14.4, name: 'Czechia' },
  { lat: 45.8, lon: 15.9, name: 'Balkans' },
];

async function buildEnsembleForecasts(useEurope = false) {
  const grid = useEurope ? EUROPE_GRID : UK_GRID;
  const results = await Promise.allSettled(grid.map(pt => fetchEnsembleForPoint(pt.lat, pt.lon)));
  const pointData = results.map((r, i) => ({
    point: grid[i],
    days:  r.status === 'fulfilled' ? aggregateHourlyByDay(r.value) : null,
  })).filter(p => p.days && p.days.length > 0);
  if (!pointData.length) throw new Error('No forecast data available');
  const nDays = pointData[0].days.length;
  const forecasts = {};
  RISK_TYPES.forEach(({ id: type }) => {
    forecasts[type] = Array.from({ length: nDays }, (_, dayIdx) => {
      const regionRisks = {};
      let sumCape = 0, sumRH = 0, count = 0;
      pointData.forEach(({ point, days }) => {
        const d = days[dayIdx];
        if (!d) return;
        sumCape += d.capeMax; sumRH += d.rhAvg; count++;
        regionRisks[point.name] = computeRiskFromMetrics(d, type);
      });
      const avgCape = count ? sumCape / count : 0;
      const avgRH   = count ? sumRH   / count : 60;
      const sampleDay = pointData[0].days[dayIdx];
      const overallRisk = computeRiskFromMetrics(
        { capeMax: avgCape, capeAvg: avgCape * 0.6, liMin: sampleDay?.liMin ?? 5, rhAvg: avgRH, ppMax: sampleDay?.ppMax ?? 0, gustMax: sampleDay?.gustMax ?? 0 },
        type
      );
      const riskValues  = Object.values(regionRisks);
      const sortedRisks = [...new Set(riskValues)].sort((a, b) => RISK_ORDER.indexOf(a) - RISK_ORDER.indexOf(b));
      const dateStr     = pointData[0].days[dayIdx].date;
      const dayLabel    = dayIdx === 0 ? 'Today' : dayIdx === 1 ? 'Tomorrow' : 'Day 3';
      const formattedDate = new Date(dateStr + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
      return {
        date: dateStr, dayLabel, formattedDate, type,
        riskLevel: overallRisk, minRisk: sortedRisks[0] || 'No Risk',
        maxRisk: sortedRisks[sortedRisks.length - 1] || 'No Risk',
        avgCape: Math.round(avgCape), avgRH: Math.round(avgRH),
        regionRisks, generatedAt: new Date().toISOString(),
      };
    });
  });
  return { forecasts, generatedAt: new Date().toISOString() };
}

/* ═══════════════════════════════════════════════════════════════
   AUTO-ARCHIVE HOOK
   ═══════════════════════════════════════════════════════════════ */
function useAutoArchive(outlooks, queryClient) {
  const mutation = useMutation({
    mutationFn: async (updates) => {
      await Promise.all(updates.map(({ id, patch }) => db.entities.TCMOutlook.update(id, patch)));
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tcmOutlooks'] }),
  });
  useEffect(() => {
    if (!outlooks || outlooks.length === 0) return;
    const runArchive = () => {
      const now      = new Date();
      const todayStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
      const updates  = [];
      outlooks.forEach(o => {
        if (!o.is_archived && o.outlook_date && o.outlook_date < todayStr && !o.is_upcoming && !o.is_tomorrow)
          updates.push({ id: o.id, patch: { is_today: false, is_archived: true } });
        if (o.is_tomorrow && o.outlook_date && o.outlook_date <= todayStr)
          updates.push({ id: o.id, patch: { is_tomorrow: false, is_today: true } });
        if (o.is_two_day && o.outlook_date) {
          const d = new Date(o.outlook_date + 'T12:00:00');
          if (Math.round((d - now) / 86400000) <= 1) updates.push({ id: o.id, patch: { is_two_day: false, is_tomorrow: true } });
        }
        if (o.is_upcoming && o.outlook_date) {
          const d = new Date(o.outlook_date + 'T12:00:00');
          if (Math.round((d - now) / 86400000) <= 2) updates.push({ id: o.id, patch: { is_upcoming: false, is_two_day: true } });
        }
      });
      if (updates.length) mutation.mutate(updates);
    };
    runArchive();
    const now = new Date();
    const ms  = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 5).getTime() - now.getTime();
    const t   = setTimeout(() => { runArchive(); }, ms);
    return () => clearTimeout(t);
  }, [outlooks]); // eslint-disable-line
}

/* ═══════════════════════════════════════════════════════════════
   7-DAY HISTORICAL LIGHTNING PANEL  (new component)
   ═══════════════════════════════════════════════════════════════ */
function HistoricalLightningPanel({ lightMode = false, forcedSnapshots = [] }) {
  const [showWarnings, setShowWarnings] = useState(false);
const [warningMapDate, setWarningMapDate] = useState(null);
const [histView,      setHistView]      = useState('uk');
  const [dailyTotals,   setDailyTotals]   = useState({});
  const [loading,       setLoading]       = useState(false);
  const [mapDateStr,    setMapDateStr]    = useState(null);
  const [mapData,       setMapData]       = useState([]);
  const [mapLoading,    setMapLoading]    = useState(false);
  const [forcedMapDate, setForcedMapDate] = useState(null);
  const mapRef        = useRef(null);
  const mapInst       = useRef(null);
const chartRef      = useRef(null);
const chartInst     = useRef(null);

  // Build lookup: YYYY-MM-DD → array of forced snapshots for that day
  const forcedByDate = {};
  forcedSnapshots.forEach(snap => {
    const d = snap.capturedAt ? new Date(snap.capturedAt).toISOString().slice(0, 10) : null;
    if (!d) return;
    if (!forcedByDate[d]) forcedByDate[d] = [];
    forcedByDate[d].push(snap);
  });

  const fetchHistory = useCallback(async (view) => {
    setLoading(true);
    setDailyTotals({});
    try {
      const data = await fetchOMHistoricalDays(90, view === 'europe');
      if (data) setDailyTotals(data);
    } catch (_) {}
    setLoading(false);
  }, []);

  useEffect(() => { fetchHistory(histView); }, [histView, fetchHistory]);

  // Build sorted last-7-days labels
  // Build days: show up to 90 days back but only render days that have data
  const allDays = [];
  for (let i = 89; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    allDays.push(d.toISOString().slice(0, 10));
  }
  const days = allDays.filter(d => {
    const hasOM     = (dailyTotals[d] || 0) > 0;
    const hasForced = (forcedByDate[d] || []).length > 0;
    const isToday   = d === todayDateStr();
    return hasOM || hasForced || isToday;
  });

  const maxTotal = Math.max(
    1,
    ...days.map(d => Math.max(
      dailyTotals[d] || 0,
      (forcedByDate[d] || []).reduce((s, sn) => s + (sn.strikes?.length || 0), 0)
    ))
  );

  const handleSelectDay = async (dateStr) => {
    setShowWarnings(false);
setWarningMapDate(null);
    const isDeselect = mapDateStr === dateStr;
    if (isDeselect) {
      setMapDateStr(null);
      setMapData([]);
      setForcedMapDate(null);
      return;
    }
    setMapDateStr(dateStr);
    setMapData([]);
    setForcedMapDate(forcedByDate[dateStr]?.length ? dateStr : null);
    setMapLoading(true);
    try {
      const data = await fetchOMStrikesForDate(dateStr, histView === 'europe');
      setMapData(data);
    } catch (_) {}
    setMapLoading(false);
  };

  // Render historical map
  useEffect(() => {
    const L = window.L;
    if (!L || !mapRef.current || !mapDateStr) return;
    if (mapInst.current) { mapInst.current.remove(); mapInst.current = null; }

    if (!document.getElementById('blitz-overlay-css')) {
      const s = document.createElement('style');
      s.id = 'blitz-overlay-css';
      s.textContent = `.blitz-screen { mix-blend-mode: screen !important; background: transparent !important; }`;
      document.head.appendChild(s);
    }

    const blitzUrl = BLITZORTUNG_DATE_IMAGES[mapDateStr];
    const center = histView === 'europe' ? [52, 12] : [54, -2];
    const zoom   = histView === 'europe' ? 4 : 5;
    const map = L.map(mapRef.current, { center, zoom, zoomControl: false, attributionControl: false });
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { maxZoom: 10, subdomains: 'abcd' }).addTo(map);

    if (blitzUrl) {
      L.imageOverlay(blitzUrl, [[-90, -180], [90, 180]], { opacity: 1.0, className: 'blitz-screen' }).addTo(map);
    } else {
      const layer = L.layerGroup().addTo(map);
      mapData.forEach(pt => {
        let color = '#facc15', radius = 14000;
        if (pt.count >= 1000) { color = '#ef4444'; radius = 32000; }
        else if (pt.count >= 300)  { color = '#f97316'; radius = 24000; }
        else if (pt.count >= 80)   { color = '#facc15'; radius = 18000; }
        else { color = '#a78bfa'; radius = 12000; }
        L.circle([pt.lat, pt.lon], {
          radius, color: 'transparent', fillColor: color, fillOpacity: 0.40, weight: 0,
        }).addTo(layer);
      });
    }

    mapInst.current = map;
    return () => { if (mapInst.current) { mapInst.current.remove(); mapInst.current = null; } };
  }, [mapData, mapDateStr, histView]);
  useEffect(() => {
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      days.push(d.toISOString().slice(0, 10));
    }
    function renderChart() {
      if (!chartRef.current || !window.Chart) return;
      if (chartInst.current) { chartInst.current.destroy(); chartInst.current = null; }
      const labels = days.map(d => new Date(d + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }));
      const data   = days.map(d => {
        const omCount     = dailyTotals[d] || 0;
        const forcedCount = (forcedByDate[d] || []).reduce((s, sn) => s + (sn.strikes?.length || 0), 0);
        return Math.max(omCount, forcedCount);
      });
      chartInst.current = new window.Chart(chartRef.current, {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: histView === 'uk' ? 'UK Strikes' : 'Europe Strikes',
            data,
            backgroundColor: data.map(v =>
              v >= 50000 ? 'rgba(239,68,68,0.8)' :
              v >= 10000 ? 'rgba(249,115,22,0.8)' :
              v >= 2000  ? 'rgba(250,204,21,0.8)' :
              v >= 300   ? 'rgba(52,211,153,0.8)' :
                           'rgba(167,139,250,0.6)'
            ),
            borderColor: 'transparent',
            borderRadius: 5,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ` ${ctx.parsed.y.toLocaleString()} strikes` } } },
          scales: {
            x: { ticks: { color: '#64748b', font: { size: 11 }, maxRotation: 30 }, grid: { color: 'rgba(255,255,255,0.04)' } },
            y: { ticks: { color: '#64748b', font: { size: 11 }, callback: v => v >= 1000 ? `${(v/1000).toFixed(0)}k` : v }, grid: { color: 'rgba(255,255,255,0.06)' }, beginAtZero: true },
          },
        },
      });
    }
    if (window.Chart) {
      renderChart();
    } else {
      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js';
      s.onload = renderChart;
      document.head.appendChild(s);
    }
    return () => { if (chartInst.current) { chartInst.current.destroy(); chartInst.current = null; } };
  }, [dailyTotals, histView, forcedByDate]);

  const bg = lightMode ? 'rgba(255,255,255,0.7)' : 'rgba(10,15,30,0.8)';
  const border = lightMode ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.08)';
  const textMain = lightMode ? '#1e293b' : '#f1f5f9';
  const textSub  = lightMode ? '#64748b' : '#64748b';

  return (
    <motion.div initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }} className="mx-auto max-w-6xl px-6 mb-10">
      <div style={{ borderRadius:20, overflow:'hidden', border:`1px solid ${border}`, background:bg, backdropFilter:'blur(16px)' }}>
        {/* Header */}
        <div style={{ padding:'18px 22px', borderBottom:`1px solid ${border}`, display:'flex', alignItems:'center', justifyContent:'space-between', flexWrap:'wrap', gap:10 }}>
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <div style={{ width:38, height:38, borderRadius:11, background:'rgba(250,204,21,0.12)', border:'1px solid rgba(250,204,21,0.3)', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <Zap style={{ width:18, height:18, color:'#facc15' }} />
            </div>
            <div>
              <h3 style={{ margin:0, fontSize:'1rem', fontWeight:700, color:textMain }}>Historical Lightning Activity</h3>
              <p style={{ margin:0, fontSize:'0.72rem', color:textSub }}>Open-Meteo ERA5 · Last 7 days · Click a day to view map</p>
            </div>
          </div>
          {/* UK / Europe toggle */}
          <div style={{ display:'flex', borderRadius:10, overflow:'hidden', border:`1px solid ${border}` }}>
            {[['uk','🇬🇧 UK'],['europe','🌍 Europe']].map(([id,lbl]) => (
              <button key={id} onClick={() => { setHistView(id); setMapDateStr(null); setMapData([]); }}
                style={{ padding:'7px 16px', fontSize:'0.74rem', fontWeight:700, color:histView===id?'#0a0f1e':(lightMode?'#64748b':'#94a3b8'), background:histView===id?'#facc15':'transparent', border:'none', cursor:'pointer', transition:'all 0.2s' }}>
                {lbl}
              </button>
            ))}
          </div>
        </div>

        {/* 7-day bar chart */}
        <div style={{ padding:'20px 22px' }}>
        {/* Bar chart */}
        <div style={{ position: 'relative', width: '100%', height: 160, marginBottom: 20 }}>
          <canvas ref={chartRef} role="img" aria-label="Day by day lightning strike counts" />
        </div>
          {loading ? (
            <div style={{ display:'flex', alignItems:'center', justifyContent:'center', padding:'32px 0', gap:10 }}>
              <Loader2 style={{ width:18, height:18, color:'#facc15', animation:'spin 1s linear infinite' }} />
              <span style={{ fontSize:'0.8rem', color:textSub }}>Fetching lightning history…</span>
            </div>
          ) : (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:8 }}>
              {days.map((dateStr) => {
                const count        = dailyTotals[dateStr] || 0;
                const forcedSnaps  = forcedByDate[dateStr] || [];
                const forcedCount  = forcedSnaps.reduce((s, sn) => s + (sn.strikes?.length || 0), 0);
                const hasForced = forcedSnaps.length > 0;
                const barH     = count > 0 ? Math.max(6, (count / maxTotal) * 100) : 4;
                const d        = new Date(dateStr + 'T12:00:00');
                const dayName  = d.toLocaleDateString('en-GB', { weekday:'short' });
                const dayNum   = d.toLocaleDateString('en-GB', { day:'numeric', month:'short' });
                const isToday  = dateStr === todayDateStr();
                const selected = mapDateStr === dateStr;
                let barColor = '#a78bfa';
                if (count >= 50000) barColor = '#ef4444';
                else if (count >= 10000) barColor = '#f97316';
                else if (count >= 2000)  barColor = '#facc15';
                else if (count >= 300)   barColor = '#34d399';
                return (
                  <button key={dateStr} onClick={() => handleSelectDay(dateStr)}
                    style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6, padding:'10px 6px', borderRadius:12, background:selected?`rgba(250,204,21,0.1)`:lightMode?'rgba(0,0,0,0.04)':'rgba(255,255,255,0.03)', border:`1px solid ${selected?'rgba(250,204,21,0.5)':border}`, cursor:'pointer', transition:'all 0.2s' }}>
                    <span style={{ fontSize:'0.65rem', fontWeight:700, color:isToday?'#facc15':textSub, letterSpacing:'0.04em' }}>{dayName}</span>
                    <div style={{ width:'100%', height:100, display:'flex', alignItems:'flex-end', justifyContent:'center' }}>
                      <div style={{ width:'70%', height:`${barH}%`, minHeight:4, borderRadius:'4px 4px 0 0', background:barColor, opacity:count===0?0.25:1, transition:'height 0.5s ease', boxShadow:count>0?`0 0 8px ${barColor}44`:undefined }} />
                    </div>
                    <span style={{ fontSize:'0.58rem', color:textSub }}>{dayNum}</span>
                    <span style={{ fontSize:'0.68rem', fontWeight:700, color:count>0?barColor:textSub, fontFamily:'monospace' }}>
                      {count > 0 ? (count >= 1000 ? `${(count/1000).toFixed(1)}k` : count) : '—'}
                    </span>
                    {hasForced && (
                      <span style={{ fontSize:'0.58rem', fontWeight:700, color:'#f59e0b', fontFamily:'monospace', background:'rgba(245,158,11,0.12)', borderRadius:4, padding:'1px 5px', marginTop:2 }}>
                        📸 {forcedCount > 0 ? `${forcedCount} live` : 'snap'}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* Map for selected day */}
          <AnimatePresence>
            {mapDateStr && (
              <motion.div initial={{ opacity:0, height:0 }} animate={{ opacity:1, height:'auto' }} exit={{ opacity:0, height:0 }} transition={{ duration:0.35 }} style={{ overflow:'hidden' }}>
                <div style={{ marginTop:18, borderRadius:14, overflow:'hidden', border:`1px solid ${border}`, position:'relative' }}>
                  <div style={{ padding:'10px 14px', background:lightMode?'rgba(0,0,0,0.05)':'rgba(0,0,0,0.4)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <span style={{ fontSize:'0.75rem', fontWeight:700, color:textMain }}>
                      ⚡ Lightning map: {new Date(mapDateStr+'T12:00:00').toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long'})}
                    </span>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      {mapLoading && <Loader2 style={{ width:13, height:13, color:'#facc15', animation:'spin 1s linear infinite' }} />}
                      <button onClick={() => { setMapDateStr(null); setMapData([]); }} style={{ background:'rgba(255,255,255,0.08)', border:'none', borderRadius:7, width:26, height:26, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}><X style={{width:12,height:12}}/></button>
                    </div>
                  </div>
                  <div ref={mapRef} style={{ width:'100%', height:320, background:'#060d1a' }} />
                  {/* Legend */}
                  <div style={{ position:'absolute', bottom:12, left:12, background:'rgba(6,13,26,0.9)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:10, padding:'8px 12px', backdropFilter:'blur(12px)' }}>
                    {[{c:'#a78bfa',l:'<80 strikes'},{c:'#facc15',l:'80–300'},{c:'#f97316',l:'300–1000'},{c:'#ef4444',l:'>1000'}].map(({c,l}) => (
                      <div key={l} style={{ display:'flex', alignItems:'center', gap:6, marginBottom:3 }}>
                        <div style={{ width:9, height:9, borderRadius:'50%', background:c }} />
                        <span style={{ fontSize:'0.62rem', color:'#94a3b8' }}>{l}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Forced snapshot live-strikes map */}
          <AnimatePresence>
            {forcedMapDate && (forcedByDate[forcedMapDate] || []).length > 0 && (
              <motion.div initial={{ opacity:0, height:0 }} animate={{ opacity:1, height:'auto' }} exit={{ opacity:0, height:0 }} transition={{ duration:0.35 }} style={{ overflow:'hidden' }}>
                <div style={{ marginTop:14, borderRadius:14, overflow:'hidden', border:`1px solid rgba(245,158,11,0.35)`, position:'relative' }}>
                  <div style={{ padding:'10px 14px', background:'rgba(245,158,11,0.08)', display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <Camera style={{ width:13, height:13, color:'#f59e0b' }} />
                      <span style={{ fontSize:'0.75rem', fontWeight:700, color:'#f59e0b' }}>
                        📸 Force Snapshot — Live Strikes:{' '}
                        {new Date(forcedMapDate + 'T12:00:00').toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long' })}
                      </span>
                      <span style={{ fontSize:'0.65rem', color:'#64748b', fontFamily:'monospace' }}>
                        ({(forcedByDate[forcedMapDate] || []).reduce((s, sn) => s + (sn.strikes?.length || 0), 0).toLocaleString()} strikes)
                      </span>
                    </div>
                    <button onClick={() => setForcedMapDate(null)} style={{ background:'rgba(255,255,255,0.08)', border:'none', borderRadius:7, width:26, height:26, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}>
                      <X style={{ width:12, height:12 }} />
                    </button>
                  </div>
                  {(forcedByDate[forcedMapDate]?.[0]?.stormWarnings || []).length > 0 && (
  <button onClick={() => setShowWarnings(v => !v)}
    style={{ margin:'10px 14px 0', display:'inline-flex', alignItems:'center', gap:6, padding:'7px 14px', borderRadius:9, background: showWarnings ? 'rgba(249,115,22,0.15)' : 'rgba(255,255,255,0.05)', border:`1px solid ${showWarnings ? '#f97316' : 'rgba(255,255,255,0.1)'}`, color: showWarnings ? '#f97316' : '#94a3b8', fontSize:'0.74rem', fontWeight:700, cursor:'pointer' }}>
    <AlertTriangle style={{width:12,height:12}}/> {showWarnings ? 'Hide' : 'View'} Storm Warnings ({(forcedByDate[forcedMapDate]?.[0]?.stormWarnings || []).length})
  </button>
)}
                  {(() => {
  const allWarnings = (forcedByDate[forcedMapDate] || [])
    .flatMap(snap => snap.stormWarnings || []);
  const uniqueWarnings = allWarnings.filter(
    (w, i, arr) => arr.findIndex(x => x.id === w.id) === i
  );
  return (
    <>
      {uniqueWarnings.length > 0 && (
        <div style={{ padding: '0 14px 10px' }}>
          <button
            onClick={() => {
              setShowWarnings(v => !v);
              setWarningMapDate(forcedMapDate);
            }}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '7px 16px',
              borderRadius: 10,
              background: showWarnings
                ? 'rgba(249,115,22,0.15)'
                : 'rgba(255,255,255,0.05)',
              border: `1px solid ${showWarnings ? '#f97316' : 'rgba(255,255,255,0.12)'}`,
              color: showWarnings ? '#f97316' : '#94a3b8',
              fontSize: '0.74rem',
              fontWeight: 700,
              cursor: 'pointer',
              transition: 'all 0.2s',
            }}
          >
            <AlertTriangle style={{ width: 12, height: 12 }} />
            {showWarnings ? 'Hide' : 'View'} Storm Warnings ({uniqueWarnings.length})
          </button>
          {showWarnings && (
            <div style={{
              marginTop: 8,
              display: 'flex',
              flexWrap: 'wrap',
              gap: 6,
            }}>
              {uniqueWarnings.map((w, i) => {
                const cfg = STORM_RISK[w.risk] || { color: '#f97316', fullLabel: w.risk };
                return (
                  <div key={w.id || i} style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '4px 10px',
                    borderRadius: 8,
                    background: `rgba(${hexToRgb(cfg.color)},0.1)`,
                    border: `1px solid rgba(${hexToRgb(cfg.color)},0.3)`,
                  }}>
                    <div style={{
                      width: 8, height: 8, borderRadius: 2,
                      background: cfg.color,
                    }} />
                    <span style={{ fontSize: '0.68rem', fontWeight: 700, color: cfg.color }}>
                      {cfg.fullLabel || w.risk}
                    </span>
                    <span style={{ fontSize: '0.65rem', color: '#64748b' }}>
                      {w.locationLabel} · {w.count} strikes
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
      <ForcedSnapshotMap
        snaps={forcedByDate[forcedMapDate] || []}
        histView={histView}
        showWarnings={showWarnings}
        warnings={uniqueWarnings}
      />
    </>
  );
})()}
                  {/* Strike age legend */}
                  <div style={{ position:'absolute', bottom:12, left:12, background:'rgba(6,13,26,0.9)', border:'1px solid rgba(245,158,11,0.2)', borderRadius:10, padding:'8px 12px', backdropFilter:'blur(12px)' }}>
                    <p style={{ margin:'0 0 5px', fontSize:'0.6rem', fontWeight:700, color:'#f59e0b', letterSpacing:'0.08em', textTransform:'uppercase' }}>Strike Age at Snapshot</p>
                    {[
                      { color:'#ffffff', label:'< 5 min' },
                      { color:'#facc15', label:'< 10 min' },
                      { color:'#f97316', label:'< 30 min' },
                      { color:'#ef4444', label:'< 1 hr' },
                      { color:'#7f1d1d', label:'< 6 hr' },
                      { color:'#7c3aed', label:'< 12 hr' },
                      { color:'#4c1d95', label:'older' },
                    ].map(k => (
                      <div key={k.label} style={{ display:'flex', alignItems:'center', gap:6, marginBottom:3 }}>
                        <svg width="9" height="9" viewBox="0 0 9 9">
                          <rect x="3.5" y="0.5" width="2" height="8" rx="1" fill={k.color} opacity="0.9"/>
                          <rect x="0.5" y="3.5" width="8" height="2" rx="1" fill={k.color} opacity="0.9"/>
                        </svg>
                        <span style={{ fontSize:'0.62rem', color:'#94a3b8' }}>{k.label}</span>
                      </div>
                    ))}
                  </div>
                  {/* Snapshot time chips */}
                  <div style={{ position:'absolute', bottom:12, right:12, display:'flex', flexDirection:'column', gap:5, maxWidth:160 }}>
                    {(forcedByDate[forcedMapDate] || []).map((snap, i) => (
                      <div key={i} style={{ background:'rgba(6,13,26,0.9)', border:'1px solid rgba(245,158,11,0.25)', borderRadius:8, padding:'5px 10px', backdropFilter:'blur(8px)' }}>
                        <p style={{ margin:0, fontSize:'0.62rem', color:'#f59e0b', fontWeight:700 }}>Snapshot {i + 1}</p>
                        <p style={{ margin:0, fontSize:'0.6rem', color:'#64748b', fontFamily:'monospace' }}>
                          {new Date(snap.capturedAt).toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit' })}
                        </p>
                        <p style={{ margin:0, fontSize:'0.6rem', color:'#475569' }}>{(snap.strikes || []).length.toLocaleString()} strikes</p>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </div>
      </div>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   RISK LEGEND
   ═══════════════════════════════════════════════════════════════ */
function RiskLegend({ lightMode = false }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45, duration: 0.5 }} className="mx-auto max-w-3xl px-6 mb-10">
      <button onClick={() => setExpanded(v => !v)} className="w-full flex items-center justify-between px-5 py-3.5 rounded-2xl transition-colors"
        style={{ background: lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.04)', border: `1px solid ${lightMode ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.08)'}` }}
        onMouseEnter={e => (e.currentTarget.style.background = lightMode ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.07)')}
        onMouseLeave={e => (e.currentTarget.style.background = lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.04)')}>
        <div className="flex items-center gap-2.5">
          <ShieldAlert className="w-4 h-4 text-purple-400" />
          <span className={`text-sm font-semibold tracking-tight ${lightMode ? 'text-slate-700' : 'text-slate-200'}`}>Risk Level Guide</span>
          <div className="flex gap-1 ml-1">
            {RISK_LEVEL_GUIDE.map(r => <span key={r.level} className="w-2.5 h-2.5 rounded-full" style={{ background: r.color }} />)}
          </div>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
      </button>
      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }} style={{ overflow: 'hidden' }}>
            <div className="mt-2 rounded-2xl p-4 grid gap-2.5" style={{ background: lightMode ? 'rgba(255,255,255,0.7)' : 'rgba(15,23,42,0.7)', border: `1px solid ${lightMode ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.07)'}`, backdropFilter: 'blur(12px)' }}>
              {RISK_LEVEL_GUIDE.map((r, i) => (
                <motion.div key={r.level} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06, duration: 0.3 }}
                  className="flex items-start gap-3 px-4 py-3 rounded-xl" style={{ background: r.bgColor, border: `1px solid ${r.borderColor}` }}>
                  <div className="flex-shrink-0 flex items-center gap-2 min-w-[110px]">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: r.color }} />
                    <span className="text-xs font-bold tracking-wide" style={{ color: r.color }}>{r.level}</span>
                  </div>
                  <p className="text-xs leading-relaxed" style={{ color: lightMode ? '#1e293b' : '#ffffff' }}>{r.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   HAMBURGER / SIDEBAR
   ═══════════════════════════════════════════════════════════════ */
function TCMHamburger({ isAdmin, tcmLogoUrl, isEurope, isUSA, lightMode, onToggleLightMode }) {
  const [open, setOpen] = useState(false);
  const gradStyle = { fontFamily: "'Orbitron',sans-serif", fontWeight: 900, background: 'linear-gradient(135deg,#a78bfa 0%,#818cf8 25%,#38bdf8 60%,#34d399 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' };
  return (
    <>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@800;900&display=swap');`}</style>
      <div className="fixed top-4 left-4 z-50 flex items-center gap-3">
        <button onClick={() => setOpen(o => !o)} className="p-3 rounded-2xl backdrop-blur-md border transition-colors flex-shrink-0"
          style={{ background: lightMode ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.07)', borderColor: lightMode ? 'rgba(0,0,0,0.15)' : 'rgba(255,255,255,0.12)' }}>
          <AnimatePresence mode="wait">
            {open ? <motion.div key="c" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.18 }}><X className={`w-5 h-5 ${lightMode ? 'text-slate-800' : 'text-white'}`} /></motion.div>
                  : <motion.div key="m" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.18 }}><Menu className={`w-5 h-5 ${lightMode ? 'text-slate-800' : 'text-white'}`} /></motion.div>}
          </AnimatePresence>
        </button>
        <AnimatePresence>
          {tcmLogoUrl && (
            <motion.img key="logo" src={tcmLogoUrl} alt="TCM" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }} transition={{ duration: 0.25 }} style={{ height: 56, width: 'auto', objectFit: 'contain' }} />
          )}
        </AnimatePresence>
        <motion.div initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15, duration: 0.4 }}
          style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', lineHeight: 1, userSelect: 'none', gap: 1 }}>
          <span style={{ ...gradStyle, fontSize: '1.75rem', letterSpacing: '0.2em', lineHeight: 1 }}>TCM</span>
          {isEurope && <span style={{ ...gradStyle, fontSize: '0.9rem', letterSpacing: '0.15em', lineHeight: 1 }}>Europe</span>}
          {isUSA    && <span style={{ ...gradStyle, fontSize: '0.9rem', letterSpacing: '0.15em', lineHeight: 1 }}>USA</span>}
          <span style={{ ...gradStyle, fontSize: '0.52rem', letterSpacing: '0.18em', lineHeight: 1, fontWeight: 800 }}>V2.0</span>
        </motion.div>
      </div>
      <AnimatePresence>
        {open && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} className="fixed inset-0 z-40" style={{ background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }} />
            <motion.div initial={{ x: -300, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -300, opacity: 0 }} transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
              className="fixed left-0 top-0 h-screen w-64 z-50 flex flex-col"
              style={{ background: lightMode ? 'linear-gradient(180deg,#f0f4f8 0%,#e2e8f0 50%,#f0f4f8 100%)' : 'linear-gradient(180deg,#0f172a 0%,#1e293b 50%,#0f172a 100%)', borderRight: `1px solid ${lightMode ? 'rgba(0,0,0,0.1)' : 'rgba(148,163,184,0.1)'}` }}>
              <div className="flex items-center gap-3 px-5 pt-6 pb-5 border-b" style={{ borderColor: lightMode ? 'rgba(0,0,0,0.08)' : 'rgba(148,163,184,0.08)' }}>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'rgba(139,92,246,0.2)', border: '1px solid rgba(139,92,246,0.3)' }}>
                  <CloudLightning className="w-4 h-4 text-purple-400" />
                </div>
                <span className={`text-sm font-semibold tracking-tight ${lightMode ? 'text-slate-800' : 'text-white'}`}>TCM Navigator</span>
              </div>
              <div className="flex flex-col gap-1 pt-4 px-3">
                <Link to="/" onClick={() => setOpen(false)} className="flex items-center gap-3 px-4 py-3 rounded-xl"
                  onMouseEnter={e => (e.currentTarget.style.background = lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                  <Home className="w-4 h-4 text-sky-500" /><span className={`text-sm font-medium ${lightMode ? 'text-slate-700' : 'text-slate-200'}`}>Back to Home</span>
                </Link>
                <Link to="/WeatherPatterns" onClick={() => setOpen(false)} className="flex items-center gap-3 px-4 py-3 rounded-xl"
                  onMouseEnter={e => (e.currentTarget.style.background = lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(139,92,246,0.07)')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                  <CloudLightning className="w-4 h-4 text-purple-400" /><span className={`text-sm font-medium ${lightMode ? 'text-slate-700' : 'text-slate-200'}`}>Weather Patterns</span>
                </Link>
                {isAdmin && (
                  <Link to="/AdminSettings" onClick={() => setOpen(false)} className="flex items-center gap-3 px-4 py-3 rounded-xl"
                    onMouseEnter={e => (e.currentTarget.style.background = 'rgba(245,158,11,0.07)')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                    <ShieldAlert className="w-4 h-4 text-amber-400" /><span className={`text-sm font-medium ${lightMode ? 'text-slate-700' : 'text-slate-200'}`}>Admin Settings</span>
                  </Link>
                )}
                <button onClick={() => { onToggleLightMode(); setOpen(false); }} className="flex items-center gap-3 px-4 py-3 rounded-xl w-full text-left transition-colors"
                  onMouseEnter={e => (e.currentTarget.style.background = lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)')} onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                  <span style={{ fontSize: '1rem' }}>{lightMode ? '🌙' : '☀️'}</span>
                  <span className={`text-sm font-medium ${lightMode ? 'text-slate-700' : 'text-slate-200'}`}>{lightMode ? 'Dark Mode' : 'Light Mode'}</span>
                </button>
              </div>
              <div className="mt-auto px-5 pb-6">
                <p className="text-xs font-medium" style={{ color: lightMode ? 'rgba(71,85,105,0.5)' : 'rgba(148,163,184,0.35)' }}>Thunderstorm Climatology Monitor</p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

/* ═══════════════════════════════════════════════════════════════
   AUTO FORECAST COMPONENTS (imports preserved)
   ═══════════════════════════════════════════════════════════════ */
import { AutoForecastCard, ForecastEditModal } from '@/components/ForecastCardComponents';
import ThunderstormMonitor from '@/components/AutoForecastCard';
import USAMonitor from '@/components/USAMonitor';

function hexToRgb(hex) {
  if (!hex || hex[0] !== '#') return '148,163,184';
  return [parseInt(hex.slice(1,3),16), parseInt(hex.slice(3,5),16), parseInt(hex.slice(5,7),16)].join(',');
}

function ArchivedEnsembleSection({ forecasts, overrides, isAdmin, isEurope }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ marginTop: 24 }}>
      <button onClick={() => setOpen(v => !v)} style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px', borderRadius: 14, background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.07)', cursor: 'pointer', marginBottom: open ? 12 : 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Archive style={{ width: 14, height: 14, color: 'rgba(148,163,184,0.4)' }} />
          <span style={{ fontSize: '0.72rem', fontWeight: 700, color: 'rgba(255,255,255,0.45)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Archived Ensemble Forecasts</span>
          <span style={{ fontSize: '0.68rem', padding: '1px 8px', borderRadius: 999, background: 'rgba(255,255,255,0.05)', color: '#475569' }}>{forecasts.length}</span>
        </div>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}>
          <ChevronDown style={{ width: 14, height: 14, color: 'rgba(148,163,184,0.3)' }} />
        </motion.div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.3 }} style={{ overflow: 'hidden' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {forecasts.map(fc => (
                <AutoForecastCard key={fc.date} forecast={fc} override={overrides[`${fc.type}-${fc.date}`] || null} isAdmin={isAdmin} onEdit={() => {}} riskTypes={RISK_TYPES} isEurope={isEurope} />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AutoForecastPanel({ isAdmin, isEurope }) {
  const [activeType, setActiveType] = useState('thunderstorm');
  const [forecasts,  setForecasts]  = useState(null);
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState(null);
  const [lastFetch,  setLastFetch]  = useState(null);
  const [overrides,  setOverrides]  = useState(loadForecastOverrides);
  const [editingFc,  setEditingFc]  = useState(null);
  const intervalRef = useRef(null);

  const fetchForecasts = useCallback(async (force = false) => {
    const cached = loadAutoForecasts();
    function lastBoundaryMs() {
      const now = new Date();
      const ukParts = new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/London', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hour12: false }).formatToParts(now);
      const get = (type) => parseInt(ukParts.find(p => p.type === type).value, 10);
      const ukYear = get('year'), ukMonth = get('month') - 1, ukDay = get('day'), ukHour = get('hour');
      const lastBoundary = [18, 12, 6, 0].find(h => h <= ukHour) ?? 0;
      const pad = (n) => String(n).padStart(2, '0');
      const ukBoundaryStr = `${ukYear}-${pad(ukMonth + 1)}-${pad(ukDay)}T${pad(lastBoundary)}:00:00`;
      const candidateUtc = new Date(ukBoundaryStr + 'Z');
      for (let offsetHours = -2; offsetHours <= 2; offsetHours++) {
        const trial = new Date(candidateUtc.getTime() - offsetHours * 3600000);
        const trialUkHour = parseInt(new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/London', hour: '2-digit', hour12: false }).format(trial), 10);
        if (trialUkHour === lastBoundary) return trial.getTime();
      }
      return candidateUtc.getTime();
    }
    if (!force && cached && cached.generatedAt && new Date(cached.generatedAt).getTime() >= lastBoundaryMs()) {
      setForecasts(cached.forecasts); setLastFetch(new Date(cached.generatedAt)); return;
    }
    setLoading(true); setError(null);
    try {
      const result = await buildEnsembleForecasts(isEurope);
      setForecasts(result.forecasts); setLastFetch(new Date(result.generatedAt)); saveAutoForecasts(result);
      const todayKey = todayDateStr();
      const prev = loadForecastArchive();
      const updated = [{ date: todayKey, forecasts: result.forecasts, generatedAt: result.generatedAt }, ...prev.filter(e => e.date !== todayKey)].slice(0, 30);
      saveForecastArchive(updated);
    } catch (e) { setError('Unable to fetch ensemble data. ' + e.message); }
    setLoading(false);
  }, [isEurope]);

  const fetchForecastsRef = useRef(fetchForecasts);
  useEffect(() => { fetchForecastsRef.current = fetchForecasts; }, [fetchForecasts]);

  useEffect(() => {
    fetchForecastsRef.current(false);
    function scheduleNextFetch() {
      const now = new Date();
      const ukParts = new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/London', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).formatToParts(now);
      const getP = (type) => parseInt(ukParts.find(p => p.type === type).value, 10);
      const ukHour = getP('hour'), ukMin = getP('minute'), ukSec = getP('second');
      const nextBoundary = [0, 6, 12, 18, 24].find(h => h > ukHour) ?? 24;
      const msUntil = (nextBoundary - ukHour) * 3600000 - ukMin * 60000 - ukSec * 1000 - (now.getTime() % 1000);
      intervalRef.current = setTimeout(() => { fetchForecastsRef.current(true); scheduleNextFetch(); }, msUntil);
    }
    scheduleNextFetch();
    return () => clearTimeout(intervalRef.current);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSaveOverride = (fc, overrideData) => {
    const key = `${fc.type}-${fc.date}`;
    setOverrides(prev => {
      const updated = { ...prev };
      if (overrideData === null) delete updated[key]; else updated[key] = overrideData;
      saveForecastOverrides(updated);
      return updated;
    });
  };

  const [activeDayIdx, setActiveDayIdx] = useState(0);
  const todayStr          = todayDateStr();
  const allTypedForecasts = forecasts?.[activeType] || [];
  const typedForecasts    = allTypedForecasts.filter(fc => fc.date >= todayStr);
  const archivedEnsemble  = allTypedForecasts.filter(fc => fc.date < todayStr);
  const currentType       = RISK_TYPES.find(t => t.id === activeType);
  const typeColor         = currentType?.color || '#facc15';
  const totalDays         = typedForecasts.length;
  const currentFc         = typedForecasts[activeDayIdx] || null;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="mx-auto max-w-6xl px-6 mb-10">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 38, height: 38, borderRadius: 12, background: `rgba(${hexToRgb(typeColor)},0.15)`, border: `1px solid ${typeColor}40`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <CloudLightning style={{ width: 18, height: 18, color: typeColor }} />
          </div>
          <div>
            <h2 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f1f5f9', margin: 0 }}>Auto Ensemble Forecast</h2>
            <p style={{ fontSize: '0.72rem', color: '#64748b', margin: 0 }}>
              10-model ensemble · ECMWF, UKMO, ICON, GFS · updated every 6 hrs
              {lastFetch && ` · Last: ${lastFetch.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`}
            </p>
          </div>
        </div>
        <button onClick={() => fetchForecasts(true)} disabled={loading} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '7px 13px', borderRadius: 10, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#94a3b8', fontSize: '0.71rem', cursor: loading ? 'wait' : 'pointer' }}>
          {loading ? <Loader2 style={{ width: 12, height: 12, animation: 'spin 1s linear infinite' }} /> : <RefreshCw style={{ width: 12, height: 12 }} />}
          Refresh
        </button>
      </div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 20, flexWrap: 'wrap' }}>
        {RISK_TYPES.map(rt => {
          const Icon   = rt.icon;
          const active = activeType === rt.id;
          return (
            <button key={rt.id} onClick={() => { setActiveType(rt.id); setActiveDayIdx(0); }}
              style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', borderRadius: 12, fontSize: '0.75rem', fontWeight: 700, cursor: 'pointer', transition: 'all 0.2s', border: `1.5px solid ${active ? rt.color : 'rgba(255,255,255,0.08)'}`, background: active ? `rgba(${hexToRgb(rt.color)},0.12)` : 'rgba(255,255,255,0.03)', color: active ? rt.color : '#64748b' }}>
              <Icon style={{ width: 13, height: 13 }} />{rt.label}
            </button>
          );
        })}
      </div>
      {loading && !forecasts && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '48px 0', gap: 12 }}>
          <Loader2 style={{ width: 20, height: 20, color: typeColor, animation: 'spin 1s linear infinite' }} />
          <span style={{ fontSize: '0.82rem', color: '#475569' }}>Fetching ensemble model data…</span>
        </div>
      )}
      {error && <div style={{ padding: '16px 20px', borderRadius: 14, background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.2)', color: '#f87171', fontSize: '0.8rem', marginBottom: 16 }}>⚠ {error}</div>}
      {!loading && !error && totalDays > 1 && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 18 }}>
          <button onClick={() => setActiveDayIdx(i => Math.max(0, i - 1))} disabled={activeDayIdx === 0} style={{ padding: '7px 14px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.1)', background: activeDayIdx === 0 ? 'transparent' : 'rgba(255,255,255,0.06)', color: activeDayIdx === 0 ? '#334155' : '#94a3b8', cursor: activeDayIdx === 0 ? 'default' : 'pointer', fontSize: '0.78rem' }}>← Previous</button>
          <div style={{ display: 'flex', gap: 6 }}>
            {typedForecasts.map((fc, idx) => (
              <button key={fc.date} onClick={() => setActiveDayIdx(idx)} style={{ padding: '6px 14px', borderRadius: 10, fontSize: '0.75rem', fontWeight: 700, cursor: 'pointer', border: `1.5px solid ${idx === activeDayIdx ? typeColor : 'rgba(255,255,255,0.08)'}`, background: idx === activeDayIdx ? `rgba(${hexToRgb(typeColor)},0.14)` : 'transparent', color: idx === activeDayIdx ? typeColor : '#475569' }}>
                {fc.dayLabel}
              </button>
            ))}
          </div>
          <button onClick={() => setActiveDayIdx(i => Math.min(totalDays - 1, i + 1))} disabled={activeDayIdx === totalDays - 1} style={{ padding: '7px 14px', borderRadius: 10, border: '1px solid rgba(255,255,255,0.1)', background: activeDayIdx === totalDays - 1 ? 'transparent' : 'rgba(255,255,255,0.06)', color: activeDayIdx === totalDays - 1 ? '#334155' : '#94a3b8', cursor: activeDayIdx === totalDays - 1 ? 'default' : 'pointer', fontSize: '0.78rem' }}>Next →</button>
        </div>
      )}
      {!loading && !error && currentFc && (
        <AnimatePresence mode="wait">
          <motion.div key={`${activeType}-${activeDayIdx}`} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.25 }}>
            <AutoForecastCard forecast={currentFc} override={overrides[`${currentFc.type}-${currentFc.date}`] || null} isAdmin={isAdmin} onEdit={setEditingFc} riskTypes={RISK_TYPES} isEurope={isEurope} />
          </motion.div>
        </AnimatePresence>
      )}
      {!loading && !error && archivedEnsemble.length > 0 && (
        <ArchivedEnsembleSection forecasts={archivedEnsemble} overrides={overrides} isAdmin={isAdmin} isEurope={isEurope} />
      )}
      <AnimatePresence>
        {editingFc && (
          <ForecastEditModal forecast={editingFc} currentOverride={overrides[`${editingFc.type}-${editingFc.date}`] || null} onSave={(data) => handleSaveOverride(editingFc, data)} onClose={() => setEditingFc(null)} />
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   HELPERS
   ═══════════════════════════════════════════════════════════════ */
function StatPill({ icon, label, value, color }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span style={{ color }}>{icon}</span>
      <div>
        <p style={{ margin: 0, fontSize: '0.65rem', color: '#475569', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>{label}</p>
        <p style={{ margin: 0, fontSize: '0.88rem', fontWeight: 700, color: '#e2e8f0', fontFamily: 'monospace' }}>{value}</p>
      </div>
    </div>
  );
}

function makePlusIcon(color, size = 14) {
  const c = Math.round(size / 2), arm = Math.round(size * 0.42), thick = Math.max(2, Math.round(size * 0.18));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <rect x="${c - thick/2}" y="${c - arm}" width="${thick}" height="${arm*2}" rx="1" fill="${color}" opacity="0.92"/>
    <rect x="${c - arm}" y="${c - thick/2}" width="${arm*2}" height="${thick}" rx="1" fill="${color}" opacity="0.92"/>
  </svg>`;
}

function strikeColor(timeMs) {
  const ageMin = (Date.now() - timeMs) / 60000;
  if (ageMin < 5)   return '#ffffff';
  if (ageMin < 10)  return '#facc15';
  if (ageMin < 30)  return '#f97316';
  if (ageMin < 60)  return '#ef4444';
  if (ageMin < 360) return '#7f1d1d';
  if (ageMin < 720) return '#7c3aed';
  return '#4c1d95';
}

function localDateKey(ts) { return new Date(ts || Date.now()).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); }

/* ═══════════════════════════════════════════════════════════════
   DBSCAN
   ═══════════════════════════════════════════════════════════════ */
function dbscan(points, eps, minPts) {
  const labels = new Array(points.length).fill(-2);
  let cluster  = 0;
  const nb = (idx) => {
    const p = points[idx]; const out = [];
    for (let i = 0; i < points.length; i++) {
      if (i === idx) continue;
      const q = points[i];
      const dLat = p.lat - q.lat;
      const dLon = (p.lon - q.lon) * Math.cos((p.lat * Math.PI) / 180);
      if (Math.sqrt(dLat * dLat + dLon * dLon) <= eps) out.push(i);
    }
    return out;
  };
  for (let i = 0; i < points.length; i++) {
    if (labels[i] !== -2) continue;
    const seeds = nb(i);
    if (seeds.length < minPts) { labels[i] = -1; continue; }
    labels[i] = cluster;
    for (let j = 0; j < seeds.length; j++) {
      const s = seeds[j];
      if (labels[s] === -1) labels[s] = cluster;
      if (labels[s] !== -2) continue;
      labels[s] = cluster;
      const nb2 = nb(s);
      if (nb2.length >= minPts) nb2.forEach(x => { if (!seeds.includes(x)) seeds.push(x); });
    }
    cluster++;
  }
  const clusters = {};
  for (let i = 0; i < points.length; i++) { const l = labels[i]; if (l < 0) continue; if (!clusters[l]) clusters[l] = []; clusters[l].push(points[i]); }
  return Object.values(clusters);
}

/* ═══════════════════════════════════════════════════════════════
   SMOOTH BLOB
   ═══════════════════════════════════════════════════════════════ */
function buildSmoothBlob(pts, padDeg = 0.18) {
  if (pts.length < 3) {
    const cLat = pts.reduce((s,p) => s+p.lat,0)/pts.length;
    const cLon = pts.reduce((s,p) => s+p.lon,0)/pts.length;
    const r = padDeg * 1.5;
    return Array.from({length:16},(_,i) => {
      const a = (i/16)*Math.PI*2;
      return [cLat + Math.cos(a)*r, cLon + Math.sin(a)*r*1.5];
    });
  }
  const cLat = pts.reduce((s,p) => s+p.lat,0)/pts.length;
  const cLon = pts.reduce((s,p) => s+p.lon,0)/pts.length;
  const ANGLES = 24;
  const radii = [];
  for (let i = 0; i < ANGLES; i++) {
    const angle = (i / ANGLES) * Math.PI * 2;
    let maxR = padDeg;
    pts.forEach(p => {
      const dLat = p.lat - cLat, dLon = (p.lon - cLon) * 0.65;
      const pAngle = Math.atan2(dLon, dLat);
      const angDiff = Math.abs(((angle - pAngle + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
      if (angDiff < Math.PI / 3) {
        const dist = Math.sqrt(dLat*dLat + dLon*dLon);
        const weight = Math.cos(angDiff * 3 / Math.PI) * 0.5 + 0.5;
        maxR = Math.max(maxR, dist * weight + padDeg);
      }
    });
    radii.push(maxR);
  }
  const smooth = radii.map((_, i) => {
    const w = [0.1, 0.2, 0.4, 0.2, 0.1];
    return w.reduce((s, wt, wi) => s + wt * radii[(i + wi - 2 + ANGLES) % ANGLES], 0);
  });
  return smooth.map((r, i) => {
    const angle = (i / ANGLES) * Math.PI * 2;
    return [cLat + Math.cos(angle)*r, cLon + Math.sin(angle)*r*1.5];
  });
}

/* ═══════════════════════════════════════════════════════════════
   STORM RISK CONFIG
   ═══════════════════════════════════════════════════════════════ */
const STORM_RISK = {
  yellow: { label: 'Yellow', fullLabel: 'Yellow Thunderstorm Advisory', color: '#facc15', minPoints: 6,  desc: 'Localised lightning and rainfall possible. Stay alert.', expiryMs: 30 * 60 * 1000 },
  amber:  { label: 'Amber',  fullLabel: 'Amber Thunderstorm Warning',   color: '#f97316', minPoints: 14, desc: 'Active thunderstorm. Flash flooding, strong gusts and hail possible. Move indoors.', expiryMs: 20 * 60 * 1000 },
  red:    { label: 'Red',    fullLabel: 'Red Severe Thunderstorm Warning', color: '#ef4444', minPoints: 28, desc: 'Dangerous thunderstorm. Structural damage, large hail and major flooding likely. Take cover immediately.', expiryMs: 10 * 60 * 1000 },
};

const STORM_PATH_MAX_DEG = 0.72;

/* ═══════════════════════════════════════════════════════════════
   TTS strings — use enhanced city lookup
   ═══════════════════════════════════════════════════════════════ */
function buildTtsString(risk, count, lat, lon) {
  const loc = nearestCity(lat, lon);
  if (risk === 'yellow') {
    return `Thunderstorm advisory. ${count} lightning strikes have been detected ${loc}. ` +
      `Localised lightning, sudden downpours, and gusty winds are possible over the next 30 minutes. ` +
      `Stay alert and avoid exposed areas such as open fields and hilltops.`;
  }
  if (risk === 'amber') {
    return `Amber thunderstorm warning. An active storm cell has been detected ${loc}, ` +
      `producing ${count} lightning strikes in the past 30 minutes. ` +
      `Flash flooding, strong wind gusts, and hail are likely. ` +
      `Move indoors now and keep away from windows.`;
  }
  return `Red severe thunderstorm warning. A dangerous and rapidly intensifying storm is occurring ${loc}. ` +
    `${count} lightning strikes have been recorded in just 30 minutes. ` +
    `There is a high risk of structural damage, large hail, and significant flooding. ` +
    `Take cover immediately in a substantial building. Do not travel. This is an emergency.`;
}

/* ═══════════════════════════════════════════════════════════════
   STORM TRACKER
   ═══════════════════════════════════════════════════════════════ */
function createStormTracker() {
  let rolling = [];
  const cellHistory = {};

  function ingest(strike) { rolling.push(strike); }
  function pruneRolling() { const cutoff = Date.now() - 30*60*1000; rolling = rolling.filter(s => s.time > cutoff); }

  function cluster(windMap = {}) {
    pruneRolling();
    if (rolling.length < 5) return [];
    const groups = dbscan(rolling, 0.55, 6);
    return groups.map((pts, idx) => {
      const cLat = pts.reduce((s,p) => s+p.lat,0)/pts.length;
      const cLon = pts.reduce((s,p) => s+p.lon,0)/pts.length;
      const id   = `storm-${idx}`;
      if (!cellHistory[id]) cellHistory[id] = { history: [], createdAt: Date.now() };
      const h = cellHistory[id];
      h.history.push({ lat: cLat, lon: cLon, time: Date.now() });
      if (h.history.length > 30) h.history.shift();

      let driftLat = 0, driftLon = 0, hasDrift = false;
      if (h.history.length >= 4) {
        const oldest = h.history[0], newest = h.history[h.history.length-1];
        const rawDLat = newest.lat - oldest.lat, rawDLon = newest.lon - oldest.lon;
        if (Math.sqrt(rawDLat*rawDLat + rawDLon*rawDLon) > 0.02) {
          driftLat = rawDLat / h.history.length;
          driftLon = rawDLon / h.history.length;
          hasDrift = true;
        }
      }
      const windKey = `${Math.round(cLat * 2) / 2}_${Math.round(cLon * 2) / 2}`;
      const wind = windMap[windKey];
      let windLat = 0, windLon = 0, hasWind = false;
      if (wind && wind.speed > 2) {
        const scale = (wind.speed / 111) * (1/60) * 3;
        windLat = wind.v * scale / 111;
        windLon = wind.u * scale / (111 * Math.cos(cLat * Math.PI / 180));
        hasWind = true;
      }
      let dir = null;
      if (hasDrift || hasWind) {
        const dw = hasDrift && hasWind ? 0.5 : hasDrift ? 1.0 : 0.0;
        const ww = hasWind  ? (hasDrift ? 0.5 : 1.0) : 0.0;
        const blendLat = driftLat * dw + windLat * ww;
        const blendLon = driftLon * dw + windLon * ww;
        const mag = Math.sqrt(blendLat*blendLat + blendLon*blendLon);
        if (mag > 0.0001) {
          const clamped = Math.min(mag * 10, STORM_PATH_MAX_DEG);
          dir = { dLat: (blendLat/mag) * clamped, dLon: (blendLon/mag) * clamped };
        }
      }

      const count  = pts.length;
      let risk = count >= STORM_RISK.red.minPoints ? 'red' : count >= STORM_RISK.amber.minPoints ? 'amber' : 'yellow';
      const avgAmp = pts.reduce((s,p) => s + Math.abs(p.amp||0),0)/pts.length;
      if (avgAmp > 80  && risk === 'yellow') risk = 'amber';
      if (avgAmp > 120 && risk === 'amber')  risk = 'red';

      const spread = pts.reduce((s,p) => {
        const dLat = p.lat-cLat, dLon = p.lon-cLon;
        return s + Math.sqrt(dLat*dLat+dLon*dLon);
      }, 0) / pts.length;
      const corePolygon = buildSmoothBlob(pts, Math.max(0.12, spread * 0.8));

      let pathPolygon = null;
      if (dir && corePolygon.length >= 2) {
        const pLen   = Math.sqrt(dir.dLon*dir.dLon + dir.dLat*dir.dLat) || 1;
        const normLat = dir.dLat / pLen, normLon = dir.dLon / pLen;
        const tipDist = Math.min(pLen, STORM_PATH_MAX_DEG);
        const tipLat  = cLat + normLat * tipDist;
        const tipLon  = cLon + normLon * tipDist;
        const baseW   = Math.max(0.08, Math.min(0.20, spread * 0.5));
        const arrowW  = baseW * 0.4;
        pathPolygon = [
          [cLat + (-normLon) * baseW,  cLon + (normLat) * baseW],
          [tipLat + (-normLon) * arrowW, tipLon + (normLat) * arrowW],
          [tipLat + normLat * 0.15,     tipLon + normLon * 0.15],
          [tipLat - (-normLon) * arrowW, tipLon - (normLat) * arrowW],
          [cLat - (-normLon) * baseW,  cLon - (normLat) * baseW],
        ];
      }

      const prevRisk  = cellHistory[id]._lastRisk;
      const RISK_RANK = { yellow: 0, amber: 1, red: 2 };
      const prevRiskWasUpgraded = prevRisk && RISK_RANK[prevRisk] > RISK_RANK[risk];
      if (prevRiskWasUpgraded) risk = prevRisk;
      const riskChanged = prevRisk && prevRisk !== risk && !prevRiskWasUpgraded;
      cellHistory[id]._lastRisk = risk;

      const expiresAt = Date.now() + STORM_RISK[risk].expiryMs;

      return {
        id, risk, corePolygon, pathPolygon, count,
        centroid: { lat: cLat, lon: cLon },
        direction: dir,
        locationLabel: nearestCityShort(cLat, cLon),
        startTime: new Date(h.createdAt).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'}),
        endTime:   new Date(h.createdAt+2*60*60*1000).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'}),
        updatedAt: Date.now(),
        expiresAt,
        riskChanged,
      };
    });
  }

  function getRolling() { return rolling; }
  function resetDay()   { const snap = [...rolling]; rolling = []; Object.keys(cellHistory).forEach(k => delete cellHistory[k]); return snap; }
  return { ingest, cluster, getRolling, resetDay };
}

/* ═══════════════════════════════════════════════════════════════
   THUNDER SOUND
   ═══════════════════════════════════════════════════════════════ */
function createThunderSound(audioCtx) {
  try {
    const ctx = audioCtx, now = ctx.currentTime;
    const bufSize = ctx.sampleRate * 0.08;
    const buf  = ctx.createBuffer(1, bufSize, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < bufSize; i++) data[i] = (Math.random()*2-1);
    const noiseSource = ctx.createBufferSource(); noiseSource.buffer = buf;
    const crackFilter = ctx.createBiquadFilter(); crackFilter.type = 'bandpass'; crackFilter.frequency.value = 1200; crackFilter.Q.value = 0.4;
    const crackGain   = ctx.createGain(); crackGain.gain.setValueAtTime(0.55, now); crackGain.gain.exponentialRampToValueAtTime(0.001, now+0.08);
    noiseSource.connect(crackFilter); crackFilter.connect(crackGain); crackGain.connect(ctx.destination);
    noiseSource.start(now); noiseSource.stop(now+0.08);
    const rumbleBuf = ctx.createBuffer(1, ctx.sampleRate*0.6, ctx.sampleRate);
    const rData = rumbleBuf.getChannelData(0);
    for (let i = 0; i < rData.length; i++) rData[i] = (Math.random()*2-1);
    const rumbleSource = ctx.createBufferSource(); rumbleSource.buffer = rumbleBuf;
    const rumbleFilter = ctx.createBiquadFilter(); rumbleFilter.type = 'lowpass'; rumbleFilter.frequency.value = 80;
    const rumbleGain   = ctx.createGain(); rumbleGain.gain.setValueAtTime(0.0, now); rumbleGain.gain.linearRampToValueAtTime(0.3, now+0.05); rumbleGain.gain.exponentialRampToValueAtTime(0.001, now+0.6);
    rumbleSource.connect(rumbleFilter); rumbleFilter.connect(rumbleGain); rumbleGain.connect(ctx.destination);
    rumbleSource.start(now+0.01); rumbleSource.stop(now+0.62);
  } catch (_) {}
}

function renderGlowFlash(lat, lon, flashLayerRef) {
  const L = window.L;
  if (!L || !flashLayerRef.current) return;
  const ring = L.circleMarker([lat,lon],{radius:6,color:'#ffffff',fillColor:'#ffffff',fillOpacity:1.0,weight:2,opacity:1.0}).addTo(flashLayerRef.current);
  const core = L.circleMarker([lat,lon],{radius:3,color:'#ffffff',fillColor:'#fffde0',fillOpacity:1.0,weight:1,opacity:1.0}).addTo(flashLayerRef.current);
  const DURATION_MS=1500,FPS=40,STEPS=Math.round((DURATION_MS/1000)*FPS);
  let step=0;
  const iv=setInterval(()=>{
    step++;
    const t=step/STEPS;
    if(t>=1){clearInterval(iv);try{flashLayerRef.current?.removeLayer(ring);}catch(_){}try{flashLayerRef.current?.removeLayer(core);}catch(_){}return;}
    const eased=1-Math.pow(1-t,2);
    try{ring.setRadius(6+eased*28);ring.setStyle({fillOpacity:0.9*(1-t),opacity:0.85*(1-t)});}catch(_){}
    try{const coreFade=Math.max(0,1-t*2.5);core.setStyle({fillOpacity:coreFade,opacity:coreFade});}catch(_){}
  },1000/FPS);
}

import OMHistoricalPanel from '@/components/tcm/OMHistoricalPanel';

/* ═══════════════════════════════════════════════════════════════
   ARCHIVE MAP
   ═══════════════════════════════════════════════════════════════ */
function ArchivedDayMap({ day }) {
  const mapRef  = useRef(null);
  const mapInst = useRef(null);
  useEffect(() => {
    const L = window.L;
    if (!L || !mapRef.current || mapInst.current) return;
    const map = L.map(mapRef.current, { center: [54,-2], zoom: 5, zoomControl: false, attributionControl: false, interactive: true });
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { maxZoom: 10, subdomains: 'abcd' }).addTo(map);
    const layer   = L.layerGroup().addTo(map);
    const strikes = day.strikes || [];

    const densityGrid = buildStrikeDensityGrid(strikes);
    densityGrid.forEach(cell => {
      const cfg = strikeDensityColor(cell.count);
      if (!cfg) return;
      L.circle([cell.lat, cell.lon], { radius: strikeDensityRadius(cell.count), color: 'transparent', fillColor: cfg.fill, fillOpacity: cfg.opacity, weight: 0 }).addTo(layer);
    });

    if (day.omGridData) {
      day.omGridData.forEach(pt => {
        const cfg = heatmapColor(pt.recentCount || pt.dayCount || 0);
        if (!cfg) return;
        L.circle([pt.lat, pt.lon], { radius: heatmapRadius(pt.recentCount || pt.dayCount || 0), color: cfg.stroke, fillColor: cfg.fill, fillOpacity: cfg.opacity * 0.5, weight: 1 }).addTo(layer);
      });
    }

    const sample = strikes.length > 8000 ? strikes.filter((_,i) => i % Math.ceil(strikes.length/8000) === 0) : strikes;
    sample.forEach(s => {
      const dayStart = day.capturedAt - 24*3600*1000;
      const ratio    = Math.min(1, Math.max(0, (s.time - dayStart) / (24*3600*1000)));
      const hue      = Math.round(ratio * 60);
      const icon     = L.divIcon({ html: makePlusIcon(`hsl(${hue},90%,65%)`,10), iconAnchor: [5,5], className: '' });
      L.marker([s.lat, s.lon], { icon }).addTo(layer);
    });
    mapInst.current = map;
    return () => { map.remove(); mapInst.current = null; };
  }, [day]);
  return <div ref={mapRef} style={{ width: '100%', height: 200, borderRadius: 12, overflow: 'hidden', background: '#0a0f1e' }} />;
}

/* ═══════════════════════════════════════════════════════════════
   ARCHIVE PANEL
   ═══════════════════════════════════════════════════════════════ */
function ArchivePanel({ archive, setArchive, isAdmin, onForceSnapshot }) {
  const [expanded,    setExpanded]    = useState(false);
  const [selectedDay, setSelectedDay] = useState(null);
  const [forcing,  setForcing]  = useState(false);
  const [snapOk,   setSnapOk]   = useState(false);

  const handleDelete = (dateKey, e) => {
    e.stopPropagation();
    if (!window.confirm(`Delete archived day "${dateKey}"? This cannot be undone.`)) return;
    setArchive(prev => {
      const updated = prev.filter(d => d.date !== dateKey);
      saveArchive(updated);
      return updated;
    });
    if (selectedDay?.date === dateKey) setSelectedDay(null);
  };

  const handleForce = async () => {
    setForcing(true);
    await onForceSnapshot();
    setForcing(false);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-6xl px-6 mb-16">
     {isAdmin && (
  <div style={{ marginBottom: 10, padding: '14px 16px', borderRadius: 14, background: 'rgba(245,158,11,0.07)', border: '1px solid rgba(245,158,11,0.22)', display: 'flex', flexDirection: 'column', gap: 10 }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <Camera style={{ width: 15, height: 15, color: '#f59e0b' }} />
      <div>
        <p style={{ margin: 0, fontSize: '0.78rem', fontWeight: 700, color: '#f59e0b' }}>Admin: Force Archive Snapshot</p>
        <p style={{ margin: 0, fontSize: '0.68rem', color: '#64748b' }}>Select a past time (up to 24h ago) to snapshot. Strikes from that window are saved as the archive entry for that day.</p>
      </div>
    </div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
      <label style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 600 }}>Snapshot time (past 24h):</label>
      <input
        type="datetime-local"
        id="admin-snapshot-time"
        max={new Date().toISOString().slice(0, 16)}
        min={new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().slice(0, 16)}
        defaultValue={new Date().toISOString().slice(0, 16)}
        style={{ padding: '5px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(245,158,11,0.3)', color: '#f1f5f9', fontSize: '0.74rem', colorScheme: 'dark' }}
      />
      <button onClick={() => {
        const el = document.getElementById('admin-snapshot-time');
        const selectedTime = el ? new Date(el.value).getTime() : Date.now();
        setForcing(true);
        onForceSnapshot(selectedTime).then(() => {
        setForcing(false);
        setSnapOk(true);
        setTimeout(() => setSnapOk(false), 3000);
      });
      }} disabled={forcing}
        style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px', borderRadius: 10, background: forcing ? 'rgba(245,158,11,0.05)' : 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.35)', color: '#f59e0b', fontSize: '0.74rem', fontWeight: 700, cursor: forcing ? 'wait' : 'pointer', whiteSpace: 'nowrap' }}>
        {forcing ? <Loader2 style={{ width: 12, height: 12, animation: 'spin 1s linear infinite' }} /> : <Camera style={{ width: 12, height: 12 }} />}
        {forcing ? 'Saving…' : 'Force Snapshot Now'}
      </button>
      {snapOk && (
        <span style={{ fontSize: '0.72rem', color: '#22c55e', fontWeight: 700 }}>✓ Snapshot saved!</span>
      )}
    </div>
  </div>
)}

      {archive.length === 0 ? (
        <div style={{ padding: '24px', borderRadius: 16, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)', textAlign: 'center' }}>
          <Archive style={{ width: 28, height: 28, color: '#334155', margin: '0 auto 10px' }} />
          <p style={{ margin: 0, fontSize: '0.85rem', color: '#475569' }}>No archived days yet — strike data will appear here after the first midnight snapshot.</p>
        </div>
      ) : (
        <>
          <button onClick={() => setExpanded(v => !v)}
            style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 20px', borderRadius: 16, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', cursor: 'pointer', marginBottom: expanded ? 12 : 0 }}
            onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.06)')} onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.03)')}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 34, height: 34, borderRadius: 10, background: 'rgba(56,189,248,0.1)', border: '1px solid rgba(56,189,248,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Archive style={{ width: 16, height: 16, color: '#38bdf8' }} />
              </div>
              <div style={{ textAlign: 'left' }}>
                <p style={{ margin: 0, fontSize: '0.9rem', fontWeight: 700, color: '#f1f5f9' }}>Lightning Archive</p>
                <p style={{ margin: 0, fontSize: '0.72rem', color: '#64748b' }}>{archive.length} day{archive.length!==1?'s':''} stored · Auto-snapshot at 23:59 daily (even with no tab open)</p>
              </div>
            </div>
            {expanded ? <ChevronUp style={{ width: 16, height: 16, color: '#475569' }} /> : <ChevronDown style={{ width: 16, height: 16, color: '#475569' }} />}
          </button>
          <AnimatePresence>
            {expanded && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.35 }} style={{ overflow: 'hidden' }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(190px,1fr))', gap: 10, marginBottom: 14 }}>
                  {[...archive].reverse().map(day => (
                    <div key={day.date} style={{ position: 'relative' }}>
                      <button onClick={() => setSelectedDay(selectedDay?.date === day.date ? null : day)}
                        style={{ width: '100%', padding: '12px 14px', borderRadius: 12, textAlign: 'left', background: selectedDay?.date === day.date ? 'rgba(56,189,248,0.1)' : 'rgba(255,255,255,0.03)', border: `1px solid ${selectedDay?.date === day.date ? '#38bdf8' : 'rgba(255,255,255,0.07)'}`, cursor: 'pointer', paddingRight: isAdmin ? 36 : 14 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 6 }}>
                          <Calendar style={{ width: 13, height: 13, color: '#38bdf8' }} />
                          <span style={{ fontSize: '0.78rem', fontWeight: 700, color: '#e2e8f0' }}>{day.date}</span>
                          {day.isForced && <span style={{ fontSize: '0.58rem', padding: '1px 5px', borderRadius: 4, background: 'rgba(245,158,11,0.15)', color: '#f59e0b', fontWeight: 700 }}>FORCED</span>}
                        </div>
                        <p style={{ margin: 0, fontSize: '0.7rem', color: '#64748b' }}>{(day.strikes||[]).length.toLocaleString()} strikes</p>
                        {day.omDayTotal != null && (
                          <p style={{ margin: '2px 0 0', fontSize: '0.7rem', color: '#facc15' }}>⚡ {day.omDayTotal.toLocaleString()} OM strikes</p>
                        )}
                        <p style={{ margin: 0, fontSize: '0.65rem', color: '#475569', marginTop: 2 }}>{day.stormCount||0} storm{day.stormCount!==1?'s':''} · Peak {day.peakHour||'—'}</p>
                      </button>
                      {isAdmin && (
                        <button onClick={(e) => handleDelete(day.date, e)}
                          style={{ position: 'absolute', top: 8, right: 8, width: 22, height: 22, borderRadius: 6, background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#ef4444' }}>
                          <Trash2 style={{ width: 11, height: 11 }} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <AnimatePresence>
                  {selectedDay && (
                    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }}
                      style={{ borderRadius: 16, overflow: 'hidden', border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(10,15,30,0.85)' }}>
                      <div style={{ padding: '13px 18px', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <div>
                          <p style={{ margin: 0, fontSize: '0.9rem', fontWeight: 700, color: '#f1f5f9' }}>{selectedDay.date} {selectedDay.isForced && <span style={{ fontSize: '0.65rem', marginLeft: 6, padding: '1px 6px', borderRadius: 4, background: 'rgba(245,158,11,0.15)', color: '#f59e0b' }}>ADMIN FORCED</span>}</p>
                          <p style={{ margin: 0, fontSize: '0.72rem', color: '#64748b' }}>{(selectedDay.strikes||[]).length.toLocaleString()} strikes · {selectedDay.stormCount||0} storm systems{selectedDay.omDayTotal != null ? ` · ${selectedDay.omDayTotal.toLocaleString()} OM total` : ''}</p>
                        </div>
                        <button onClick={() => setSelectedDay(null)} style={{ background: 'rgba(255,255,255,0.06)', border: 'none', borderRadius: 8, width: 29, height: 29, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b' }}><X style={{ width: 13, height: 13 }} /></button>
                      </div>
                      <div style={{ padding: 16 }}>
                        <ArchivedDayMap day={selectedDay} />
                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10, marginTop: 12 }}>
                          {[
                            { label: 'Strikes',         val: (selectedDay.strikes||[]).length.toLocaleString() },
                            { label: 'OM Total',        val: selectedDay.omDayTotal != null ? selectedDay.omDayTotal.toLocaleString() : '—' },
                            { label: 'Storm Systems',   val: selectedDay.stormCount || 0 },
                            { label: 'Peak Hour',       val: selectedDay.peakHour || '—' },
                            { label: 'OM Active Cells', val: selectedDay.omActiveCells || '—' },
                            { label: 'Max Cell Count',  val: selectedDay.omMaxCell || '—' },
                          ].map(({ label, val }) => (
                            <div key={label} style={{ padding: '10px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
                              <p style={{ margin: 0, fontSize: '0.62rem', color: '#64748b', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</p>
                              <p style={{ margin: 0, fontSize: '1rem', fontWeight: 700, color: '#e2e8f0', fontFamily: 'monospace' }}>{val}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      )}
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   LAYER DEFS
   ═══════════════════════════════════════════════════════════════ */
const LAYER_DEFS = [
  { id: 'strikes',    label: 'Strikes',     icon: CloudLightning, color: '#facc15' },
  { id: 'strikeheat', label: 'Strike Heat', icon: Zap,            color: '#a78bfa' },
  { id: 'storms',     label: 'Storm Paths', icon: AlertTriangle,  color: '#f97316' },
  { id: 'radar',      label: 'Radar',       icon: Radio,          color: '#38bdf8' },
  { id: 'omheat',     label: 'OM Heatmap',  icon: Zap,            color: '#ef4444' },
  { id: 'omblobs',    label: 'Storm Cells', icon: AlertTriangle,  color: '#a78bfa' },
];

const MAP_VIEWS = {
  uk:     { center: [54.8, -3.2], zoom: 6 },
  europe: { center: [52.0,  9.0], zoom: 4 },
};

/* ═══════════════════════════════════════════════════════════════
   BLITZORTUNG WEBSOCKET
   ═══════════════════════════════════════════════════════════════ */
function blitzortungDecode(raw) {
  try {
    const d = Array.from(raw);
    if (!d.length) return null;
    const e = {};
    let c = d[0];
    let f = c;
    const g = [c];
    let h = 256;
    let o = h;
    for (let i = 1; i < d.length; i++) {
      const code = d[i].charCodeAt(0);
      let a;
      if (h > code)                   a = d[i];
      else if (e[code] !== undefined) a = e[code];
      else                            a = f + c;
      g.push(a);
      c = a[0];
      e[o] = f + c;
      o++;
      f = a;
    }
    return JSON.parse(g.join(''));
  } catch (_) { return null; }
}

const BO_SERVERS = [
  'wss://ws1.blitzortung.org',
  'wss://ws7.blitzortung.org',
  'wss://ws8.blitzortung.org',
];

export { connectBlitzortung };
function connectBlitzortung(onStrike, onStatusChange) {
  let stopped = false;
  let ws = null;
  let serverIdx = 0;
  let reconnectTimer = null;

  function connect() {
    if (stopped) return;
    const url = BO_SERVERS[serverIdx % BO_SERVERS.length];
    serverIdx++;
    onStatusChange('connecting');
    try { ws = new WebSocket(url); } catch (_) { scheduleReconnect(); return; }
    ws.onopen = () => {
      if (stopped) { ws.close(); return; }
      onStatusChange('live');
      try { ws.send(JSON.stringify({ a: 111 })); } catch (_) {}
    };
    ws.onmessage = (evt) => {
      if (stopped) return;
      try {
        const raw = evt.data;
        let parsed = null;
        try { parsed = JSON.parse(raw); } catch (_) {}
        if (!parsed) parsed = blitzortungDecode(raw);
        if (!parsed) return;
        const strikes = parsed.strikes || (parsed.lat !== undefined ? [parsed] : null);
        if (!strikes) return;
        const nowMs = Date.now();
        strikes.forEach(s => {
          let timeMs = s.time ? (s.time > 1e12 ? Math.floor(s.time / 1e6) : s.time * 1000) : nowMs;
          let lat = s.lat; let lon = s.lon;
          if (Math.abs(lat) > 90)  lat = lat / 1e7;
          if (Math.abs(lon) > 180) lon = lon / 1e7;
          if (isNaN(lat) || isNaN(lon)) return;
          if (!inBounds(lat, lon, 'europe')) return;
          onStrike({ lat, lon, time: timeMs, amp: s.mamp || 0 });
        });
      } catch (_) {}
    };
    ws.onerror = () => { scheduleReconnect(); };
    ws.onclose = () => { if (!stopped) scheduleReconnect(); };
  }

  function scheduleReconnect(ms = 5000) {
    if (stopped) return;
    onStatusChange('connecting');
    reconnectTimer = setTimeout(connect, ms);
  }

  connect();
  return () => {
    stopped = true;
    clearTimeout(reconnectTimer);
    try { ws && ws.close(); } catch (_) {}
  };
}

/* ═══════════════════════════════════════════════════════════════
   OM EUROPE GRID
   ═══════════════════════════════════════════════════════════════ */
const OM_GRID_EUROPE = [];
for (let lat = 36.0; lat <= 70.0; lat += 4.0) {
  for (let lon = -12.0; lon <= 42.0; lon += 4.0) {
    OM_GRID_EUROPE.push({ lat: parseFloat(lat.toFixed(1)), lon: parseFloat(lon.toFixed(1)) });
  }
}

/* ═══════════════════════════════════════════════════════════════
   MAIN LIGHTNING MAP COMPONENT
   ═══════════════════════════════════════════════════════════════ */
function LightningMap({ onOMHistoryUpdate, region = 'uk', isAdmin, archive, setArchive }) {
  const isEuropeMap  = region === 'europe';
  const activeOMGrid = isEuropeMap ? OM_GRID_EUROPE : OM_GRID;

  const mapRef            = useRef(null);
  const mapInst           = useRef(null);
  const allDayLayer       = useRef(null);
  const strikeHeatLayer   = useRef(null);
  const flashLayer        = useRef(null);
  const stormLayer        = useRef(null);
  const radarLayer        = useRef(null);
  const omHeatLayer       = useRef(null);
  const omBlobLayer       = useRef(null);
  const stormPolygonMap   = useRef({});
  const omBlobMap         = useRef({});
  const tracker           = useRef(createStormTracker());
  const audioCtx          = useRef(null);
  const knownStormIds     = useRef(new Set());
  const knownStormRisks   = useRef({});
  const omDataRef         = useRef([]);
  const omSnapshotRef     = useRef(null);
  const markerPoolRef     = useRef([]);
  const windMapRef        = useRef({});
  const lastThunderTime   = useRef(0);
  const newestLoadedTsRef = useRef(0);
  const heatRebuildTimer  = useRef(null);
  const alertQueue        = useRef(new AlertQueue()); // ← sequential alert queue

  const todayStrikesRef = useRef([]);
  const dirtyRef        = useRef(false);

  const [view,             setView]             = useState(isEuropeMap ? 'europe' : 'uk');
  const [activeLayers,     setActiveLayers]     = useState(['strikes', 'strikeheat', 'storms', 'radar', 'omheat', 'omblobs']);
 const [stormPolys, setStormPolys] = useState(() => {
    const stored = loadStoredWarnings();
    return stored;
  });
  const restoredWarningsRef = useRef(false);
  const [omActiveCells,    setOMActiveCells]    = useState([]);
  const [selectedStorm,    setSelectedStorm]    = useState(null);
  const [selectedOMCell,   setSelectedOMCell]   = useState(null);
  const [newStormAlert,    setNewStormAlert]    = useState(null);
  const [leafletReady,     setLeafletReady]     = useState(false);
  const [wsStatus,         setWsStatus]         = useState('connecting');
  const [lastUpdate,       setLastUpdate]       = useState(new Date());
  const [strikeCount,      setStrikeCount]      = useState(0);
  const [lastMinCount,     setLastMinCount]     = useState(0);
  const lastMinBufferRef = useRef([]);
  const [todayCount,       setTodayCount]       = useState(0);
  const [ukCount,          setUkCount]          = useState(0);
  const [euCount,          setEuCount]          = useState(0);
  const [isFlashing,       setIsFlashing]       = useState({});
  const [omLoading,        setOMLoading]        = useState(false);
  const [timeTravelMode,   setTimeTravelMode]   = useState(false);
  const [timeTravelDate,   setTimeTravelDate]   = useState('');
  const [timeTravelHour,   setTimeTravelHour]   = useState(12);
  const [timeTravelImgUrl, setTimeTravelImgUrl] = useState(null);
  const [timeTravelLoading,setTimeTravelLoading]= useState(false);
  const timeTravelLayerRef = useRef(null);
  const [omTodayTotal,     setOMTodayTotal]     = useState(0);
  const [omLastFetch,      setOMLastFetch]      = useState(null);
  const [soundEnabled,     setSoundEnabled]     = useState(() => localStorage.getItem('tcm_sound') !== 'false');
  const [ttsEnabled,       setTtsEnabled]       = useState(() => localStorage.getItem('tcm_tts')   !== 'false');
  const [warnSoundEnabled, setWarnSoundEnabled] = useState(() => localStorage.getItem('tcm_warnsound') !== 'false');
  const soundEnabledRef     = useRef(soundEnabled);
  const ttsEnabledRef       = useRef(ttsEnabled);
  const warnSoundEnabledRef = useRef(warnSoundEnabled);
  useEffect(() => { soundEnabledRef.current = soundEnabled;         localStorage.setItem('tcm_sound',    String(soundEnabled));    }, [soundEnabled]);
  useEffect(() => { ttsEnabledRef.current   = ttsEnabled;           localStorage.setItem('tcm_tts',      String(ttsEnabled));      }, [ttsEnabled]);
  useEffect(() => { warnSoundEnabledRef.current = warnSoundEnabled; localStorage.setItem('tcm_warnsound', String(warnSoundEnabled)); }, [warnSoundEnabled]);

  /* ── Load Leaflet ─────────────────────────────────────────── */
  useEffect(() => {
    if (!document.getElementById('leaflet-css')) {
      const l = document.createElement('link');
      l.id = 'leaflet-css'; l.rel = 'stylesheet';
      l.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(l);
    }
    if (window.L) { setLeafletReady(true); return; }
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    s.onload = () => setLeafletReady(true);
    document.head.appendChild(s);
  }, []);

  /* ── Init map ─────────────────────────────────────────────── */
  useEffect(() => {
    if (!leafletReady || !mapRef.current) return;
    const L = window.L;
    const v = MAP_VIEWS[view];
    const renderer = L.canvas({ padding: 0.5, tolerance: 3 });
    const map = L.map(mapRef.current, { center: v.center, zoom: v.zoom, zoomControl: true, attributionControl: false, preferCanvas: true, renderer });
    mapRef.current.style.background = '#060d1a';
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { maxZoom: 19, subdomains: 'abcd' }).addTo(map);
    L.control.attribution({ position: 'bottomright', prefix: '' })
      .addAttribution('© <a href="https://carto.com/">CARTO</a> | ⚡ <a href="https://blitzortung.org">Blitzortung</a> | ⚡ <a href="https://open-meteo.com">Open-Meteo</a> | 🌧 <a href="https://rainviewer.com">RainViewer</a>')
      .addTo(map);
    if (!document.getElementById('blitz-popup-css')) {
      const style = document.createElement('style');
      style.id = 'blitz-popup-css';
      style.textContent = `.blitz-popup .leaflet-popup-content-wrapper{background:transparent!important;border:none!important;box-shadow:none!important;padding:0!important}.blitz-popup .leaflet-popup-content{margin:0!important}.blitz-popup .leaflet-popup-tip-container{display:none}`;
      document.head.appendChild(style);
    }
    radarLayer.current         = L.layerGroup().addTo(map);
    omHeatLayer.current        = L.layerGroup().addTo(map);
    strikeHeatLayer.current    = L.layerGroup().addTo(map);
    omBlobLayer.current        = L.layerGroup().addTo(map);
    stormLayer.current         = L.layerGroup().addTo(map);
    allDayLayer.current        = L.layerGroup().addTo(map);  // strikes always above heat
    flashLayer.current         = L.layerGroup().addTo(map);
    timeTravelLayerRef.current = L.layerGroup().addTo(map);
    mapInst.current         = map;
    return () => { map.remove(); mapInst.current = null; };
  }, [leafletReady]); // eslint-disable-line

  const loadTimeTravelImage = useCallback(async () => {
    if (!timeTravelDate) return;
    setTimeTravelLoading(true);
    const d    = new Date(timeTravelDate + 'T00:00:00Z');
    const endTs   = Math.floor(d.getTime() / 1000) + (timeTravelHour + 1) * 3600;
    const startTs = endTs - 3600;
    const url = `https://www.blitzortung.org/en/archive_data.php?stations_users=0&selected_numbers=&end_date=${endTs}&end_time=0&start_date=${startTs}&start_time=0&north=90&west=-180&east=180&south=-90&rawdata_image=1&map=10&width_orig=640&width_result=640&png_gif=0`;
    setTimeTravelImgUrl(url);

    const L = window.L;
    if (L && timeTravelLayerRef.current && mapInst.current) {
      timeTravelLayerRef.current.clearLayers();
      if (!document.getElementById('blitz-overlay-css')) {
        const s = document.createElement('style');
        s.id = 'blitz-overlay-css';
        s.textContent = `.blitz-screen { mix-blend-mode: screen !important; }`;
        document.head.appendChild(s);
      }
      L.imageOverlay(url, [[-90, -180], [90, 180]], {
        opacity: 1.0,
        className: 'blitz-screen',
      }).addTo(timeTravelLayerRef.current);
    }
    setTimeTravelLoading(false);
  }, [timeTravelDate, timeTravelHour]);

  const exitTimeTravel = useCallback(() => {
    setTimeTravelMode(false);
    setTimeTravelImgUrl(null);
    if (timeTravelLayerRef.current) timeTravelLayerRef.current.clearLayers();
  }, []);

  const handleTimeTravelSnapshot = useCallback(() => {
    if (!timeTravelDate || !timeTravelImgUrl) return;
    const d = new Date(timeTravelDate + 'T00:00:00Z');
    const snapshotTs = d.getTime() + timeTravelHour * 3600 * 1000;
    const windowStart = snapshotTs - 3600 * 1000;
    const windowStrikes = todayStrikesRef.current.filter(
      s => s.time >= windowStart && s.time <= snapshotTs
    );
    const prevStrikes = todayStrikesRef.current;
    todayStrikesRef.current = windowStrikes;
    forceSnapshotRef.current(true);
    todayStrikesRef.current = prevStrikes;
  }, [timeTravelDate, timeTravelHour, timeTravelImgUrl]);

  /* ── Fly to view ──────────────────────────────────────────── */
  useEffect(() => {
    const mapView = MAP_VIEWS[view]; const c = mapView?.center;
    if (!mapInst.current || !Array.isArray(c) || !Number.isFinite(c[0]) || !Number.isFinite(c[1])) return;
    try { mapInst.current.flyTo(c, mapView.zoom, { animate: true, duration: 1.0 }); } catch (_) {}

    // Repaint strikes filtered to the new region
    const L = window.L;
    if (!L || !allDayLayer.current) return;
    allDayLayer.current.clearLayers();
    markerPoolRef.current = [];

    const regionKey = view === 'europe' ? 'europe' : 'uk';
    const filtered  = todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, regionKey));
    const sample    = filtered.length > MAX_MAP_MARKERS
      ? filtered.filter((_, i) => i % Math.ceil(filtered.length / MAX_MAP_MARKERS) === 0)
      : filtered;

    sample.forEach(s => {
      const color  = strikeColor(s.time);
      const v = L.polyline([[s.lat - 0.018, s.lon],[s.lat + 0.018, s.lon]], { color, weight: 1.8, opacity: 0.92, smoothFactor: 0, interactive: false, pane: 'markerPane' }).addTo(allDayLayer.current);
const h = L.polyline([[s.lat, s.lon - 0.028],[s.lat, s.lon + 0.028]], { color, weight: 1.8, opacity: 0.92, smoothFactor: 0, interactive: false, pane: 'markerPane' }).addTo(allDayLayer.current);
const marker = L.circleMarker([s.lat, s.lon], { radius: 5, color: 'transparent', fillColor: 'transparent', fillOpacity: 0, weight: 0, interactive: true }).addTo(allDayLayer.current);
marker.on('click', () => marker.bindPopup(strikePopupHtml(s), { className: 'blitz-popup', maxWidth: 220 }).openPopup());
v._strikeTime = s.time; h._strikeTime = s.time; marker._strikeTime = s.time;
marker._vLine = v; marker._hLine = h;
markerPoolRef.current.push(marker);
    });

    rebuildStrikeHeatmap();
  }, [view]); // eslint-disable-line

  /* ── Layer visibility ─────────────────────────────────────── */
  useEffect(() => {
    if (!mapInst.current) return;
    [
      [allDayLayer,      'strikes'],
      [strikeHeatLayer,  'strikeheat'],
      [stormLayer,       'storms'],
      [radarLayer,       'radar'],
      [omHeatLayer,      'omheat'],
      [omBlobLayer,      'omblobs'],
    ].forEach(([ref, id]) => {
      if (!ref.current) return;
      activeLayers.includes(id)
        ? (!mapInst.current.hasLayer(ref.current) && mapInst.current.addLayer(ref.current))
        : ( mapInst.current.hasLayer(ref.current) && mapInst.current.removeLayer(ref.current));
    });
  }, [activeLayers]);

  /* ── Periodic localStorage flush ─────────────────────────── */
  useEffect(() => {
    const iv = setInterval(() => {
      if (dirtyRef.current) {
        saveTodayStrikes(todayStrikesRef.current);
        dirtyRef.current = false;
        if (todayStrikesRef.current.length) {
          newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1].time;
        }
      }
    }, 10000);
    return () => clearInterval(iv);
  }, []);

  /* ── Auto-refresh marker colours every 2 minutes ─────────── */
  useEffect(() => {
    const iv = setInterval(() => {
      const pool  = markerPoolRef.current;
      const slice = Math.ceil(pool.length / 8);
      const start = Math.floor(Math.random() * Math.max(1, pool.length - slice));
      pool.slice(start, start + slice).forEach(dot => {
        try {
          const t = dot._strikeTime;
          if (!t) return;
          const c = strikeColor(t);
          if (dot._vLine) dot._vLine.setStyle({ color: c });
          if (dot._hLine) dot._hLine.setStyle({ color: c });
        } catch (_) {}
      });
    }, 5 * 60 * 1000);
    return () => clearInterval(iv);
  }, []);

  /* ── REBUILD STRIKE DENSITY HEATMAP ── */
const rebuildStrikeHeatmap = useCallback(() => {
  const L = window.L;
  if (!L || !strikeHeatLayer.current || !mapInst.current) return;
  strikeHeatLayer.current.clearLayers();

  const regionKey = isEuropeMap ? 'europe' : 'uk';
  const strikes   = todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, regionKey));
  const cellSize  = isEuropeMap ? 0.4 : 0.12;
  const grid      = buildStrikeDensityGrid(strikes, cellSize);

  // Render low-density first so high-density glows on top
  grid.sort((a, b) => a.count - b.count);

  grid.forEach(cell => {
    const cfg = strikeDensityColor(cell.count);
    if (!cfg) return;

    // Outer soft glow
    const outerR = isEuropeMap
      ? Math.min(55000, 12000 + cell.count * 500)
      : Math.min(28000, 5000 + cell.count * 350);

    const outerDeg = outerR / 111000;
L.rectangle([[cell.lat - outerDeg, cell.lon - outerDeg * 1.5],[cell.lat + outerDeg, cell.lon + outerDeg * 1.5]], { color: 'transparent', fillColor: cfg.fill, fillOpacity: cfg.opacity * 0.35, weight: 0, interactive: false, pane: 'overlayPane' }).addTo(strikeHeatLayer.current);

    // Inner bright core
    const innerR = outerR * 0.45;
    const innerDeg = innerR / 111000;
L.rectangle([[cell.lat - innerDeg, cell.lon - innerDeg * 1.5],[cell.lat + innerDeg, cell.lon + innerDeg * 1.5]], { color: 'transparent', fillColor: cfg.fill, fillOpacity: cfg.opacity * 0.75, weight: 0, interactive: false, pane: 'overlayPane' }).addTo(strikeHeatLayer.current);
  });
}, [isEuropeMap]);

  /* ── Load today's persisted strikes on mount — ALWAYS show ─ */
  const paintStrikes = useCallback((strikes, L) => {
    if (!L || !allDayLayer.current) return;
    const regionKey = isEuropeMap ? 'europe' : 'uk';
    const filtered  = strikes.filter(s => inBounds(s.lat, s.lon, regionKey));
    const sample    = filtered.length > MAX_MAP_MARKERS
      ? filtered.filter((_, i) => i % Math.ceil(filtered.length / MAX_MAP_MARKERS) === 0)
      : filtered;
    sample.forEach(s => {
      const color  = strikeColor(s.time);
      sample.forEach(s => {
  const color = strikeColor(s.time);
  const v = L.polyline([[s.lat - 0.018, s.lon],[s.lat + 0.018, s.lon]], { color, weight: 1.8, opacity: 0.92, smoothFactor: 0, interactive: false, pane: 'markerPane' }).addTo(allDayLayer.current);
  const h = L.polyline([[s.lat, s.lon - 0.028],[s.lat, s.lon + 0.028]], { color, weight: 1.8, opacity: 0.92, smoothFactor: 0, interactive: false, pane: 'markerPane' }).addTo(allDayLayer.current);
  const dot = L.circleMarker([s.lat, s.lon], { radius: 5, color: 'transparent', fillColor: 'transparent', fillOpacity: 0, weight: 0, interactive: true }).addTo(allDayLayer.current);
  dot.on('click', () => dot.bindPopup(strikePopupHtml(s), { className: 'blitz-popup', maxWidth: 220 }).openPopup());
  v._strikeTime = s.time; h._strikeTime = s.time; dot._strikeTime = s.time;
  dot._vLine = v; dot._hLine = h;
  markerPoolRef.current.push(dot);
});
    });
  }, [isEuropeMap]); // eslint-disable-line

  useEffect(() => {
    if (!leafletReady) return;
    const L        = window.L;
    const existing = loadTodayStrikes();

    if (existing.length) {
      // Merge into ref, dedup by time+lat
      const existingSet = new Set(existing.map(s => `${s.time}_${s.lat}`));
      todayStrikesRef.current = existing;
      newestLoadedTsRef.current = existing[existing.length - 1]?.time || 0;

      setTodayCount(existing.length);
      setUkCount(existing.filter(s => inBounds(s.lat, s.lon, 'uk')).length);
      setEuCount(existing.filter(s => inBounds(s.lat, s.lon, 'europe')).length);

      if (L) paintStrikes(existing, L);
      existing.forEach(s => tracker.current.ingest(s));
      setTimeout(rebuildStrikeHeatmap, 800);
    }
  }, [leafletReady]); // eslint-disable-line

  /* ── Sounds ───────────────────────────────────────────────── */
  const playThunder = useCallback(() => {
  if (!soundEnabledRef.current) return;
  try {
    if (!audioCtx.current) audioCtx.current = new (window.AudioContext || window.webkitAudioContext)();
    const ctx = audioCtx.current;
    if (ctx.state === 'suspended') { ctx.resume(); return; }
    const now = ctx.currentTime;

    // Compressor to prevent clipping at high volume
    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.value = -6;
    compressor.knee.value      = 3;
    compressor.ratio.value     = 3;
    compressor.attack.value    = 0.001;
    compressor.release.value   = 0.08;
    compressor.connect(ctx.destination);

    // Master gain — raised from 0.18 to 0.85
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.85, now);
    masterGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    masterGain.connect(compressor);

    // Initial crack — short broadband burst
    const crackDur = 0.055;
    const crackBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * crackDur), ctx.sampleRate);
    const crackData = crackBuf.getChannelData(0);
    for (let i = 0; i < crackData.length; i++) {
      crackData[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / crackData.length, 1.4);
    }
    const crackSrc = ctx.createBufferSource();
    crackSrc.buffer = crackBuf;

    const crackFilter = ctx.createBiquadFilter();
    crackFilter.type = 'bandpass';
    crackFilter.frequency.value = 1800;
    crackFilter.Q.value = 0.4;

    const crackGain = ctx.createGain();
    crackGain.gain.setValueAtTime(1.0, now);
    crackGain.gain.exponentialRampToValueAtTime(0.001, now + crackDur);

    crackSrc.connect(crackFilter);
    crackFilter.connect(crackGain);
    crackGain.connect(masterGain);
    crackSrc.start(now);
    crackSrc.stop(now + crackDur + 0.01);

    // Low rumble layer
    const rumbleDur = 0.18;
    const rumbleBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * rumbleDur), ctx.sampleRate);
    const rumbleData = rumbleBuf.getChannelData(0);
    for (let i = 0; i < rumbleData.length; i++) {
      rumbleData[i] = (Math.random() * 2 - 1);
    }
    const rumbleSrc = ctx.createBufferSource();
    rumbleSrc.buffer = rumbleBuf;

    const rumbleFilter = ctx.createBiquadFilter();
    rumbleFilter.type = 'lowpass';
    rumbleFilter.frequency.value = 120;

    const rumbleGain = ctx.createGain();
    rumbleGain.gain.setValueAtTime(0, now);
    rumbleGain.gain.linearRampToValueAtTime(0.6, now + 0.01);
    rumbleGain.gain.exponentialRampToValueAtTime(0.001, now + rumbleDur);

    rumbleSrc.connect(rumbleFilter);
    rumbleFilter.connect(rumbleGain);
    rumbleGain.connect(masterGain);
    rumbleSrc.start(now + 0.005);
    rumbleSrc.stop(now + rumbleDur + 0.01);

    // High transient click for extra sharpness
    const clickBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.008), ctx.sampleRate);
    const clickData = clickBuf.getChannelData(0);
    for (let i = 0; i < clickData.length; i++) {
      clickData[i] = (Math.random() * 2 - 1);
    }
    const clickSrc = ctx.createBufferSource();
    clickSrc.buffer = clickBuf;

    const clickGain = ctx.createGain();
    clickGain.gain.setValueAtTime(1.0, now);
    clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.008);

    clickSrc.connect(clickGain);
    clickGain.connect(masterGain);
    clickSrc.start(now);
    clickSrc.stop(now + 0.01);

  } catch (_) {}
}, []);

  const playWarningSiren = useCallback((riskLevel = 'yellow') => {
  return new Promise(resolve => {
    if (!warnSoundEnabledRef.current) { resolve(); return; }
    try {
      if (!audioCtx.current) audioCtx.current = new (window.AudioContext || window.webkitAudioContext)();
      const ctx = audioCtx.current;
      if (ctx.state === 'suspended') { ctx.resume().then(resolve); return; }
      const now = ctx.currentTime;

      // Different siren profiles per risk level
      const profiles = {
        yellow: { freq1: 440, freq2: 660, sweeps: 2, gainPeak: 0.25, sweepDur: 0.5 },
        amber:  { freq1: 520, freq2: 880, sweeps: 3, gainPeak: 0.35, sweepDur: 0.45 },
        red:    { freq1: 600, freq2: 1100, sweeps: 4, gainPeak: 0.5,  sweepDur: 0.38 },
      };
      const p = profiles[riskLevel] || profiles.yellow;

      // Master gain with soft limiter
      const master = ctx.createDynamicsCompressor();
      master.threshold.value = -6;
      master.knee.value = 3;
      master.ratio.value = 4;
      master.attack.value = 0.003;
      master.release.value = 0.1;
      master.connect(ctx.destination);

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0, now);
      masterGain.gain.linearRampToValueAtTime(p.gainPeak, now + 0.05);
      masterGain.connect(master);

      for (let i = 0; i < p.sweeps; i++) {
        const offset = i * (p.sweepDur + 0.08);

        // Main siren tone
        const osc = ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(p.freq1, now + offset);
        osc.frequency.linearRampToValueAtTime(p.freq2, now + offset + p.sweepDur * 0.6);
        osc.frequency.linearRampToValueAtTime(p.freq1, now + offset + p.sweepDur);

        const oscGain = ctx.createGain();
        oscGain.gain.setValueAtTime(0, now + offset);
        oscGain.gain.linearRampToValueAtTime(0.7, now + offset + 0.04);
        oscGain.gain.setValueAtTime(0.7, now + offset + p.sweepDur - 0.06);
        oscGain.gain.linearRampToValueAtTime(0, now + offset + p.sweepDur);

        // Harmonics layer
        const osc2 = ctx.createOscillator();
        osc2.type = 'square';
        osc2.frequency.setValueAtTime(p.freq1 * 1.5, now + offset);
        osc2.frequency.linearRampToValueAtTime(p.freq2 * 1.5, now + offset + p.sweepDur * 0.6);
        osc2.frequency.linearRampToValueAtTime(p.freq1 * 1.5, now + offset + p.sweepDur);

        const osc2Gain = ctx.createGain();
        osc2Gain.gain.setValueAtTime(0.15, now + offset);
        osc2Gain.gain.setValueAtTime(0.15, now + offset + p.sweepDur);
        osc2Gain.gain.linearRampToValueAtTime(0, now + offset + p.sweepDur + 0.04);

        osc.connect(oscGain);   oscGain.connect(masterGain);
        osc2.connect(osc2Gain); osc2Gain.connect(masterGain);

        osc.start(now + offset);  osc.stop(now + offset + p.sweepDur + 0.05);
        osc2.start(now + offset); osc2.stop(now + offset + p.sweepDur + 0.05);
      }

      const totalDur = p.sweeps * (p.sweepDur + 0.08) + 0.3;
      masterGain.gain.setValueAtTime(p.gainPeak, now + totalDur - 0.15);
      masterGain.gain.linearRampToValueAtTime(0, now + totalDur);
      setTimeout(resolve, totalDur * 1000 + 200);
    } catch (_) { resolve(); }
  });
}, []);

  const speakWarning = useCallback((text, riskLevel = 'yellow') => {
  return new Promise(resolve => {
    if (!ttsEnabledRef.current) { resolve(); return; }
    try {
      if (!window.speechSynthesis) { resolve(); return; }
      window.speechSynthesis.cancel();

      // Pick best available British voice
      const voices   = window.speechSynthesis.getVoices();
      const preferred = [
        'Google UK English Female',
        'Google UK English Male',
        'Microsoft Hazel Desktop',
        'Microsoft George Desktop',
        'en-GB',
      ];
      let chosenVoice = null;
      for (const name of preferred) {
        chosenVoice = voices.find(v => v.name === name || v.lang === name);
        if (chosenVoice) break;
      }

      const rateMap  = { yellow: 0.95, amber: 1.0,  red: 1.08 };
      const pitchMap = { yellow: 1.0,  amber: 0.95, red: 0.9  };

      const utt   = new SpeechSynthesisUtterance(text);
      utt.lang    = 'en-GB';
      utt.rate    = rateMap[riskLevel]  ?? 1.0;
      utt.pitch   = pitchMap[riskLevel] ?? 1.0;
      utt.volume  = 1.0;
      if (chosenVoice) utt.voice = chosenVoice;

      // Chrome has a bug where long utterances get cut off — keep synthesis alive
      let keepAlive = null;
      const startKeepAlive = () => {
        keepAlive = setInterval(() => {
          if (!window.speechSynthesis.speaking) { clearInterval(keepAlive); return; }
          window.speechSynthesis.pause();
          window.speechSynthesis.resume();
        }, 10000);
      };

      utt.onstart = startKeepAlive;
      utt.onend   = () => { clearInterval(keepAlive); resolve(); };
      utt.onerror = () => { clearInterval(keepAlive); resolve(); };
      window.speechSynthesis.speak(utt);

      // Hard fallback in case speech never fires
      setTimeout(() => { clearInterval(keepAlive); resolve(); }, 20000);
    } catch (_) { resolve(); }
  });
}, []);

  /* ── QUEUED ALERT — siren → TTS → next alert ─────────────── */
  const queueAlert = useCallback((poly, isUpgrade = false) => {
    alertQueue.current.push(async () => {
      // Show toast (only for new storms, not upgrades)
      if (!isUpgrade) {
        setNewStormAlert(poly);
        setTimeout(() => setNewStormAlert(null), 7000);
      }
      await playWarningSiren(poly.risk);
      const ttsText = buildTtsString(poly.risk, poly.count, poly.centroid.lat, poly.centroid.lon);
      await speakWarning(ttsText, poly.risk);
    });
  }, [playWarningSiren, speakWarning]);

  /* ── FETCH WIND DATA ───────────────────────────────────────── */
  const fetchWindData = useCallback(async (stormCentroids) => {
    const toFetch = [];
    stormCentroids.forEach(({ lat, lon }) => {
      const rLat = Math.round(lat * 2) / 2;
      const rLon = Math.round(lon * 2) / 2;
      const key  = `${rLat}_${rLon}`;
      if (!windMapRef.current[key]) toFetch.push({ lat: rLat, lon: rLon, key });
    });
    if (!toFetch.length) return;
    await Promise.all(toFetch.map(async ({ lat, lon, key }) => {
      const wind = await fetchWindForPoint(lat, lon);
      if (wind) windMapRef.current[key] = wind;
    }));
  }, []);

  /* ── OM HEATMAP RENDER ─────────────────────────────────────── */
  const renderOMHeatmap = useCallback((gridData) => {
    const L = window.L;
    if (!L || !omHeatLayer.current) return;
    omHeatLayer.current.clearLayers();
    if (omBlobLayer.current) omBlobLayer.current.clearLayers();
    omBlobMap.current = {};
    const newActiveCells = [];

    gridData.forEach((pt, idx) => {
      const cfg = heatmapColor(pt.recentCount);
      if (cfg) {
        const radius = heatmapRadius(pt.recentCount);
        L.circle([pt.lat, pt.lon], {
          radius: radius * 1.35, color: 'transparent', fillColor: cfg.fill, fillOpacity: cfg.opacity * 0.28, weight: 0,
        }).addTo(omHeatLayer.current);
        const circle = L.circle([pt.lat, pt.lon], {
          radius, color: cfg.stroke, fillColor: cfg.fill, fillOpacity: cfg.opacity, weight: 1.5, opacity: 0.9,
        }).addTo(omHeatLayer.current);
        circle.bindPopup(
          `<div style="background:#0f172a;border:1px solid ${cfg.fill}55;border-radius:10px;padding:10px 14px;font-family:system-ui,sans-serif;min-width:160px">
            <p style="margin:0 0 4px;font-size:0.78rem;font-weight:700;color:${cfg.fill}">⚡ OM Lightning Heatmap</p>
            <p style="margin:0;font-size:0.7rem;color:#94a3b8">${nearestCityShort(pt.lat, pt.lon)}</p>
            <p style="margin:4px 0 0;font-size:0.72rem;color:#e2e8f0">Recent (2hr): <b style="color:${cfg.fill}">${pt.recentCount}</b> strikes</p>
            <p style="margin:2px 0 0;font-size:0.72rem;color:#e2e8f0">Today total: <b>${pt.dayTotal}</b></p>
          </div>`,
          { className: 'blitz-popup', maxWidth: 220 }
        );
      }
      if (pt.recentCount >= STORM_THRESHOLD && omBlobLayer.current) {
        const blobRing = buildBlobPolygon(pt.lat, pt.lon, pt.recentCount);
        const risk     = blobRiskLevel(pt.recentCount);
        const cellId   = `om-cell-${idx}`;
        const polygon  = L.polygon(blobRing, {
          color: risk.color, fillColor: risk.color, fillOpacity: 0.15, weight: 2, dashArray: '6 4', smoothFactor: 2.0,
        }).addTo(omBlobLayer.current);
        polygon.on('click', () => setSelectedOMCell({ ...pt, risk, cellId }));
        const iconHtml = `<div style="background:rgba(0,0,0,0.75);border:1.5px solid ${risk.color};border-radius:7px;padding:2px 8px;font-size:10px;font-weight:700;color:${risk.color};white-space:nowrap;backdrop-filter:blur(6px)">⚡ ${pt.recentCount}</div>`;
        const icon = L.divIcon({ html: iconHtml, iconAnchor: [30,12], className: '' });
        L.marker([pt.lat, pt.lon], { icon }).on('click', () => setSelectedOMCell({ ...pt, risk, cellId })).addTo(omBlobLayer.current);
        omBlobMap.current[cellId] = { polygon };
        newActiveCells.push({ ...pt, risk, cellId, locationLabel: nearestCityShort(pt.lat, pt.lon) });
      }
    });
    setOMActiveCells(newActiveCells);
  }, []);

  /* ── FETCH OM DATA ─────────────────────────────────────────── */
  const fetchOMData = useCallback(async () => {
    setOMLoading(true);
    try {
      const gridData = await fetchOMStrikesNow(activeOMGrid);
      omDataRef.current = gridData;
      const dayTotal = gridData.reduce((s, pt) => s + pt.dayTotal, 0);
      setOMTodayTotal(dayTotal);
      setOMLastFetch(new Date());
      renderOMHeatmap(gridData);
      omSnapshotRef.current = { gridData, dayTotal, timestamp: Date.now() };
    } catch (_) {}
    setOMLoading(false);
  }, [renderOMHeatmap, activeOMGrid]);

  /* ── RADAR ─────────────────────────────────────────────────── */
  const loadRadar = useCallback(async () => {
    try {
      const res   = await fetch('https://api.rainviewer.com/public/weather-maps.json');
      const data  = await res.json();
      const frames = data?.radar?.past;
      if (!frames?.length) return;
      const latest = frames[frames.length-1];
      const L      = window.L;
      if (!L || !radarLayer.current) return;
      radarLayer.current.clearLayers();
      L.tileLayer(`https://tilecache.rainviewer.com${latest.path}/256/{z}/{x}/{y}/6/1_1.png`, { opacity: 0.65, maxZoom: 12, tileSize: 256 }).addTo(radarLayer.current);
    } catch (_) {}
  }, []);

  const renderFlash = useCallback((lat, lon) => { renderGlowFlash(lat, lon, flashLayer); }, []);

  function strikePopupHtml(s) {
    const t = new Date(s.time);
    const timeStr = t.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    const dateStr = t.toLocaleDateString('en-GB',{day:'2-digit',month:'short'});
    const ageMin  = Math.round((Date.now()-s.time)/60000);
    const ageStr  = ageMin<60?`${ageMin}m ago`:`${Math.round(ageMin/60)}h ${ageMin%60}m ago`;
    const locStr  = nearestCityShort(s.lat, s.lon);
    return `<div style="background:#0f172a;border:1px solid rgba(250,204,21,0.35);border-radius:11px;padding:11px 14px;min-width:170px;font-family:system-ui,sans-serif;box-shadow:0 8px 32px rgba(0,0,0,0.6)">
      <p style="margin:0 0 6px;font-size:0.82rem;font-weight:700;color:#facc15">⚡ Lightning Strike</p>
      <p style="margin:0 0 3px;font-size:0.74rem;color:#e2e8f0;font-family:monospace">${dateStr} · ${timeStr}</p>
      <p style="margin:0 0 3px;font-size:0.7rem;color:#94a3b8">📍 ${locStr}</p>
      <p style="margin:0 0 3px;font-size:0.68rem;color:#64748b">${ageStr}</p>
      ${s.amp?`<p style="margin:3px 0 0;font-size:0.68rem;color:#94a3b8">Amplitude: <b style="color:#f1f5f9">${Math.abs(s.amp)} kA</b></p>`:''}
    </div>`;
  }

  /* ── ADD MARKER ───────────────────────────────────────────── */
const addOrUpdateMarker = useCallback((L, strike) => {
    if (!L || !allDayLayer.current) return;
    const color = strikeColor(strike.time);

    // Vertical bar of the plus
    const v = L.polyline([
      [strike.lat - 0.018, strike.lon],
      [strike.lat + 0.018, strike.lon],
    ], { color, weight: 1.8, opacity: 0.92, smoothFactor: 0, interactive: false, pane: 'markerPane' })
      .addTo(allDayLayer.current);

    const h = L.polyline([
      [strike.lat, strike.lon - 0.028],
      [strike.lat, strike.lon + 0.028],
    ], { color, weight: 1.8, opacity: 0.92, smoothFactor: 0, interactive: false, pane: 'markerPane' })
      .addTo(allDayLayer.current);

    // Invisible click target
    const dot = L.circleMarker([strike.lat, strike.lon], {
      radius: 5, color: 'transparent', fillColor: 'transparent',
      fillOpacity: 0, weight: 0, interactive: true,
    }).addTo(allDayLayer.current);

    dot.on('click', () => {
      dot.bindPopup(strikePopupHtml(strike), { className: 'blitz-popup', maxWidth: 220 }).openPopup();
    });

    // Store refs for colour updates
    v._strikeTime = strike.time;
    h._strikeTime = strike.time;
    dot._strikeTime = strike.time;
    dot._vLine = v;
    dot._hLine = h;

    markerPoolRef.current.push(dot);
  }, []);// eslint-disable-line

  /* ── HANDLE STRIKE ────────────────────────────────────────── */
  const pendingStrikesRef = useRef([]);
  const rafPendingRef     = useRef(null);

  const flushPendingStrikes = useCallback(() => {
    const L = window.L;
    rafPendingRef.current = null;
    if (!pendingStrikesRef.current.length || !L || !allDayLayer.current) return;

    // Process up to 300 per frame, defer the rest to next RAF
    const batch = pendingStrikesRef.current.splice(0, 300);
    batch.forEach(strike => addOrUpdateMarker(L, strike));

    if (pendingStrikesRef.current.length > 0) {
      rafPendingRef.current = requestAnimationFrame(flushPendingStrikes);
    }
  }, [addOrUpdateMarker]);

  const handleStrike = useCallback((strike) => {
    const isDup = todayStrikesRef.current.length > 0 &&
      todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time === strike.time &&
      Math.abs(todayStrikesRef.current[todayStrikesRef.current.length - 1]?.lat - strike.lat) < 0.001;
    if (isDup) return;

    setStrikeCount(c => c + 1);
setTodayCount(c => c + 1);
if (inBounds(strike.lat, strike.lon, 'uk'))     setUkCount(c => c + 1);
if (inBounds(strike.lat, strike.lon, 'europe')) setEuCount(c => c + 1);
lastMinBufferRef.current.push(Date.now());
const cutoff = Date.now() - 60000;
lastMinBufferRef.current = lastMinBufferRef.current.filter(t => t > cutoff);
setLastMinCount(lastMinBufferRef.current.length);

    playThunder();

    todayStrikesRef.current.push(strike);
    dirtyRef.current = true;
    renderFlash(strike.lat, strike.lon);
    tracker.current.ingest(strike);

    // Batch DOM updates via RAF — prevents per-strike layout thrash
    pendingStrikesRef.current.push(strike);
    if (!rafPendingRef.current) {
      rafPendingRef.current = requestAnimationFrame(flushPendingStrikes);
    }

    if (navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({ type: 'NEW_STRIKES', strikes: [strike] });
    }
    if (heatRebuildTimer.current) clearTimeout(heatRebuildTimer.current);
    heatRebuildTimer.current = setTimeout(rebuildStrikeHeatmap, 90000);
  }, [playThunder, renderFlash, flushPendingStrikes, rebuildStrikeHeatmap]); // eslint-disable-line

  /* ── RENDER STORM POLYGONS — with queued alerts ─────────── */
  const renderStormPolygons = useCallback((polys) => {
    const L = window.L;
    if (!L || !stormLayer.current) return;
    const now = Date.now();

    const currentIds = new Set(polys.map(p => p.id));
    Object.keys(stormPolygonMap.current).forEach(id => {
      const entry = stormPolygonMap.current[id];
      if (!currentIds.has(id) && entry.expiresAt && now > entry.expiresAt) {
        try { stormLayer.current?.removeLayer(entry.core); }   catch (_) {}
        try { stormLayer.current?.removeLayer(entry.path); }   catch (_) {}
        try { stormLayer.current?.removeLayer(entry.marker); } catch (_) {}
        delete stormPolygonMap.current[id];
        delete knownStormRisks.current[id];
        knownStormIds.current.delete(id);
      }
    });

    polys.forEach(poly => {
      const cfg = STORM_RISK[poly.risk];
      const rgb = hexToRgb(cfg.color);
      const existing = stormPolygonMap.current[poly.id];

      if (existing) {
        try { existing.core.setLatLngs(poly.corePolygon); existing.core.setStyle({ color: cfg.color, fillColor: cfg.color }); } catch (_) {}
        if (poly.pathPolygon) {
          if (existing.path) {
            try { existing.path.setLatLngs(poly.pathPolygon); existing.path.setStyle({ color: cfg.color }); } catch (_) {}
          } else {
            existing.path = L.polygon(poly.pathPolygon, { color: cfg.color, fillColor: cfg.color, fillOpacity: 0.18, weight: 1.5, dashArray: '5 3', smoothFactor: 1.5 }).addTo(stormLayer.current);
          }
        }
        try { existing.marker.setLatLng([poly.centroid.lat, poly.centroid.lon]); } catch (_) {}
        existing.updatedAt = now;
        existing.expiresAt = poly.expiresAt;

        // Queue TTS on risk upgrade
        const prevRisk = knownStormRisks.current[poly.id];
        const RISK_RANK = { yellow: 0, amber: 1, red: 2 };
        if (prevRisk && RISK_RANK[poly.risk] > RISK_RANK[prevRisk]) {
          knownStormRisks.current[poly.id] = poly.risk;
          queueAlert(poly, true);
        }
      } else {
       const core = L.polygon(poly.corePolygon, {
          color:       cfg.color,
          fillColor:   cfg.color,
          fillOpacity: 0.18,
          weight:      2,
          smoothFactor: 3.0,
          dashArray:   poly.risk === 'red' ? null : '6 3',
          pane:        'overlayPane',
        }).addTo(stormLayer.current);

        // Glow ring around core
        L.polygon(poly.corePolygon, {
          color:       cfg.color,
          fillColor:   'transparent',
          fillOpacity: 0,
          weight:      6,
          opacity:     0.15,
          smoothFactor: 3.0,
          interactive: false,
          pane:        'overlayPane',
        }).addTo(stormLayer.current);
        core.on('click', () => setSelectedStorm(poly));

        let path = null;
        if (poly.pathPolygon) {
          path = L.polygon(poly.pathPolygon, {
            color: cfg.color, fillColor: cfg.color, fillOpacity: 0.18, weight: 1.5, dashArray: '5 3', smoothFactor: 1.5,
          }).addTo(stormLayer.current);
          path.on('click', () => setSelectedStorm(poly));
        }

        const marker = L.marker([poly.centroid.lat, poly.centroid.lon], { icon: L.divIcon({ html: '', className: '', iconSize: [0,0] }), interactive: false }).addTo(stormLayer.current);

        stormPolygonMap.current[poly.id] = { core, path, marker, updatedAt: now, expiresAt: poly.expiresAt };

        let fc = 0;
        const fi = setInterval(() => {
          try { core.setStyle({ weight: fc%2===0?5:2.5, fillOpacity: fc%2===0?0.38:0.18 }); } catch(_){}
          if(++fc>8) clearInterval(fi);
        }, 300);

        if (!knownStormIds.current.has(poly.id)) {
          knownStormIds.current.add(poly.id);
          knownStormRisks.current[poly.id] = poly.risk;
          setIsFlashing(prev => ({ ...prev, [poly.id]: true }));
          setTimeout(() => setIsFlashing(prev => { const n={...prev}; delete n[poly.id]; return n; }), 2500);
          // Queue new-storm alert (plays sequentially if multiple)
          queueAlert(poly, false);
        }
      }
    });
  }, [queueAlert]); // eslint-disable-line

  /* ── 23:59 MIDNIGHT SNAPSHOT ─────────────────────────────── */
  const doMidnightSnapshot = useCallback((isForced = false) => {
    const snap    = [...todayStrikesRef.current];
    const dateKey = isForced
      ? `${localDateKey(Date.now())} [FORCED]`
      : localDateKey(snap.length ? snap[snap.length-1].time : Date.now());
    const hourBuckets = {};
    snap.forEach(s => { const h = new Date(s.time).getHours(); hourBuckets[h] = (hourBuckets[h]||0)+1; });
    const peakHour = Object.entries(hourBuckets).sort((a,b) => b[1]-a[1])[0];

    const omSnap        = omSnapshotRef.current;
    const omDayTotal    = omSnap?.dayTotal ?? 0;
    const omGridData    = omSnap?.gridData ?? [];
    const omActiveCells = omGridData.filter(pt => pt.recentCount >= STORM_THRESHOLD).length;
    const omMaxCell     = omGridData.reduce((max, pt) => Math.max(max, pt.recentCount), 0);

    const entry = {
      date:        dateKey,
      capturedAt:  Date.now(),
      isForced,
      strikes:     snap.map(s => ({ lat: s.lat, lon: s.lon, time: s.time, amp: s.amp })),
      stormCount:  stormPolys.length,
      peakHour:    peakHour ? `${String(peakHour[0]).padStart(2,'0')}:00` : '—',
      omDayTotal,
      omGridData:  omGridData.map(pt => ({ lat: pt.lat, lon: pt.lon, recentCount: pt.recentCount, dayTotal: pt.dayTotal })),
      omActiveCells,
      omMaxCell,
    };

    setArchive(prev => {
      const updated = [...prev.filter(d => d.date !== dateKey), entry].slice(-30);
      saveArchive(updated);
      return updated;
    });

    if (!isForced) {
  // Only prune strikes that are genuinely >24h old
  const cutoff24h = Date.now() - 24 * 60 * 60 * 1000;
  todayStrikesRef.current = todayStrikesRef.current.filter(s => s.time > cutoff24h);
  dirtyRef.current = true;
  saveTodayStrikes(todayStrikesRef.current);
  setTodayCount(todayStrikesRef.current.length);
  setOMTodayTotal(0);
  // Don't clear map markers — re-render with updated set
  try { allDayLayer.current?.clearLayers(); } catch (_) {}
  markerPoolRef.current = [];
  const L = window.L;
  if (L && allDayLayer.current) {
   const regionFiltered = todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, isEuropeMap ? 'europe' : 'uk'));
    regionFiltered.forEach(s => addOrUpdateMarker(L, s));
  }
  if (strikeHeatLayer.current) strikeHeatLayer.current.clearLayers();
  omSnapshotRef.current = null;
  setTimeout(rebuildStrikeHeatmap, 800);
}
  }, [stormPolys.length]);

  const forceSnapshotRef = useRef(doMidnightSnapshot);
  useEffect(() => { forceSnapshotRef.current = doMidnightSnapshot; }, [doMidnightSnapshot]);

  const handleForceSnapshot = useCallback((snapshotTime) => {
    return new Promise(resolve => {
      const cutoff      = snapshotTime || Date.now();
      const cutoffStart = cutoff - 24 * 60 * 60 * 1000;
      const windowStrikes = todayStrikesRef.current.filter(
        s => s.time >= cutoffStart && s.time <= cutoff
      );
      const prevStrikes = todayStrikesRef.current;
      todayStrikesRef.current = windowStrikes;
      forceSnapshotRef.current(true);
      todayStrikesRef.current = prevStrikes;
      // Save to SNAPSHOT_KEY so HistoricalLightningPanel picks it up
      const snap = {
  capturedAt:     cutoff,
  isForced:       true,
  strikes:        windowStrikes.map(s => ({ lat: s.lat, lon: s.lon, time: s.time, amp: s.amp })),
  stormCount:     stormPolys.length,
  peakHour:       new Date(cutoff).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
  omDayTotal:     omTodayTotal,
  stormWarnings:  stormPolys.map(p => ({
    id:          p.id,
    risk:        p.risk,
    count:       p.count,
    centroid:    p.centroid,
    corePolygon: p.corePolygon,
    pathPolygon: p.pathPolygon || null,
    locationLabel: p.locationLabel,
    expiresAt:   p.expiresAt,
  })),
};
      saveSnapshot(snap);
      // Fire storage event so HistoricalLightningPanel updates immediately
      window.dispatchEvent(new StorageEvent('storage', {
        key:      SNAPSHOT_KEY,
        newValue: JSON.stringify(loadSnapshots()),
      }));
      setTimeout(resolve, 200);
    });
  }, [stormPolys.length, omTodayTotal]);

  /* ── MAIN EFFECT ───────────────────────────────────────────── */
  useEffect(() => {
    if (!leafletReady) return;

   // Register SW for background persistence
    registerServiceWorker();

    // ── Restore saved warnings on mount ──────────────────────
    if (!restoredWarningsRef.current) {
      restoredWarningsRef.current = true;
      const stored = loadStoredWarnings();
      if (stored.length > 0) {
        setStormPolys(stored);
        // Render the restored polygons onto the map after a short delay
        // to ensure layers are ready
        setTimeout(() => {
          renderStormPolygons(stored);
        }, 800);
      }
    }

    // Pre-load speech synthesis voices
    if (window.speechSynthesis) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
    }

    // Blitzortung today archive overlay
    const addBlitzOverlay = () => {
      try {
        const L = window.L;
        if (!L || !mapInst.current) return;
        if (!document.getElementById('blitz-overlay-css')) {
          const s = document.createElement('style');
          s.id = 'blitz-overlay-css';
          s.textContent = `.blitz-screen { mix-blend-mode: screen !important; }`;
          document.head.appendChild(s);
        }
        const now = new Date();
        const endTs = Math.floor(now.getTime() / 1000);
        const startTs = Math.floor(
          new Date(now.toISOString().slice(0, 10) + 'T00:00:00Z').getTime() / 1000
        );
        const elapsedSecs = endTs - startTs;
        const url =
          `https://www.blitzortung.org/en/archive_data.php?stations_users=0` +
          `&selected_numbers=*&end_date=${endTs}&end_time=${elapsedSecs}` +
          `&start_date=${startTs}&start_time=0&north=90&west=-180&east=180&south=-90` +
          `&rawdata_image=1&map=10&width_orig=640&width_result=640&png_gif=0` +
          `&agespan=60&frames=12&delay=100&last_delay=1000&show_result=1`;
        L.imageOverlay(url, [[-90, -180], [90, 180]], {
          opacity: 0.85,
          className: 'blitz-screen',
          zIndex: 150,
          interactive: false,
        }).addTo(mapInst.current);
      } catch (_) {}
    };
    setTimeout(addBlitzOverlay, 500);

// ── Cross-session storage sync ──────────────────────────
    // When another tab or a returning user saves strikes, pick up
    // anything newer than what we already have and paint it.
    const onStorage = (e) => {
      if (e.key !== STORE_KEY) return;
      try {
        const incoming  = JSON.parse(e.newValue || '[]');
        const cutoff24h = Date.now() - 24 * 60 * 60 * 1000;
        const fresh     = incoming.filter(s =>
          s.time && s.time > cutoff24h && s.time > newestLoadedTsRef.current
        );
        if (!fresh.length) return;

        // Dedup against what we already hold
        const held    = new Set(todayStrikesRef.current.map(s => `${s.time}_${s.lat}`));
        const toAdd   = fresh.filter(s => !held.has(`${s.time}_${s.lat}`));
        if (!toAdd.length) return;

        todayStrikesRef.current.push(...toAdd);
        todayStrikesRef.current.sort((a, b) => a.time - b.time);
        newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;

        setTodayCount(todayStrikesRef.current.length);
        setUkCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length);
        setEuCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length);

        const L = window.L;
        if (L) paintStrikes(toAdd, L);
        toAdd.forEach(s => tracker.current.ingest(s));
      } catch (_) {}
    };
    const onWarningStorage = (e) => {
      if (e.key !== STORM_STORE_KEY) return;
      try {
        const incoming = JSON.parse(e.newValue || '[]');
        const live = incoming.filter(w => w.expiresAt && w.expiresAt > Date.now());
        setStormPolys(prev => {
          const prevIds = new Set(prev.map(p => p.id));
          const toAdd   = live.filter(w => !prevIds.has(w.id));
          if (!toAdd.length) return prev;
          return [...prev, ...toAdd];
        });
        if (live.length) renderStormPolygons(live);
      } catch (_) {}
    };
    window.addEventListener('storage', onWarningStorage);
    window.addEventListener('storage', onStorage);

    // Listen for SW messages (buffered strikes + snapshot requests)
    const swMessageHandler = (event) => {
      if (event.data?.type === 'BUFFERED_STRIKES') {
        event.data.strikes.forEach(s => {
          const exists = todayStrikesRef.current.some(e => e.time === s.time && e.lat === s.lat);
          if (!exists) handleStrike(s);
        });
      }
      if (event.data?.type === 'DO_MIDNIGHT_SNAPSHOT') {
        doMidnightSnapshot(false);
      }
    };
    navigator.serviceWorker?.addEventListener('message', swMessageHandler);

    // Pull buffered strikes when tab becomes visible
    const onVisible = () => {
      if (document.visibilityState !== 'visible') return;
      navigator.serviceWorker?.ready.then(reg => {
        reg.active?.postMessage({ type: 'GET_BUFFERED_STRIKES' });
      }).catch(() => {});
    };
    document.addEventListener('visibilitychange', onVisible);

    const stopWs = connectBlitzortung(handleStrike, setWsStatus);

    // Cluster with wind blending every 60s
    const clusterIv = setInterval(async () => {
      const rolling = tracker.current.getRolling();
      if (rolling.length >= 5) {
        const roughGroups = dbscan(rolling, 0.55, 6);
        const centroids = roughGroups.map(pts => ({
          lat: pts.reduce((s,p)=>s+p.lat,0)/pts.length,
          lon: pts.reduce((s,p)=>s+p.lon,0)/pts.length,
        }));
        if (centroids.length) await fetchWindData(centroids);
      }
      const p = tracker.current.cluster(windMapRef.current);
      // Merge with any still-live stored warnings that haven't been
      // superseded by a freshly computed polygon with the same id
      const storedLive = loadStoredWarnings();
      const freshIds   = new Set(p.map(x => x.id));
      const merged     = [
        ...p,
        ...storedLive.filter(w => !freshIds.has(w.id)),
      ];
      setStormPolys(merged);
      renderStormPolygons(merged);
      broadcastWarnings(merged);
    }, 60000);

    const expireIv = setInterval(() => {
      const now = Date.now();
      Object.keys(stormPolygonMap.current).forEach(id => {
        const entry = stormPolygonMap.current[id];
        if (entry.expiresAt && now > entry.expiresAt) {
          try { stormLayer.current?.removeLayer(entry.core); }   catch (_) {}
          try { stormLayer.current?.removeLayer(entry.path); }   catch (_) {}
          try { stormLayer.current?.removeLayer(entry.marker); } catch (_) {}
          delete stormPolygonMap.current[id];
          delete knownStormRisks.current[id];
          knownStormIds.current.delete(id);
          setStormPolys(prev => {
            const updated = prev.filter(p => p.id !== id);
            broadcastWarnings(updated);
            return updated;
          });
        }
      });
      // Also prune localStorage of anything now expired
      broadcastWarnings(loadStoredWarnings());
    }, 60000);

    loadRadar();
    fetchOMData();

    const radarIv    = setInterval(loadRadar,   10*60*1000);
    const omIv       = setInterval(fetchOMData,  5*60*1000);
    const updateIv   = setInterval(() => setLastUpdate(new Date()), 30*1000);
    const lastMinIv = setInterval(() => {
  const cutoff = Date.now() - 60000;
  lastMinBufferRef.current = lastMinBufferRef.current.filter(t => t > cutoff);
  setLastMinCount(lastMinBufferRef.current.length);
}, 5000);

    let snapshotDone = false;
    const snapshotIv = setInterval(() => {
      const now = new Date();
      if (now.getHours() === 23 && now.getMinutes() === 59 && !snapshotDone) {
        snapshotDone = true;
        doMidnightSnapshot(false);
        setTimeout(() => { snapshotDone = false; }, 70000);
      }
    }, 30000);

    // SW keepalive ping
    let swPingInterval = null;
    if ('serviceWorker' in navigator) {
      swPingInterval = setInterval(() => {
        navigator.serviceWorker.ready.then(reg => {
          reg.active?.postMessage({ type: 'PING' });
        }).catch(() => {});
        if (todayStrikesRef.current.length) saveTodayStrikes(todayStrikesRef.current);
      }, 25000);
    }

    return () => {
      stopWs();
      clearInterval(clusterIv);
      clearInterval(expireIv);
      clearInterval(radarIv);
      clearInterval(omIv);
      clearInterval(updateIv);
      clearInterval(snapshotIv);
      clearInterval(swPingInterval);
      document.removeEventListener('visibilitychange', onVisible);
      navigator.serviceWorker?.removeEventListener('message', swMessageHandler);
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('storage', onWarningStorage);
      if (dirtyRef.current) saveTodayStrikes(todayStrikesRef.current);
    };
  }, [leafletReady, handleStrike, renderStormPolygons, loadRadar, fetchOMData, doMidnightSnapshot, fetchWindData]); // eslint-disable-line

  /* ── Flush on tab hide ────────────────────────────────────── */
  useEffect(() => {
    const flush = () => {
      if (!todayStrikesRef.current.length) return;
      saveTodayStrikes(todayStrikesRef.current);
      newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
    };

    const onVisibility = () => {
      if (document.visibilityState === 'hidden') {
        flush();
      } else {
        // Tab became visible again — pick up anything saved while hidden
        const newStrikes = loadNewStrikesSince(newestLoadedTsRef.current);
        if (!newStrikes.length) return;
        const held  = new Set(todayStrikesRef.current.map(s => `${s.time}_${s.lat}`));
        const toAdd = newStrikes.filter(s => !held.has(`${s.time}_${s.lat}`));
        if (!toAdd.length) return;
        todayStrikesRef.current.push(...toAdd);
        todayStrikesRef.current.sort((a, b) => a.time - b.time);
        newestLoadedTsRef.current = todayStrikesRef.current[todayStrikesRef.current.length - 1]?.time || 0;
        setTodayCount(todayStrikesRef.current.length);
        setUkCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'uk')).length);
        setEuCount(todayStrikesRef.current.filter(s => inBounds(s.lat, s.lon, 'europe')).length);
        const L = window.L;
        if (L) paintStrikes(toAdd, L);
        toAdd.forEach(s => tracker.current.ingest(s));
      }
    };

    document.addEventListener('visibilitychange', onVisibility);
    const flushAll = () => {
      if (todayStrikesRef.current.length) saveTodayStrikes(todayStrikesRef.current);
      // Persist any still-live warnings so other users/sessions see them
      broadcastWarnings(stormPolys);
    };

    window.addEventListener('beforeunload', flushAll);
    window.addEventListener('pagehide', flushAll);

    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('beforeunload', flushAll);
      window.removeEventListener('pagehide', flushAll);
    };
  }, [paintStrikes]); // eslint-disable-line;

  const toggleLayer = (id) => setActiveLayers(prev => prev.includes(id) ? prev.filter(l => l!==id) : [...prev, id]);
  const fmt         = (d)  => d.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
  const sc = { live: { color: '#22c55e', label: 'BLITZORTUNG LIVE' }, connecting: { color: '#facc15', label: 'CONNECTING…' } }[wsStatus] || { color: '#facc15', label: 'CONNECTING…' };

  return (
    <>
      <style>{`
        @keyframes livePulse  { 0%,100%{box-shadow:0 0 0 0 rgba(34,197,94,0.5)} 50%{box-shadow:0 0 0 6px rgba(34,197,94,0)} }
        @keyframes stormPulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(1.1)} }
        @keyframes alertSlide { 0%{transform:translateX(120%);opacity:0} 10%{transform:translateX(0);opacity:1} 82%{transform:translateX(0);opacity:1} 100%{transform:translateX(120%);opacity:0} }
        @keyframes spin { to { transform: rotate(360deg); } }
        .leaflet-container { background: #060d1a !important; }
.leaflet-tile-pane { background: #060d1a !important; }
.leaflet-map-pane  { background: #060d1a !important; }
.leaflet-pane      { background: #060d1a !important; }
.leaflet-tile      { background: #060d1a !important; }
.leaflet-tile-container { background: #060d1a !important; }
.leaflet-layer          { background: #060d1a !important; }
        .live-dot-green { width:8px;height:8px;border-radius:50%;background:#22c55e;animation:livePulse 1.8s ease infinite; }
        .live-dot-amber  { width:8px;height:8px;border-radius:50%;background:#f97316; }
        .alert-banner { animation: alertSlide 7s ease forwards; }
        .leaflet-container { background: #060d1a !important; }
        .leaflet-tile-pane { background: #060d1a !important; }
.leaflet-map-pane  { background: #060d1a !important; }
        .leaflet-control-attribution { background:rgba(6,13,26,0.75)!important;color:rgba(148,163,184,0.45)!important;font-size:9px!important;backdrop-filter:blur(8px);border-radius:6px 0 0 0!important;padding:2px 8px!important; }
        .leaflet-control-attribution a { color:rgba(148,163,184,0.55)!important; }
        .leaflet-attribution-flag { display:none!important; }
        .blitz-popup .leaflet-popup-content-wrapper { background:transparent!important;border:none!important;box-shadow:none!important;padding:0!important; }
        .blitz-popup .leaflet-popup-content { margin:0!important; }
        .blitz-popup .leaflet-popup-tip-container { display:none!important; }
        @media (max-width: 768px) {
  .map-risk-legend {
    position: static !important;
    bottom: auto !important;
    left: auto !important;
    max-height: none !important;
    width: calc(100% - 0px) !important;
    border-radius: 0 0 13px 13px !important;
    border-top: none !important;
  }
}
      `}</style>

      {/* Header */}
      <motion.div initial={{ opacity:0,y:20 }} animate={{ opacity:1,y:0 }} transition={{ duration:0.6 }} className="mx-auto max-w-6xl px-6 mb-6">
        <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:10 }}>
          <div style={{ width:42, height:42, borderRadius:13, background:'linear-gradient(135deg,rgba(250,204,21,0.18),rgba(239,68,68,0.12))', border:'1px solid rgba(250,204,21,0.28)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <CloudLightning style={{ width:22, height:22, color:'#facc15' }} />
          </div>
          <div>
            <h2 style={{ fontSize:'1.3rem', fontWeight:700, color:'#f1f5f9', letterSpacing:'-0.02em', margin:0 }}>Live Lightning & Storm Tracker</h2>
            <p style={{ fontSize:'0.78rem', color:'#64748b', margin:0, marginTop:2 }}>
              Blitzortung real-time · Open-Meteo heatmap · Auto-snapshot 23:59 · Alerts queued sequentially
            </p>
          </div>
          <div style={{ marginLeft:'auto', display:'flex', alignItems:'center', gap:8 }}>
            <div className={wsStatus === 'live' ? 'live-dot-green' : 'live-dot-amber'} />
            <span style={{ fontSize:'0.7rem', fontWeight:700, color:sc.color, fontFamily:'monospace', letterSpacing:'0.06em' }}>{sc.label}</span>
          </div>
        </div>
        <div style={{ display:'flex', gap:20, padding:'10px 16px', background:'rgba(255,255,255,0.025)', border:'1px solid rgba(255,255,255,0.06)', borderRadius:12, flexWrap:'wrap', alignItems:'center' }}>
          <StatPill icon={<CloudLightning style={{width:13,height:13}}/>} label="Last min"   value={lastMinCount.toLocaleString()}  color="#facc15" />
          <StatPill icon={<CloudLightning style={{width:13,height:13}}/>} label="UK today"   value={ukCount.toLocaleString()}        color="#38bdf8" />
          <StatPill icon={<CloudLightning style={{width:13,height:13}}/>} label="EU today"   value={euCount.toLocaleString()}        color="#a78bfa" />
          <StatPill icon={<Zap           style={{width:13,height:13}}/>} label="OM total"    value={omTodayTotal.toLocaleString()}   color="#ef4444" />
          <StatPill icon={<AlertTriangle style={{width:13,height:13}}/>} label="Storms"      value={stormPolys.length}               color="#f97316" />
          <StatPill icon={<Clock         style={{width:13,height:13}}/>} label="Updated"     value={fmt(lastUpdate)}                 color="#64748b" />
        </div>
      </motion.div>

      {/* Map */}
      <motion.div initial={{ opacity:0,scale:0.99 }} animate={{ opacity:1,scale:1 }} transition={{ duration:0.7, delay:0.1 }} className="mx-auto max-w-6xl px-6 mb-6">
        <div style={{ position:'relative', borderRadius:22, overflow:'hidden', border:'1px solid rgba(255,255,255,0.07)', boxShadow:'0 0 80px rgba(0,0,0,0.55)' }}>

          {/* Control bar */}
          <div style={{ position:'absolute', top:0, left:0, right:0, zIndex:1000, padding:'12px 14px', display:'flex', gap:8, alignItems:'center', flexWrap:'wrap', background:'linear-gradient(to bottom,rgba(6,13,26,0.95),transparent)', pointerEvents:'none' }}>
            <div style={{ display:'flex', borderRadius:10, overflow:'hidden', border:'1px solid rgba(255,255,255,0.09)', background:'rgba(6,13,26,0.9)', backdropFilter:'blur(14px)', pointerEvents:'all' }}>
              {[['uk','🇬🇧 UK'],['europe','🌍 Europe']].map(([id,lbl]) => (
                <button key={id} onClick={() => {
                  setView(id);
                  const v = MAP_VIEWS[id]; const c2 = v?.center;
                  if (mapInst.current && Array.isArray(c2) && Number.isFinite(c2[0]) && Number.isFinite(c2[1])) { try { mapInst.current.flyTo(c2, v.zoom, { animate: true, duration: 1.2 }); } catch(_) {} }
                }} style={{ padding:'6px 14px', fontSize:'0.73rem', fontWeight:700, color:view===id?'#0a0f1e':'#94a3b8', background:view===id?'#facc15':'transparent', border:'none', cursor:'pointer', transition:'all 0.2s', fontFamily:'system-ui,sans-serif' }}>{lbl}</button>
              ))}
            </div>

            <div style={{ display:'flex', gap:5, flexWrap:'wrap', pointerEvents:'all' }}>
              {LAYER_DEFS.map(layer => {
                const active = activeLayers.includes(layer.id);
                const Icon   = layer.icon;
                return (
                  <button key={layer.id} onClick={() => toggleLayer(layer.id)}
                    style={{ display:'flex', alignItems:'center', gap:5, padding:'6px 11px', borderRadius:9, background:active?`rgba(${hexToRgb(layer.color)},0.18)`:'rgba(6,13,26,0.9)', border:`1px solid ${active?layer.color:'rgba(255,255,255,0.09)'}`, color:active?layer.color:'#64748b', fontSize:'0.71rem', fontWeight:700, cursor:'pointer', backdropFilter:'blur(14px)', transition:'all 0.2s', fontFamily:'system-ui,sans-serif', pointerEvents:'all' }}>
                    <Icon style={{width:12,height:12}} />
                    {layer.label}
                    {layer.id==='strikes'   && <span style={{background:`rgba(${hexToRgb(layer.color)},0.18)`,borderRadius:4,padding:'0 5px',fontSize:'0.63rem',color:layer.color,fontFamily:'monospace'}}>{todayCount}</span>}
                    {layer.id==='omheat'    && omLoading && <Loader2 style={{width:10,height:10,animation:'spin 1s linear infinite'}}/>}
                    {layer.id==='omheat'    && !omLoading && omTodayTotal > 0 && <span style={{background:`rgba(${hexToRgb(layer.color)},0.18)`,borderRadius:4,padding:'0 5px',fontSize:'0.63rem',color:layer.color,fontFamily:'monospace'}}>{omTodayTotal}</span>}
                    {layer.id==='omblobs'   && omActiveCells.length > 0 && <span style={{background:`rgba(${hexToRgb(layer.color)},0.18)`,borderRadius:4,padding:'0 5px',fontSize:'0.63rem',color:layer.color,fontFamily:'monospace'}}>{omActiveCells.length}</span>}
                    {layer.id==='storms'    && stormPolys.length > 0 && <span style={{background:`rgba(${hexToRgb(layer.color)},0.18)`,borderRadius:4,padding:'0 5px',fontSize:'0.63rem',color:layer.color,fontFamily:'monospace'}}>{stormPolys.length}</span>}
                  </button>
                );
              })}
            </div>

            <div style={{ marginLeft:'auto', display:'flex', gap:6, pointerEvents:'all', flexWrap:'wrap' }}>
              {[
                { key:'strike', label:'⚡ Sound', state: soundEnabled,     set: setSoundEnabled },
                { key:'warn',   label:'🚨 Alert',  state: warnSoundEnabled, set: setWarnSoundEnabled },
                { key:'tts',    label:'🗣 Voice',   state: ttsEnabled,       set: setTtsEnabled },
              ].map(({ key, label, state, set }) => (
                <button key={key} onClick={() => set(v => !v)}
                  style={{ display:'flex', alignItems:'center', gap:4, padding:'6px 10px', borderRadius:9, background: state ? 'rgba(34,197,94,0.12)' : 'rgba(6,13,26,0.9)', border: `1px solid ${state ? '#22c55e' : 'rgba(255,255,255,0.09)'}`, color: state ? '#22c55e' : '#475569', fontSize:'0.68rem', fontWeight:700, cursor:'pointer', backdropFilter:'blur(14px)', fontFamily:'system-ui,sans-serif', transition:'all 0.2s' }}>
                  {label}
                </button>
              ))}
              <button onClick={() => { setTimeTravelMode(v => !v); if (timeTravelMode) exitTimeTravel(); }}
                style={{ display:'flex', alignItems:'center', gap:5, padding:'6px 11px', borderRadius:9, background: timeTravelMode ? 'rgba(167,139,250,0.18)' : 'rgba(6,13,26,0.9)', border: `1px solid ${timeTravelMode ? '#a78bfa' : 'rgba(255,255,255,0.09)'}`, color: timeTravelMode ? '#a78bfa' : '#64748b', fontSize:'0.71rem', cursor:'pointer', backdropFilter:'blur(14px)', fontFamily:'system-ui,sans-serif' }}>
                <Clock style={{width:11,height:11}}/> Time Travel
              </button>
              <button onClick={() => { fetchOMData(); loadRadar(); setLastUpdate(new Date()); }}
                style={{ display:'flex', alignItems:'center', gap:5, padding:'6px 11px', borderRadius:9, background:'rgba(6,13,26,0.9)', border:'1px solid rgba(255,255,255,0.09)', color:'#64748b', fontSize:'0.71rem', cursor:'pointer', backdropFilter:'blur(14px)', fontFamily:'system-ui,sans-serif' }}>
                {omLoading ? <Loader2 style={{width:11,height:11,animation:'spin 1s linear infinite'}}/> : <RefreshCw style={{width:11,height:11}}/>}
                Refresh
              </button>
            </div>
          </div>

          <div ref={mapRef} style={{ width:'100%', height:'min(580px, 60vh)', minHeight:320, background:'#060d1a' }} />
          {/* Time Travel Panel */}
          {timeTravelMode && (
            <div style={{ position:'absolute', top:56, left:'50%', transform:'translateX(-50%)', zIndex:1001, background:'rgba(6,13,26,0.97)', border:'1px solid rgba(167,139,250,0.4)', borderRadius:14, padding:'14px 18px', backdropFilter:'blur(18px)', display:'flex', flexDirection:'column', gap:10, minWidth:340 }}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
                <span style={{ fontSize:'0.78rem', fontWeight:700, color:'#a78bfa' }}>⏪ Time Travel — Archive View</span>
                <button onClick={exitTimeTravel} style={{ background:'rgba(255,255,255,0.06)', border:'none', borderRadius:6, width:24, height:24, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}><X style={{width:11,height:11}}/></button>
              </div>
              <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
                <div style={{ display:'flex', flexDirection:'column', gap:3 }}>
                  <span style={{ fontSize:'0.65rem', color:'#64748b', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.06em' }}>Date</span>
                  <input type="date"
                    value={timeTravelDate}
                    max={new Date().toISOString().slice(0,10)}
                    min="2010-01-01"
                    onChange={e => setTimeTravelDate(e.target.value)}
                    style={{ padding:'5px 8px', borderRadius:7, background:'rgba(255,255,255,0.06)', border:'1px solid rgba(167,139,250,0.3)', color:'#f1f5f9', fontSize:'0.74rem', colorScheme:'dark' }}
                  />
                </div>
                <div style={{ display:'flex', flexDirection:'column', gap:3 }}>
                  <span style={{ fontSize:'0.65rem', color:'#64748b', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.06em' }}>Hour (UTC) — {String(timeTravelHour).padStart(2,'0')}:00</span>
                  <input type="range" min={0} max={23} step={1} value={timeTravelHour}
                    onChange={e => setTimeTravelHour(Number(e.target.value))}
                    style={{ width:140, accentColor:'#a78bfa' }}
                  />
                </div>
                <button onClick={loadTimeTravelImage} disabled={!timeTravelDate || timeTravelLoading}
                  style={{ display:'flex', alignItems:'center', gap:5, padding:'8px 14px', borderRadius:9, background: !timeTravelDate ? 'rgba(167,139,250,0.05)' : 'rgba(167,139,250,0.18)', border:'1px solid rgba(167,139,250,0.35)', color: !timeTravelDate ? '#475569' : '#a78bfa', fontSize:'0.74rem', fontWeight:700, cursor: !timeTravelDate ? 'default' : 'pointer', alignSelf:'flex-end' }}>
                  {timeTravelLoading ? <Loader2 style={{width:11,height:11,animation:'spin 1s linear infinite'}}/> : <Clock style={{width:11,height:11}}/>}
                  Load
                </button>
              </div>
              {timeTravelImgUrl && (
                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 12px', borderRadius:9, background:'rgba(167,139,250,0.08)', border:'1px solid rgba(167,139,250,0.2)' }}>
                  <span style={{ fontSize:'0.72rem', color:'#94a3b8' }}>
                    Showing: {timeTravelDate} {String(timeTravelHour).padStart(2,'0')}:00 – {String(timeTravelHour+1).padStart(2,'0')}:00 UTC
                  </span>
                  <button onClick={handleTimeTravelSnapshot}
                    style={{ display:'flex', alignItems:'center', gap:5, padding:'6px 12px', borderRadius:8, background:'rgba(245,158,11,0.15)', border:'1px solid rgba(245,158,11,0.35)', color:'#f59e0b', fontSize:'0.72rem', fontWeight:700, cursor:'pointer' }}>
                    <Camera style={{width:11,height:11}}/> Force Snapshot
                  </button>
                </div>
              )}
              <p style={{ margin:0, fontSize:'0.65rem', color:'#475569' }}>Data from Blitzortung archive · overlaid on live map · use Force Snapshot to save to Historical panel</p>
            </div>
          )}
          {!leafletReady && (
            <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', background:'#060d1a', zIndex:999 }}>
              <div style={{ textAlign:'center' }}>
                <div style={{ width:44, height:44, border:'2px solid #facc15', borderTopColor:'transparent', borderRadius:'50%', margin:'0 auto 12px', animation:'spin 1s linear infinite' }} />
                <p style={{ color:'#475569', fontSize:'0.82rem' }}>Loading map…</p>
              </div>
            </div>
          )}

          {/* Legend */}
          <div className="map-risk-legend" style={{ position:'absolute', bottom:16, left:16, zIndex:1000, maxHeight:'calc(100% - 80px)', overflowY:'auto', background:'rgba(6,13,26,0.92)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:13, padding:'11px 15px', backdropFilter:'blur(16px)', minWidth:185 }}>
            <p style={{ fontSize:'0.6rem', fontWeight:700, color:'#475569', margin:'0 0 7px', letterSpacing:'0.1em', textTransform:'uppercase' }}>Strike Age (Blitzortung)</p>{[{label:'< 5 min',color:'#ffffff'},{label:'< 10 min',color:'#facc15'},{label:'< 30 min',color:'#f97316'},{label:'< 1 h',color:'#ef4444'},{label:'< 6 h',color:'#7f1d1d'},{label:'< 12 h',color:'#7c3aed'},{label:'< 24 h',color:'#4c1d95'}].map(k => (
              <div key={k.label} style={{ display:'flex', alignItems:'center', gap:7, marginBottom:4 }}>
                <svg width="11" height="11" viewBox="0 0 11 11"><rect x="4.5" y="1" width="2" height="9" rx="1" fill={k.color} opacity="0.9"/><rect x="1" y="4.5" width="9" height="2" rx="1" fill={k.color} opacity="0.9"/></svg>
                <span style={{ fontSize:'0.66rem', color:'#94a3b8' }}>{k.label}</span>
              </div>
            ))}
            <div style={{ borderTop:'1px solid rgba(255,255,255,0.06)', marginTop:9, paddingTop:8 }}>
              <p style={{ fontSize:'0.6rem', fontWeight:700, color:'#475569', margin:'0 0 7px', letterSpacing:'0.1em', textTransform:'uppercase' }}>Strike Density Heatmap</p>
              {[{color:'#a78bfa',label:'≥3 strikes/cell'},{color:'#facc15',label:'≥8 strikes/cell'},{color:'#f97316',label:'≥20 strikes/cell'},{color:'#ef4444',label:'≥50 strikes/cell'}].map(k => (
                <div key={k.label} style={{ display:'flex', alignItems:'center', gap:7, marginBottom:4 }}>
                  <div style={{ width:10, height:10, borderRadius:'50%', background:k.color, opacity:0.8 }} />
                  <span style={{ fontSize:'0.66rem', color:'#94a3b8' }}>{k.label}</span>
                </div>
              ))}
            </div>
            <div style={{ borderTop:'1px solid rgba(255,255,255,0.06)', marginTop:9, paddingTop:8 }}>
              <p style={{ fontSize:'0.6rem', fontWeight:700, color:'#475569', margin:'0 0 7px', letterSpacing:'0.1em', textTransform:'uppercase' }}>OM Heatmap (2hr)</p>
              {[{color:'#facc15',label:'≥30 strikes'},{color:'#f97316',label:'≥150 strikes'},{color:'#ef4444',label:'≥300 strikes'}].map(k => (
                <div key={k.label} style={{ display:'flex', alignItems:'center', gap:7, marginBottom:4 }}>
                  <div style={{ width:10, height:10, borderRadius:'50%', background:k.color, opacity:0.85 }} />
                  <span style={{ fontSize:'0.66rem', color:'#94a3b8' }}>{k.label}</span>
                </div>
              ))}
            </div>
            <div style={{ borderTop:'1px solid rgba(255,255,255,0.06)', marginTop:9, paddingTop:8 }}>
              <p style={{ fontSize:'0.6rem', fontWeight:700, color:'#475569', margin:'0 0 7px', letterSpacing:'0.1em', textTransform:'uppercase' }}>Storm Warning (expires)</p>
              {Object.entries(STORM_RISK).map(([key,r]) => (
                <div key={key} style={{ display:'flex', alignItems:'center', gap:7, marginBottom:4 }}>
                  <div style={{ width:9, height:9, borderRadius:2, background:r.color }} />
                  <span style={{ fontSize:'0.66rem', color:'#94a3b8' }}>{r.fullLabel} · {r.expiryMs >= 3600000 ? `${r.expiryMs/3600000}h` : `${r.expiryMs/60000}min`}</span>
                </div>
              ))}
            </div>
            <p style={{ fontSize:'0.58rem', color:'#334155', marginTop:8, marginBottom:0 }}>Click cells/strikes for info</p>
          </div>

          {/* RainViewer accurate colour bar */}
          {activeLayers.includes('radar') && (
            <div style={{ position:'absolute', bottom:16, right:16, zIndex:1000, background:'rgba(6,13,26,0.92)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:13, padding:'11px 15px', backdropFilter:'blur(16px)' }}>
              <p style={{ fontSize:'0.6rem', fontWeight:700, color:'#475569', margin:'0 0 7px', letterSpacing:'0.1em', textTransform:'uppercase' }}>Rainfall Intensity</p>
              <div style={{ display:'flex', gap:1.5, borderRadius:5, overflow:'hidden', marginBottom:5 }}>
                {RAINVIEWER_COLORS.map((c,i) => (
                  <div key={i} style={{ flex:1, height:9, background:c }} />
                ))}
              </div>
              <div style={{ display:'flex', justifyContent:'space-between' }}>
                <span style={{ fontSize:'0.6rem', color:'#64748b', fontFamily:'monospace' }}>Light</span>
                <span style={{ fontSize:'0.6rem', color:'#64748b', fontFamily:'monospace' }}>Heavy</span>
              </div>
            </div>
          )}

          {omLastFetch && (
            <div style={{ position:'absolute', top:60, right:16, zIndex:1000, background:'rgba(6,13,26,0.88)', border:'1px solid rgba(250,204,21,0.2)', borderRadius:9, padding:'4px 10px', backdropFilter:'blur(12px)' }}>
              <span style={{ fontSize:'0.62rem', color:'#64748b', fontFamily:'monospace' }}>OM: {omLastFetch.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})}</span>
            </div>
          )}
        </div>

        {/* Active storm cards */}
        <AnimatePresence>
          {stormPolys.length > 0 && (
            <motion.div initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} exit={{ opacity:0,y:10 }}
              style={{ marginTop:12, display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:10 }}>
              {stormPolys.map(poly => {
                const cfg      = STORM_RISK[poly.risk];
                const rgb      = hexToRgb(cfg.color);
                const flashing = isFlashing[poly.id];
                const expiresIn = Math.max(0, Math.round((poly.expiresAt - Date.now()) / 60000));
                return (
                  <button key={poly.id} onClick={() => setSelectedStorm(poly)}
                    style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderRadius:13, textAlign:'left', background:`rgba(${rgb},0.07)`, border:`1px solid ${flashing?cfg.color:`rgba(${rgb},0.28)`}`, cursor:'pointer', animation:flashing?'stormPulse 0.45s ease infinite':'none', transition:'border-color 0.3s', width:'100%' }}>
                    <div style={{ width:36, height:36, borderRadius:10, flexShrink:0, background:`rgba(${rgb},0.15)`, display:'flex', alignItems:'center', justifyContent:'center' }}>
                      <AlertTriangle style={{width:17,height:17,color:cfg.color}}/>
                    </div>
                    <div style={{ flex:1, minWidth:0 }}>
                      <p style={{ margin:0, fontSize:'0.78rem', fontWeight:700, color:cfg.color }}>{cfg.fullLabel}</p>
                      <p style={{ margin:0, fontSize:'0.69rem', color:'#64748b', marginTop:1 }}>{poly.count} strikes · expires in {expiresIn}m</p>
                      <p style={{ margin:0, fontSize:'0.65rem', color:'#94a3b8', marginTop:1 }}>📍 {poly.locationLabel}</p>
                    </div>
                    <ChevronRight style={{width:14,height:14,color:'#475569',flexShrink:0}}/>
                  </button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>

        {/* OM active storm cell cards */}
        <AnimatePresence>
          {omActiveCells.length > 0 && (
            <motion.div initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} exit={{ opacity:0,y:10 }}
              style={{ marginTop:10, display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:10 }}>
              {omActiveCells.map(cell => (
                <button key={cell.cellId} onClick={() => setSelectedOMCell(cell)}
                  style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 16px', borderRadius:13, textAlign:'left', background:`rgba(${hexToRgb(cell.risk.color)},0.07)`, border:`1px solid rgba(${hexToRgb(cell.risk.color)},0.28)`, cursor:'pointer', width:'100%' }}>
                  <div style={{ width:36, height:36, borderRadius:10, flexShrink:0, background:`rgba(${hexToRgb(cell.risk.color)},0.15)`, display:'flex', alignItems:'center', justifyContent:'center' }}>
                    <Zap style={{width:17,height:17,color:cell.risk.color}}/>
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ margin:0, fontSize:'0.78rem', fontWeight:700, color:cell.risk.color }}>{cell.risk.label}</p>
                    <p style={{ margin:0, fontSize:'0.69rem', color:'#64748b', marginTop:1 }}>{cell.recentCount} OM strikes (2hr)</p>
                    <p style={{ margin:0, fontSize:'0.65rem', color:'#94a3b8', marginTop:1 }}>📍 {cell.locationLabel}</p>
                  </div>
                  <ChevronRight style={{width:14,height:14,color:'#475569',flexShrink:0}}/>
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Storm detail modal */}
      <AnimatePresence>
        {selectedStorm && (
          <>
            <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={() => setSelectedStorm(null)} style={{ position:'fixed', inset:0, zIndex:9000, background:'rgba(0,0,0,0.65)', backdropFilter:'blur(8px)' }} />
            <motion.div initial={{opacity:0,scale:0.9,y:24}} animate={{opacity:1,scale:1,y:0}} exit={{opacity:0,scale:0.9,y:24}} transition={{ type:'spring', stiffness:300, damping:26 }}
              style={{ position:'fixed', top:'50%', left:'50%', transform:'translate(-50%,-50%)', zIndex:9001, width:'90%', maxWidth:468, background:'linear-gradient(160deg,#0d1829,#1a1040)', border:`1px solid ${STORM_RISK[selectedStorm.risk].color}45`, borderRadius:22, padding:28, boxShadow:`0 0 80px ${STORM_RISK[selectedStorm.risk].color}18,0 32px 80px rgba(0,0,0,0.7)` }}>
              <button onClick={() => setSelectedStorm(null)} style={{ position:'absolute', top:14, right:14, background:'rgba(255,255,255,0.06)', border:'none', borderRadius:8, width:30, height:30, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}><X style={{width:14,height:14}}/></button>
              <div style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'5px 13px', borderRadius:9, marginBottom:16, background:`rgba(${hexToRgb(STORM_RISK[selectedStorm.risk].color)},0.14)`, border:`1px solid ${STORM_RISK[selectedStorm.risk].color}48` }}>
                <AlertTriangle style={{width:13,height:13,color:STORM_RISK[selectedStorm.risk].color}} />
                <span style={{ fontSize:'0.74rem', fontWeight:700, color:STORM_RISK[selectedStorm.risk].color }}>{STORM_RISK[selectedStorm.risk].fullLabel}</span>
              </div>
              <h3 style={{ margin:'0 0 4px', fontSize:'1.1rem', fontWeight:700, color:'#f1f5f9' }}>Thunderstorm Warning</h3>
              <p style={{ margin:'0 0 6px', fontSize:'0.78rem', color:'#94a3b8', fontWeight:600 }}>
                📍 {nearestCity(selectedStorm.centroid.lat, selectedStorm.centroid.lon)}
                &nbsp;·&nbsp; 🕐 Active: {selectedStorm.startTime} – {selectedStorm.endTime}
              </p>
              <p style={{ margin:'0 0 18px', fontSize:'0.84rem', color:'#94a3b8', lineHeight:1.65 }}>{STORM_RISK[selectedStorm.risk].desc}</p>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:16 }}>
                {[
                  {label:'First detected', val:selectedStorm.startTime,  Icon:Clock},
                  {label:'Est. clear',     val:selectedStorm.endTime,    Icon:Clock},
                  {label:'Strikes (30m)',  val:selectedStorm.count,      Icon:CloudLightning},
                  {label:'Movement',       val:selectedStorm.direction ? `${selectedStorm.direction.dLon>0?'E':'W'}${selectedStorm.direction.dLat>0?'N':'S'}` : 'Stationary', Icon:Wind},
                ].map(({label,val,Icon})=>(
                  <div key={label} style={{ padding:'10px 12px', borderRadius:11, background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.07)' }}>
                    <div style={{ display:'flex', alignItems:'center', gap:5, marginBottom:4 }}>
                      <Icon style={{width:11,height:11,color:'#64748b'}}/>
                      <p style={{ margin:0, fontSize:'0.62rem', color:'#64748b', fontWeight:700, letterSpacing:'0.07em', textTransform:'uppercase' }}>{label}</p>
                    </div>
                    <p style={{ margin:0, fontSize:'0.92rem', fontWeight:700, color:'#e2e8f0', fontFamily:'monospace' }}>{val}</p>
                  </div>
                ))}
              </div>
              <p style={{ margin:0, fontSize:'0.71rem', color:'#475569', textAlign:'center' }}>Data: Blitzortung · clustered from 30-min window · path based on drift + wind direction</p>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* OM Cell modal */}
      <AnimatePresence>
        {selectedOMCell && (
          <>
            <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={() => setSelectedOMCell(null)} style={{ position:'fixed', inset:0, zIndex:9000, background:'rgba(0,0,0,0.65)', backdropFilter:'blur(8px)' }} />
            <motion.div initial={{opacity:0,scale:0.9,y:24}} animate={{opacity:1,scale:1,y:0}} exit={{opacity:0,scale:0.9,y:24}} transition={{ type:'spring', stiffness:300, damping:26 }}
              style={{ position:'fixed', top:'50%', left:'50%', transform:'translate(-50%,-50%)', zIndex:9001, width:'90%', maxWidth:440, background:'linear-gradient(160deg,#0d1829,#1a1040)', border:`1px solid ${selectedOMCell.risk.color}45`, borderRadius:22, padding:28, boxShadow:`0 0 80px ${selectedOMCell.risk.color}18,0 32px 80px rgba(0,0,0,0.7)` }}>
              <button onClick={() => setSelectedOMCell(null)} style={{ position:'absolute', top:14, right:14, background:'rgba(255,255,255,0.06)', border:'none', borderRadius:8, width:30, height:30, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', color:'#64748b' }}><X style={{width:14,height:14}}/></button>
              <div style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'5px 13px', borderRadius:9, marginBottom:16, background:`rgba(${hexToRgb(selectedOMCell.risk.color)},0.14)`, border:`1px solid ${selectedOMCell.risk.color}48` }}>
                <Zap style={{width:13,height:13,color:selectedOMCell.risk.color}} />
                <span style={{ fontSize:'0.74rem', fontWeight:700, color:selectedOMCell.risk.color }}>Open-Meteo Storm Cell</span>
              </div>
              <h3 style={{ margin:'0 0 4px', fontSize:'1.1rem', fontWeight:700, color:'#f1f5f9' }}>{selectedOMCell.risk.label}</h3>
              <p style={{ margin:'0 0 6px', fontSize:'0.78rem', color:'#94a3b8', fontWeight:600 }}>
                📍 {nearestCity(selectedOMCell.lat, selectedOMCell.lon)}
              </p>
              <p style={{ margin:'0 0 20px', fontSize:'0.84rem', color:'#94a3b8', lineHeight:1.65 }}>{selectedOMCell.risk.desc}</p>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:16 }}>
                {[
                  {label:'Recent Strikes (2hr)', val:selectedOMCell.recentCount},
                  {label:'Today Total',          val:selectedOMCell.dayTotal},
                  {label:'Warning Level',        val:selectedOMCell.risk.label},
                  {label:'Threshold',            val:`≥${blobRiskLevel(selectedOMCell.recentCount).color === '#ef4444' ? 300 : blobRiskLevel(selectedOMCell.recentCount).color === '#f97316' ? 150 : 30} strikes`},
                ].map(({label,val})=>(
                  <div key={label} style={{ padding:'10px 12px', borderRadius:11, background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.07)' }}>
                    <p style={{ margin:0, fontSize:'0.62rem', color:'#64748b', fontWeight:700, letterSpacing:'0.07em', textTransform:'uppercase' }}>{label}</p>
                    <p style={{ margin:0, fontSize:'0.92rem', fontWeight:700, color:'#e2e8f0', fontFamily:'monospace' }}>{val}</p>
                  </div>
                ))}
              </div>
              <p style={{ margin:0, fontSize:'0.71rem', color:'#475569', textAlign:'center' }}>Data: Open-Meteo ERA5 archive · updated every 5 min</p>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* New storm toast */}
      {newStormAlert && (
        <div className="alert-banner" style={{ position:'fixed', top:80, right:20, zIndex:9999, width:340, padding:'14px 16px', borderRadius:15, background:'rgba(6,13,26,0.97)', border:`1px solid ${STORM_RISK[newStormAlert.risk].color}55`, backdropFilter:'blur(18px)', display:'flex', alignItems:'flex-start', gap:12 }}>
          <div style={{ width:38, height:38, borderRadius:11, flexShrink:0, background:`rgba(${hexToRgb(STORM_RISK[newStormAlert.risk].color)},0.18)`, display:'flex', alignItems:'center', justifyContent:'center', animation:'stormPulse 0.5s ease infinite' }}>
            <AlertTriangle style={{width:19,height:19,color:STORM_RISK[newStormAlert.risk].color}}/>
          </div>
          <div>
            <p style={{ margin:0, fontSize:'0.82rem', fontWeight:700, color:'#f1f5f9', marginBottom:3 }}>⚡ Thunderstorm Detected</p>
            <p style={{ margin:0, fontSize:'0.74rem', color:'#94a3b8' }}>{STORM_RISK[newStormAlert.risk].fullLabel} · {newStormAlert.count} strikes in 30 min</p>
            <p style={{ margin:0, fontSize:'0.68rem', color:'#94a3b8', marginTop:2 }}>📍 {nearestCity(newStormAlert.centroid.lat, newStormAlert.centroid.lon)}</p>
            <p style={{ margin:0, fontSize:'0.68rem', color:'#475569', marginTop:2 }}>Alerts queued sequentially · Click polygon for details</p>
          </div>
        </div>
      )}

      <ArchivePanel
        archive={archive}
        setArchive={setArchive}
        isAdmin={isAdmin}
        onForceSnapshot={handleForceSnapshot}
      />
    </>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SECTION DIVIDER
   ═══════════════════════════════════════════════════════════════ */
function SectionDivider({ label, lightMode = false }) {
  return (
    <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} transition={{ duration:0.5 }}
      className="mx-auto max-w-6xl px-6 mb-10" style={{ display:'flex', alignItems:'center', gap:16 }}>
      <div style={{ flex:1, height:1, background: lightMode?'linear-gradient(to right,transparent,rgba(0,0,0,0.1))':'linear-gradient(to right,transparent,rgba(255,255,255,0.07))' }} />
      <span style={{ fontSize:'0.68rem', fontWeight:700, letterSpacing:'0.14em', color: lightMode?'rgba(71,85,105,0.6)':'rgba(148,163,184,0.35)', textTransform:'uppercase', padding:'4px 14px', borderRadius:20, border:`1px solid ${lightMode?'rgba(0,0,0,0.1)':'rgba(255,255,255,0.06)'}`, background: lightMode?'rgba(0,0,0,0.04)':'rgba(255,255,255,0.02)', whiteSpace:'nowrap' }}>{label}</span>
      <div style={{ flex:1, height:1, background: lightMode?'linear-gradient(to left,transparent,rgba(0,0,0,0.1))':'linear-gradient(to left,transparent,rgba(255,255,255,0.07))' }} />
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   ROOT PAGE
   ═══════════════════════════════════════════════════════════════ */
export default function TCM() {
  const queryClient = useQueryClient();
  const [archive, setArchive] = useState(loadArchive);

  const { data: outlooks = [], isLoading } = useQuery({
    queryKey: ['tcmOutlooks'],
    queryFn:  () => db.entities.TCMOutlook.list('-outlook_date'),
  });
  const { data: userMe } = useQuery({
    queryKey: ['me'],
    queryFn:  () => db.auth.me().catch(() => null),
  });
  const { data: settingsList = [] } = useQuery({
    queryKey: ['settings'],
    queryFn:  () => db.entities.SiteSettings.list(),
  });

  const tcmLogoUrl = settingsList[0]?.tcm_logo_url || null;
  const isAdmin    = userMe?.role === 'admin';
  const [region, setRegion] = useState(() => localStorage.getItem('tcm_region') || 'uk');
  const isEurope  = region === 'europe';
  const isUSA     = region === 'usa';
  const [lightMode, setLightMode] = useState(() => localStorage.getItem('tcm_light_mode') === 'true');

  const [omHistory,    setOMHistory]    = useState(loadOMHistory);
  const [omHistLoading,setOMHistLoading]= useState(false);

  const toggleLightMode = () => setLightMode(v => {
    const next = !v;
    localStorage.setItem('tcm_light_mode', String(next));
    return next;
  });
  const setRegionAndSave = (r) => { setRegion(r); localStorage.setItem('tcm_region', r); };

  useEffect(() => {
    const doFetch = async () => {
      setOMHistLoading(true);
      const data = await fetchOMHistoricalDays(30);
      if (data) {
        setOMHistory(prev => {
          const merged = { ...prev, ...data };
          saveOMHistory(merged);
          return merged;
        });
      }
      setOMHistLoading(false);
    };
    doFetch();
    const iv = setInterval(doFetch, 6 * 60 * 60 * 1000);
    return () => clearInterval(iv);
  }, []);

  useAutoArchive(outlooks, queryClient);
  const visibleOutlooks = outlooks.filter(o => !o.is_upcoming && !o.is_archived);

 const pageBg = lightMode
  ? 'linear-gradient(160deg, #e8edf5, #ffffff)'
  : 'linear-gradient(160deg, #0a0f1e, #1a1040)';

  return (
    <div className="min-h-screen" style={{ background: pageBg, backgroundColor: '#0a0f1e', transition: 'background 0.6s ease' }}>
      <TCMHamburger isAdmin={isAdmin} tcmLogoUrl={tcmLogoUrl} isEurope={isEurope} isUSA={isUSA} lightMode={lightMode} onToggleLightMode={toggleLightMode} />

      <div className="fixed top-4 right-4 z-50 flex" style={{ borderRadius:12, overflow:'hidden', border:`1px solid ${lightMode?'rgba(0,0,0,0.12)':'rgba(255,255,255,0.1)'}`, background: lightMode?'rgba(240,244,248,0.9)':'rgba(15,23,42,0.85)', backdropFilter:'blur(12px)' }}>
        {[{id:'uk',label:'🇬🇧 UK'},{id:'europe',label:'🌍 Europe'},{id:'usa',label:'🇺🇸 USA'}].map(({id,label})=>(
          <button key={id} onClick={() => setRegionAndSave(id)}
            style={{ padding:'7px 14px', fontSize:'0.72rem', fontWeight:700, color:region===id?'#0a0f1e':(lightMode?'#64748b':'#64748b'), background:region===id?'linear-gradient(135deg,#a78bfa,#38bdf8)':'transparent', border:'none', cursor:'pointer', transition:'all 0.2s' }}>
            {label}
          </button>
        ))}
      </div>

      <div className="pt-20" />

      {isUSA ? (
        <motion.div key="usa" initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.5 }} className="mx-auto max-w-3xl">
          <USAMonitor isAdmin={isAdmin} lightMode={lightMode} />
        </motion.div>
      ) : (
        <>
          <RiskLegend lightMode={lightMode} />

          <SectionDivider label={isEurope ? 'Europe Ensemble Forecast' : 'TCM UK — Ensemble Forecast'} lightMode={lightMode} />
          <motion.div className="mx-auto max-w-3xl px-0 mb-10" initial={{ opacity:0, y:24 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.6, ease:[0.4,0,0.2,1] }}>
            <ThunderstormMonitor isAdmin={isAdmin} lightMode={lightMode} isEurope={isEurope} />
          </motion.div>

          {(isLoading || visibleOutlooks.length > 0) && (
            <>
              <SectionDivider label="Published Outlooks" lightMode={lightMode} />
              {isLoading
                ? <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
                : <TCMSection outlooks={visibleOutlooks} isOwner={isAdmin} />
              }
            </>
          )}

          <SectionDivider label="Historical Lightning Activity" lightMode={lightMode} />
          <HistoricalLightningPanel
            lightMode={lightMode}
            forcedSnapshots={loadArchive().filter(d => d.isForced)}
          />

          <SectionDivider label="Live Lightning & Storm Tracker" lightMode={lightMode} />
          <LightningMap onOMHistoryUpdate={setOMHistory} region={region} isAdmin={isAdmin} archive={archive} setArchive={setArchive} />
        </>
      )}
    </div>
  );
}