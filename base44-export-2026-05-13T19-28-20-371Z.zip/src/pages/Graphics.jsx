const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Image, Loader2, Search } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import GraphicCard from '@/components/GraphicCard';
import GraphicForm from '@/components/GraphicForm';

export default function Graphics() {
  const [showForm, setShowForm] = useState(false);
  const [editingGraphic, setEditingGraphic] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const queryClient = useQueryClient();

  const { data: graphics, isLoading } = useQuery({
    queryKey: ['graphics'],
    queryFn: () => db.entities.WeatherGraphic.list('-created_date'),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.WeatherGraphic.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['graphics'] });
      setShowForm(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => db.entities.WeatherGraphic.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['graphics'] });
      setShowForm(false);
      setEditingGraphic(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => db.entities.WeatherGraphic.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['graphics'] }),
  });

  const handleSubmit = (data) => {
    if (editingGraphic) {
      updateMutation.mutate({ id: editingGraphic.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (graphic) => {
    setEditingGraphic(graphic);
    setShowForm(true);
  };

  const handleToggleFeatured = (graphic) => {
    updateMutation.mutate({
      id: graphic.id,
      data: { is_featured: !graphic.is_featured }
    });
  };

  const filteredGraphics = graphics.filter(g => 
    g.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    g.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-sky-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-800">Weather Graphics</h1>
            <p className="text-slate-500 mt-1">Manage your weather graphics and forecasts</p>
          </div>
          <Button 
            onClick={() => {
              setEditingGraphic(null);
              setShowForm(true);
            }}
            className="bg-sky-600 hover:bg-sky-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Graphic
          </Button>
        </div>

        {/* Search */}
        <div className="relative mb-8">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <Input
            placeholder="Search graphics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 h-12 bg-white border-slate-200"
          />
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-sky-600" />
          </div>
        ) : filteredGraphics.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredGraphics.map((graphic, index) => (
                <GraphicCard
                  key={graphic.id}
                  graphic={graphic}
                  index={index}
                  onEdit={handleEdit}
                  onDelete={(id) => deleteMutation.mutate(id)}
                  onToggleFeatured={handleToggleFeatured}
                />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
              <Image className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-700 mb-2">
              {searchQuery ? 'No matching graphics' : 'No graphics yet'}
            </h3>
            <p className="text-slate-500 mb-6">
              {searchQuery ? 'Try a different search term' : 'Add your first weather graphic to get started'}
            </p>
            {!searchQuery && (
              <Button 
                onClick={() => setShowForm(true)}
                className="bg-sky-600 hover:bg-sky-700"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add Your First Graphic
              </Button>
            )}
          </motion.div>
        )}
      </div>

      {/* Form Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-[95vw] w-full h-[95vh] flex flex-col p-0 overflow-hidden">
          <DialogHeader className="px-6 pt-6 pb-4 border-b flex-shrink-0">
            <DialogTitle>
              {editingGraphic ? 'Edit Graphic' : 'Add New Graphic'}
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto overflow-x-auto p-6">
            <GraphicForm
              graphic={editingGraphic}
              onSubmit={handleSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditingGraphic(null);
              }}
              isLoading={createMutation.isPending || updateMutation.isPending}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}