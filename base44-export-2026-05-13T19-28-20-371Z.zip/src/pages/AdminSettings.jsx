const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Save, Upload, Loader2, X, Palette, Share2, Home,
  ShieldAlert, CloudLightning, Settings, Lock,
  Menu as MenuIcon, Globe, ChevronRight, Zap, Users,
  AlertTriangle, Megaphone, Sun, CloudRain, Type, Eye,
  Twitter, Youtube, MessageCircle, Facebook, Instagram,
  Check, Info, RefreshCw, ToggleLeft, ToggleRight,
  Image, Link2, Bell, Layers, Activity, Clock,
  ChevronDown, Copy, ExternalLink, Shield, Database
} from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

import SubscriptionAnimation from '@/components/SubscriptionAnimation';

// ─── Design Tokens ─────────────────────────────────────────────────────────────
const C = {
  bg:        '#05090f',
  bgAlt:     '#080e1a',
  surface:   '#0c1422',
  surface2:  '#101c2e',
  surface3:  '#142030',
  border:    'rgba(148,163,184,0.07)',
  border2:   'rgba(148,163,184,0.12)',
  border3:   'rgba(148,163,184,0.18)',
  sky:       '#38bdf8',
  skyLow:    'rgba(56,189,248,0.06)',
  skyMed:    'rgba(56,189,248,0.12)',
  skyBorder: 'rgba(56,189,248,0.2)',
  violet:    '#a78bfa',
  violetLow: 'rgba(167,139,250,0.08)',
  green:     '#4ade80',
  greenLow:  'rgba(74,222,128,0.08)',
  amber:     '#fbbf24',
  amberLow:  'rgba(251,191,36,0.08)',
  red:       '#f87171',
  redLow:    'rgba(248,113,113,0.08)',
  text:      '#f1f5f9',
  textMid:   '#94a3b8',
  textDim:   'rgba(148,163,184,0.5)',
  textFaint: 'rgba(148,163,184,0.3)',
};

const FONT = "'Geist', 'DM Sans', system-ui, sans-serif";

// ─── Nav Items ──────────────────────────────────────────────────────────────────
const NAV = [
  { id: 'general',  label: 'General',       icon: Palette,       group: 'Site',    desc: 'Branding & identity',     color: C.sky },
  { id: 'site',     label: 'Site Control',  icon: Activity,      group: 'Site',    desc: 'Status & weather text',   color: C.sky },
  { id: 'publish',  label: 'Publish',       icon: Zap,           group: 'Site',    desc: 'Feature releases',        color: C.violet },
  { id: 'warnings', label: 'Warnings',      icon: AlertTriangle, group: 'Content', desc: 'Manual weather alerts',   color: C.amber },
  { id: 'announce', label: 'Announcements', icon: Megaphone,     group: 'Content', desc: 'Site-wide notices',       color: C.sky },
  { id: 'tcm',      label: 'TCM',           icon: CloudLightning,group: 'Content', desc: 'Storm centre data',       color: '#60a5fa' },
  { id: 'menu',     label: 'Menu Lock',     icon: Shield,        group: 'Access',  desc: 'Navigation gating',       color: C.violet },
  { id: 'access',   label: 'Access',        icon: Lock,          group: 'Access',  desc: 'Codes & requests',        color: '#34d399' },
];
const GROUPS = ['Site', 'Content', 'Access'];

// ─── Shared Input Styles ────────────────────────────────────────────────────────
const inputBase = {
  width: '100%',
  boxSizing: 'border-box',
  padding: '10px 14px',
  background: C.surface3,
  border: `1px solid ${C.border2}`,
  borderRadius: 10,
  color: C.text,
  fontSize: 13,
  fontFamily: FONT,
  outline: 'none',
  transition: 'border-color 0.2s, box-shadow 0.2s',
  lineHeight: 1.5,
};

function StyledInput({ prefix, suffix, ...props }) {
  const [focused, setFocused] = useState(false);
  if (prefix || suffix) {
    return (
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
        {prefix && <div style={{ position: 'absolute', left: 12, color: C.textDim, fontSize: 13, pointerEvents: 'none', display: 'flex', alignItems: 'center' }}>{prefix}</div>}
        <input {...props} style={{ ...inputBase, ...(prefix ? { paddingLeft: 36 } : {}), ...(suffix ? { paddingRight: 36 } : {}), ...(focused ? { borderColor: C.skyBorder, boxShadow: `0 0 0 3px ${C.skyLow}` } : {}), ...props.style }} onFocus={e => { setFocused(true); props.onFocus?.(e); }} onBlur={e => { setFocused(false); props.onBlur?.(e); }} />
        {suffix && <div style={{ position: 'absolute', right: 12, color: C.textDim, fontSize: 13, pointerEvents: 'none', display: 'flex', alignItems: 'center' }}>{suffix}</div>}
      </div>
    );
  }
  return <input {...props} style={{ ...inputBase, ...(focused ? { borderColor: C.skyBorder, boxShadow: `0 0 0 3px ${C.skyLow}` } : {}), ...props.style }} onFocus={e => { setFocused(true); props.onFocus?.(e); }} onBlur={e => { setFocused(false); props.onBlur?.(e); }} />;
}

function StyledTextarea({ rows = 3, ...props }) {
  const [focused, setFocused] = useState(false);
  return <textarea rows={rows} {...props} style={{ ...inputBase, resize: 'vertical', ...(focused ? { borderColor: C.skyBorder, boxShadow: `0 0 0 3px ${C.skyLow}` } : {}), ...props.style }} onFocus={e => { setFocused(true); props.onFocus?.(e); }} onBlur={e => { setFocused(false); props.onBlur?.(e); }} />;
}

function StyledSelect({ children, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <select {...props} style={{ ...inputBase, appearance: 'none', paddingRight: 36, cursor: 'pointer', ...(focused ? { borderColor: C.skyBorder, boxShadow: `0 0 0 3px ${C.skyLow}` } : {}), ...props.style }} onFocus={e => { setFocused(true); props.onFocus?.(e); }} onBlur={e => { setFocused(false); props.onBlur?.(e); }}>
        {children}
      </select>
      <ChevronDown style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', width: 14, height: 14, color: C.textDim, pointerEvents: 'none' }} />
    </div>
  );
}

// ─── Toggle ─────────────────────────────────────────────────────────────────────
function Toggle({ checked, onChange, label, desc, danger }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 20, padding: '16px 0', borderBottom: `1px solid ${C.border}` }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: 0, fontSize: 13.5, fontWeight: 600, color: C.text, lineHeight: 1.4 }}>{label}</p>
        {desc && <p style={{ margin: '4px 0 0', fontSize: 12, color: C.textMid, lineHeight: 1.6 }}>{desc}</p>}
      </div>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        aria-checked={checked}
        role="switch"
        style={{
          flexShrink: 0,
          width: 46,
          height: 26,
          borderRadius: 13,
          border: 'none',
          cursor: 'pointer',
          transition: 'all 0.25s cubic-bezier(0.4,0,0.2,1)',
          background: checked
            ? (danger ? 'linear-gradient(135deg, #dc2626, #b91c1c)' : 'linear-gradient(135deg, #0ea5e9, #0284c7)')
            : C.surface3,
          outline: `1px solid ${checked ? 'transparent' : C.border3}`,
          position: 'relative',
          padding: 0,
        }}
      >
        <div style={{
          width: 20, height: 20, borderRadius: '50%', background: '#fff',
          position: 'absolute', top: 3, left: checked ? 23 : 3,
          transition: 'left 0.25s cubic-bezier(0.4,0,0.2,1)',
          boxShadow: '0 1px 4px rgba(0,0,0,0.4)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {checked && <Check style={{ width: 10, height: 10, color: '#0284c7', strokeWidth: 3 }} />}
        </div>
      </button>
    </div>
  );
}

// ─── Field ───────────────────────────────────────────────────────────────────────
function Field({ label, hint, required, children, row }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
      {label && (
        <label style={{ fontSize: 11.5, fontWeight: 600, color: C.textMid, letterSpacing: '0.06em', textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 4 }}>
          {label}
          {required && <span style={{ color: C.red, fontSize: 12 }}>*</span>}
        </label>
      )}
      {children}
      {hint && <p style={{ margin: 0, fontSize: 11.5, color: C.textFaint, lineHeight: 1.6 }}>{hint}</p>}
    </div>
  );
}

// ─── Card ─────────────────────────────────────────────────────────────────────────
function Card({ children, style = {}, glow }) {
  return (
    <div style={{
      background: C.surface,
      border: `1px solid ${C.border}`,
      borderRadius: 18,
      overflow: 'hidden',
      position: 'relative',
      ...(glow ? { boxShadow: `0 0 0 1px ${glow}22, 0 8px 32px ${glow}08` } : {}),
      ...style,
    }}>
      {glow && <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1, background: `linear-gradient(90deg, transparent, ${glow}40, transparent)` }} />}
      {children}
    </div>
  );
}

function CardHeader({ icon: Icon, color = C.sky, title, desc, badge, badgeVariant = 'info', actions }) {
  const badgeStyles = {
    info:    { bg: C.skyMed,    text: C.sky,   border: C.skyBorder },
    success: { bg: C.greenLow,  text: C.green,  border: 'rgba(74,222,128,0.2)' },
    warning: { bg: C.amberLow,  text: C.amber,  border: 'rgba(251,191,36,0.2)' },
    danger:  { bg: C.redLow,    text: C.red,    border: 'rgba(248,113,113,0.2)' },
    violet:  { bg: C.violetLow, text: C.violet, border: 'rgba(167,139,250,0.2)' },
  };
  const bs = badgeStyles[badgeVariant] || badgeStyles.info;
  return (
    <div style={{ padding: '20px 24px 18px', borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
        <div style={{ width: 40, height: 40, borderRadius: 12, background: `${color}12`, border: `1px solid ${color}25`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
          <Icon style={{ width: 17, height: 17, color }} />
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: C.text, letterSpacing: '-0.01em' }}>{title}</h3>
            {badge && (
              <span style={{ fontSize: 10.5, fontWeight: 700, padding: '2px 9px', borderRadius: 20, letterSpacing: '0.06em', textTransform: 'uppercase', background: bs.bg, color: bs.text, border: `1px solid ${bs.border}` }}>
                {badge}
              </span>
            )}
          </div>
          {desc && <p style={{ margin: '4px 0 0', fontSize: 12, color: C.textMid, lineHeight: 1.5 }}>{desc}</p>}
        </div>
      </div>
      {actions && <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>{actions}</div>}
    </div>
  );
}

function CardBody({ children, style = {} }) {
  return <div style={{ padding: '22px 24px', ...style }}>{children}</div>;
}

// ─── Save Button ──────────────────────────────────────────────────────────────────
function SaveButton({ loading, disabled, label = 'Save Changes', icon: Icon = Save }) {
  return (
    <button
      type="submit"
      disabled={loading || disabled}
      style={{
        padding: '11px 28px',
        borderRadius: 12,
        fontSize: 13,
        fontWeight: 700,
        cursor: loading || disabled ? 'not-allowed' : 'pointer',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        background: loading || disabled ? C.surface3 : 'linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%)',
        border: `1px solid ${loading || disabled ? C.border2 : 'transparent'}`,
        color: loading || disabled ? C.textDim : '#fff',
        boxShadow: loading || disabled ? 'none' : '0 4px 20px rgba(56,189,248,0.25)',
        transition: 'all 0.2s',
        fontFamily: FONT,
        letterSpacing: '-0.01em',
      }}
    >
      {loading ? <><Loader2 style={{ width: 14, height: 14, animation: 'spin 0.8s linear infinite' }} />Saving…</> : <><Icon style={{ width: 14, height: 14 }} />{label}</>}
    </button>
  );
}

// ─── Icon Button ──────────────────────────────────────────────────────────────────
function IconBtn({ icon: Icon, onClick, title, color = C.textMid, danger }) {
  const [hov, setHov] = useState(false);
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        width: 30, height: 30, borderRadius: 8,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: hov ? (danger ? C.redLow : C.surface3) : 'transparent',
        border: `1px solid ${hov ? (danger ? 'rgba(248,113,113,0.2)' : C.border2) : 'transparent'}`,
        cursor: 'pointer', transition: 'all 0.15s', flexShrink: 0,
      }}
    >
      <Icon style={{ width: 14, height: 14, color: hov && danger ? C.red : color }} />
    </button>
  );
}

// ─── Status Dot ───────────────────────────────────────────────────────────────────
function StatusDot({ active, label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
      <div style={{ width: 7, height: 7, borderRadius: '50%', background: active ? C.green : C.textFaint, boxShadow: active ? `0 0 0 3px ${C.greenLow}` : 'none', flexShrink: 0 }} />
      <span style={{ fontSize: 12, color: active ? C.green : C.textDim, fontWeight: 600 }}>{label}</span>
    </div>
  );
}

// ─── Sidebar ─────────────────────────────────────────────────────────────────────
function Sidebar({ active, setActive }) {
  return (
    <aside style={{
      width: 240, flexShrink: 0, height: '100vh', position: 'sticky', top: 0,
      display: 'flex', flexDirection: 'column',
      background: `linear-gradient(180deg, #040810 0%, ${C.bgAlt} 100%)`,
      borderRight: `1px solid ${C.border}`,
    }}>
      {/* Logo */}
      <div style={{ padding: '24px 20px', borderBottom: `1px solid ${C.border}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 38, height: 38, borderRadius: 12, background: C.skyLow, border: `1px solid ${C.skyBorder}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <ShieldAlert style={{ width: 17, height: 17, color: C.sky }} />
          </div>
          <div>
            <p style={{ margin: 0, fontSize: 13.5, fontWeight: 800, color: C.text, letterSpacing: '-0.02em' }}>Admin</p>
            <p style={{ margin: 0, fontSize: 10, color: C.textFaint, letterSpacing: '0.12em', textTransform: 'uppercase', marginTop: 2 }}>Control Centre</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '14px 12px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 22 }}>
        {GROUPS.map(group => (
          <div key={group}>
            <p style={{ margin: '0 0 8px 8px', fontSize: 10, color: C.textFaint, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 700 }}>{group}</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {NAV.filter(n => n.group === group).map(item => {
                const Icon = item.icon;
                const isActive = active === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActive(item.id)}
                    style={{
                      width: '100%', display: 'flex', alignItems: 'center', gap: 10,
                      padding: '9px 10px', borderRadius: 11,
                      border: `1px solid ${isActive ? `${item.color}25` : 'transparent'}`,
                      background: isActive ? `${item.color}08` : 'transparent',
                      cursor: 'pointer', textAlign: 'left', fontFamily: FONT,
                      transition: 'all 0.15s',
                    }}
                    onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = 'rgba(255,255,255,0.035)'; }}
                    onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; }}
                  >
                    <div style={{
                      width: 28, height: 28, borderRadius: 8,
                      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                      background: isActive ? `${item.color}15` : 'transparent',
                    }}>
                      <Icon style={{ width: 14, height: 14, color: isActive ? item.color : C.textFaint }} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: isActive ? C.text : C.textMid, lineHeight: 1.3 }}>{item.label}</p>
                      <p style={{ margin: 0, fontSize: 10.5, color: C.textFaint, marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.desc}</p>
                    </div>
                    {isActive && (
                      <div style={{ width: 4, height: 4, borderRadius: '50%', background: item.color, flexShrink: 0 }} />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Bottom links */}
      <div style={{ padding: '12px', borderTop: `1px solid ${C.border}` }}>
        {[
          { to: '/', icon: Home, label: 'Back to Home', color: C.sky },
          { to: '/TCM', icon: CloudLightning, label: 'TCM View', color: C.violet }
        ].map(({ to, icon: Icon, label, color }) => (
          <Link
            key={to} to={to}
            style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 10px', borderRadius: 10, color: C.textDim, textDecoration: 'none', transition: 'all 0.15s', marginBottom: 2 }}
            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; e.currentTarget.style.color = C.text; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = C.textDim; }}
          >
            <Icon style={{ width: 14, height: 14, color }} />
            <span style={{ fontSize: 12.5, fontWeight: 500 }}>{label}</span>
          </Link>
        ))}
      </div>
    </aside>
  );
}

// ─── Mobile Nav ──────────────────────────────────────────────────────────────────
function MobileNav({ active, setActive }) {
  const [open, setOpen] = useState(false);
  const cur = NAV.find(n => n.id === active);
  const Icon = cur?.icon ?? Settings;
  return (
    <>
      <header className="lg:hidden sticky top-0 z-40 flex items-center gap-3 px-4 h-14"
        style={{ background: 'rgba(5,9,15,0.95)', backdropFilter: 'blur(16px)', borderBottom: `1px solid ${C.border}` }}>
        <button onClick={() => setOpen(true)} style={{ padding: 7, borderRadius: 9, background: C.skyLow, border: `1px solid ${C.skyBorder}` }}>
          <MenuIcon style={{ width: 15, height: 15, color: C.sky }} />
        </button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Icon style={{ width: 14, height: 14, color: cur?.color ?? C.sky }} />
          <span style={{ fontSize: 13.5, fontWeight: 700, color: C.text }}>{cur?.label}</span>
        </div>
      </header>
      <AnimatePresence>
        {open && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 50, background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(6px)' }} />
            <motion.div initial={{ x: -260 }} animate={{ x: 0 }} exit={{ x: -260 }} transition={{ type: 'spring', stiffness: 320, damping: 32 }}
              style={{ position: 'fixed', left: 0, top: 0, height: '100%', width: 260, zIndex: 51, background: C.bgAlt, borderRight: `1px solid ${C.border}`, overflowY: 'auto' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px', borderBottom: `1px solid ${C.border}` }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <ShieldAlert style={{ width: 16, height: 16, color: C.sky }} />
                  <span style={{ fontSize: 13.5, fontWeight: 700, color: C.text }}>Admin Panel</span>
                </div>
                <button onClick={() => setOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.textMid }}>
                  <X style={{ width: 14, height: 14 }} />
                </button>
              </div>
              <nav style={{ padding: '14px 12px' }}>
                {GROUPS.map(group => (
                  <div key={group} style={{ marginBottom: 22 }}>
                    <p style={{ margin: '0 0 8px 8px', fontSize: 10, color: C.textFaint, letterSpacing: '0.14em', textTransform: 'uppercase', fontWeight: 700 }}>{group}</p>
                    {NAV.filter(n => n.group === group).map(item => {
                      const II = item.icon;
                      const isActive = active === item.id;
                      return (
                        <button key={item.id} onClick={() => { setActive(item.id); setOpen(false); }}
                          style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '9px 10px', borderRadius: 11, border: `1px solid ${isActive ? `${item.color}25` : 'transparent'}`, background: isActive ? `${item.color}08` : 'transparent', cursor: 'pointer', textAlign: 'left', fontFamily: FONT, marginBottom: 2 }}>
                          <II style={{ width: 14, height: 14, color: isActive ? item.color : C.textFaint }} />
                          <span style={{ fontSize: 13, fontWeight: 600, color: isActive ? C.text : C.textMid }}>{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                ))}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

// ─── Page Header ──────────────────────────────────────────────────────────────────
function PageHeader({ tab }) {
  const item = NAV.find(n => n.id === tab);
  const Icon = item?.icon ?? Settings;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 28 }}>
      <div style={{ width: 44, height: 44, borderRadius: 13, background: `${item?.color ?? C.sky}10`, border: `1px solid ${item?.color ?? C.sky}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon style={{ width: 18, height: 18, color: item?.color ?? C.sky }} />
      </div>
      <div>
        <h1 style={{ margin: 0, fontSize: 20, fontWeight: 800, color: C.text, letterSpacing: '-0.03em', lineHeight: 1.2 }}>{item?.label}</h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 4 }}>
          <span style={{ fontSize: 11.5, color: C.textFaint }}>Admin</span>
          <ChevronRight style={{ width: 10, height: 10, color: C.textFaint }} />
          <span style={{ fontSize: 11.5, color: C.textMid }}>{item?.label}</span>
          {item?.desc && (
            <><ChevronRight style={{ width: 10, height: 10, color: C.textFaint }} />
            <span style={{ fontSize: 11.5, color: C.textFaint }}>{item.desc}</span></>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Divider ──────────────────────────────────────────────────────────────────────
function Divider({ label }) {
  if (!label) return <div style={{ height: 1, background: C.border, margin: '4px 0' }} />;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '8px 0' }}>
      <div style={{ flex: 1, height: 1, background: C.border }} />
      <span style={{ fontSize: 10.5, color: C.textFaint, letterSpacing: '0.1em', textTransform: 'uppercase', fontWeight: 600 }}>{label}</span>
      <div style={{ flex: 1, height: 1, background: C.border }} />
    </div>
  );
}

// ─── Info Banner ──────────────────────────────────────────────────────────────────
function InfoBanner({ icon: Icon = Info, children, variant = 'info' }) {
  const variants = {
    info:    { bg: C.skyLow,    border: C.skyBorder,              color: C.sky,   iconColor: C.sky },
    warning: { bg: C.amberLow,  border: 'rgba(251,191,36,0.2)',   color: C.amber, iconColor: C.amber },
    danger:  { bg: C.redLow,    border: 'rgba(248,113,113,0.2)',  color: C.red,   iconColor: C.red },
    success: { bg: C.greenLow,  border: 'rgba(74,222,128,0.2)',   color: C.green, iconColor: C.green },
  };
  const v = variants[variant];
  return (
    <div style={{ display: 'flex', gap: 10, padding: '12px 16px', borderRadius: 10, background: v.bg, border: `1px solid ${v.border}` }}>
      <Icon style={{ width: 14, height: 14, color: v.iconColor, flexShrink: 0, marginTop: 1 }} />
      <p style={{ margin: 0, fontSize: 12, color: v.color, lineHeight: 1.6 }}>{children}</p>
    </div>
  );
}

// ─── Image Upload Slot ────────────────────────────────────────────────────────────
function ImageSlot({ label, hint, url, uploading, onUpload, onClear, size = 80, aspect }) {
  const [hov, setHov] = useState(false);
  return (
    <Field label={label} hint={hint}>
      {url ? (
        <div style={{ position: 'relative', display: 'inline-flex', borderRadius: 12, overflow: 'visible' }}>
          <img src={url} alt={label} style={{ width: aspect ? 'auto' : size, height: size, aspectRatio: aspect, objectFit: 'cover', borderRadius: 12, border: `1px solid ${C.border2}`, display: 'block' }} />
          <button type="button" onClick={onClear}
            style={{ position: 'absolute', top: -8, right: -8, width: 24, height: 24, borderRadius: '50%', background: '#dc2626', border: `2px solid ${C.bg}`, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <X style={{ width: 10, height: 10, color: '#fff', strokeWidth: 3 }} />
          </button>
        </div>
      ) : (
        <label
          onMouseEnter={() => setHov(true)}
          onMouseLeave={() => setHov(false)}
          style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6,
            width: aspect ? '100%' : size, height: size, aspectRatio: aspect,
            border: `1.5px dashed ${hov ? C.skyBorder : C.border2}`,
            borderRadius: 12,
            background: hov ? C.skyLow : 'transparent',
            cursor: uploading ? 'not-allowed' : 'pointer',
            transition: 'all 0.2s',
          }}
        >
          {uploading
            ? <Loader2 style={{ width: 16, height: 16, color: C.sky, animation: 'spin 0.8s linear infinite' }} />
            : <>
                <Upload style={{ width: 16, height: 16, color: hov ? C.sky : C.textFaint }} />
                <span style={{ fontSize: 10.5, color: hov ? C.sky : C.textFaint, fontWeight: 600 }}>Upload</span>
              </>}
          <input type="file" style={{ display: 'none' }} accept="image/*" onChange={onUpload} disabled={uploading} />
        </label>
      )}
    </Field>
  );
}

// ─── Stat Chip ────────────────────────────────────────────────────────────────────
function StatChip({ emoji, label, value, color }) {
  return (
    <div style={{ padding: '14px 16px', borderRadius: 12, background: C.surface2, border: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <span style={{ fontSize: 16 }}>{emoji}</span>
        <span style={{ fontSize: 11, fontWeight: 700, color: color || C.textFaint, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{label}</span>
      </div>
      <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: C.text }}>{value}</p>
    </div>
  );
}

// ─── General Tab ─────────────────────────────────────────────────────────────────
function GeneralTab({ formData, setFormData, saveMutation, handleImageUpload, uploadingLogo, uploadingBanner, setPreviewAnimTier }) {
  const SOCIALS = [
    { key: 'twitter_url',   label: 'Twitter / X',  icon: Twitter,       placeholder: 'https://twitter.com/yourhandle',   color: '#1d9bf0' },
    { key: 'facebook_url',  label: 'Facebook',     icon: Facebook,      placeholder: 'https://facebook.com/yourpage',    color: '#1877f2' },
    { key: 'instagram_url', label: 'Instagram',    icon: Instagram,     placeholder: 'https://instagram.com/yourhandle', color: '#e1306c' },
    { key: 'youtube_url',   label: 'YouTube',      icon: Youtube,       placeholder: 'https://youtube.com/yourchannel',  color: '#ff0000' },
    { key: 'discord_url',   label: 'Discord',      icon: MessageCircle, placeholder: 'https://discord.gg/yourserver',    color: '#5865f2' },
  ];

  const TIERS = [
    { id: 'lite',      label: 'Lite',      color: '#60a5fa' },
    { id: 'pro',       label: 'Pro',       color: '#a78bfa' },
    { id: 'elite',     label: 'Elite',     color: '#fbbf24' },
    { id: 'developer', label: 'Dev',       color: '#34d399' },
  ];

  const charCount = formData.description?.length || 0;

  return (
    <form onSubmit={e => { e.preventDefault(); saveMutation.mutate(formData); }} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Branding */}
      <Card glow={C.sky}>
        <CardHeader icon={Palette} color={C.sky} title="Branding" desc="Define your site's identity, logo, and version string" />
        <CardBody>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 150px', gap: 14 }}>
              <Field label="Site Name" required hint="This appears in the browser tab and metadata">
                <StyledInput
                  placeholder="MyWeatherUK"
                  value={formData.site_name}
                  onChange={e => setFormData(p => ({ ...p, site_name: e.target.value }))}
                  required
                />
              </Field>
              <Field label="Version Tag" hint="e.g. v2.1.0">
                <StyledInput
                  placeholder="v1.0.0"
                  value={formData.version}
                  onChange={e => setFormData(p => ({ ...p, version: e.target.value }))}
                />
              </Field>
            </div>

            <Field label="Description / Tagline" hint={`${charCount}/160 characters · Shown in meta tags and headers`}>
              <div style={{ position: 'relative' }}>
                <StyledTextarea
                  rows={2}
                  placeholder="Your trusted source for UK weather warnings and live alerts."
                  value={formData.description}
                  onChange={e => setFormData(p => ({ ...p, description: e.target.value }))}
                  maxLength={160}
                />
                <span style={{ position: 'absolute', bottom: 10, right: 12, fontSize: 10.5, color: charCount > 140 ? C.amber : C.textFaint, fontWeight: 600 }}>{charCount}/160</span>
              </div>
            </Field>

            <Divider label="Media Assets" />

            <div style={{ display: 'grid', gridTemplateColumns: '92px 1fr', gap: 20, alignItems: 'start' }}>
              <ImageSlot
                label="Logo"
                hint="Square, min 256×256"
                url={formData.logo_url}
                uploading={uploadingLogo}
                onUpload={e => handleImageUpload(e, 'logo')}
                onClear={() => setFormData(p => ({ ...p, logo_url: '' }))}
                size={92}
              />
              <ImageSlot
                label="Banner Image"
                hint="Recommended 1280×400px"
                url={formData.banner_url}
                uploading={uploadingBanner}
                onUpload={e => handleImageUpload(e, 'banner')}
                onClear={() => setFormData(p => ({ ...p, banner_url: '' }))}
                size={92}
                aspect="16/5"
              />
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Social */}
      <Card glow="#34d399">
        <CardHeader icon={Share2} color="#34d399" title="Social Media Links" desc="Connect your community channels for display in the site footer and profile" />
        <CardBody>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {SOCIALS.map(s => {
              const SIcon = s.icon;
              return (
                <Field key={s.key} label={s.label}>
                  <StyledInput
                    prefix={<SIcon style={{ width: 13, height: 13, color: s.color }} />}
                    placeholder={s.placeholder}
                    value={formData[s.key] || ''}
                    onChange={e => setFormData(p => ({ ...p, [s.key]: e.target.value }))}
                  />
                </Field>
              );
            })}
          </div>
        </CardBody>
      </Card>

      {/* Subscription Animation Preview */}
      <Card glow={C.violet}>
        <CardHeader icon={Zap} color={C.violet} title="Subscription Animations" desc="Preview the upgrade celebration animations by tier" />
        <CardBody>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {TIERS.map(tier => (
              <button
                key={tier.id}
                type="button"
                onClick={() => setPreviewAnimTier(tier.id)}
                style={{
                  padding: '10px 20px', borderRadius: 10, fontSize: 13, fontWeight: 700,
                  cursor: 'pointer', fontFamily: FONT,
                  background: `${tier.color}10`,
                  border: `1px solid ${tier.color}28`,
                  color: tier.color,
                  transition: 'all 0.15s',
                  display: 'flex', alignItems: 'center', gap: 7,
                }}
                onMouseEnter={e => { e.currentTarget.style.background = `${tier.color}20`; e.currentTarget.style.transform = 'translateY(-1px)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = `${tier.color}10`; e.currentTarget.style.transform = 'none'; }}
              >
                <Zap style={{ width: 13, height: 13 }} />
                {tier.label}
              </button>
            ))}
          </div>
          <p style={{ margin: '14px 0 0', fontSize: 12, color: C.textFaint }}>Click any tier to preview the full-screen animation overlay.</p>
        </CardBody>
      </Card>

      <div style={{ display: 'flex', justifyContent: 'flex-end', paddingTop: 4 }}>
        <SaveButton loading={saveMutation.isPending} disabled={!formData.site_name} />
      </div>
    </form>
  );
}

// ─── Site Control Tab ─────────────────────────────────────────────────────────────
function SiteControlTab() {
  const queryClient = useQueryClient();
  const [stormTitle, setStormTitle] = useState('');
  const [stormMsg, setStormMsg] = useState('');
  const [sunnyTitle, setSunnyTitle] = useState('');
  const [sunnyMsg, setSunnyMsg] = useState('');
  const [siteDisabled, setSiteDisabled] = useState(false);
  const [countdownEnabled, setCountdownEnabled] = useState(false);
  const [countdownTarget, setCountdownTarget] = useState('');
  const [countdownTitle, setCountdownTitle] = useState('');
  const [countdownDesc, setCountdownDesc] = useState('');
  const [saving, setSaving] = useState(false);
  const [settingsId, setSettingsId] = useState(null);

  const { data: existingSettings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => { const list = await db.entities.SiteSettings.list(); return list[0] || null; },
  });

  useEffect(() => {
    if (!existingSettings) return;
    setSettingsId(existingSettings.id);
    setSiteDisabled(existingSettings.site_disabled || false);
    setCountdownEnabled(existingSettings.countdown_enabled || false);
    setCountdownTarget(existingSettings.countdown_target || '');
    setCountdownTitle(existingSettings.countdown_title || '');
    setCountdownDesc(existingSettings.countdown_description || '');
    try {
      if (existingSettings.storm_text) { const p = JSON.parse(existingSettings.storm_text); setStormTitle(p.title || ''); setStormMsg(p.message || ''); }
      if (existingSettings.sunny_text) { const p = JSON.parse(existingSettings.sunny_text); setSunnyTitle(p.title || ''); setSunnyMsg(p.message || ''); }
    } catch {}
  }, [existingSettings]);

  const handleSave = async (e) => {
    e.preventDefault(); setSaving(true);
    try {
      const payload = {
        site_disabled: siteDisabled,
        countdown_enabled: countdownEnabled,
        countdown_target: countdownTarget,
        countdown_title: countdownTitle,
        countdown_description: countdownDesc,
        storm_text: JSON.stringify({ title: stormTitle, message: stormMsg }),
        sunny_text: JSON.stringify({ title: sunnyTitle, message: sunnyMsg }),
      };
      if (settingsId) await db.entities.SiteSettings.update(settingsId, payload);
      else await db.entities.SiteSettings.create(payload);
      queryClient.invalidateQueries({ queryKey: ['settings'] });
      toast.success('Site settings saved');
    } catch { toast.error('Failed to save'); }
    setSaving(false);
  };

  const PHASES = [
    { label: '⛈ Storm',    dur: '40s', color: '#818cf8', bg: 'rgba(129,140,248,0.08)' },
    { label: '🌦 Clearing', dur: '40s', color: '#60a5fa', bg: 'rgba(96,165,250,0.08)' },
    { label: '☀ Sunny',    dur: '40s', color: C.amber,   bg: C.amberLow },
    { label: '🌥 Clouding', dur: '40s', color: C.textMid, bg: C.surface2 },
  ];

  return (
    <form onSubmit={handleSave} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      {/* Site Status */}
      <Card glow={siteDisabled ? C.red : C.green}>
        <CardHeader
          icon={Activity}
          color={siteDisabled ? C.red : C.green}
          title="Site Status"
          desc="Control whether visitors can access the live site"
          badge={siteDisabled ? 'Offline' : 'Live'}
          badgeVariant={siteDisabled ? 'danger' : 'success'}
          actions={<StatusDot active={!siteDisabled} label={siteDisabled ? 'Offline' : 'Online'} />}
        />
        <CardBody>
          {siteDisabled && (
            <div style={{ marginBottom: 18 }}>
              <InfoBanner icon={AlertTriangle} variant="warning">
                Site is currently in maintenance mode. All visitors are seeing the coming soon page.
              </InfoBanner>
            </div>
          )}
          <div>
            <Toggle
              checked={siteDisabled}
              onChange={setSiteDisabled}
              label="Maintenance Mode"
              desc="Redirect all visitors to a coming soon / maintenance page"
              danger
            />
            <Toggle
              checked={countdownEnabled}
              onChange={setCountdownEnabled}
              label="Show Countdown Timer"
              desc="Display a countdown clock on the maintenance page"
            />
          </div>

          <AnimatePresence>
            {countdownEnabled && (
              <motion.div
                initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.2 }}
                style={{ overflow: 'hidden' }}
              >
                <div style={{ paddingTop: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
                  <Divider label="Countdown Configuration" />
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                    <Field label="Target Date & Time" hint="Countdown ends at this moment">
                      <StyledInput type="datetime-local" value={countdownTarget} onChange={e => setCountdownTarget(e.target.value)} />
                    </Field>
                    <Field label="Headline" hint="Shown above the timer">
                      <StyledInput placeholder="Launching soon…" value={countdownTitle} onChange={e => setCountdownTitle(e.target.value)} />
                    </Field>
                  </div>
                  <Field label="Supporting Description">
                    <StyledInput placeholder="Something big is coming. Stay tuned." value={countdownDesc} onChange={e => setCountdownDesc(e.target.value)} />
                  </Field>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardBody>
      </Card>

      {/* Weather Phase Text */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
        {/* Storm */}
        <Card>
          <CardHeader icon={CloudRain} color="#818cf8" title="Storm Phase Text" desc="Content displayed during storm / TCM mode" badge="⛈ Thunder" badgeVariant="violet" />
          <CardBody>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <Field label="Headline">
                <StyledInput placeholder="TCM Storm Centre" value={stormTitle} onChange={e => setStormTitle(e.target.value)} />
              </Field>
              <Field label="Description">
                <StyledTextarea rows={2} placeholder="Professional storm chasing and severe weather tracking across the UK." value={stormMsg} onChange={e => setStormMsg(e.target.value)} />
              </Field>
              {(stormTitle || stormMsg) && (
                <div style={{ padding: '12px 14px', borderRadius: 10, background: 'rgba(129,140,248,0.06)', border: '1px solid rgba(129,140,248,0.15)' }}>
                  <p style={{ margin: '0 0 2px', fontSize: 10, color: 'rgba(129,140,248,0.5)', letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 700 }}>Preview</p>
                  <p style={{ margin: '0 0 4px', fontSize: 13.5, fontWeight: 700, color: C.text }}>{stormTitle || 'TCM Storm Centre'}</p>
                  <p style={{ margin: 0, fontSize: 12, color: C.textMid, lineHeight: 1.6 }}>{stormMsg || 'Description…'}</p>
                </div>
              )}
            </div>
          </CardBody>
        </Card>

        {/* Sunny */}
        <Card>
          <CardHeader icon={Sun} color={C.amber} title="Sunny Phase Text" desc="Content displayed during clear / sunny weather mode" badge="☀ Clear" badgeVariant="warning" />
          <CardBody>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <Field label="Headline">
                <StyledInput placeholder="MyWeatherUK" value={sunnyTitle} onChange={e => setSunnyTitle(e.target.value)} />
              </Field>
              <Field label="Description">
                <StyledTextarea rows={2} placeholder="Your trusted source for UK weather forecasts and alerts." value={sunnyMsg} onChange={e => setSunnyMsg(e.target.value)} />
              </Field>
              {(sunnyTitle || sunnyMsg) && (
                <div style={{ padding: '12px 14px', borderRadius: 10, background: 'rgba(251,191,36,0.06)', border: '1px solid rgba(251,191,36,0.15)' }}>
                  <p style={{ margin: '0 0 2px', fontSize: 10, color: 'rgba(251,191,36,0.5)', letterSpacing: '0.08em', textTransform: 'uppercase', fontWeight: 700 }}>Preview</p>
                  <p style={{ margin: '0 0 4px', fontSize: 13.5, fontWeight: 700, color: C.text }}>{sunnyTitle || 'MyWeatherUK'}</p>
                  <p style={{ margin: 0, fontSize: 12, color: C.textMid, lineHeight: 1.6 }}>{sunnyMsg || 'Description…'}</p>
                </div>
              )}
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Cycle Info */}
      <Card>
        <CardHeader icon={Clock} color={C.textMid} title="Weather Cycle" desc="Automatic phase durations — read only" />
        <CardBody style={{ paddingTop: 16, paddingBottom: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10 }}>
            {PHASES.map(({ label, dur, color, bg }) => (
              <div key={label} style={{ padding: '12px 14px', borderRadius: 12, background: bg, border: `1px solid ${color}20`, display: 'flex', flexDirection: 'column', gap: 5 }}>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color }}>{label}</p>
                <p style={{ margin: 0, fontSize: 10.5, color: C.textFaint, letterSpacing: '0.04em' }}>{dur} · auto</p>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <SaveButton loading={saving} />
      </div>
    </form>
  );
}

// ─── Placeholder Tab ──────────────────────────────────────────────────────────────
function PlaceholderTab({ id }) {
  const componentMap = {
    warnings: { label: 'Manual Warnings', icon: AlertTriangle, color: C.amber,  comp: 'ManualWarningsAdmin' },
    publish:  { label: 'Publish',          icon: Zap,           color: C.violet, comp: 'PublishFeatureManager' },
    access:   { label: 'Access',           icon: Lock,          color: '#34d399',comp: 'AccessRequestPanel + InvitationLinkGenerator' },
    tcm:      { label: 'TCM',              icon: CloudLightning,color: '#60a5fa',comp: 'TCMAdmin' },
    menu:     { label: 'Menu Lock',        icon: Shield,        color: C.violet, comp: 'MenuItemsAdmin' },
    announce: { label: 'Announcements',    icon: Megaphone,     color: C.sky,    comp: 'AnnouncementsAdmin' },
  };
  const info = componentMap[id] || { label: id, icon: Settings, color: C.sky, comp: id };
  const Icon = info.icon;
  return (
    <Card>
      <CardBody style={{ padding: '60px 40px', textAlign: 'center' }}>
        <div style={{ width: 56, height: 56, borderRadius: 16, background: `${info.color}10`, border: `1px solid ${info.color}25`, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 18px' }}>
          <Icon style={{ width: 22, height: 22, color: info.color }} />
        </div>
        <p style={{ margin: '0 0 8px', fontSize: 16, fontWeight: 700, color: C.text }}>{info.label}</p>
        <p style={{ margin: '0 0 20px', fontSize: 13, color: C.textMid, lineHeight: 1.6 }}>
          This section renders the <code style={{ fontFamily: 'monospace', fontSize: 12, padding: '2px 6px', background: C.surface2, borderRadius: 6, color: C.sky }}>{info.comp}</code> component.
        </p>
        <InfoBanner>Connect your imported component here. The slot is ready.</InfoBanner>
      </CardBody>
    </Card>
  );
}

// ─── Main Export ──────────────────────────────────────────────────────────────────
export default function AdminSettings() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('general');
  const [formData, setFormData] = useState({
    site_name: '', description: '', logo_url: '', banner_url: '', version: '',
    twitter_url: '', facebook_url: '', instagram_url: '', youtube_url: '', discord_url: '',
  });
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const [previewAnimTier, setPreviewAnimTier] = useState(null);

  const { data: existingSettings, isLoading } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => { const list = await db.entities.SiteSettings.list(); return list[0] || null; },
  });

  useEffect(() => {
    if (!existingSettings) return;
    setFormData({
      site_name: existingSettings.site_name || '',
      description: existingSettings.description || '',
      logo_url: existingSettings.logo_url || '',
      banner_url: existingSettings.banner_url || '',
      version: existingSettings.version || '',
      twitter_url: existingSettings.twitter_url || '',
      facebook_url: existingSettings.facebook_url || '',
      instagram_url: existingSettings.instagram_url || '',
      youtube_url: existingSettings.youtube_url || '',
      discord_url: existingSettings.discord_url || '',
    });
  }, [existingSettings]);

  const saveMutation = useMutation({
    mutationFn: async (data) =>
      existingSettings
        ? db.entities.SiteSettings.update(existingSettings.id, data)
        : db.entities.SiteSettings.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['settings'] }); toast.success('Settings saved successfully'); },
    onError: () => toast.error('Failed to save settings'),
  });

  const handleImageUpload = async (e, type) => {
    const file = e.target.files[0]; if (!file) return;
    if (type === 'logo') setUploadingLogo(true); else setUploadingBanner(true);
    try {
      const { file_url } = await db.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, [`${type}_url`]: file_url }));
    } finally {
      if (type === 'logo') setUploadingLogo(false); else setUploadingBanner(false);
    }
  };

  const tabContent = {
    general:  <GeneralTab formData={formData} setFormData={setFormData} saveMutation={saveMutation} handleImageUpload={handleImageUpload} uploadingLogo={uploadingLogo} uploadingBanner={uploadingBanner} setPreviewAnimTier={setPreviewAnimTier} />,
    site:     <SiteControlTab />,
    warnings: <PlaceholderTab id="warnings" />,
    publish:  <PlaceholderTab id="publish" />,
    access:   <PlaceholderTab id="access" />,
    tcm:      <PlaceholderTab id="tcm" />,
    menu:     <PlaceholderTab id="menu" />,
    announce: <PlaceholderTab id="announce" />,
  };

  if (isLoading) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: C.bg, fontFamily: FONT }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
        <div style={{ width: 52, height: 52, borderRadius: 16, background: C.skyLow, border: `1px solid ${C.skyBorder}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Loader2 style={{ width: 22, height: 22, color: C.sky, animation: 'spin 0.8s linear infinite' }} />
        </div>
        <p style={{ fontSize: 13, color: C.textMid, margin: 0, fontWeight: 500 }}>Loading admin panel…</p>
      </div>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', display: 'flex', background: C.bg, fontFamily: FONT }}>
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(148,163,184,0.15); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(148,163,184,0.3); }
        select option { background: #0c1422; color: #f1f5f9; }
      `}</style>

      {/* Ambient background */}
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', background: 'radial-gradient(ellipse 100% 60% at 15% -5%, rgba(56,189,248,0.045) 0%, transparent 55%), radial-gradient(ellipse 70% 50% at 85% 105%, rgba(167,139,250,0.03) 0%, transparent 55%)' }} />

      {/* Desktop Sidebar */}
      <div className="hidden lg:flex">
        <Sidebar active={activeTab} setActive={setActiveTab} />
      </div>

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' }}>
        <MobileNav active={activeTab} setActive={setActiveTab} />
        <main style={{ flex: 1, overflowY: 'auto' }}>
          <div style={{ maxWidth: 820, margin: '0 auto', padding: '36px 28px 60px' }}>
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18, ease: [0.4, 0, 0.2, 1] }}
              >
                <PageHeader tab={activeTab} />
                {tabContent[activeTab]}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Subscription animation overlay */}
      {previewAnimTier && (
        <SubscriptionAnimation
          tier={previewAnimTier}
          planName={previewAnimTier.charAt(0).toUpperCase() + previewAnimTier.slice(1)}
          onClose={() => setPreviewAnimTier(null)}
        />
      )}
    </div>
  );
}