import React, { useState, useEffect, useMemo, useRef, useCallback, createContext, useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Menu, X, AlertTriangle, Clock, Home, ShieldAlert, CloudLightning, ChevronRight, ChevronDown,
  Wind, Zap, CloudRain, Activity, Play, Pause, RefreshCw, MapPin, Info, Layers, Loader2,
  Sun, Moon, Database, Radio, Thermometer, Droplets, ArrowUp, BarChart2, Eye, Navigation,
  TrendingUp, TrendingDown, Minus, AlertCircle, CheckCircle, CloudSnow, Tornado, Map as MapIcon
} from 'lucide-react';

import TCMApiStatus from '@/components/tcm/TCMApiStatus';
import TCMLeafletBase from '@/components/tcm/TCMLeafletBase';
import useBlitzortung from '@/components/tcm/useBlitzortung';
import DiurnalTimingSection from '@/components/tcm/DiurnalTimingSection';
import { RISK_META, RISK_INDEX, LEVEL_RANGE, LEVEL_OPACITY, scoreToLevel, fmtRange, MIN_SCORE_PER_LEVEL, RISK_COLOR, RISK_FILL, RISK_BORDER, descFor } from '@/components/tcm/riskConfig';
import { fetchOpenMeteoTCM } from '@/lib/openMeteoTCM';
import { fetchAIForecastFallback } from '@/lib/aiForecastFallback';
import { verifyForecastWithAI } from '@/lib/tcmAIVerifier';
import AIAuthCard from '@/components/tcm/AIAuthCard';
import { isFetchDue, setLastFetch, getLastFetch, msUntilNextFetch, formatRemaining, isCurrentUserAdmin } from '@/lib/tcmFetchPolicy';
import { smoothBlobPath } from '@/components/tcm/smoothBlobPath';
import { isInUKIreland } from '@/components/tcm/ukIrelandMask';
import { seedUKStrikesOnce } from '@/lib/seedUKStrikes';
import { loadRunFromCache, saveRunToCache, pruneOldForecastRuns } from '@/lib/tcmForecastCache';

/* ============================================================================
   TCM — Thunderstorm Convection Model
   ============================================================================ */

const HOURS_PER_STEP = 3;
const STEPS_PER_DAY = 8;
const TOTAL_STEPS = 32;
const RUN_CACHE_VERSION = 'v13_dayvar_ai';

const REGIONS = {
  uk: { id:'uk', label:'UK & Ireland', flag:'🇬🇧', bbox:{ lonMin:-10.5, lonMax:2.0, latMin:50.0, latMax:60.5 }, gridStep:0.30 },
  eu: { id:'eu', label:'Europe', flag:'🇪🇺', bbox:{ lonMin:-12.0, lonMax:32.0, latMin:35.0, latMax:62.0 }, gridStep:0.55 }
};

const VIEW_MODES = [
  { id: 'outlook', label: 'Outlook', icon: Layers, desc: 'Nested risk polygons (SPC-style)' },
  { id: 'probability', label: 'Probability', icon: MapIcon, desc: 'Smooth % grid (UKMO-style)' },
  { id: 'animated', label: 'Animated', icon: Activity, desc: '3-hourly time steps' },
];

function hashStr(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}
function mulberry32(seed){return function(){let t=(seed+=0x6D2B79F5)>>>0;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
function buildBlobField(seed,n=7){const rng=mulberry32(seed);const blobs=[];for(let i=0;i<n;i++)blobs.push({x:rng(),y:rng(),r:0.12+rng()*0.35,sign:rng()<0.5?-1:1,amp:0.6+rng()*0.6});return(u,v)=>{let val=0;for(const b of blobs){const dx=u-b.x,dy=v-b.y;val+=b.amp*b.sign*Math.exp(-(dx*dx+dy*dy)/(b.r*b.r));}return val;};}

function engineScores(cape,shear,li,cin,td,tdSpread,fzLvl,precip,gust,wind,helicity01,shear01){
  const trigger=Math.max(0,1-cin/80);const moistFactor=Math.max(0,td-4)/14;const capeTerm=Math.min(1,cape/2200);
  let ts=0;if(cape>80&&tdSpread<10){const shearMod=0.7+Math.min(0.5,shear/40);ts=100*capeTerm*Math.min(1,moistFactor*1.4)*trigger*shearMod;}
  ts=Math.max(0,Math.min(100,ts));
  let hail=0;if(ts>20&&fzLvl<4500){const c=Math.min(1,Math.max(0,cape-400)/1400);const f=Math.max(0,(4500-fzLvl)/2200);const s=Math.min(1,shear/20);hail=100*c*f*s;}
  hail=Math.max(0,Math.min(100,hail));
  let tor=0;if(ts>25&&tdSpread<5&&shear01>5){const lcl=Math.max(0,(4-tdSpread)/4);const s01=Math.min(1,(shear01-5)/8);const hel=Math.min(1,helicity01/200);tor=100*lcl*s01*hel*capeTerm*0.75;}
  tor=Math.max(0,Math.min(100,tor));
  let ltg=0;if(ts>10){const ice=Math.min(1,Math.max(0,4500-fzLvl)/3000);ltg=ts*(0.7+0.3*ice);}
  ltg=Math.max(0,Math.min(100,ltg));
  const slowSteer=Math.max(0,1-shear/30);
  const flashFlood=Math.min(100,Math.max(0,(precip-3)*9*(0.5+0.6*slowSteer)));
  const strongWinds=Math.min(100,Math.max(0,(gust-22)*2.2+(tdSpread>5?capeTerm*40:0)));
  let supercell=0;if(shear>16&&cape>800)supercell=Math.min(100,((shear-16)/16)*50+(cape-800)/20+helicity01/8);
  return{thunderstorm:Math.round(ts),hail:Math.round(hail),tornado:Math.round(tor),lightning:Math.round(ltg),sub:{tornado:Math.round(tor),hail:Math.round(hail),flashFlood:Math.round(flashFlood),strongWinds:Math.round(strongWinds),supercell:Math.round(supercell)},metrics:{cape:Math.round(cape),shear:Math.round(shear*10)/10,li:Math.round(li*10)/10,gust:Math.round(gust),precip:Math.round(precip*10)/10}};
}

const runKey=(d)=>`${d.getUTCFullYear()}${(d.getUTCMonth()+1).toString().padStart(2,'0')}${d.getUTCDate().toString().padStart(2,'0')}_${d.getUTCHours().toString().padStart(2,'0')}Z`;
function utcRunForDate(d){const h=d.getUTCHours();const run=h>=18?18:h>=12?12:h>=6?6:0;const out=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate(),run));return out;}
function pastRuns(n=28){const runs=[];const now=new Date();for(let i=0;i<n;i++){const d=new Date(now.getTime()-i*6*3600_000);runs.push(utcRunForDate(d));}return runs.filter((r,i,a)=>i===0||r.getTime()!==a[i-1].getTime());}
function fmtRun(d){return`${d.getUTCDate().toString().padStart(2,'0')}/${(d.getUTCMonth()+1).toString().padStart(2,'0')} ${d.getUTCHours().toString().padStart(2,'0')}Z`;}
function stepLabel(step,run){const ms=run.getTime()+step*HOURS_PER_STEP*3600_000;const d=new Date(ms);return`${d.toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short'})} ${d.getUTCHours().toString().padStart(2,'0')}Z`;}

function pruneOldRuns(){
  try{const cutoff=Date.now()-7*86400_000;for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(!k||!k.startsWith(`tcm_${RUN_CACHE_VERSION}_`))continue;const raw=localStorage.getItem(k);if(!raw)continue;try{const d=JSON.parse(raw);if(d?.builtAt&&d.builtAt<cutoff)localStorage.removeItem(k);}catch{localStorage.removeItem(k);}}}catch{}
}

// CACHE KEY is per region only (no run timestamp) — there's only ONE active
// outlook per region at any time, refreshed strictly every 6 hours.
function tcmCacheKey(region){return `tcm_${RUN_CACHE_VERSION}_${region}_active`;}

function loadCachedTCM(region){
  try{const c=localStorage.getItem(tcmCacheKey(region));return c?JSON.parse(c):null;}catch{return null;}
}

// Tracks in-flight background refreshes so we don't start two at once.
const _bgRefreshInFlight=new Set();

async function doFetch({region,run,onProgress,fastMode}){
  const reg=REGIONS[region];
  const omStep=region==='uk'?1.0:2.0;
  const key=tcmCacheKey(region);
  let payload;
  try{
    payload=await fetchOpenMeteoTCM({
      bbox:reg.bbox,
      gridStep:omStep,
      run,
      onProgress:p=>onProgress?.(0.05+p*0.90),
      fastMode,
    });
    if(!payload?.grid?.length)throw new Error('Open-Meteo returned empty grid');
  }catch(omErr){
    console.warn('[runTCM] Open-Meteo failed, switching to AI fallback:',omErr?.message);
    payload=await fetchAIForecastFallback({
      bbox:reg.bbox,
      gridStep:omStep,
      run,
      regionLabel:reg.label,
      onProgress:p=>onProgress?.(0.05+p*0.90),
    });
  }
  payload.region=region;
  payload.run=run.toISOString();
  try{localStorage.setItem(key,JSON.stringify(payload));}catch{pruneOldRuns();try{localStorage.setItem(key,JSON.stringify(payload));}catch{}}
  onProgress?.(1);
  return payload;
}

async function runTCM({region,run,onProgress,force=false}){
  // Try the per-run cache FIRST — any run we've ever fetched for this region
  // in the past 7 days is held there. This means revisiting the page and
  // scrolling through historical runs is instant, no re-fetching.
  const perRunCached=loadRunFromCache(region,run);
  if(perRunCached && !force){
    onProgress?.(1);
    return perRunCached;
  }

  const cached=loadCachedTCM(region);

  // Admin force-refresh: fast fetch, immediate return, don't advance the
  // scheduled refresh timer.
  if(force){
    onProgress?.(0.05);
    const payload=await doFetch({region,run,onProgress,fastMode:true});
    saveRunToCache(region,run,payload);
    return payload;
  }

  // No cache exists at all → fast fetch so the user isn't waiting 90 minutes.
  if(!cached){
    onProgress?.(0.05);
    const payload=await doFetch({region,run,onProgress,fastMode:true});
    setLastFetch(region,Date.now());
    saveRunToCache(region,run,payload);
    return payload;
  }

  // Cache exists and is still fresh (<6h) → return cached.
  if(!isFetchDue(region)){
    onProgress?.(1);
    saveRunToCache(region,run,cached);
    return cached;
  }

  // Cache exists but is stale → return cached IMMEDIATELY so the user sees
  // data without waiting, and kick off a SPACED background refresh that
  // populates the next cache over ~1–2 hours.
  if(!_bgRefreshInFlight.has(region)){
    _bgRefreshInFlight.add(region);
    // Mark the timer now so we don't re-enter another background refresh
    // before this one completes.
    setLastFetch(region,Date.now());
    doFetch({region,run,onProgress:()=>{},fastMode:false})
      .then(p=>saveRunToCache(region,run,p))
      .catch(e=>console.warn('[runTCM] background refresh failed:',e?.message))
      .finally(()=>_bgRefreshInFlight.delete(region));
  }
  onProgress?.(1);
  return cached;
}

async function runTCMSynthetic({region,run,onProgress}){
  const cacheKey=`tcm_${RUN_CACHE_VERSION}_${region}_${runKey(run)}`;
  const reg=REGIONS[region];const{bbox}=reg;
  const nLon=Math.ceil((bbox.lonMax-bbox.lonMin)/reg.gridStep)+1;
  const nLat=Math.ceil((bbox.latMax-bbox.latMin)/reg.gridStep)+1;
  const baseSeed=hashStr(`${region}|${run.toISOString()}`);
  const noiseInst=[],noiseShear=[],noiseMoist=[],noiseTrigger=[];
  const dayBias=[0,1,2,3].map(d=>{const r=mulberry32(baseSeed+d*7919);const eastBias=d===1?1.35:1.0;return{cape:150+r()*1400*eastBias,shear:10+r()*22,moist:7+r()*10,fz:2500+r()*1600,wind:8+r()*16,cin:20+r()*50};});
  for(let s=0;s<TOTAL_STEPS;s++){noiseInst.push(buildBlobField(baseSeed^(s*2654435761),8));noiseShear.push(buildBlobField(baseSeed^(s*2246822519),6));noiseMoist.push(buildBlobField(baseSeed^(s*3266489917),6));noiseTrigger.push(buildBlobField(baseSeed^(s*668265263),10));}
  const grid=[];const totalCells=nLat*nLon;let cellIdx=0;
  for(let j=0;j<nLat;j++){
    const lat=bbox.latMin+j*reg.gridStep;
    for(let i=0;i<nLon;i++){
      const lon=bbox.lonMin+i*reg.gridStep;
      const u=i/(nLon-1||1),v=j/(nLat-1||1);
      const isEast=lon>-1.0;const isScotland=lat>56.5;const eastEnglandScotBias=(isEast||isScotland)?1.4:0.85;
      const perStep=[];
      for(let s=0;s<TOTAL_STEPS;s++){
        const dayIdx=Math.floor(s/STEPS_PER_DAY);const stepOfDay=s%STEPS_PER_DAY;const localHour=stepOfDay*HOURS_PER_STEP;
        const diurnal=0.45+0.6*Math.max(0,Math.cos((localHour-14)/24*2*Math.PI));
        const db=dayBias[dayIdx];const latPenalty=Math.max(0.5,1-(Math.max(0,lat-54))*0.018);
        const fInst=(noiseInst[s](u,v)+1.5)/3;const fSh=(noiseShear[s](u,v)+1.5)/3;const fMo=(noiseMoist[s](u,v)+1.5)/3;const fTr=(noiseTrigger[s](u,v)+1.5)/3;
        const dayBiasMultiplier=dayIdx===1?eastEnglandScotBias:1.0;
        const cape=Math.max(0,db.cape*fInst*diurnal*latPenalty*(0.55+fMo)*dayBiasMultiplier);
        const shear=Math.max(3,db.shear*(0.45+0.85*fSh));const shear01=Math.max(1.5,shear*(0.28+0.22*fSh));const helicity01=shear01*(50+90*fSh);
        const li=3.5-cape/200-fInst*1.8;const cin=Math.max(0,db.cin-cape*0.05-fTr*28);const td=db.moist+fMo*7-Math.max(0,lat-56)*0.35;const tdSpread=Math.max(0.5,5.5-fMo*5.5+fTr*3.5);
        const fzLvl=db.fz+fInst*500-Math.max(0,lat-50)*55;const wind=db.wind*(0.65+0.75*fSh);const trigger=Math.max(0,fTr-0.40)*2.2;const moistFactor=Math.max(0,td-4)/13;const cinSup=Math.exp(-cin/55);
        const precip=Math.max(0,(cape/1200)*trigger*moistFactor*cinSup*20);const convActive=cape>300&&fTr>0.50?1.55:1.15;const gust=(wind*convActive+Math.max(0,cape-600)*0.014)*2.237;
        perStep.push({scores:engineScores(cape,shear,li,cin,td,tdSpread,fzLvl,precip,gust,wind,helicity01,shear01)});
      }
      const perDay=[];
      for(let d=0;d<4;d++){
        const slice=perStep.slice(d*STEPS_PER_DAY,(d+1)*STEPS_PER_DAY);
        const peak={thunderstorm:0,hail:0,tornado:0,lightning:0,sub:{tornado:0,hail:0,flashFlood:0,strongWinds:0,supercell:0},metrics:{cape:0,shear:0,li:5,gust:0,precip:0}};
        for(const st of slice){peak.thunderstorm=Math.max(peak.thunderstorm,st.scores.thunderstorm);peak.hail=Math.max(peak.hail,st.scores.hail);peak.tornado=Math.max(peak.tornado,st.scores.tornado);peak.lightning=Math.max(peak.lightning,st.scores.lightning);peak.sub.tornado=Math.max(peak.sub.tornado,st.scores.sub.tornado);peak.sub.hail=Math.max(peak.sub.hail,st.scores.sub.hail);peak.sub.flashFlood=Math.max(peak.sub.flashFlood,st.scores.sub.flashFlood);peak.sub.strongWinds=Math.max(peak.sub.strongWinds,st.scores.sub.strongWinds);peak.sub.supercell=Math.max(peak.sub.supercell,st.scores.sub.supercell);peak.metrics.cape=Math.max(peak.metrics.cape,st.scores.metrics.cape);peak.metrics.shear=Math.max(peak.metrics.shear,st.scores.metrics.shear);peak.metrics.li=Math.min(peak.metrics.li,st.scores.metrics.li);peak.metrics.gust=Math.max(peak.metrics.gust,st.scores.metrics.gust);peak.metrics.precip=Math.max(peak.metrics.precip,st.scores.metrics.precip);}
        perDay.push({scores:peak});
      }
      grid.push({lat,lon,perStep,perDay});
      cellIdx++;if(cellIdx%50===0)onProgress?.(cellIdx/totalCells);
    }
    if(j%4===0)await new Promise(r=>setTimeout(r,0));
  }
  const summary=[0,1,2,3].map(d=>{
    const ts=[],hl=[],tn=[],lg=[],subT=[],subH=[],subF=[],subW=[],subS=[],capes=[],shears=[],gusts=[],precs=[];let stormyCells=0;
    for(const p of grid){const sc=p.perDay[d].scores;ts.push(sc.thunderstorm);hl.push(sc.hail);tn.push(sc.tornado);lg.push(sc.lightning);if(sc.thunderstorm>=8){stormyCells++;subT.push(sc.sub.tornado);subH.push(sc.sub.hail);subF.push(sc.sub.flashFlood);subW.push(sc.sub.strongWinds);subS.push(sc.sub.supercell);capes.push(sc.metrics.cape);shears.push(sc.metrics.shear);gusts.push(sc.metrics.gust);precs.push(sc.metrics.precip);}}
    const p95=a=>{if(!a.length)return 0;const s=[...a].sort((x,y)=>x-y);return s[Math.floor(s.length*0.95)];};const p05=a=>{if(!a.length)return 0;const s=[...a].sort((x,y)=>x-y);return s[Math.floor(s.length*0.05)];};
    return{thunderstorm:p95(ts),hail:p95(hl),tornado:p95(tn),lightning:p95(lg),stormyCells,totalCells:grid.length,sub:{tornado:p95(subT),hail:p95(subH),flashFlood:p95(subF),strongWinds:p95(subW),supercell:p95(subS)},ranges:{cape:{min:p05(capes),max:p95(capes)},shear:{min:p05(shears),max:p95(shears)},gust:{min:p05(gusts),max:p95(gusts)},precip:{min:p05(precs),max:p95(precs)},hailMm:{min:0,max:Math.round(Math.max(...(subH.length?subH:[0]),0)*0.7)}}};
  });
  const payload={region,run:run.toISOString(),grid,summary,builtAt:Date.now()};
  try{localStorage.setItem(cacheKey,JSON.stringify(payload));}catch{pruneOldRuns();try{localStorage.setItem(cacheKey,JSON.stringify(payload));}catch{}}
  onProgress?.(1);return payload;
}

async function fetchSounding(lat,lon,when,dayOffset=0){
  try{const res=await db.functions.invoke('tcmSounding',{lat,lon,dayOffset});if(res?.data?.ok&&Array.isArray(res.data.levels)&&res.data.levels.length)return res.data.levels;}catch(e){console.warn('[fetchSounding]',e?.message);}
  const seed=hashStr(`${lat.toFixed(2)}_${lon.toFixed(2)}_${when.toISOString().slice(0,10)}`);const rng=mulberry32(seed);
  const sfcT=18+rng()*10;const sfcTd=sfcT-(2+rng()*5);const fzAlt=2800+rng()*1400;const levels=[1000,925,850,700,500,400,300,250,200];
  return levels.map((p,i)=>{const z=i===0?0:8000*Math.log(1000/p);let T;if(z<fzAlt)T=sfcT*(1-z/fzAlt);else T=-(z-fzAlt)*6.5/1000;let Td=p>=850?sfcTd-(1000-p)/50:p>=700?sfcTd-(1000-p)/30:T-15-(700-p)/30;Td=Math.min(T-0.5,Td);const wspd=10+(z/6000)*25+rng()*5;const wdir=200+(z/8000)*70;return{pressure:p,height:Math.round(z),temp:+T.toFixed(1),dew:+Td.toFixed(1),wspd:+wspd.toFixed(1),wdir:+wdir.toFixed(1)};});
}

// RISK_META, RISK_INDEX, RISK_DESCRIPTIONS, RISK_PALETTES, scoreToLevel, etc. imported from riskConfig
const THEME_TOKENS={
  light:{pageBg:'linear-gradient(160deg, #e8edf5 0%, #ffffff 60%, #eef2ff 100%)',cardBg:'rgba(255,255,255,0.78)',cardBorder:'rgba(15,23,42,0.10)',cardShadow:'0 4px 24px rgba(15,23,42,0.06)',textPrimary:'#0f172a',textSecondary:'#475569',textMuted:'#94a3b8',inputBorder:'rgba(15,23,42,0.10)',titleCardBg:'rgba(255,255,255,0.93)',titleCardBorder:'#cbd5e1',titleCardText:'#0f172a',titleCardSub:'#475569'},
  dark:{pageBg:'linear-gradient(160deg, #0a0f1e 0%, #0f1730 60%, #1a1040 100%)',cardBg:'rgba(15,23,42,0.65)',cardBorder:'rgba(255,255,255,0.07)',cardShadow:'0 4px 24px rgba(0,0,0,0.30)',textPrimary:'#f1f5f9',textSecondary:'#94a3b8',textMuted:'#64748b',inputBorder:'rgba(255,255,255,0.08)',titleCardBg:'rgba(15,23,42,0.92)',titleCardBorder:'#334155',titleCardText:'#f1f5f9',titleCardSub:'#94a3b8'}
};
const TCMThemeContext=createContext({lightMode:false,toggle:()=>{},t:THEME_TOKENS.dark});
const useTCMTheme=()=>useContext(TCMThemeContext);
function TCMThemeProvider({children}){
  const[lightMode,setLightMode]=useState(()=>{try{return localStorage.getItem('tcm_light_mode')==='true';}catch{return false;}});
  useEffect(()=>{try{localStorage.setItem('tcm_light_mode',String(lightMode));}catch{}},[lightMode]);
  const value=useMemo(()=>({lightMode,toggle:()=>setLightMode(m=>!m),t:lightMode?THEME_TOKENS.light:THEME_TOKENS.dark}),[lightMode]);
  return <TCMThemeContext.Provider value={value}>{children}</TCMThemeContext.Provider>;
}

const INLINE_LOGO_DATAURL='https://media.db.com/images/public/69945c97e07811f2b5427aa6/c5edb1383_IMG_73723.png';
const TCMLogoContext=createContext({logoUrl:INLINE_LOGO_DATAURL,refresh:()=>{}});
const useLogo=()=>useContext(TCMLogoContext);
function TCMLogoProvider({children}){
  const[logoUrl,setLogoUrl]=useState(()=>{try{return localStorage.getItem('tcm_logo_local_dataurl')||INLINE_LOGO_DATAURL;}catch{return INLINE_LOGO_DATAURL;}});
  const refresh=useCallback(()=>{try{setLogoUrl(localStorage.getItem('tcm_logo_local_dataurl')||INLINE_LOGO_DATAURL);}catch{setLogoUrl(INLINE_LOGO_DATAURL);}},[]);
  const value=useMemo(()=>({logoUrl,refresh}),[logoUrl,refresh]);
  return <TCMLogoContext.Provider value={value}>{children}</TCMLogoContext.Provider>;
}

const PROB_COLORS_DARK=[{min:5,max:15,fill:'rgba(173,216,230,0.45)',label:'Marginal 5–15%'},{min:15,max:30,fill:'rgba(144,238,144,0.50)',label:'Slight 15–30%'},{min:30,max:45,fill:'rgba(255,255,0,0.50)',label:'Enhanced 30–45%'},{min:45,max:60,fill:'rgba(255,140,0,0.55)',label:'Moderate 45–60%'},{min:60,max:101,fill:'rgba(220,38,38,0.60)',label:'High ≥60%'}];
const PROB_COLORS_LIGHT=[{min:5,max:15,fill:'rgba(135,206,235,0.55)',label:'Marginal 5–15%'},{min:15,max:30,fill:'rgba(60,179,113,0.55)',label:'Slight 15–30%'},{min:30,max:45,fill:'rgba(218,165,32,0.55)',label:'Enhanced 30–45%'},{min:45,max:60,fill:'rgba(255,100,0,0.60)',label:'Moderate 45–60%'},{min:60,max:101,fill:'rgba(180,0,0,0.65)',label:'High ≥60%'}];

const RISK_TYPES=[
  {id:'thunderstorm',label:'Thunderstorm',shortLabel:'Storm',icon:CloudLightning,color:'#facc15'},
  {id:'hail',        label:'Hail',        shortLabel:'Hail', icon:CloudRain,      color:'#38bdf8'},
  {id:'tornado',     label:'Tornado',     shortLabel:'Tor',  icon:Wind,           color:'#f97316'},
  {id:'lightning',   label:'Lightning',   shortLabel:'Ltg',  icon:Zap,            color:'#a78bfa'}
];

// ── Geometry Engine ────────────────────────────────────────────────────────────
function convexHull(pts){if(pts.length<=2)return pts.slice();const p=pts.slice().sort((a,b)=>a[0]-b[0]||a[1]-b[1]);const cross=(o,a,b)=>(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0]);const lo=[],up=[];for(const x of p){while(lo.length>=2&&cross(lo[lo.length-2],lo[lo.length-1],x)<=0)lo.pop();lo.push(x);}for(let i=p.length-1;i>=0;i--){const x=p[i];while(up.length>=2&&cross(up[up.length-2],up[up.length-1],x)<=0)up.pop();up.push(x);}lo.pop();up.pop();return lo.concat(up);}
function inflatePoly(pts,padDeg){if(!pts.length)return pts;const cx=pts.reduce((s,p)=>s+p[0],0)/pts.length;const cy=pts.reduce((s,p)=>s+p[1],0)/pts.length;return pts.map(([x,y])=>{const dx=x-cx,dy=y-cy;const len=Math.hypot(dx,dy)||1;return[x+(dx/len)*padDeg,y+(dy/len)*padDeg];});}

// Smooth Catmull-Rom spline through hull points — produces natural blob shapes like SPC/SOTUK
function smoothClosedPath(pts, tension=0.5){
  if(!pts.length) return '';
  if(pts.length===1){const[x,y]=pts[0];const r=20;return`M${x-r},${y} a${r},${r} 0 1,0 ${r*2},0 a${r},${r} 0 1,0 -${r*2},0`;}
  if(pts.length===2){const[ax,ay]=pts[0],[bx,by]=pts[1];const mx=(ax+bx)/2,my=(ay+by)/2;const len=Math.hypot(bx-ax,by-ay)||1;const px=-(by-ay)/len*15,py=(bx-ax)/len*15;return`M${ax},${ay} Q${mx+px},${my+py} ${bx},${by} Q${mx-px},${my-py} ${ax},${ay}Z`;}
  const n=pts.length;
  // Catmull-Rom → Bezier: smooth, no jagged corners — high tension for ultra-smooth blobs
  let d=`M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
  for(let i=0;i<n;i++){
    const p0=pts[(i-1+n)%n];
    const p1=pts[i];
    const p2=pts[(i+1)%n];
    const p3=pts[(i+2)%n];
    const cp1x=p1[0]+tension*(p2[0]-p0[0]);
    const cp1y=p1[1]+tension*(p2[1]-p0[1]);
    const cp2x=p2[0]-tension*(p3[0]-p1[0]);
    const cp2y=p2[1]-tension*(p3[1]-p1[1]);
    d+=` C${cp1x.toFixed(1)},${cp1y.toFixed(1)} ${cp2x.toFixed(1)},${cp2y.toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
  }
  return d+' Z';
}

function clusterPoints(pts,gridStep,minClusterSize=1){if(!pts.length)return[];const visited=new Set();const key=p=>`${Math.round(p.lat*1000)},${Math.round(p.lon*1000)}`;const clusters=[];const searchRadius=gridStep*5;for(const p of pts){const k=key(p);if(visited.has(k))continue;const cluster=[];const queue=[p];visited.add(k);while(queue.length){const cur=queue.shift();cluster.push(cur);for(const pt of pts){const ck=key(pt);if(visited.has(ck))continue;const dist=Math.hypot(pt.lat-cur.lat,pt.lon-cur.lon);if(dist<=searchRadius){visited.add(ck);queue.push(pt);}}}if(cluster.length>=minClusterSize)clusters.push(cluster);}return clusters;}

// Build smooth filled blob — Chaikin-subdivided & quadratic-Bézier closed path
// (no hexagons, no sharp corners, no self-intersecting loops).
function clusterToPath(cluster, projector, gridStep=0.3){
  return smoothBlobPath(cluster, projector, gridStep, 2.2);
}
// Score accessor — hail/tornado/lightning use sub-scores; thunderstorm/lightning use main score
function getRiskScore(pt, riskType, dayIdx) {
  // Try perDay first (pre-built), fallback to computing from perStep
  let scores = pt.perDay?.[dayIdx]?.scores;
  
  if (!scores && pt.perStep) {
    // Rebuild from perStep for this day
    const dayStart = dayIdx * STEPS_PER_DAY;
    const dayEnd = (dayIdx + 1) * STEPS_PER_DAY;
    const daySlice = pt.perStep.slice(dayStart, dayEnd);
    
    if (daySlice.length > 0) {
      // Compute peak scores for the day
      let ts = 0, hl = 0, tn = 0, lg = 0;
      let subT = 0, subH = 0, subF = 0, subW = 0, subS = 0;
      for (const st of daySlice) {
        if (st.scores) {
          ts = Math.max(ts, st.scores.thunderstorm || 0);
          hl = Math.max(hl, st.scores.hail || 0);
          tn = Math.max(tn, st.scores.tornado || 0);
          lg = Math.max(lg, st.scores.lightning || 0);
          if (st.scores.sub) {
            subT = Math.max(subT, st.scores.sub.tornado || 0);
            subH = Math.max(subH, st.scores.sub.hail || 0);
            subF = Math.max(subF, st.scores.sub.flashFlood || 0);
            subW = Math.max(subW, st.scores.sub.strongWinds || 0);
            subS = Math.max(subS, st.scores.sub.supercell || 0);
          }
        }
      }
      scores = {
        thunderstorm: ts,
        hail: hl,
        tornado: tn,
        lightning: lg,
        sub: { tornado: subT, hail: subH, flashFlood: subF, strongWinds: subW, supercell: subS }
      };
    }
  }
  
  if (!scores) return 0;
  if (riskType === 'hail')    return scores.sub?.hail      ?? scores.hail    ?? 0;
  if (riskType === 'tornado') return scores.sub?.tornado   ?? scores.tornado  ?? 0;
  if (riskType === 'lightning') return scores.lightning ?? 0;
  return scores[riskType] ?? 0;
}
function getRiskScoreStep(pt, riskType, stepIdx) {
  const scores = pt.perStep?.[stepIdx]?.scores;
  if (!scores) return 0;
  if (riskType === 'hail')    return scores.sub?.hail      ?? scores.hail    ?? 0;
  if (riskType === 'tornado') return scores.sub?.tornado   ?? scores.tornado  ?? 0;
  if (riskType === 'lightning') return scores.lightning ?? 0;
  return scores[riskType] ?? 0;
}

const ORDERED_LEVELS=['Very Low','Low','Marginal','Slight','Moderate','High','Severe'];

// UK view clips risk areas to the UK & Ireland landmask so risks don't
// spill into France, Belgium, the Netherlands, or open Atlantic.
function passesRegionMask(p,region,bbox){
  if(bbox && (p.lat<bbox.latMin-0.5 || p.lat>bbox.latMax+0.5 || p.lon<bbox.lonMin-0.5 || p.lon>bbox.lonMax+0.5))return false;
  if(region==='uk' && !isInUKIreland(p.lat,p.lon))return false;
  return true;
}

function buildOutlookLayers(grid,riskType,dayIdx,gridStep,region='uk'){
  const layers=[];
  const bbox=REGIONS[region]?.bbox;
  for(const lvl of ORDERED_LEVELS){
    const thresh=MIN_SCORE_PER_LEVEL[lvl];
    const pts=grid.filter(p=>passesRegionMask(p,region,bbox) && getRiskScore(p,riskType,dayIdx)>=thresh);
    if(!pts.length)continue;
    const clusters=clusterPoints(pts,gridStep,1);
    if(!clusters.length)continue;
    layers.push({level:lvl,clusters});
  }
  return layers;
}
function buildOutlookLayersForStep(grid,riskType,stepIdx,gridStep,region='uk'){
  const layers=[];
  const bbox=REGIONS[region]?.bbox;
  for(const lvl of ORDERED_LEVELS){
    const thresh=MIN_SCORE_PER_LEVEL[lvl];
    const pts=grid.filter(p=>passesRegionMask(p,region,bbox) && getRiskScoreStep(p,riskType,stepIdx)>=thresh);
    if(!pts.length)continue;
    const idx=ORDERED_LEVELS.indexOf(lvl);
    const minSize=idx>=5?1:idx>=3?1:2;
    const clusters=clusterPoints(pts,gridStep,minSize);
    if(!clusters.length)continue;
    layers.push({level:lvl,clusters});
  }
  return layers;
}
function buildProbabilityLayers(grid,riskType,dayIdx,colors,gridStep){const layers=[];for(const band of colors){const pts=grid.filter(p=>getRiskScore(p,riskType,dayIdx)>=band.min);if(!pts.length)continue;const clusters=clusterPoints(pts,gridStep,1);if(!clusters.length)continue;layers.push({...band,clusters});}return layers;}

// ── UI Primitives ────────────────────────────────────────────────────────────
const Card=({children,style,className=''})=>{const{t}=useTCMTheme();return<div className={className} style={{background:t.cardBg,border:`1px solid ${t.cardBorder}`,borderRadius:16,backdropFilter:'blur(12px)',boxShadow:t.cardShadow,...style}}>{children}</div>;};
const Pill=({active,children,onClick,color='#38bdf8'})=>{const{t}=useTCMTheme();return<button onClick={onClick} style={{padding:'8px 14px',borderRadius:10,fontSize:'0.78rem',fontWeight:700,color:active?'#0a0f1e':t.textSecondary,background:active?`linear-gradient(135deg, ${color}, ${color}aa)`:'transparent',border:`1px solid ${active?color:t.inputBorder}`,cursor:'pointer',transition:'all .18s',fontFamily:"'DM Sans', system-ui, sans-serif"}}>{children}</button>;};
const Section=({title,icon:Icon,children,extra})=>{const{t}=useTCMTheme();return<Card style={{padding:20,marginBottom:20}}><div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14,flexWrap:'wrap'}}>{Icon&&<Icon style={{width:18,height:18,color:'#38bdf8'}}/>}<h3 style={{margin:0,fontSize:'0.92rem',fontWeight:700,color:t.textPrimary,fontFamily:"'DM Sans',system-ui,sans-serif"}}>{title}</h3><div style={{flex:1}}/>{extra}</div>{children}</Card>;};

const TitleCard=React.memo(function TitleCard({w,x=10,y=10,h=50,title,sub}){
  const{t}=useTCMTheme();const{logoUrl}=useLogo();const logoBox=h-8;
  return(<g>
    <rect x={x} y={y} width={w} height={h} fill={t.titleCardBg} stroke={t.titleCardBorder} strokeWidth={0.5} rx={8}/>
    <text x={x+12} y={y+22} fontFamily="DM Sans,sans-serif" fontSize={13} fontWeight={800} fill={t.titleCardText} style={{letterSpacing:'-0.01em'}}>{title}</text>
    <text x={x+12} y={y+40} fontFamily="DM Mono,monospace" fontSize={10} fill={t.titleCardSub}>{sub}</text>
    {logoUrl&&<image href={logoUrl} x={x+w-logoBox-6} y={y+4} width={logoBox} height={logoBox} preserveAspectRatio="xMidYMid meet"/>}
  </g>);
});

// ── Outlook Legend ────────────────────────────────────────────────────────────
const OutlookLegend=React.memo(function OutlookLegend({riskType,regionLabel,activeLevels,lightMode}){
  const{logoUrl}=useLogo();
  const tone={bg:'rgba(15,23,42,0.93)',border:'rgba(255,255,255,0.15)',text:'#f1f5f9',sub:'#cbd5e1',dim:'#94a3b8',faint:'#64748b',rule:'rgba(255,255,255,0.08)'};
  const headerLabel=RISK_TYPES.find(rt=>rt.id===riskType)?.label||'Risk';

  return(
    <div style={{position:'absolute',top:10,right:10,zIndex:500,width:280,background:tone.bg,backdropFilter:'blur(14px)',borderRadius:8,border:`1px solid ${tone.border}`,boxShadow:'0 12px 40px rgba(0,0,0,0.32)',overflow:'hidden',fontFamily:"'DM Sans',system-ui,sans-serif"}}>
      <div style={{display:'flex',alignItems:'center',gap:10,padding:'12px 14px',borderBottom:`1px solid ${tone.rule}`}}>
        <img src={logoUrl} alt="" onError={e=>e.currentTarget.style.display='none'} style={{width:32,height:32,objectFit:'contain',flexShrink:0,borderRadius:4}}/>
        <div style={{minWidth:0,flex:1}}>
          <div style={{fontSize:'0.56rem',fontWeight:800,color:tone.faint,letterSpacing:'0.12em',textTransform:'uppercase',fontFamily:"'DM Mono',monospace"}}>Risk Level</div>
          <div style={{fontSize:'0.8rem',fontWeight:700,color:tone.text}}>{headerLabel}</div>
        </div>
      </div>
      <div style={{padding:'10px 12px 12px'}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:8,marginBottom:8,paddingBottom:8,borderBottom:`1px solid ${tone.rule}`}}>
          <span style={{fontSize:'0.60rem',fontWeight:700,color:tone.sub,textTransform:'uppercase',letterSpacing:'0.04em'}}>{regionLabel}</span>
          <span style={{fontSize:'0.56rem',fontStyle:'italic',color:tone.dim,fontFamily:"'DM Mono',monospace"}}>/100</span>
        </div>
        {[...RISK_META].reverse().map(r=>{
          if(r.level==='No Risk')return null;
          const active=activeLevels.has(r.level);
          const c=RISK_COLOR(r.level,riskType),f=RISK_FILL(r.level,riskType),b=RISK_BORDER(r.level,riskType);
          return(
            <div key={r.level} style={{display:'flex',alignItems:'center',gap:8,padding:'4px 0',marginBottom:3}}>
              <span style={{width:24,height:12,flexShrink:0,borderRadius:3,background:f,border:`1.5px solid ${b}`}}/>
              <span style={{flex:1,fontSize:'0.72rem',fontWeight:active?700:600,color:tone.text}}>{r.level}</span>
              <span style={{fontSize:'0.58rem',fontFamily:"'DM Mono',monospace",color:tone.dim,minWidth:32,textAlign:'right'}}>{fmtRange(r.level)}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
});

// ── Probability Legend ────────────────────────────────────────────────────────
const ProbabilityLegend=React.memo(function ProbabilityLegend({riskType,regionLabel,lightMode}){
  const{logoUrl}=useLogo();
  const colors=lightMode?PROB_COLORS_LIGHT:PROB_COLORS_DARK;
  const tone=lightMode
    ?{bg:'rgba(255,255,255,0.97)',border:'rgba(15,23,42,0.12)',text:'#0f172a',sub:'#475569',dim:'#64748b',faint:'#94a3b8',rule:'rgba(15,23,42,0.08)'}
    :{bg:'rgba(10,15,30,0.96)',border:'rgba(255,255,255,0.10)',text:'#f1f5f9',sub:'#cbd5e1',dim:'#94a3b8',faint:'#64748b',rule:'rgba(255,255,255,0.07)'};
  const headerLabel=RISK_TYPES.find(rt=>rt.id===riskType)?.label||'Risk';
  return(
    <div style={{position:'absolute',top:70,right:10,zIndex:500,width:220,background:tone.bg,backdropFilter:'blur(14px)',borderRadius:14,border:`1px solid ${tone.border}`,boxShadow:'0 12px 40px rgba(0,0,0,0.32)',overflow:'hidden',fontFamily:"'DM Sans',system-ui,sans-serif"}}>
      <div style={{display:'flex',alignItems:'center',gap:10,padding:'11px 13px',borderBottom:`1px solid ${tone.rule}`}}>
        <img src={logoUrl} alt="" onError={e=>e.currentTarget.style.display='none'} style={{width:28,height:28,objectFit:'contain',flexShrink:0,borderRadius:5}}/>
        <div style={{minWidth:0,flex:1}}>
          <div style={{fontSize:'0.58rem',fontWeight:800,color:tone.faint,letterSpacing:'0.14em',textTransform:'uppercase',fontFamily:"'DM Mono',monospace"}}>Thunderstorm Risk</div>
          <div style={{fontSize:'0.76rem',fontWeight:700,color:tone.text}}>% chance within 40 km</div>
        </div>
      </div>
      <div style={{padding:'8px 12px 12px'}}>
        {[...colors].reverse().map((band,i)=>(
          <div key={i} style={{display:'flex',alignItems:'center',gap:8,padding:'3px 4px',borderRadius:4}}>
            <span style={{width:26,height:13,flexShrink:0,borderRadius:3,background:band.fill,border:`1px solid ${band.fill.replace(/[\d.]+\)$/,'0.9)')}`}}/>
            <span style={{fontSize:'0.72rem',fontWeight:600,color:tone.text}}>{band.label}</span>
          </div>
        ))}
        <div style={{marginTop:8,paddingTop:8,borderTop:`1px solid ${tone.rule}`,fontSize:'0.60rem',color:tone.faint,lineHeight:1.4}}>
          No Signal &lt;5% — white/transparent
        </div>
      </div>
    </div>
  );
});

// ═══════════════════════════════════════════════════════════════════════════
// OUTLOOK MAP — Professional SPC-style nested risk contours
// Each risk level is painted from outermost (Very Low) inward to highest,
// with multiple disconnected clusters rendered per level, proper smooth
// concave outlines, and graduated fill opacity like real met office products.
// ═══════════════════════════════════════════════════════════════════════════
const OutlookMap=React.memo(function OutlookMap({data,region,riskType,dayIdx,onClickPoint}){
  const{t,lightMode}=useTCMTheme();
  const bbox=REGIONS[region].bbox;
  const grid=data?.grid??[];
  const gridStep=REGIONS[region].gridStep;

  const layers=useMemo(()=>{
    if(!grid.length)return[];
    return buildOutlookLayers(grid,riskType,dayIdx,gridStep,region);
  },[grid,riskType,dayIdx,region]);

  const activeLevels=useMemo(()=>{const s=new Set();for(const l of layers)s.add(l.level);return s;},[layers]);
  const isMobile=typeof window!=='undefined'&&window.innerWidth<640;
  const mapHeight=isMobile?Math.min(320,window.innerHeight*0.55):Math.max(420,Math.min(720,window.innerHeight*0.66));

  return(
    <div style={{position:'relative'}}>
      <TCMLeafletBase bbox={bbox} height={mapHeight} lightMode={lightMode}>
        {({projector,map})=>{
          if(!projector||!map)return null;
          const {x:w,y:h}=projector.size;

          return(
            <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}
              onClick={(e)=>{const r=e.currentTarget.getBoundingClientRect();const ll=projector.unproject(e.clientX-r.left,e.clientY-r.top);onClickPoint?.(ll);}}
              style={{position:'absolute',inset:0,pointerEvents:'auto',cursor:'crosshair',zIndex:400}}>
              <defs>
                <filter id="outlook-ambient" x="-30%" y="-30%" width="160%" height="160%">
                  <feGaussianBlur stdDeviation="14" result="blur"/>
                  <feComposite in="SourceGraphic" in2="blur" operator="over"/>
                </filter>
                <filter id="outlook-edge" x="-5%" y="-5%" width="110%" height="110%">
                  <feGaussianBlur stdDeviation="1.8" result="blur"/>
                  <feComposite in="SourceGraphic" in2="blur" operator="over"/>
                </filter>
                {/* Severe hatch pattern — black diagonal lines, no fill */}
                <pattern id="severe-hatch" patternUnits="userSpaceOnUse" width="10" height="10" patternTransform="rotate(45)">
                  <line x1="0" y1="0" x2="0" y2="10" stroke="rgba(0,0,0,0.75)" strokeWidth="3"/>
                </pattern>
              </defs>

              {/* No ambient glow — clean polygon edges like SPC/SOTUK */}

              {/* ── Layer 2: Main risk polygons — SPC/SOTUK style nested filled blobs */}
              {layers.map((layer,li)=>
                layer.clusters.map((cluster,ci)=>{
                  const d=clusterToPath(cluster,projector,gridStep);
                  if(!d)return null;
                  const levelOpacity=LEVEL_OPACITY[layer.level]??0.7;
                  const isSevere=layer.level==='Severe';
                  const isVeryLow=layer.level==='Very Low';
                  return(
                    <path
                      key={`poly-${riskType}-${dayIdx}-${layer.level}-${ci}`}
                      d={d}
                      fill={isSevere?'url(#severe-hatch)':RISK_FILL(layer.level,riskType)}
                      stroke={RISK_BORDER(layer.level,riskType)}
                      strokeWidth={isSevere?2.5:1.5}
                      strokeLinejoin="round"
                      strokeLinecap="round"
                      opacity={levelOpacity}
                    />
                  );
                })
              )}

              {/* ── Layer 3: Risk level labels inside Moderate+ cluster centroids */}
              {layers
                .filter(layer=>RISK_INDEX[layer.level]>=5)
                .map((layer,li)=>
                  layer.clusters.map((cluster,ci)=>{
                    if(cluster.length<3)return null;
                    const projected=cluster.map(p=>projector.project(p.lat,p.lon));
                    const cx=projected.reduce((s,p)=>s+p[0],0)/projected.length;
                    const cy=projected.reduce((s,p)=>s+p[1],0)/projected.length;
                    const shortLabels={'Slight':'SLGT','Moderate':'MOD','High':'HIGH','Severe':'SVR'};
                    const lbl=shortLabels[layer.level];
                    if(!lbl)return null;
                    return(
                      <g key={`lbl-${li}-${ci}`}>
                        {/* Drop shadow */}
                        <text x={cx+0.8} y={cy+1.8} textAnchor="middle" dominantBaseline="middle"
                          fontSize={10} fontWeight={900} fontFamily="DM Mono,monospace"
                          fill="rgba(0,0,0,0.70)" letterSpacing="0.10em">{lbl}</text>
                        {/* Label */}
                        <text x={cx} y={cy} textAnchor="middle" dominantBaseline="middle"
                          fontSize={10} fontWeight={900} fontFamily="DM Mono,monospace"
                          fill="rgba(255,255,255,0.96)" letterSpacing="0.10em">{lbl}</text>
                      </g>
                    );
                  })
                )
              }

              {layers.length===0&&(
                <text x={w/2} y={h/2} textAnchor="middle" fontSize={13} fontWeight={600}
                  fill={lightMode?'rgba(0,0,0,0.28)':'rgba(255,255,255,0.28)'}
                  fontFamily="DM Sans,system-ui,sans-serif">No significant risk areas</text>
              )}

              <TitleCard w={Math.max(180,Math.min(360,w-250))} x={10} y={10}
                title={`${RISK_TYPES.find(tt=>tt.id===riskType)?.label} Risk`}
                sub={`${REGIONS[region].label} · Day ${dayIdx+1}`}/>
            </svg>
          );
        }}
      </TCMLeafletBase>
      <OutlookLegend riskType={riskType} regionLabel={REGIONS[region].label} activeLevels={activeLevels} lightMode={lightMode}/>
    </div>
  );
});

// ── PROBABILITY MAP — 5-band UKMO-style per-cell choropleth (matches reference photo) ──
const CHOROPLETH_BANDS=[
  {min:5,  max:15, fill:'rgba(176,206,224,0.78)', stroke:'rgba(130,170,200,0.55)', label:'Marginal',  range:'5–15%'},
  {min:15, max:30, fill:'rgba(200,212,180,0.82)', stroke:'rgba(155,175,135,0.60)', label:'Slight',    range:'15–30%'},
  {min:30, max:45, fill:'rgba(232,210,140,0.86)', stroke:'rgba(190,165,80,0.65)',  label:'Enhanced',  range:'30–45%'},
  {min:45, max:60, fill:'rgba(236,160,80,0.90)',  stroke:'rgba(200,120,40,0.70)',  label:'Moderate',  range:'45–60%'},
  {min:60, max:101,fill:'rgba(190,40,40,0.92)',   stroke:'rgba(140,20,20,0.75)',   label:'High',      range:'≥60%'},
];

function bandForScore(score){
  for(let i=CHOROPLETH_BANDS.length-1;i>=0;i--){
    if(score>=CHOROPLETH_BANDS[i].min)return CHOROPLETH_BANDS[i];
  }
  return null;
}

function ProbabilityLegendOverlay(){
  return(
    <div style={{position:'absolute',top:10,left:10,zIndex:500,
      width:178,background:'#eaf2f7',borderRadius:3,
      border:'1px solid #6b8a9e',padding:'7px 9px 8px',fontFamily:"'DM Sans',system-ui,sans-serif",
      boxShadow:'0 2px 6px rgba(0,0,0,0.22)'}}>
      <div style={{marginBottom:5,paddingBottom:4,borderBottom:'1px solid #b8c8d4'}}>
        <div style={{fontSize:'0.78rem',fontWeight:800,color:'#1e3a5f',lineHeight:1.1}}>Thunderstorm Risk</div>
        <div style={{fontSize:'0.60rem',color:'#5a7088',fontStyle:'italic',marginTop:1}}>% chance within 40 km</div>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:2}}>
        {[...CHOROPLETH_BANDS].reverse().map((b,i)=>(
          <div key={i} style={{display:'flex',alignItems:'center',gap:6}}>
            <span style={{width:18,height:11,flexShrink:0,background:b.fill,border:`1px solid ${b.stroke}`}}/>
            <span style={{fontSize:'0.66rem',color:'#1e3a5f'}}>
              <span style={{fontWeight:700}}>{b.label}</span> {b.range}
            </span>
          </div>
        ))}
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <span style={{width:18,height:11,flexShrink:0,background:'#ffffff',border:'1px solid #b0bfcc'}}/>
          <span style={{fontSize:'0.66rem',color:'#1e3a5f'}}>
            <span style={{fontWeight:700}}>No Signal</span> &lt;5%
          </span>
        </div>
      </div>
    </div>
  );
}

const ProbabilityMap=React.memo(function ProbabilityMap({data,region,riskType,dayIdx,onClickPoint}){
  const{t,lightMode}=useTCMTheme();
  const bbox=REGIONS[region].bbox;
  const grid=data?.grid??[];
  const gridStep=REGIONS[region].gridStep;
  const isMobile=typeof window!=='undefined'&&window.innerWidth<640;
  const mapHeight=isMobile?Math.min(320,window.innerHeight*0.55):Math.max(420,Math.min(720,window.innerHeight*0.66));

  // Use Outlook risk levels (same palette as Outlook). One filled, rounded cell per
  // grid point. Cells are sized to gridStep so they touch/overlap and fill the map.
  const cells=useMemo(()=>{
    if(!grid.length)return[];
    const out=[];
    for(const p of grid){
      if(p.lat<bbox.latMin-0.1||p.lat>bbox.latMax+0.1||p.lon<bbox.lonMin-0.1||p.lon>bbox.lonMax+0.1)continue;
      // UK view: clip cells to UK & Ireland landmask
      if(region==='uk' && !isInUKIreland(p.lat,p.lon))continue;
      const score=getRiskScore(p,riskType,dayIdx);
      if(score<MIN_SCORE_PER_LEVEL['Very Low'])continue;
      const level=scoreToLevel(score);
      if(!level||level==='No Risk')continue;
      out.push({lat:p.lat,lon:p.lon,score,level});
    }
    return out;
  },[grid,riskType,dayIdx,bbox,region]);

  const activeLevels=useMemo(()=>{const s=new Set();for(const c of cells)s.add(c.level);return s;},[cells]);

  return(
    <div style={{position:'relative'}}>
      <TCMLeafletBase bbox={bbox} height={mapHeight} lightMode={lightMode}>
        {({projector,map})=>{
          if(!projector||!map)return null;
          const {x:w,y:h}=projector.size;

          // Cell pixel size from gridStep; overscale slightly so neighbouring cells
          // touch/overlap (no gaps), filling the map continuously.
          let cellW=18, cellH=18;
          if(cells.length){
            const [x0,y0]=projector.project(cells[0].lat,cells[0].lon);
            const [x1,y1]=projector.project(cells[0].lat+gridStep,cells[0].lon+gridStep);
            cellW=Math.max(8,Math.abs(x1-x0)*1.15);
            cellH=Math.max(8,Math.abs(y1-y0)*1.15);
          }
          const radius=Math.min(cellW,cellH)*0.32;

          return(
            <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}
              onClick={(e)=>{const r=e.currentTarget.getBoundingClientRect();const ll=projector.unproject(e.clientX-r.left,e.clientY-r.top);onClickPoint?.(ll);}}
              style={{position:'absolute',inset:0,pointerEvents:'auto',cursor:'crosshair',zIndex:400}}>

              {/* Per-grid-cell choropleth — rounded, overlapping cells using Outlook palette */}
              {cells.map((c,i)=>{
                const [cx,cy]=projector.project(c.lat,c.lon);
                const fill=RISK_FILL(c.level,riskType);
                const opacity=LEVEL_OPACITY[c.level]??0.7;
                return(
                  <rect
                    key={`cell-${i}`}
                    x={cx-cellW/2}
                    y={cy-cellH/2}
                    width={cellW}
                    height={cellH}
                    rx={radius}
                    ry={radius}
                    fill={fill}
                    opacity={opacity}
                  />
                );
              })}

              {cells.length===0&&(
                <text x={w/2} y={h/2} textAnchor="middle" fontSize={13} fontWeight={600}
                  fill={lightMode?'rgba(0,0,0,0.28)':'rgba(255,255,255,0.28)'}
                  fontFamily="DM Sans">No significant risk areas</text>
              )}

              <TitleCard w={Math.max(180,Math.min(340,w-250))} x={10} y={10}
                title={`${RISK_TYPES.find(tt=>tt.id===riskType)?.label} Risk`}
                sub={`${REGIONS[region].label} · Day ${dayIdx+1} · Probability`}/>
            </svg>
          );
        }}
      </TCMLeafletBase>
      <OutlookLegend riskType={riskType} regionLabel={REGIONS[region].label} activeLevels={activeLevels} lightMode={lightMode}/>
    </div>
  );
});

// ── ANIMATED MAP ──────────────────────────────────────────────────────────────
const AnimatedMap=React.memo(function AnimatedMap({data,region,riskType,run}){
  const{lightMode}=useTCMTheme();
  const[playing,setPlaying]=useState(true);
  const[step,setStep]=useState(0);
  useEffect(()=>{if(!playing)return;const id=setInterval(()=>setStep(s=>(s+1)%TOTAL_STEPS),1100);return()=>clearInterval(id);},[playing]);
  const bbox=REGIONS[region].bbox;
  const gridStep=REGIONS[region].gridStep;
  const tickLabel=stepLabel(step,run);
  const grid=data?.grid??[];

  const layers=useMemo(()=>{
    if(!grid.length)return[];
    return buildOutlookLayersForStep(grid,riskType,step,gridStep,region);
  },[grid,riskType,step,region]);

  const activeLevels=useMemo(()=>{const s=new Set();for(const l of layers)s.add(l.level);return s;},[layers]);
  const mapHeight=Math.max(380,Math.min(680,typeof window!=='undefined'?window.innerHeight*0.62:520));

  return(
    <div style={{position:'relative'}}>
      <TCMLeafletBase bbox={bbox} height={mapHeight} lightMode={lightMode}>
        {({projector})=>{
          if(!projector)return null;
          const {x:w,y:h}=projector.size;
          return(
            <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{position:'absolute',inset:0,pointerEvents:'none',zIndex:400}}>
              <defs>
                <filter id="anim-ambient"><feGaussianBlur stdDeviation="8"/></filter>
                <pattern id="anim-severe-hatch" patternUnits="userSpaceOnUse" width="10" height="10" patternTransform="rotate(45)">
                  <line x1="0" y1="0" x2="0" y2="10" stroke="rgba(0,0,0,0.75)" strokeWidth="3"/>
                </pattern>
              </defs>
              {/* Main polygons — graduated opacity per level */}
              {layers.map((layer,li)=>
                layer.clusters.map((cluster,ci)=>{
                  const d=clusterToPath(cluster,projector,gridStep);
                  if(!d)return null;
                  const lvlOpacity=LEVEL_OPACITY[layer.level]??0.7;
                  const isSevere=layer.level==='Severe';
                  const isVLL=['Very Low','Low'].includes(layer.level);
                  return(
                    <motion.path key={`anim-${step}-${layer.level}-${ci}`} d={d}
                      fill={isSevere?'url(#anim-severe-hatch)':RISK_FILL(layer.level,riskType)}
                      stroke={RISK_BORDER(layer.level,riskType)}
                      strokeWidth={isSevere?2.8:isVLL?1.0:1.8}
                      strokeLinejoin="round"
                      strokeDasharray={isVLL?'6,3':'none'}
                      opacity={lvlOpacity}
                      initial={{opacity:0}} animate={{opacity:lvlOpacity}} transition={{duration:0.25}}
                    />
                  );
                })
              )}
              {layers.length===0&&(
                <text x={w/2} y={h/2} textAnchor="middle" fontSize={13} fontWeight={600}
                  fill={lightMode?'rgba(0,0,0,0.25)':'rgba(255,255,255,0.25)'}
                  fontFamily="DM Sans">No significant risk at this time</text>
              )}
              <TitleCard w={Math.min(380,w-250)} x={10} y={10}
                title={`${REGIONS[region].label} — ${RISK_TYPES.find(tt=>tt.id===riskType)?.label}`}
                sub={tickLabel}/>
            </svg>
          );
        }}
      </TCMLeafletBase>
      <OutlookLegend riskType={riskType} regionLabel={REGIONS[region].label} activeLevels={activeLevels} lightMode={lightMode}/>
      <div style={{position:'absolute',bottom:8,left:'50%',transform:'translateX(-50%)',zIndex:500,display:'flex',alignItems:'center',gap:6,padding:'5px 10px',background:lightMode?'rgba(255,255,255,0.92)':'rgba(15,23,42,0.92)',border:`1px solid ${lightMode?'rgba(0,0,0,0.08)':'rgba(255,255,255,0.08)'}`,borderRadius:99,maxWidth:'90%',flexWrap:'nowrap',overflowX:'auto'}}>
        {Array.from({length:TOTAL_STEPS}).map((_,i)=>(<div key={i} onClick={()=>{setPlaying(false);setStep(i);}} title={stepLabel(i,run)} style={{width:i===step?14:4,height:4,borderRadius:2,flexShrink:0,background:i===step?'#a78bfa':(i%STEPS_PER_DAY===0?'rgba(167,139,250,0.45)':(lightMode?'rgba(0,0,0,0.18)':'rgba(255,255,255,0.20)')),cursor:'pointer',transition:'all .2s'}}/>))}
      </div>
    </div>
  );
});

// ── Main map section with view mode switcher ──────────────────────────────────
function MainMapSection({data,region,riskType,dayIdx,run,onClickPoint}){
  const{t}=useTCMTheme();
  const[viewMode,setViewMode]=useState('outlook');

  return(
    <Section
      title={viewMode==='outlook'?`Convective Outlook — ${RISK_TYPES.find(tt=>tt.id===riskType)?.label}`:viewMode==='probability'?`Probability Grid — ${RISK_TYPES.find(tt=>tt.id===riskType)?.label}`:`Animated Forecast — ${RISK_TYPES.find(tt=>tt.id===riskType)?.label}`}
      icon={VIEW_MODES.find(v=>v.id===viewMode)?.icon||Layers}
      extra={
        <div style={{display:'flex',alignItems:'center',gap:6,flexWrap:'wrap'}}>
          <div style={{display:'flex',gap:4,background:'rgba(255,255,255,0.04)',border:'1px solid rgba(255,255,255,0.08)',borderRadius:10,padding:'3px'}}>
            {VIEW_MODES.map(vm=>{
              const VIcon=vm.icon;
              return(
                <button key={vm.id} onClick={()=>setViewMode(vm.id)} title={vm.desc}
                  style={{padding:'5px 10px',borderRadius:8,fontSize:'0.7rem',fontWeight:700,display:'flex',alignItems:'center',gap:5,cursor:'pointer',transition:'all .15s',background:viewMode===vm.id?'rgba(167,139,250,0.25)':'transparent',color:viewMode===vm.id?'#a78bfa':t.textMuted,border:'none'}}>
                  <VIcon style={{width:11,height:11}}/>{vm.label}
                </button>
              );
            })}
          </div>
          <span style={{fontSize:'0.67rem',fontWeight:700,color:t.textMuted}}>Click map for detail</span>
        </div>
      }
    >
      {viewMode==='outlook'&&<OutlookMap data={data} region={region} riskType={riskType} dayIdx={dayIdx} onClickPoint={onClickPoint}/>}
      {viewMode==='probability'&&<ProbabilityMap data={data} region={region} riskType={riskType} dayIdx={dayIdx} onClickPoint={onClickPoint}/>}
      {viewMode==='animated'&&<AnimatedMap data={data} region={region} riskType={riskType} run={run}/>}
    </Section>
  );
}

// ── Day selector ──────────────────────────────────────────────────────────────
function DaySelector({value,onChange,run,summary,riskType}){
  const{t,lightMode}=useTCMTheme();
  const dates=[0,1,2,3].map(d=>{const x=new Date(run);x.setDate(x.getDate()+d);return x;});
  const dayLabel=d=>d===0?'Today':d===1?'Tomorrow':`Day ${d+1}`;
  const allRiskTypes=RISK_TYPES.map(rt=>rt.id);

  return(
    <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:8}}>
      {[0,1,2,3].map(d=>{
        const date=dates[d];
        const wd=date.toLocaleDateString(undefined,{weekday:'long'});
        const dd=date.toLocaleDateString(undefined,{day:'numeric',month:'short'});
        const score=summary?.[d]?.[riskType]??null;
        const lvl=score==null?null:scoreToLevel(score);
        const dotColor=lvl?RISK_COLOR(lvl,riskType):'#475569';
        const fillColor=lvl?RISK_FILL(lvl,riskType):'transparent';
        const borderColor=lvl?RISK_BORDER(lvl,riskType):t.cardBorder;
        const isActive=value===d;
        const miniRisks=allRiskTypes.map(rt=>{const s=summary?.[d]?.[rt]??0;return{id:rt,score:s,color:RISK_TYPES.find(x=>x.id===rt)?.color||'#38bdf8'};});

        return(
          <motion.button key={d} onClick={()=>onChange(d)}
            whileHover={{y:-2}} whileTap={{scale:0.98}}
            style={{flex:'1 1 auto',minWidth:0,padding:'12px 12px',borderRadius:14,textAlign:'left',cursor:'pointer',transition:'all .2s',background:isActive?`linear-gradient(135deg, ${fillColor===fillColor?fillColor:'rgba(255,255,255,0.03)'}, rgba(167,139,250,0.12))`:'rgba(255,255,255,0.025)',border:`2px solid ${isActive?dotColor:t.cardBorder}`,boxShadow:isActive?`0 0 20px ${dotColor}25`:'none',position:'relative',overflow:'hidden'}}>
            {isActive&&<div style={{position:'absolute',top:0,left:0,right:0,height:3,background:`linear-gradient(90deg,${dotColor},${dotColor}88)`,borderRadius:'14px 14px 0 0'}}/>}
            <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',gap:8}}>
              <div>
                <div style={{fontSize:'0.68rem',fontWeight:800,color:isActive?dotColor:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em',marginBottom:3}}>{dayLabel(d)}</div>
                <div style={{fontSize:'1rem',fontWeight:800,color:t.textPrimary,letterSpacing:'-0.01em'}}>{wd}</div>
                <div style={{fontSize:'0.72rem',color:t.textMuted,marginTop:1}}>{dd}</div>
              </div>
              {lvl&&lvl!=='No Risk'&&(
                <div style={{textAlign:'right',flexShrink:0}}>
                  <div style={{display:'inline-flex',alignItems:'center',gap:5,padding:'4px 10px',borderRadius:99,background:fillColor,border:`1.5px solid ${borderColor}`,marginBottom:4}}>
                    <span style={{width:7,height:7,borderRadius:99,background:dotColor,boxShadow:`0 0 8px ${dotColor}`}}/>
                    <span style={{fontSize:'0.7rem',fontWeight:800,color:dotColor==='#000000'?t.textPrimary:dotColor}}>{lvl}</span>
                  </div>
                  <div style={{fontSize:'0.7rem',fontWeight:800,color:t.textPrimary,fontFamily:"'DM Mono',monospace",textAlign:'right'}}>{score}</div>
                </div>
              )}
              {(lvl==='No Risk'||!lvl)&&(
                <div style={{padding:'4px 8px',borderRadius:8,background:'rgba(255,255,255,0.03)',border:`1px solid ${t.cardBorder}`}}>
                  <span style={{fontSize:'0.68rem',fontWeight:600,color:t.textMuted}}>Quiet</span>
                </div>
              )}
            </div>
            <div style={{marginTop:10,display:'flex',flexDirection:'column',gap:4}}>
              {miniRisks.map(mr=>{
                return(
                  <div key={mr.id} style={{display:'flex',alignItems:'center',gap:6}}>
                    <span style={{fontSize:'0.55rem',fontWeight:700,color:t.textMuted,width:20,textAlign:'right',textTransform:'uppercase',letterSpacing:'0.04em'}}>{RISK_TYPES.find(x=>x.id===mr.id)?.shortLabel}</span>
                    <div style={{flex:1,height:3,background:'rgba(255,255,255,0.05)',borderRadius:99,overflow:'hidden'}}>
                      <div style={{width:`${mr.score}%`,height:'100%',background:mr.color,borderRadius:99,transition:'width 0.6s ease'}}/>
                    </div>
                    <span style={{fontSize:'0.55rem',fontFamily:"'DM Mono',monospace",color:mr.score>10?mr.color:t.textMuted,width:20}}>{Math.round(mr.score)}</span>
                  </div>
                );
              })}
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}

// ── Risk legend ───────────────────────────────────────────────────────────────
function RiskLegend({riskType}){
  const{t}=useTCMTheme();const[open,setOpen]=useState(false);
  const typeLabel=RISK_TYPES.find(rt=>rt.id===riskType)?.label||'Thunderstorm';
  return(
    <Card style={{padding:14,marginBottom:20}}>
      <div onClick={()=>setOpen(o=>!o)} style={{display:'flex',alignItems:'center',gap:10,cursor:'pointer',userSelect:'none'}}>
        <Layers style={{width:16,height:16,color:'#a78bfa'}}/>
        <span style={{fontSize:'0.85rem',fontWeight:700,color:t.textPrimary}}>{typeLabel} Risk Level Guide</span>
        <div style={{flex:1}}/>
        <ChevronDown style={{width:16,height:16,color:t.textMuted,transform:open?'rotate(180deg)':'none',transition:'transform .2s'}}/>
      </div>
      <div style={{display:'flex',flexWrap:'wrap',gap:8,marginTop:12}}>
        {RISK_META.filter(r=>r.level!=='No Risk').map(r=>{const c=RISK_COLOR(r.level,riskType),f=RISK_FILL(r.level,riskType),b=RISK_BORDER(r.level,riskType);return(
          <div key={r.level} style={{display:'flex',alignItems:'center',gap:6,padding:'5px 10px',background:f,border:`2px solid ${b}`,borderRadius:99,fontSize:'0.7rem',fontWeight:700,color:c==='#000000'?t.textPrimary:c}}>
            <span style={{width:8,height:8,borderRadius:99,background:c}}/>{r.level}
          </div>
        );})}
      </div>
      <AnimatePresence>
        {open&&(
          <motion.div initial={{opacity:0,height:0}} animate={{opacity:1,height:'auto'}} exit={{opacity:0,height:0}} style={{overflow:'hidden',marginTop:12}}>
            <div style={{display:'flex',flexDirection:'column',gap:8}}>
              {RISK_META.filter(r=>r.level!=='No Risk').map(r=>(
                <div key={r.level} style={{display:'flex',gap:10,alignItems:'flex-start',padding:'8px 10px',background:'rgba(255,255,255,0.02)',border:`1px solid ${t.cardBorder}`,borderRadius:8}}>
                  <span style={{width:14,height:14,borderRadius:4,background:RISK_FILL(r.level,riskType),border:`2px solid ${RISK_BORDER(r.level,riskType)}`,flexShrink:0,marginTop:2}}/>
                  <div>
                    <div style={{fontSize:'0.78rem',fontWeight:700,color:RISK_COLOR(r.level,riskType)==='#000000'?t.textPrimary:RISK_COLOR(r.level,riskType)}}>{r.level} <span style={{fontFamily:"'DM Mono',monospace",color:t.textMuted,fontSize:'0.65rem',fontWeight:600}}>{fmtRange(r.level)}</span></div>
                    <div style={{fontSize:'0.72rem',color:t.textSecondary,marginTop:2,lineHeight:1.5}}>{descFor(riskType,r.level)}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

// ── Hamburger nav ─────────────────────────────────────────────────────────────
function Hamburger(){
  const[open,setOpen]=useState(false);
  const{lightMode,toggle}=useTCMTheme();
  useEffect(()=>{const k=e=>{if(e.key==='Escape')setOpen(false);};window.addEventListener('keydown',k);return()=>window.removeEventListener('keydown',k);},[]);
  const items=[{id:'home',label:'Home',icon:Home,color:'#34d399',accent:'rgba(52,211,153,0.12)',href:'/'},{id:'tcm',label:'TCM Page',icon:CloudLightning,color:'#a78bfa',accent:'rgba(167,139,250,0.12)',href:'/TCM'},{id:'admin',label:'Admin Settings',icon:ShieldAlert,color:'#f59e0b',accent:'rgba(245,158,11,0.12)',href:'/AdminSettings'}];
  return(<>
    <motion.button onClick={()=>setOpen(o=>!o)} whileTap={{scale:0.92}} style={{position:'fixed',top:20,left:20,zIndex:51,width:46,height:46,borderRadius:14,background:open?'rgba(15,23,42,0.95)':'rgba(15,23,42,0.75)',border:`1px solid ${open?'rgba(56,189,248,0.35)':'rgba(255,255,255,0.1)'}`,backdropFilter:'blur(16px)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer'}}>
      <AnimatePresence mode="wait">
        {open?<motion.div key="x" initial={{rotate:-90,opacity:0}} animate={{rotate:0,opacity:1}} exit={{rotate:90,opacity:0}}><X style={{width:18,height:18,color:'#38bdf8'}}/></motion.div>:<motion.div key="m" initial={{rotate:90,opacity:0}} animate={{rotate:0,opacity:1}} exit={{rotate:-90,opacity:0}}><Menu style={{width:18,height:18,color:'#94a3b8'}}/></motion.div>}
      </AnimatePresence>
    </motion.button>
    <AnimatePresence>
      {open&&(<>
        <motion.div initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={()=>setOpen(false)} style={{position:'fixed',inset:0,zIndex:40,background:'rgba(2,6,15,0.7)',backdropFilter:'blur(6px)'}}/>
        <motion.div initial={{x:-340,opacity:0}} animate={{x:0,opacity:1}} exit={{x:-340,opacity:0}} transition={{duration:0.38,ease:[0.22,1,0.36,1]}} style={{position:'fixed',left:0,top:0,bottom:0,width:300,zIndex:50,background:'linear-gradient(180deg,#090f1e,#0d1525,#090f1e)',borderRight:'1px solid rgba(255,255,255,0.07)',display:'flex',flexDirection:'column',overflow:'hidden'}}>
          <div style={{padding:'28px 20px 18px',borderBottom:'1px solid rgba(255,255,255,0.05)'}}>
            <div style={{display:'flex',alignItems:'center',gap:11}}>
              <div style={{width:36,height:36,borderRadius:10,background:'linear-gradient(135deg,rgba(56,189,248,0.2),rgba(167,139,250,0.2))',border:'1px solid rgba(56,189,248,0.2)',display:'flex',alignItems:'center',justifyContent:'center'}}><CloudLightning style={{width:17,height:17,color:'#38bdf8'}}/></div>
              <div><p style={{margin:0,fontSize:'0.95rem',fontWeight:700,color:'#f1f5f9'}}>Navigation</p><p style={{margin:0,fontSize:'0.62rem',fontWeight:600,color:'rgba(255,255,255,0.2)',textTransform:'uppercase'}}>MyWeatherUK</p></div>
            </div>
          </div>
          <div style={{flex:1,overflowY:'auto',padding:'12px 8px'}}>
            {items.map((it,i)=>{const I=it.icon;return(
              <motion.a key={it.id} href={it.href} initial={{opacity:0,x:-28}} animate={{opacity:1,x:0}} transition={{delay:0.06+i*0.055,duration:0.38}} whileHover={{x:4}} onClick={()=>setOpen(false)} style={{display:'flex',alignItems:'center',gap:13,padding:'11px 14px 11px 18px',borderRadius:14,cursor:'pointer',marginBottom:4,textDecoration:'none'}}>
                <div style={{width:34,height:34,borderRadius:10,background:it.accent,border:`1px solid ${it.color}40`,display:'flex',alignItems:'center',justifyContent:'center'}}><I style={{width:15,height:15,color:it.color}}/></div>
                <span style={{fontSize:'0.85rem',fontWeight:600,color:'#94a3b8',flex:1}}>{it.label}</span>
                <ChevronRight style={{width:13,height:13,color:'#64748b'}}/>
              </motion.a>
            );})}
            <div style={{height:1,background:'rgba(255,255,255,0.05)',margin:'10px 6px'}}/>
            <motion.button initial={{opacity:0,x:-28}} animate={{opacity:1,x:0}} transition={{delay:0.24,duration:0.38}} whileHover={{x:4}} onClick={toggle} style={{width:'100%',display:'flex',alignItems:'center',gap:13,padding:'11px 14px 11px 18px',borderRadius:14,cursor:'pointer',background:'transparent',border:'none',textAlign:'left'}}>
              <div style={{width:34,height:34,borderRadius:10,background:lightMode?'rgba(250,204,21,0.12)':'rgba(56,189,248,0.12)',border:`1px solid ${lightMode?'rgba(250,204,21,0.4)':'rgba(56,189,248,0.4)'}`,display:'flex',alignItems:'center',justifyContent:'center'}}>
                {lightMode?<Moon style={{width:15,height:15,color:'#38bdf8'}}/>:<Sun style={{width:15,height:15,color:'#facc15'}}/>}
              </div>
              <span style={{fontSize:'0.85rem',fontWeight:600,color:'#94a3b8',flex:1}}>{lightMode?'Dark Mode':'Light Mode'}</span>
            </motion.button>
          </div>
          <div style={{padding:'14px 20px',borderTop:'1px solid rgba(255,255,255,0.05)'}}><p style={{margin:0,fontSize:'0.62rem',fontWeight:600,color:'rgba(255,255,255,0.15)',letterSpacing:'0.1em',textTransform:'uppercase',textAlign:'center'}}>Thunderstorm Convection Model</p></div>
        </motion.div>
      </>)}
    </AnimatePresence>
  </>);
}

// ── Risk narrative helpers ────────────────────────────────────────────────────
function getThreatNarrative(riskType,level,sub,ranges,coverage,peakHrs,regionLabel,dayLabel){
  const regionShort=regionLabel?.split(' ')[0]||'the region';
  const narratives={
    thunderstorm:{
      'No Risk':`${regionShort} remains quiet ${dayLabel.toLowerCase()}. Stable airmass expected.`,
      'Thunderstorms':`Isolated thunderstorms possible ${dayLabel.toLowerCase()}, particularly near ${peakHrs}. CAPE is marginal at ${ranges?.cape?.max||0} J/kg.`,
      'Marginal':`A few isolated storms possible across parts of ${regionShort} ${dayLabel.toLowerCase()}. Instability modest (CAPE ${ranges?.cape?.max||0} J/kg). Peak activity ${peakHrs}.`,
      'Slight':`Organised storms possible across ${regionShort} ${dayLabel.toLowerCase()}. CAPE ${ranges?.cape?.min||0}–${ranges?.cape?.max||0} J/kg with shear ${ranges?.shear?.max||0} m/s support multicells. Peak ${peakHrs}.`,
      'Enhanced':`An active convective day expected for ${regionShort} ${dayLabel.toLowerCase()}. CAPE ${ranges?.cape?.max||0} J/kg, shear ${ranges?.shear?.max||0} m/s supports organised severe storms around ${peakHrs}.`,
      'Moderate':`Significant organised severe storm activity expected across ${regionShort} ${dayLabel.toLowerCase()}. Supercell potential with CAPE ${ranges?.cape?.max||0} J/kg around ${peakHrs}.`,
      'High':`Extreme severe weather outbreak forecast for ${regionShort} ${dayLabel.toLowerCase()}. Long-tracked supercells, destructive hail and significant tornadoes possible near ${peakHrs}. Take shelter.`
    },
    hail:{
      'No Risk':'No hail expected.',
      'Thunderstorms':'Small hail possible in isolated cells.',
      'Marginal':'Small hail (<10mm) possible.',
      'Slight':'Hail to 15–20mm possible.',
      'Enhanced':'Severe hail (20–40mm) likely.',
      'Moderate':'Large hail (40–60mm) likely from supercells.',
      'High':'Giant hail (>60mm) possible from long-tracked supercells.'
    },
    tornado:{
      'No Risk':'No tornado threat.',
      'Thunderstorms':'Tornado not expected.',
      'Marginal':'Isolated weak tornado not impossible.',
      'Slight':'Brief weak tornado possible in stronger storms.',
      'Enhanced':'Localised T1–T2 tornado possible.',
      'Moderate':'Organised T2–T3 tornado possible from supercells.',
      'High':'Strong T3–T4 tornado possible.'
    },
    lightning:{
      'No Risk':'No lightning expected.',
      'Thunderstorms':'Isolated lightning possible.',
      'Marginal':'Scattered lightning with occasional CG strikes.',
      'Slight':'Frequent lightning likely under stronger cells.',
      'Enhanced':'Widespread, frequent lightning. High strike density.',
      'Moderate':'Very frequent lightning. Elevated strike density.',
      'High':'Extreme lightning rates. Exceptional strike density.'
    }
  };
  return narratives[riskType]?.[level]||descFor(riskType,level);
}

function getMetOfficeWarningAdvice(level){
  const advice={
    'No Risk':{color:'#22c55e',badge:'No Warning',text:'No weather warning in force.',icon:CheckCircle},
    'Thunderstorms':{color:'#84cc16',badge:'Awareness',text:'Awareness message — isolated storms possible.',icon:Info},
    'Marginal':{color:'#facc15',badge:'Yellow Possible',text:'Yellow thunderstorm warning may be issued.',icon:AlertCircle},
    'Slight':{color:'#f97316',badge:'Yellow Likely',text:'Yellow weather warning for thunderstorms is likely.',icon:AlertTriangle},
    'Enhanced':{color:'#ef4444',badge:'Amber Likely',text:'Amber weather warning likely. Plan ahead.',icon:AlertTriangle},
    'Moderate':{color:'#dc2626',badge:'Red Possible',text:'Red weather warning possible. Widespread severe disruption.',icon:ShieldAlert},
    'High':{color:'#7c3aed',badge:'Red Warning',text:'Red weather warning likely. Extreme severe event. Take immediate precautions.',icon:ShieldAlert}
  };
  return advice[level]||advice['No Risk'];
}

function clamp(v,a,b){return Math.max(a,Math.min(b,v));}

function PercentBar({label,value,color,riskType='thunderstorm'}){
  const{t}=useTCMTheme();const lvl=scoreToLevel(value);const lvlColor=RISK_COLOR(lvl,riskType);
  return(<div style={{marginBottom:12}}><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}><span style={{fontSize:'0.8rem',fontWeight:600,color:t.textSecondary}}>{label}</span><span style={{display:'flex',alignItems:'center',gap:8}}><span style={{fontSize:'0.7rem',fontWeight:700,color:lvlColor}}>{lvl}</span><span style={{fontSize:'0.85rem',fontWeight:800,color:t.textPrimary,minWidth:42,textAlign:'right',fontFamily:"'DM Mono',monospace"}}>{value}/100</span></span></div><div style={{height:8,background:'rgba(255,255,255,0.05)',borderRadius:99,overflow:'hidden'}}><motion.div initial={{width:0}} animate={{width:`${value}%`}} transition={{duration:0.6,ease:[0.22,1,0.36,1]}} style={{height:'100%',background:`linear-gradient(90deg, ${color}, ${lvlColor})`,borderRadius:99}}/></div></div>);
}

function RangeRow({label,min,max,unit,color='#38bdf8',wholeMin=0,wholeMax=100}){
  const{t}=useTCMTheme();const span=wholeMax-wholeMin||1;const lo=clamp((min-wholeMin)/span,0,1)*100;const hi=clamp((max-wholeMin)/span,0,1)*100;
  return(<div style={{marginBottom:10}}><div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}}><span style={{fontSize:'0.78rem',color:t.textSecondary,fontWeight:600}}>{label}</span><span style={{fontSize:'0.74rem',color:t.textMuted,fontFamily:"'DM Mono',monospace"}}>{min} – {max} {unit}</span></div><div style={{position:'relative',height:6,background:'rgba(255,255,255,0.05)',borderRadius:99}}><div style={{position:'absolute',left:`${lo}%`,width:`${Math.max(2,hi-lo)}%`,height:'100%',background:`linear-gradient(90deg, ${color}, ${color}aa)`,borderRadius:99}}/></div></div>);
}

// DiurnalTimingSection lives in components/tcm/DiurnalTimingSection.jsx

// ── Day Overview ──────────────────────────────────────────────────────────────
function DayOverview({data,summary,riskType,regionLabel,dayLabel,dayIdx,run}){
  const{t,lightMode}=useTCMTheme();
  const[expanded,setExpanded]=useState({timing:true,atmos:true,hazards:true});
  const toggle=(k)=>setExpanded(e=>({...e,[k]:!e[k]}));

  const{peakStep,peakLocation}=useMemo(()=>{
    if(!data?.grid)return{peakStep:null,peakLocation:null};
    let bestScore=-1,bestStep=null,bestLat=null,bestLon=null;
    for(const p of data.grid){
      for(let s=dayIdx*STEPS_PER_DAY;s<(dayIdx+1)*STEPS_PER_DAY;s++){
        const sc=p.perStep?.[s]?.scores?.[riskType]??0;
        if(sc>bestScore){bestScore=sc;bestStep=s%STEPS_PER_DAY;bestLat=p.lat;bestLon=p.lon;}
      }
    }
    if(bestScore<3)return{peakStep:null,peakLocation:null};
    const reg=data.region?REGIONS[data.region]?.bbox:null;let bearing='central areas';
    if(reg){const cLat=(reg.latMin+reg.latMax)/2,cLon=(reg.lonMin+reg.lonMax)/2,dy=bestLat-cLat,dx=bestLon-cLon;const ns=dy>0.6?'northern':dy<-0.6?'southern':'central',ew=dx>0.5?'eastern':dx<-0.5?'western':'';bearing=(ns+(ns&&ew?' ':'')+ew+' '+regionLabel.split(' ')[0]).trim();}
    return{peakStep:bestStep,peakLocation:{lat:bestLat,lon:bestLon,bearing}};
  },[data,dayIdx,riskType]);

  if(!summary)return(<Section title="Day Overview" icon={Info}><p style={{margin:0,color:t.textMuted,fontSize:'0.86rem'}}>Forecast initialising — please wait.</p></Section>);

  const score=summary[riskType]??0;
  const level=scoreToLevel(score);
  const lvlColor=RISK_COLOR(level,riskType);
  const lvlFill=RISK_FILL(level,riskType);
  const lvlBorder=RISK_BORDER(level,riskType);
  const r=summary.ranges||{cape:{min:0,max:0},shear:{min:0,max:0},gust:{min:0,max:0},precip:{min:0,max:0},hailMm:{min:0,max:0}};
  const sub=summary.sub||{};
  const coverage=summary.totalCells?Math.round((summary.stormyCells/summary.totalCells)*100):0;
  const peakHrs=peakStep!=null?`${(peakStep*HOURS_PER_STEP).toString().padStart(2,'0')}–${(((peakStep*HOURS_PER_STEP)+HOURS_PER_STEP)%24).toString().padStart(2,'0')}Z`:'the afternoon';
  const warningAdvice=getMetOfficeWarningAdvice(level);
  const WarningIcon=warningAdvice.icon;
  const narrative=getThreatNarrative(riskType,level,sub,r,coverage,peakHrs,regionLabel,dayLabel);

  const prevScore=data?.summary?.[dayIdx-1]?.[riskType]??null;
  const TrendIcon=prevScore!=null?(score>prevScore?TrendingUp:score<prevScore?TrendingDown:Minus):null;
  const trendColor=prevScore!=null?(score>prevScore?'#ef4444':score<prevScore?'#22c55e':'#94a3b8'):'#94a3b8';

  const SectionToggle=({id,title,icon:Icon,iconColor,children})=>{
    const isOpen=expanded[id]??true;
    return(
      <div style={{border:`1px solid ${t.cardBorder}`,borderRadius:12,marginBottom:12,overflow:'hidden'}}>
        <div onClick={()=>toggle(id)} style={{display:'flex',alignItems:'center',gap:10,padding:'12px 16px',cursor:'pointer',background:isOpen?'rgba(255,255,255,0.03)':'transparent',userSelect:'none'}}>
          {Icon&&<Icon style={{width:15,height:15,color:iconColor||'#38bdf8',flexShrink:0}}/>}
          <span style={{fontSize:'0.82rem',fontWeight:700,color:t.textPrimary}}>{title}</span>
          <div style={{flex:1}}/><ChevronDown style={{width:14,height:14,color:t.textMuted,transform:isOpen?'rotate(180deg)':'none',transition:'transform .2s'}}/>
        </div>
        <AnimatePresence>
          {isOpen&&(<motion.div initial={{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}} transition={{duration:0.25}} style={{overflow:'hidden'}}><div style={{padding:'0 16px 14px'}}>{children}</div></motion.div>)}
        </AnimatePresence>
      </div>
    );
  };

  const MiniBar=({label,value,max=100,color='#38bdf8',unit=''})=>(
    <div style={{marginBottom:8}}>
      <div style={{display:'flex',justifyContent:'space-between',marginBottom:3}}>
        <span style={{fontSize:'0.74rem',color:t.textSecondary,fontWeight:600}}>{label}</span>
        <span style={{fontSize:'0.74rem',color:t.textPrimary,fontWeight:700,fontFamily:"'DM Mono',monospace"}}>{value}{unit}</span>
      </div>
      <div style={{height:5,background:'rgba(255,255,255,0.05)',borderRadius:99}}>
        <motion.div initial={{width:0}} animate={{width:`${Math.min(100,(value/max)*100)}%`}} transition={{duration:0.7,ease:[0.22,1,0.36,1]}} style={{height:'100%',background:`linear-gradient(90deg,${color}99,${color})`,borderRadius:99}}/>
      </div>
    </div>
  );

  const DataPill=({label,value,color='#38bdf8'})=>(
    <div style={{padding:'8px 12px',background:'rgba(255,255,255,0.03)',border:`1px solid ${t.cardBorder}`,borderRadius:10,flex:'1 1 auto',minWidth:90}}>
      <div style={{fontSize:'0.56rem',fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em',fontFamily:"'DM Mono',monospace"}}>{label}</div>
      <div style={{fontSize:'0.95rem',fontWeight:800,color,fontFamily:"'DM Mono',monospace",marginTop:2}}>{value}</div>
    </div>
  );

  return(
    <Card style={{padding:0,marginBottom:20,overflow:'hidden'}}>
      <div style={{background:`linear-gradient(135deg, ${lvlFill}, rgba(15,23,42,0.5))`,borderBottom:`1px solid ${lvlBorder}`,padding:'20px 22px'}}>
        <div style={{display:'flex',alignItems:'flex-start',gap:14,flexWrap:'wrap'}}>
          <div style={{flex:1,minWidth:200}}>
            <div style={{display:'flex',alignItems:'center',gap:10,flexWrap:'wrap',marginBottom:8}}>
              <span style={{display:'inline-flex',alignItems:'center',gap:6,padding:'5px 12px',borderRadius:99,background:lvlFill,border:`2px solid ${lvlBorder}`,fontSize:'0.78rem',fontWeight:800,color:lvlColor==='#000000'?t.textPrimary:lvlColor}}>
                <span style={{width:8,height:8,borderRadius:99,background:lvlColor,boxShadow:`0 0 10px ${lvlColor}`}}/>
                {level}
              </span>
              <span style={{fontSize:'0.76rem',fontWeight:700,color:t.textMuted,fontFamily:"'DM Mono',monospace"}}>Score: {score}/100</span>
              {TrendIcon&&<span style={{display:'flex',alignItems:'center',gap:4,fontSize:'0.72rem',fontWeight:700,color:trendColor}}><TrendIcon style={{width:13,height:13}}/></span>}
            </div>
            <h2 style={{margin:'0 0 6px',fontSize:'1.05rem',fontWeight:800,color:t.textPrimary,letterSpacing:'-0.01em'}}>
              {RISK_TYPES.find(tt=>tt.id===riskType)?.label} Risk · {regionLabel} · {dayLabel}
            </h2>
            <p style={{margin:'0 0 8px',fontSize:'0.8rem',color:t.textSecondary,lineHeight:1.55}}>{narrative}</p>
            {score>=10&&<p style={{margin:0,fontSize:'0.78rem',color:t.textSecondary,lineHeight:1.55,borderTop:`1px solid rgba(255,255,255,0.06)`,paddingTop:8}}>
              {riskType==='thunderstorm'&&`Primary hazards include${sub.hail>=20?` large hail (${r.hailMm?.max||0}mm likely),`:''} ${sub.strongWinds>=15?`damaging gusts (${r.gust?.max||0} mph),`:''} ${sub.flashFlood>=15?'flash flooding potential,':''} ${sub.tornado>=10?'an isolated tornado cannot be ruled out,':''} and frequent lightning. Coverage ~${coverage}% of ${regionLabel.split(' ')[0]}. CAPE ${r.cape?.min||0}–${r.cape?.max||0} J/kg, bulk shear ${r.shear?.min||0}–${r.shear?.max||0} m/s.`}
              {riskType==='hail'&&`Hail potential up to ${r.hailMm?.max||0}mm diameter. ${sub.hail>=50?'Large hail impacts on vehicles and property likely.':'Smaller hail possible; unlikely to cause widespread damage.'} CAPE ${r.cape?.max||0} J/kg supports deep convective cores.`}
              {riskType==='tornado'&&`Tornado threat driven by ${r.shear?.max||0} m/s bulk shear and helicity. ${sub.supercell>=30?'Supercell development likely.':'Quasi-linear convective systems (QLCSs) more probable.'} CAPE environment: ${r.cape?.max||0} J/kg.`}
              {riskType==='lightning'&&`Lightning Activity Index ~${Math.round((summary.lightning??0)*coverage/100*0.8)}. Peak strike density expected ${peakHrs} over ${peakLocation?.bearing||'central areas'}.`}
            </p>}
          </div>
        </div>
      </div>

      <div style={{padding:'16px 20px'}}>
        <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:16}}>
          <DataPill label="Peak CAPE" value={`${r.cape?.max||0}`} color="#ef4444"/>
          <DataPill label="Bulk Shear" value={`${r.shear?.max||0}m/s`} color="#38bdf8"/>
          <DataPill label="Max Gust" value={`${r.gust?.max||0}mph`} color="#a78bfa"/>
          <DataPill label="Coverage" value={`~${coverage}%`} color="#22c55e"/>
          <DataPill label="Hail" value={`${r.hailMm?.max||0}mm`} color="#7dd3fc"/>
          <DataPill label="Rain Rate" value={`${r.precip?.max||0}mm/h`} color="#0ea5e9"/>
          <DataPill label="LAI" value={`${Math.round((summary.lightning??0)*coverage/100*0.8)}`} color="#fbbf24"/>
        </div>

        <div style={{display:'flex',alignItems:'flex-start',gap:12,padding:'12px 14px',background:'rgba(15,23,42,0.4)',border:`1.5px solid ${warningAdvice.color==='#000000'?'rgba(255,255,255,0.3)':warningAdvice.color+'44'}`,borderRadius:10,marginBottom:16}}>
          <WarningIcon style={{width:18,height:18,color:warningAdvice.color==='#000000'?t.textPrimary:warningAdvice.color,flexShrink:0,marginTop:1}}/>
          <div>
            <span style={{display:'inline-block',padding:'2px 8px',borderRadius:6,fontSize:'0.68rem',fontWeight:800,background:`${warningAdvice.color==='#000000'?'rgba(255,255,255,0.1)':warningAdvice.color+'22'}`,color:warningAdvice.color==='#000000'?t.textPrimary:warningAdvice.color,marginBottom:4}}>{warningAdvice.badge}</span>
            <p style={{margin:0,fontSize:'0.78rem',color:t.textSecondary,lineHeight:1.5}}>{warningAdvice.text}</p>
          </div>
        </div>

        {/* ── IMPROVED TIMING SECTION ─────────────────────────────────── */}
        <SectionToggle id="timing" title="Timing & Diurnal Pattern" icon={Clock} iconColor="#38bdf8">
          <DiurnalTimingSection
            data={data}
            dayIdx={dayIdx}
            riskType={riskType}
            peakStep={peakStep}
            peakLocation={peakLocation}
            summary={summary}
          />
        </SectionToggle>

        <SectionToggle id="atmos" title="Atmospheric Environment" icon={BarChart2} iconColor="#a78bfa">
          <div style={{display:'grid',gridTemplateColumns:'minmax(0,1fr) minmax(0,1fr)',gap:16,paddingTop:8}}>
            <div>
              <h4 style={{margin:'0 0 10px',fontSize:'0.7rem',fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em'}}>Instability</h4>
              <MiniBar label="CAPE" value={r.cape?.max||0} max={3000} color="#ef4444" unit=" J/kg"/>
              <MiniBar label="CAPE Min" value={r.cape?.min||0} max={3000} color="#ef444455" unit=" J/kg"/>
            </div>
            <div>
              <h4 style={{margin:'0 0 10px',fontSize:'0.7rem',fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em'}}>Dynamics</h4>
              <MiniBar label="Bulk Shear" value={r.shear?.max||0} max={35} color="#38bdf8" unit=" m/s"/>
              <MiniBar label="Max Gusts" value={r.gust?.max||0} max={100} color="#a78bfa" unit=" mph"/>
            </div>
          </div>
        </SectionToggle>

        <SectionToggle id="hazards" title="Hazard Breakdown" icon={AlertTriangle} iconColor="#f97316">
          <div style={{display:'grid',gridTemplateColumns:'minmax(0,1fr) minmax(0,1fr)',gap:10,paddingTop:10}}>
            {[
              {id:'tornado',label:'Tornado',score:sub.tornado||0,color:'#f97316',icon:'🌪️'},
              {id:'hail',label:'Large Hail',score:sub.hail||0,color:'#38bdf8',icon:'🧊'},
              {id:'flashFlood',label:'Flash Flooding',score:sub.flashFlood||0,color:'#0ea5e9',icon:'💧'},
              {id:'strongWinds',label:'Strong Winds',score:sub.strongWinds||0,color:'#a78bfa',icon:'💨'},
              {id:'supercell',label:'Supercell',score:sub.supercell||0,color:'#dc2626',icon:'🌀'},
            ].map(h=>{
              const hlvl=scoreToLevel(h.score);
              return(
                <div key={h.id} style={{padding:'12px',background:'rgba(255,255,255,0.025)',border:`1px solid ${t.cardBorder}`,borderRadius:10}}>
                  <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
                    <span style={{fontSize:'1.1rem'}}>{h.icon}</span>
                    <span style={{fontSize:'0.78rem',fontWeight:700,color:t.textPrimary}}>{h.label}</span>
                    <span style={{marginLeft:'auto',fontSize:'0.68rem',fontWeight:700,color:h.score>5?h.color:t.textMuted,fontFamily:"'DM Mono',monospace"}}>{h.score}</span>
                  </div>
                  <div style={{height:5,background:'rgba(255,255,255,0.05)',borderRadius:99,marginBottom:6}}>
                    <motion.div initial={{width:0}} animate={{width:`${h.score}%`}} transition={{duration:0.7}} style={{height:'100%',background:`linear-gradient(90deg,${h.color}55,${h.color})`,borderRadius:99}}/>
                  </div>
                  <div style={{fontSize:'0.63rem',fontWeight:700,color:RISK_COLOR(hlvl,'thunderstorm')}}>{hlvl}</div>
                </div>
              );
            })}
          </div>
        </SectionToggle>

        <div style={{marginBottom:12}}>
          <div style={{fontSize:'0.7rem',fontWeight:700,color:t.textMuted,marginBottom:8,textTransform:'uppercase',letterSpacing:'0.08em'}}>4-Day Risk Trend</div>
          <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
            {[0,1,2,3].map(d=>{
              const ds=data?.summary?.[d]?.[riskType]??0;const dl=scoreToLevel(ds);const dc=RISK_COLOR(dl,riskType);const df=RISK_FILL(dl,riskType);const isThis=d===dayIdx;
              return(
                <div key={d} style={{flex:'1 1 auto',minWidth:70,padding:'10px',background:isThis?df:'rgba(255,255,255,0.025)',border:`2px solid ${isThis?dc:t.cardBorder}`,borderRadius:10,textAlign:'center'}}>
                  <div style={{fontSize:'0.60rem',color:t.textMuted,fontWeight:700}}>{d===0?'Today':d===1?'Tmw':`D${d+1}`}</div>
                  <div style={{fontSize:'1.1rem',fontWeight:800,color:dc,fontFamily:"'DM Mono',monospace",margin:'4px 0'}}>{Math.round(ds)}</div>
                  <div style={{fontSize:'0.60rem',fontWeight:700,color:dc}}>{dl}</div>
                </div>
              );
            })}
          </div>
        </div>

        <div style={{padding:'10px 14px',background:'rgba(255,255,255,0.02)',border:`1px solid ${t.cardBorder}`,borderRadius:8,display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
          <Database style={{width:13,height:13,color:t.textMuted,flexShrink:0}}/>
          <span style={{fontSize:'0.68rem',color:t.textMuted,lineHeight:1.4,flex:1}}>TCM blends ECMWF IFS, ECMWF EPS (51-member), UKMO Seamless (10km), UKV (2km) and AROME France (1.3km).</span>
          <span style={{fontSize:'0.62rem',fontFamily:"'DM Mono',monospace",color:t.textMuted,whiteSpace:'nowrap'}}>~{coverage}% · {summary.stormyCells||0} cells</span>
        </div>
      </div>
    </Card>
  );
}

function RiskDetail({summary}){
  const{t}=useTCMTheme();if(!summary)return null;const{sub,ranges}=summary;
  return(<Section title="Thunderstorm Risk Details" icon={AlertTriangle}><div style={{display:'grid',gridTemplateColumns:'minmax(0,1fr) minmax(0,1fr)',gap:24}}><div><h4 style={{margin:'0 0 12px',fontSize:'0.78rem',fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em'}}>Hazard Sub-Risks</h4><PercentBar label="Tornado" value={sub.tornado} color="#f97316"/><PercentBar label="Hail" value={sub.hail} color="#38bdf8"/><PercentBar label="Flash Flooding" value={sub.flashFlood} color="#0ea5e9"/><PercentBar label="Strong Winds" value={sub.strongWinds} color="#a78bfa"/><PercentBar label="Supercell" value={sub.supercell} color="#dc2626"/></div><div><h4 style={{margin:'0 0 12px',fontSize:'0.78rem',fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em'}}>Atmospheric Range</h4><RangeRow label="Wind Gusts" min={ranges.gust.min} max={ranges.gust.max} unit="mph" wholeMax={120} color="#a78bfa"/><RangeRow label="Rainfall" min={ranges.precip.min} max={ranges.precip.max} unit="mm/h" wholeMax={50} color="#0ea5e9"/><RangeRow label="Hail Diameter" min={ranges.hailMm?.min??0} max={ranges.hailMm?.max??0} unit="mm" wholeMax={70} color="#38bdf8"/><RangeRow label="CAPE" min={ranges.cape.min} max={ranges.cape.max} unit="J/kg" wholeMax={3000} color="#dc2626"/><RangeRow label="Shear" min={ranges.shear.min} max={ranges.shear.max} unit="m/s" wholeMax={30} color="#22c55e"/></div></div></Section>);
}

function Sounding({levels}){
  const{t}=useTCMTheme();if(!levels)return null;
  const w=320,h=280,tMin=-60,tMax=35,pMin=200,pMax=1000;
  const xT=tt=>((tt-tMin)/(tMax-tMin))*w;
  const yP=p=>h-((Math.log(p)-Math.log(pMin))/(Math.log(pMax)-Math.log(pMin)))*h;
  const tempPath=levels.filter(l=>l.temp!=null).map((l,i)=>`${i?'L':'M'}${xT(l.temp).toFixed(1)},${yP(l.pressure).toFixed(1)}`).join('');
  const dewPath=levels.filter(l=>l.dew!=null).map((l,i)=>`${i?'L':'M'}${xT(l.dew).toFixed(1)},${yP(l.pressure).toFixed(1)}`).join('');
  return(<div><svg width={w} height={h} style={{background:'rgba(0,0,0,0.4)',borderRadius:8}}>
    {[1000,850,700,500,300,200].map(p=>(<g key={p}><line x1={0} x2={w} y1={yP(p)} y2={yP(p)} stroke="rgba(255,255,255,0.07)" strokeWidth={0.5}/><text x={4} y={yP(p)-2} fontSize={9} fill={t.textMuted}>{p}</text></g>))}
    {[-40,-20,0,20].map(tt=>(<g key={tt}><line y1={0} y2={h} x1={xT(tt)} x2={xT(tt)} stroke="rgba(255,255,255,0.07)" strokeWidth={0.5}/><text y={h-4} x={xT(tt)+2} fontSize={9} fill={t.textMuted}>{tt}°</text></g>))}
    <path d={dewPath} fill="none" stroke="#22c55e" strokeWidth={2}/>
    <path d={tempPath} fill="none" stroke="#ef4444" strokeWidth={2}/>
    {levels.filter(l=>l.wspd!=null).map((l,i)=>{const y=yP(l.pressure);const len=Math.min(28,(l.wspd??0)*0.4);const dir=(l.wdir??0)*Math.PI/180;return(<line key={i} x1={w-25} y1={y} x2={w-25+Math.sin(dir)*len} y2={y-Math.cos(dir)*len} stroke="#94a3b8" strokeWidth={1}/>);})}
    <text x={8} y={14} fontSize={11} fontWeight={700} fill={t.textSecondary}>Sounding (T=red, Td=green)</text>
  </svg></div>);
}

function LocationPanel({data,riskType,dayIdx,run,point,onClose}){
  const{t}=useTCMTheme();
  const[sounding,setSounding]=useState(null);const[loadingSnd,setLoadingSnd]=useState(false);
  const nearest=useMemo(()=>{if(!point||!data?.grid)return null;let best=null,bd=Infinity;for(const p of data.grid){const d=(p.lat-point[0])**2+(p.lon-point[1])**2;if(d<bd){bd=d;best=p;}}return best;},[point,data]);
  useEffect(()=>{if(!point)return;setLoadingSnd(true);setSounding(null);fetchSounding(point[0],point[1],new Date(run.getTime()+dayIdx*86400_000),dayIdx).then(s=>{setSounding(s);setLoadingSnd(false);});},[point?.[0],point?.[1],dayIdx]);
  if(!point||!nearest)return null;const sc=nearest.perDay?.[dayIdx]?.scores;if(!sc)return null;
  const lvl=scoreToLevel(sc[riskType]??0);const m=sc.metrics;
  const Metric=({label,value})=>(<div style={{background:'rgba(255,255,255,0.03)',border:'1px solid rgba(255,255,255,0.06)',borderRadius:8,padding:'8px 10px'}}><div style={{fontSize:'0.62rem',color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em',fontWeight:700}}>{label}</div><div style={{fontSize:'0.85rem',color:t.textPrimary,fontWeight:700,fontFamily:"'DM Mono',monospace",marginTop:2}}>{value}</div></div>);
  return(
    <AnimatePresence>
      <motion.div initial={{opacity:0,x:340}} animate={{opacity:1,x:0}} exit={{opacity:0,x:340}} transition={{duration:0.32}} style={{position:'fixed',right:0,top:0,bottom:0,width:'min(420px,100vw)',zIndex:60,background:'linear-gradient(180deg,#0c1226,#070b18)',borderLeft:'1px solid rgba(255,255,255,0.07)',overflowY:'auto',padding:24}}>
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:18}}>
          <MapPin style={{width:18,height:18,color:RISK_COLOR(lvl,riskType)}}/>
          <div><h3 style={{margin:0,fontSize:'0.95rem',fontWeight:700,color:'#f1f5f9'}}>{point[0].toFixed(2)}°, {point[1].toFixed(2)}°</h3><p style={{margin:'2px 0 0',fontSize:'0.72rem',fontWeight:700,color:RISK_COLOR(lvl,riskType)}}>{lvl} {riskType}</p></div>
          <div style={{flex:1}}/>
          <button onClick={onClose} style={{padding:8,borderRadius:8,background:'rgba(255,255,255,0.05)',border:'1px solid rgba(255,255,255,0.1)',color:'#94a3b8',cursor:'pointer'}}><X style={{width:14,height:14}}/></button>
        </div>
        <p style={{color:'#cbd5e1',fontSize:'0.82rem',lineHeight:1.6,marginTop:0}}>CAPE {m.cape} J/kg · shear {m.shear} m/s · gusts {m.gust} mph · precip {m.precip} mm/h</p>
        <h4 style={{margin:'16px 0 8px',fontSize:'0.74rem',fontWeight:700,color:'#94a3b8',textTransform:'uppercase',letterSpacing:'0.08em'}}>All Risk Types</h4>
        {RISK_TYPES.map(rt=>{const s=sc[rt.id]??0;const l=scoreToLevel(s);return(<div key={rt.id} style={{marginBottom:10}}><div style={{display:'flex',justifyContent:'space-between',marginBottom:4}}><span style={{fontSize:'0.78rem',fontWeight:600,color:'#94a3b8',display:'flex',alignItems:'center',gap:6}}><rt.icon style={{width:13,height:13,color:rt.color}}/>{rt.label}</span><span style={{fontSize:'0.72rem',fontWeight:700,color:RISK_COLOR(l,rt.id)}}>{l} · {s}</span></div><div style={{height:5,background:'rgba(255,255,255,0.05)',borderRadius:99}}><div style={{width:`${s}%`,height:'100%',background:rt.color,borderRadius:99}}/></div></div>);})}
        <h4 style={{margin:'16px 0 8px',fontSize:'0.74rem',fontWeight:700,color:'#94a3b8',textTransform:'uppercase',letterSpacing:'0.08em'}}>Atmospheric Metrics</h4>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}><Metric label="CAPE" value={`${m.cape} J/kg`}/><Metric label="LI" value={m.li}/><Metric label="Shear 0-6" value={`${m.shear} m/s`}/><Metric label="Gusts" value={`${m.gust} mph`}/></div>
        <h4 style={{margin:'18px 0 8px',fontSize:'0.74rem',fontWeight:700,color:'#94a3b8',textTransform:'uppercase',letterSpacing:'0.08em'}}>Sounding</h4>
        {loadingSnd?<div style={{display:'flex',alignItems:'center',gap:8,color:'#64748b',fontSize:'0.78rem'}}><Loader2 className="animate-spin" style={{width:14,height:14}}/> Loading…</div>:(sounding?<Sounding levels={sounding}/>:<p style={{color:'#64748b',fontSize:'0.78rem'}}>Sounding unavailable.</p>)}
      </motion.div>
    </AnimatePresence>
  );
}

function RunSelector({runs,value,onChange}){
  const{t}=useTCMTheme();const[open,setOpen]=useState(false);
  const groupByDay=useMemo(()=>{const m=new Map();for(const r of runs){const k=r.toISOString().slice(0,10);if(!m.has(k))m.set(k,[]);m.get(k).push(r);}return[...m.entries()];},[runs]);
  return(
    <div style={{position:'relative',zIndex:200}}>
      <button onClick={()=>setOpen(o=>!o)} style={{padding:'8px 12px',borderRadius:10,background:'rgba(255,255,255,0.04)',border:`1px solid ${t.cardBorder}`,color:t.textSecondary,fontSize:'0.74rem',fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
        <Clock style={{width:13,height:13}}/> Run: {fmtRun(value)} <ChevronDown style={{width:13,height:13,transform:open?'rotate(180deg)':'none',transition:'transform .2s'}}/>
      </button>
      <AnimatePresence>
        {open&&(<motion.div initial={{opacity:0,y:-6}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-6}} style={{position:'absolute',top:'calc(100% + 6px)',right:0,zIndex:9999,minWidth:240,background:'rgba(15,23,42,0.96)',backdropFilter:'blur(12px)',border:'1px solid rgba(255,255,255,0.1)',borderRadius:12,padding:8,maxHeight:320,overflowY:'auto',boxShadow:'0 12px 36px rgba(0,0,0,0.5)'}}>
          {groupByDay.map(([k,rs])=>(<div key={k} style={{marginBottom:6}}><div style={{fontSize:'0.62rem',fontWeight:700,color:'#64748b',padding:'4px 8px',textTransform:'uppercase',letterSpacing:'0.08em'}}>{new Date(k).toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'short'})}</div>{rs.map(r=>(<button key={r.toISOString()} onClick={()=>{onChange(r);setOpen(false);}} style={{width:'100%',padding:'6px 8px',textAlign:'left',background:value.getTime()===r.getTime()?'rgba(56,189,248,0.15)':'transparent',border:'none',borderRadius:6,color:value.getTime()===r.getTime()?'#38bdf8':'#cbd5e1',fontSize:'0.74rem',fontWeight:600,cursor:'pointer'}}>{r.getUTCHours().toString().padStart(2,'0')}Z UTC</button>))}</div>))}
        </motion.div>)}
      </AnimatePresence>
    </div>
  );
}

// ── Lightning strike persistence helpers ─────────────────────────────────────
const STRIKE_CACHE_KEY='tcm_lightning_strikes_today';
function loadTodayStrikes(bbox=null){
  try{
    const raw=localStorage.getItem(STRIKE_CACHE_KEY);
    if(!raw)return[];
    const parsed=JSON.parse(raw);
    const todayDate=new Date().toISOString().slice(0,10);
    if(parsed.date!==todayDate)return[];
    const strikes=parsed.strikes||[];
    if(!bbox)return strikes;
    return strikes.filter(s=>
      s.lat>=bbox.latMin&&s.lat<=bbox.latMax&&
      s.lon>=bbox.lonMin&&s.lon<=bbox.lonMax
    );
  }catch{return[];}
}
function saveTodayStrikes(strikes){
  try{
    const todayDate=new Date().toISOString().slice(0,10);
    const toSave=strikes.slice(-10000);
    localStorage.setItem(STRIKE_CACHE_KEY,JSON.stringify({date:todayDate,strikes:toSave}));
  }catch{}
}

// ═══════════════════════════════════════════════════════════════════════════
// LIGHTNING VERIFICATION — with selectable outlook layer per risk type & day
// ═══════════════════════════════════════════════════════════════════════════
function TCMLightningVerification({data,region,dayIdx}){
  const{t,lightMode}=useTCMTheme();
  const bbox=REGIONS[region].bbox;
  const gridStep=REGIONS[region].gridStep;

  const[strikes,setStrikes]=useState(()=>loadTodayStrikes(bbox));
  const[live,setLive]=useState(true);
  const[status,setStatus]=useState('idle');

  // Outlook layer controls
  const[outlookEnabled,setOutlookEnabled]=useState(true);
  const[outlookRiskType,setOutlookRiskType]=useState('lightning');
  const[outlookDayIdx,setOutlookDayIdx]=useState(dayIdx);

  // Sync outlookDayIdx when parent dayIdx changes (unless user manually changed it)
  const userChangedDay=useRef(false);
  useEffect(()=>{if(!userChangedDay.current)setOutlookDayIdx(dayIdx);},[dayIdx]);

  const freshRef=useRef(new Set());
  const nowRef=useRef(Date.now());

  const onStrike=useCallback((s)=>{
    freshRef.current.add(s.time);
    setTimeout(()=>freshRef.current.delete(s.time),90_000);
    setStrikes(prev=>{
      const todayStart=new Date();todayStart.setUTCHours(0,0,0,0);
      const next=[...prev.filter(x=>x.time>=todayStart.getTime()),s].slice(-5000);
      saveTodayStrikes(next);
      return next;
    });
  },[]);

  useBlitzortung({enabled:live,bbox,onStrike,onStatus:setStatus});

  // Seed UK & Ireland strikes from the reference snapshot ONCE, then load
  // historical strikes from backend on top.
  useEffect(()=>{
    if(region==='uk'){if(seedUKStrikesOnce())setStrikes(loadTodayStrikes(bbox));}
    (async()=>{
      try{
        const res=await db.functions.invoke('historicalLightning',{});
        if(res?.data?.ok&&res.data.strikes){
          const merged=[...loadTodayStrikes(),...res.data.strikes].slice(-10000);
          saveTodayStrikes(merged);
          setStrikes(merged.filter(s=>s.lat>=bbox.latMin&&s.lat<=bbox.latMax&&s.lon>=bbox.lonMin&&s.lon<=bbox.lonMax));
        }
      }catch(e){console.warn('[loadHistorical]',e?.message);}
    })();
  },[region]);

  useEffect(()=>{setStrikes(loadTodayStrikes(bbox));},[region]);
  useEffect(()=>{const id=setInterval(()=>{nowRef.current=Date.now();},1000);return()=>clearInterval(id);},[]);

  // One-time strike-driven outlook boost. Snapshots the boosted grid the first
  // time we have data+strikes for a given (data, risk type) and then locks it.
  // New strikes arriving afterwards do NOT re-adjust the outlook.
  const boostSnapshotRef=useRef({key:null,grid:null});
  const boostedGrid=useMemo(()=>{
    if(!data?.grid?.length)return data?.grid||[];
    if(outlookDayIdx!==0)return data.grid;
    if(outlookRiskType!=='thunderstorm'&&outlookRiskType!=='lightning')return data.grid;
    const key=`${data.builtAt||0}_${outlookRiskType}_${region}`;
    if(boostSnapshotRef.current.key===key&&boostSnapshotRef.current.grid)return boostSnapshotRef.current.grid;
    const now=Date.now();
    const recent=strikes.filter(s=>now-s.time<3*3600_000);
    if(!recent.length)return data.grid;
    const radius=Math.max(REGIONS[region].gridStep*1.2,0.6);
    const result=data.grid.map(p=>{
      let n=0;
      for(const s of recent){const dy=p.lat-s.lat,dx=p.lon-s.lon;if(dy*dy+dx*dx<=radius*radius)n++;}
      if(!n)return p;
      const boost=Math.min(85,Math.round(15*Math.log2(1+n)+5));
      const cloneScores=(sc)=>sc?{...sc,thunderstorm:Math.min(100,(sc.thunderstorm||0)+boost),lightning:Math.min(100,(sc.lightning||0)+boost)}:sc;
      return{...p,perDay:p.perDay?.map((d,i)=>i===0?{...d,scores:cloneScores(d.scores)}:d)};
    });
    boostSnapshotRef.current={key,grid:result};
    return result;
  // strikes intentionally excluded — snapshot once per data/risk/region
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[data,outlookDayIdx,outlookRiskType,region]);

  // Build outlook layers for selected risk type + day
  const outlookLayers=useMemo(()=>{
    if(!outlookEnabled||!boostedGrid?.length)return[];
    return buildOutlookLayers(boostedGrid,outlookRiskType,outlookDayIdx,gridStep,region);
  },[boostedGrid,region,outlookDayIdx,outlookRiskType,outlookEnabled]);

  const now=Date.now();
  const last30min=strikes.filter(s=>now-s.time<30*60*1000);
  const stats=useMemo(()=>{
    const total30=last30min.length;
    // Realistic LAI = strikes / minute / 1000 km². 1° lat ≈ 111 km, so
    // 1 deg² ≈ 111 × 111 × cos(lat) km². Use mid-lat for the bbox.
    const midLat=(bbox.latMin+bbox.latMax)/2;
    const areaKm2=(bbox.latMax-bbox.latMin)*111
                 *(bbox.lonMax-bbox.lonMin)*111*Math.cos(midLat*Math.PI/180);
    const lai=areaKm2>0?Math.round((total30/30)*1000/areaKm2*100)/100:0;
    if(!data?.grid?.length||!total30)return{total30,totalToday:strikes.length,inForecast:0,pct:0,lai};
    const reg=REGIONS[region];let inForecast=0;
    for(const s of last30min){let bestSc=0;for(const p of data.grid){if(Math.abs(p.lat-s.lat)>reg.gridStep||Math.abs(p.lon-s.lon)>reg.gridStep)continue;const sc=p.perDay?.[dayIdx]?.scores?.lightning??0;if(sc>bestSc)bestSc=sc;}if(bestSc>=8)inForecast++;}
    return{total30,totalToday:strikes.length,inForecast,pct:total30?Math.round(100*inForecast/total30):0,lai};
  },[last30min,strikes,data,region,dayIdx,bbox]);

  const statusColor={live:'#22c55e',connecting:'#eab308',reconnecting:'#eab308',error:'#dc2626',disabled:'#64748b',idle:'#64748b'}[status]||'#64748b';
  const mapHeight=Math.max(380,Math.min(620,typeof window!=='undefined'?window.innerHeight*0.6:520));

  return(
    <Section title="Lightning Verification — Live Strike Feed (Blitzortung)" icon={Zap}
      extra={<div style={{display:'flex',alignItems:'center',gap:8,flexWrap:'wrap'}}>
        <span style={{display:'inline-flex',alignItems:'center',gap:6,fontSize:'0.7rem',fontWeight:700,color:statusColor,fontFamily:"'DM Mono',monospace"}}>
          <span style={{width:7,height:7,borderRadius:99,background:statusColor,boxShadow:`0 0 8px ${statusColor}`}}/>
          {status.toUpperCase()}
        </span>
        <button onClick={()=>setLive(l=>!l)} style={{padding:'5px 9px',borderRadius:8,fontSize:'0.7rem',fontWeight:700,background:live?'rgba(220,38,38,0.15)':'rgba(34,197,94,0.15)',color:live?'#dc2626':'#22c55e',border:`1px solid ${live?'#dc2626':'#22c55e'}40`,display:'flex',alignItems:'center',gap:5,cursor:'pointer'}}>
          <Radio style={{width:11,height:11}}/> {live?'Disconnect':'Connect'}
        </button>
        <span style={{fontSize:'0.7rem',fontWeight:700,color:'#a78bfa',fontFamily:"'DM Mono',monospace"}}>{stats.total30} last 30m · {stats.totalToday} today · LAI {stats.lai}</span>
      </div>}
    >
      {/* ── Outlook layer controls ──────────────────────────────────────── */}
      <div style={{
        display:'flex', alignItems:'center', gap:10, flexWrap:'wrap',
        padding:'10px 14px', marginBottom:12,
        background: outlookEnabled
          ? (lightMode?'rgba(167,139,250,0.06)':'rgba(167,139,250,0.08)')
          : (lightMode?'rgba(0,0,0,0.03)':'rgba(255,255,255,0.02)'),
        border:`1px solid ${outlookEnabled?'rgba(167,139,250,0.28)':t.cardBorder}`,
        borderRadius:10
      }}>
        {/* Toggle */}
        <button
          onClick={()=>setOutlookEnabled(v=>!v)}
          style={{display:'flex',alignItems:'center',gap:7,padding:'5px 11px',borderRadius:8,
            fontSize:'0.72rem',fontWeight:700,cursor:'pointer',transition:'all .15s',
            background:outlookEnabled?'rgba(167,139,250,0.20)':'rgba(255,255,255,0.04)',
            color:outlookEnabled?'#a78bfa':t.textMuted,
            border:`1px solid ${outlookEnabled?'rgba(167,139,250,0.50)':t.inputBorder}`}}>
          <Layers style={{width:12,height:12}}/>
          Outlook Layer {outlookEnabled ? 'ON' : 'OFF'}
        </button>

        {outlookEnabled && (<>
          {/* Separator */}
          <div style={{width:1,height:22,background:t.cardBorder}}/>

          {/* Risk type selector */}
          <div style={{display:'flex',alignItems:'center',gap:4}}>
            <span style={{fontSize:'0.60rem',fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em',fontFamily:"'DM Mono',monospace"}}>Type</span>
            <div style={{display:'flex',gap:3}}>
              {RISK_TYPES.map(rt=>{
                const RIcon=rt.icon;
                return(
                  <button key={rt.id} onClick={()=>setOutlookRiskType(rt.id)}
                    title={rt.label}
                    style={{padding:'4px 8px',borderRadius:6,fontSize:'0.65rem',fontWeight:700,
                      display:'flex',alignItems:'center',gap:4,cursor:'pointer',
                      background:outlookRiskType===rt.id?`${rt.color}22`:'transparent',
                      color:outlookRiskType===rt.id?rt.color:t.textMuted,
                      border:`1px solid ${outlookRiskType===rt.id?rt.color+'55':t.inputBorder}`}}>
                    <RIcon style={{width:10,height:10}}/> {rt.shortLabel}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Separator */}
          <div style={{width:1,height:22,background:t.cardBorder}}/>

          {/* Day selector */}
          <div style={{display:'flex',alignItems:'center',gap:4}}>
            <span style={{fontSize:'0.60rem',fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em',fontFamily:"'DM Mono',monospace"}}>Day</span>
            <div style={{display:'flex',gap:3}}>
              {[0,1,2,3].map(d=>{
                const labels=['Today','Tmw','D3','D4'];
                const isActive=outlookDayIdx===d;
                // Get risk level for this day/type for colour hint
                const ds=data?.summary?.[d]?.[outlookRiskType]??0;
                const dl=scoreToLevel(ds);
                const dc=RISK_COLOR(dl,outlookRiskType);
                return(
                  <button key={d}
                    onClick={()=>{userChangedDay.current=true;setOutlookDayIdx(d);}}
                    style={{padding:'4px 8px',borderRadius:6,fontSize:'0.65rem',fontWeight:700,
                      cursor:'pointer',
                      background:isActive?`${dc}22`:'transparent',
                      color:isActive?dc:t.textMuted,
                      border:`1px solid ${isActive?dc+'55':t.inputBorder}`}}>
                    {labels[d]}
                    {ds>=3&&<span style={{marginLeft:3,fontSize:'0.52rem',opacity:0.7}}>{Math.round(ds)}</span>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Legend chips for active layers */}
          <div style={{display:'flex',gap:4,flexWrap:'wrap',marginLeft:'auto'}}>
            {outlookLayers.map(layer=>(
              <div key={layer.level} style={{display:'flex',alignItems:'center',gap:5,
                padding:'2px 7px',borderRadius:6,
                background:RISK_FILL(layer.level,outlookRiskType),
                border:`1.5px solid ${RISK_BORDER(layer.level,outlookRiskType)}`}}>
                <span style={{fontSize:'0.58rem',fontWeight:800,
                  color:RISK_COLOR(layer.level,outlookRiskType)==='#000000'?'#fff':RISK_COLOR(layer.level,outlookRiskType)}}>
                  {layer.level}
                </span>
              </div>
            ))}
            {outlookLayers.length===0&&(
              <span style={{fontSize:'0.60rem',color:t.textMuted,fontStyle:'italic'}}>No risk areas</span>
            )}
          </div>
        </>)}
      </div>

      {/* ── Map ──────────────────────────────────────────────────────────── */}
      <div style={{position:'relative'}}>
        <TCMLeafletBase bbox={bbox} height={mapHeight} lightMode={lightMode}>
          {({projector})=>{
            if(!projector)return null;
            const {x:w,y:h}=projector.size;const renderNow=Date.now();
            return(
              <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{position:'absolute',inset:0,pointerEvents:'none',zIndex:400}}>
                <defs>
                  <radialGradient id="strikeGlow"><stop offset="0%" stopColor="#fde68a" stopOpacity="1"/><stop offset="60%" stopColor="#f59e0b" stopOpacity="0.55"/><stop offset="100%" stopColor="#f59e0b" stopOpacity="0"/></radialGradient>
                  <filter id="ltg-ambient"><feGaussianBlur stdDeviation="10"/></filter>
                  <pattern id="ltg-severe-hatch" patternUnits="userSpaceOnUse" width="10" height="10" patternTransform="rotate(45)">
                   <line x1="0" y1="0" x2="0" y2="10" stroke="rgba(0,0,0,0.75)" strokeWidth="3"/>
                  </pattern>
                  <filter id="ltg-edge" x="-5%" y="-5%" width="110%" height="110%">
                    <feGaussianBlur stdDeviation="2" result="blur"/>
                    <feComposite in="SourceGraphic" in2="blur" operator="over"/>
                  </filter>
                </defs>

                {/* ── Outlook layer: main polygons with graduated opacity */}
                {outlookEnabled && outlookLayers.length > 0 && (
                  <g>
                    {outlookLayers.map((layer,li)=>
                      layer.clusters.map((cluster,ci)=>{
                        const d=clusterToPath(cluster,projector,gridStep);
                        if(!d)return null;
                        const lvlOpacity=(LEVEL_OPACITY[layer.level]??0.7)*0.75;
                        const isSev=layer.level==='Severe';
                        const isVLL2=['Very Low','Low'].includes(layer.level);
                        return(
                          <path key={`ltg-poly-${li}-${ci}`}
                            d={d}
                            fill={isSev?'url(#ltg-severe-hatch)':RISK_FILL(layer.level,outlookRiskType)}
                            stroke={RISK_BORDER(layer.level,outlookRiskType)}
                            strokeWidth={isSev?2.8:isVLL2?1.0:1.7}
                            strokeLinejoin="round"
                            strokeDasharray={isVLL2?'6,3':'none'}
                            opacity={lvlOpacity}
                          />
                        );
                      })
                    )}
                  </g>
                )}

                {/* ── Lightning strikes — plus-sign glyph, white in dark mode, black in light mode */}
                {(() => {
                  const strikeColor = lightMode ? '#000000' : '#ffffff';
                  return strikes.map((s,i)=>{
                    const[x,y]=projector.project(s.lat,s.lon);
                    const ageMs=renderNow-s.time;
                    const alpha=Math.max(0.10,1-ageMs/(3*3600_000));
                    const isFresh=freshRef.current.has(s.time);
                    return(<g key={`${s.time}_${i}`} opacity={alpha} transform={`translate(${x.toFixed(1)},${y.toFixed(1)})`}>
                      {isFresh&&<circle r={2} fill="none" stroke={strikeColor} strokeWidth={1.4}><animate attributeName="r" from="2" to="22" dur="0.8s" fill="freeze"/><animate attributeName="opacity" from="0.9" to="0" dur="0.8s" fill="freeze"/></circle>}
                      <line x1={-4} x2={4} y1={0} y2={0} stroke={strikeColor} strokeWidth={1.6} strokeLinecap="round"/>
                      <line y1={-4} y2={4} x1={0} x2={0} stroke={strikeColor} strokeWidth={1.6} strokeLinecap="round"/>
                    </g>);
                  });
                })()}

                <TitleCard w={Math.max(180,Math.min(360,w-260))} x={10} y={10}
                  title={`Lightning · ${REGIONS[region].label}`}
                  sub={`${stats.totalToday} strikes today · ${stats.total30} last 30m${outlookEnabled?` · ${RISK_TYPES.find(rt=>rt.id===outlookRiskType)?.label} D${outlookDayIdx+1} outlook`:''}`}/>
              </svg>
            );
          }}
        </TCMLeafletBase>
      </div>

      {/* Stats row */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(120px,1fr))',gap:8,marginTop:12}}>
        {[
          {label:'Today total',value:stats.totalToday,color:'#facc15'},
          {label:'Last 30 min',value:stats.total30,color:'#f59e0b'},
          {label:'In forecast',value:`${stats.pct}%`,color:'#22c55e'},
          {label:'LAI',value:stats.lai,color:'#a78bfa'},
        ].map(p=>(
          <div key={p.label} style={{padding:'8px 12px',background:'rgba(255,255,255,0.025)',border:`1px solid ${t.cardBorder}`,borderRadius:10}}>
            <div style={{fontSize:'0.58rem',fontWeight:700,color:t.textMuted,textTransform:'uppercase',letterSpacing:'0.08em',fontFamily:"'DM Mono',monospace"}}>{p.label}</div>
            <div style={{fontSize:'1.1rem',fontWeight:800,color:p.color,fontFamily:"'DM Mono',monospace",marginTop:2}}>{p.value}</div>
          </div>
        ))}
      </div>
    </Section>
  );
}

// ── Archive section ──────────────────────────────────────────────────────────
function TCMArchive({region}){
  const{t}=useTCMTheme();
  const[open,setOpen]=useState(false);
  const archive=useMemo(()=>{
    try{const raw=localStorage.getItem(`tcm_archive_${region}`);return raw?JSON.parse(raw):[];}catch{return[];}
  },[region,open]);

  if(!archive.length)return null;

  return(
    <Card style={{padding:0,marginBottom:20,overflow:'hidden'}}>
      <div onClick={()=>setOpen(o=>!o)} style={{display:'flex',alignItems:'center',gap:10,padding:'14px 18px',cursor:'pointer',userSelect:'none'}}>
        <Clock style={{width:16,height:16,color:'#a78bfa'}}/>
        <span style={{fontSize:'0.88rem',fontWeight:700,color:t.textPrimary}}>Archived Outlooks</span>
        <span style={{fontSize:'0.68rem',fontWeight:600,color:t.textMuted,marginLeft:4}}>{archive.length} day{archive.length!==1?'s':''}</span>
        <div style={{flex:1}}/>
        <ChevronDown style={{width:15,height:15,color:t.textMuted,transform:open?'rotate(180deg)':'none',transition:'transform .2s'}}/>
      </div>
      <AnimatePresence>
        {open&&(
          <motion.div initial={{height:0,opacity:0}} animate={{height:'auto',opacity:1}} exit={{height:0,opacity:0}} transition={{duration:0.28}} style={{overflow:'hidden'}}>
            <div style={{padding:'0 18px 16px',display:'flex',flexDirection:'column',gap:10}}>
              {archive.map((entry,i)=>{
                const lvlColor=RISK_COLOR(entry.level,'thunderstorm');
                const lvlFill=RISK_FILL(entry.level,'thunderstorm');
                const lvlBorder=RISK_BORDER(entry.level,'thunderstorm');
                return(
                  <div key={i} style={{background:'rgba(255,255,255,0.025)',border:`1px solid ${t.cardBorder}`,borderRadius:12,overflow:'hidden'}}>
                    <div style={{background:`linear-gradient(135deg,${lvlFill},transparent)`,borderBottom:`1px solid ${lvlBorder}`,padding:'10px 14px',display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
                      <div style={{display:'inline-flex',alignItems:'center',gap:6,padding:'3px 10px',borderRadius:99,background:lvlFill,border:`1.5px solid ${lvlBorder}`}}>
                        <span style={{width:6,height:6,borderRadius:99,background:lvlColor,boxShadow:`0 0 6px ${lvlColor}`}}/>
                        <span style={{fontSize:'0.7rem',fontWeight:800,color:lvlColor==='#000000'?t.textPrimary:lvlColor}}>{entry.level}</span>
                      </div>
                      <span style={{fontSize:'0.82rem',fontWeight:700,color:t.textPrimary}}>{new Date(entry.date).toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</span>
                      <span style={{fontSize:'0.65rem',fontFamily:"'DM Mono',monospace",color:t.textMuted,marginLeft:'auto'}}>{entry.region?.toUpperCase()} · Score {entry.score}/100</span>
                    </div>
                    <div style={{padding:'10px 14px'}}>
                      <p style={{margin:'0 0 6px',fontSize:'0.78rem',color:t.textSecondary,lineHeight:1.55}}>{entry.narrative}</p>
                      <p style={{margin:0,fontSize:'0.74rem',color:t.textMuted,lineHeight:1.5}}>{entry.hazardNote}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

function TCMOutlooksHero(){
  const{t,lightMode}=useTCMTheme();
  return(
    <motion.section initial={{opacity:0,y:-8}} animate={{opacity:1,y:0}} transition={{duration:0.5}} style={{position:'relative',overflow:'hidden',padding:'48px 20px 32px',textAlign:'center',background:lightMode?'linear-gradient(160deg, rgba(167,139,250,0.08), rgba(56,189,248,0.05))':'linear-gradient(160deg, rgba(167,139,250,0.18), rgba(56,189,248,0.10))',borderBottom:`1px solid ${t.cardBorder}`}}>
      <div aria-hidden style={{position:'absolute',inset:0,pointerEvents:'none',opacity:0.4,backgroundImage:'radial-gradient(circle at 20% 30%, rgba(167,139,250,0.25), transparent 40%), radial-gradient(circle at 80% 70%, rgba(56,189,248,0.20), transparent 40%)'}}/>
      <div style={{position:'relative',maxWidth:1100,margin:'0 auto'}}>
        <div style={{display:'inline-flex',alignItems:'center',gap:10,padding:'6px 14px',borderRadius:99,background:'rgba(167,139,250,0.12)',border:'1px solid rgba(167,139,250,0.3)',marginBottom:14}}>
          <CloudLightning style={{width:13,height:13,color:'#a78bfa'}}/>
          <span style={{fontSize:'0.66rem',fontWeight:700,color:'#a78bfa',letterSpacing:'0.12em',textTransform:'uppercase',fontFamily:"'DM Mono',monospace"}}>TCM Outlooks · 4-Day · 20 km</span>
        </div>
        <h1 style={{margin:0,fontSize:'clamp(1.8rem,4.5vw,2.8rem)',fontWeight:800,letterSpacing:'-0.025em',backgroundImage:'linear-gradient(120deg, #ff3b3b 0%, #ff9a1f 22%, #f5d04a 42%, #3fbf6b 60%, #3a8de8 80%, #8a48c4 100%)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',backgroundClip:'text',color:'transparent',fontFamily:"'DM Sans',system-ui,sans-serif"}}>Thunderstorm Convection Model</h1>
        <p style={{margin:'10px auto 0',maxWidth:620,color:t.textSecondary,fontSize:'0.92rem',lineHeight:1.55}}>4-day convective outlook for the UK &amp; Ireland and Europe, combining ECMWF IFS · ECMWF EPS · UKMO Seamless · UKV 2 km · AROME France HD.</p>
      </div>
    </motion.section>
  );
}

function DataProviderStatusBar({lightMode}){
  const{t}=useTCMTheme();
  const providers=[{id:'ecmwf',label:'ECMWF IFS',detail:'0.25°'},{id:'eps',label:'ECMWF EPS',detail:'51-member'},{id:'ukmo',label:'UKMO Seamless',detail:'10 km'},{id:'ukv',label:'UKV',detail:'2 km UK'},{id:'arome',label:'AROME',detail:'1.3 km'},{id:'om',label:'Open-Meteo',detail:'soundings'}];
  return(
    <div style={{borderBottom:`1px solid ${t.cardBorder}`,background:lightMode?'rgba(255,255,255,0.5)':'rgba(15,23,42,0.5)',backdropFilter:'blur(10px)'}}>
      <div style={{maxWidth:1200,margin:'0 auto',padding:'10px 20px',display:'flex',alignItems:'center',gap:14,overflowX:'auto',whiteSpace:'nowrap'}}>
        <div style={{display:'flex',alignItems:'center',gap:6,color:t.textMuted,fontSize:'0.62rem',fontWeight:700,letterSpacing:'0.1em',textTransform:'uppercase',fontFamily:"'DM Mono',monospace",flexShrink:0}}><Database style={{width:11,height:11}}/> Models</div>
        {providers.map(p=>(<div key={p.id} style={{display:'flex',alignItems:'center',gap:6,padding:'5px 10px',borderRadius:8,background:lightMode?'rgba(255,255,255,0.6)':'rgba(255,255,255,0.04)',border:`1px solid ${t.cardBorder}`,flexShrink:0}}><span style={{width:6,height:6,borderRadius:99,background:'#22c55e',boxShadow:'0 0 6px #22c55e'}}/><span style={{fontSize:'0.74rem',fontWeight:700,color:t.textPrimary}}>{p.label}</span><span style={{fontSize:'0.66rem',color:t.textMuted,fontFamily:"'DM Mono',monospace"}}>{p.detail}</span></div>))}
      </div>
    </div>
  );
}

export default function TCMPage(){
  return(<TCMThemeProvider><TCMLogoProvider><TCMPageContent/></TCMLogoProvider></TCMThemeProvider>);
}

function TCMPageContent(){
  const{t,lightMode}=useTCMTheme();
  const[region,setRegion]=useState(()=>{try{return localStorage.getItem('tcm_region')||'uk';}catch{return'uk';}});
  const[riskType,setRiskType]=useState('thunderstorm');
  const[dayIdx,setDayIdx]=useState(0);
  const[run,setRun]=useState(()=>utcRunForDate(new Date()));
  const[data,setData]=useState(null);const[loading,setLoading]=useState(false);const[progress,setProgress]=useState(0);
  const[clickPoint,setClickPoint]=useState(null);
  const[aiVerdict,setAiVerdict]=useState(null);
  const[aiLoading,setAiLoading]=useState(false);
  const[isAdmin,setIsAdmin]=useState(false);
  const[nextFetchMs,setNextFetchMs]=useState(()=>msUntilNextFetch(region));
  const allRuns=useMemo(()=>pastRuns(28),[]);

  useEffect(()=>{isCurrentUserAdmin().then(setIsAdmin);},[]);
  useEffect(()=>{
    const id=setInterval(()=>setNextFetchMs(msUntilNextFetch(region)),30_000);
    setNextFetchMs(msUntilNextFetch(region));
    return()=>clearInterval(id);
  },[region]);

  useEffect(()=>{try{localStorage.setItem('tcm_region',region);}catch{}},[region]);
  useEffect(()=>{pruneOldRuns();pruneOldForecastRuns();},[]);
  useEffect(()=>{
    let alive=true;setData(null);setLoading(true);setProgress(0);setAiVerdict(null);
    runTCM({region,run,onProgress:p=>{if(alive)setProgress(p);}})
      .then(p=>{if(alive){setData(p);setLoading(false);setProgress(1);}})
      .catch(()=>{if(alive)setLoading(false);});
    return()=>{alive=false;};
  },[region,run]);

  // AI authentication — verify the forecast with an LLM acting as a meteorologist.
  // Admin-only feature: skip the LLM call entirely for regular users.
  useEffect(()=>{
    if(!data?.summary)return;
    if(!isAdmin)return;
    let alive=true;
    setAiLoading(true);
    verifyForecastWithAI({
      payload:data,
      regionLabel:REGIONS[region].label,
      runISO:run.toISOString()
    })
      .then(v=>{if(alive)setAiVerdict(v);})
      .catch(e=>{if(alive)setAiVerdict({verdict:'FLAGGED',confidence:0,notes:`AI verification unavailable: ${e?.message||'error'}`,issues:[]});})
      .finally(()=>{if(alive)setAiLoading(false);});
    return()=>{alive=false;};
  },[data,region,run,isAdmin]);
  useEffect(()=>{const id=setInterval(()=>{const n=utcRunForDate(new Date());if(n.getTime()!==run.getTime())setRun(n);},60*1000);return()=>clearInterval(id);},[run]);

  useEffect(()=>{
    if(!data)return;
    const checkMidnight=()=>{
      const nowUtc=new Date();const todayStr=nowUtc.toISOString().slice(0,10);const archiveKey=`tcm_archive_${region}`;
      try{
        const existing=JSON.parse(localStorage.getItem(archiveKey)||'[]');
        const alreadyArchived=existing.some(e=>e.date===todayStr);
        if(!alreadyArchived&&data.summary?.[0]){
          const daySum=data.summary[0];const score=daySum[riskType]??0;const level=scoreToLevel(score);
          const r=daySum.ranges||{};const sub=daySum.sub||{};const coverage=daySum.totalCells?Math.round((daySum.stormyCells/daySum.totalCells)*100):0;
          const narrative=getThreatNarrative(riskType,level,sub,r,coverage,'peak hours',REGIONS[region].label,'Today');
          const hazardNote=score>=10?`Hazards: hail ${r.hailMm?.max||0}mm, gusts ${r.gust?.max||0}mph, CAPE ${r.cape?.max||0}J/kg, shear ${r.shear?.max||0}m/s, coverage ~${coverage}%.`:'Convectively quiet. No significant hazards expected.';
          const entry={date:todayStr,region,riskType,score,level,coverage,narrative,hazardNote,ranges:r,sub,builtAt:data.builtAt};
          const updated=[entry,...existing].slice(0,30);localStorage.setItem(archiveKey,JSON.stringify(updated));
        }
      }catch{}
    };
    checkMidnight();
    const now=new Date();const msToMidnight=(24-now.getUTCHours())*3600_000-now.getUTCMinutes()*60_000-now.getUTCSeconds()*1000;
    const tid=setTimeout(()=>{checkMidnight();},msToMidnight);return()=>clearTimeout(tid);
  },[data,region,riskType]);

  const dayLabels=['Today','Tomorrow',new Date(run.getTime()+2*86400_000).toLocaleDateString(undefined,{weekday:'long'}),new Date(run.getTime()+3*86400_000).toLocaleDateString(undefined,{weekday:'long'})];

  // Admin-only force refresh — bypasses the 6-hour fetch lock
  const handleRerun=()=>{
    if(!isAdmin){alert('Outlook data refreshes automatically every 6 hours. Manual refresh is restricted to administrators.');return;}
    setData(null);setLoading(true);
    runTCM({region,run,onProgress:setProgress,force:true})
      .then(p=>{setData(p);setLoading(false);setNextFetchMs(msUntilNextFetch(region));})
      .catch(()=>setLoading(false));
  };

  // Admin-only: force the AI fallback path (bypass Open-Meteo entirely)
  const handleRunAIFallback=async()=>{
    if(!isAdmin)return;
    setData(null);setLoading(true);setProgress(0);
    try{
      const reg=REGIONS[region];
      const omStep=region==='uk'?1.0:2.0;
      const payload=await fetchAIForecastFallback({
        bbox:reg.bbox,
        gridStep:omStep,
        run,
        regionLabel:reg.label,
        onProgress:setProgress,
      });
      payload.region=region;payload.run=run.toISOString();
      try{localStorage.setItem(tcmCacheKey(region),JSON.stringify(payload));}catch{}
      saveRunToCache(region,run,payload);
      setData(payload);
    }catch(e){
      console.error('[AI fallback]',e);
      alert(`AI fallback failed: ${e?.message||'unknown error'}`);
    }finally{
      setLoading(false);
    }
  };

  return(
    <div style={{minHeight:'100vh',background:t.pageBg,color:t.textSecondary,fontFamily:"'DM Sans',system-ui,sans-serif",transition:'background 0.3s ease'}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=DM+Mono:wght@500&display=swap');
        *{box-sizing:border-box}body{margin:0}
        ::-webkit-scrollbar{width:6px;height:6px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:rgba(148,163,184,0.2);border-radius:99px}
        .animate-spin{animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:0.3}}
        .tcm-region-switcher{position:fixed;top:20px;right:20px;z-index:50;display:flex;border-radius:12px;overflow:hidden;}
        .tcm-controls-row{display:flex;flex-wrap:wrap;gap:10px;align-items:center;}
        .tcm-risk-pills{display:flex;gap:6px;flex-wrap:wrap;}
        .tcm-controls-right{display:flex;align-items:center;gap:8px;margin-left:auto;flex-wrap:wrap;}
        .tcm-main-pad{max-width:1200px;margin:0 auto;padding:24px 16px 40px;}
        @media(min-width:640px){.tcm-main-pad{padding:40px 20px;}}
        @media(max-width:639px){
          .tcm-region-switcher{top:auto;bottom:80px;right:12px;left:12px;justify-content:center;}
          .tcm-region-switcher button{flex:1;text-align:center;padding:10px 8px!important;font-size:0.8rem!important;}
          .tcm-controls-row{flex-direction:column;align-items:stretch;}
          .tcm-risk-pills{justify-content:center;}
          .tcm-controls-right{justify-content:center;margin-left:0;}
          .tcm-day-title{font-size:1.5rem!important;}
        }
      `}</style>
      <Hamburger/>

      <div className="tcm-region-switcher" style={{border:`1px solid ${t.cardBorder}`,background:t.cardBg,backdropFilter:'blur(12px)'}}>
        {Object.values(REGIONS).map(r=>(<button key={r.id} onClick={()=>setRegion(r.id)} style={{padding:'8px 14px',fontSize:'0.74rem',fontWeight:700,color:region===r.id?'#0a0f1e':t.textSecondary,background:region===r.id?'linear-gradient(135deg,#a78bfa,#38bdf8)':'transparent',border:'none',cursor:'pointer',transition:'all .2s'}}>{r.flag} {r.label}</button>))}
      </div>

      <TCMOutlooksHero/>
      <DataProviderStatusBar lightMode={lightMode}/>

      <div className="tcm-main-pad">
        <motion.div initial={{opacity:0,y:-12}} animate={{opacity:1,y:0}} transition={{duration:0.4}} style={{marginBottom:20,textAlign:'center'}}>
          <h1 className="tcm-day-title" style={{margin:0,fontSize:'clamp(1.2rem,3.5vw,2rem)',fontWeight:700,letterSpacing:'-0.02em',background:lightMode?'linear-gradient(135deg,#0f172a,#475569)':'linear-gradient(135deg,#f1f5f9,#94a3b8)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>{REGIONS[region].label} · {RISK_TYPES.find(tt=>tt.id===riskType)?.label} Risk</h1>
          <p style={{margin:'6px 0 0',color:t.textMuted,fontSize:'0.78rem'}}>Run init {fmtRun(run)} · ECMWF + UKMO Seamless + UKV 2km + AROME</p>
        </motion.div>

        {/* Day selector */}
        <Card style={{padding:12,marginBottom:12,position:'relative',zIndex:99}}>
          <DaySelector value={dayIdx} onChange={setDayIdx} run={run} summary={data?.summary} riskType={riskType}/>
        </Card>

        <Card style={{padding:12,marginBottom:20,position:'relative',zIndex:100,overflow:'visible'}}>
          <div className="tcm-controls-row">
            <div className="tcm-risk-pills">
              {RISK_TYPES.map(tt=>{const Ic=tt.icon;return(
                <Pill key={tt.id} active={riskType===tt.id} onClick={()=>setRiskType(tt.id)} color={tt.color}>
                  <span style={{display:'inline-flex',alignItems:'center',gap:6}}><Ic style={{width:13,height:13}}/> {tt.label}</span>
                </Pill>
              );})}
            </div>
            <div className="tcm-controls-right">
              <RunSelector runs={allRuns} value={run} onChange={setRun}/>
              <span style={{padding:'8px 12px',borderRadius:10,background:'rgba(56,189,248,0.08)',border:'1px solid rgba(56,189,248,0.25)',color:'#38bdf8',fontSize:'0.7rem',fontWeight:700,fontFamily:"'DM Mono',monospace",display:'flex',alignItems:'center',gap:6}}>
                <Clock style={{width:11,height:11}}/> Next refresh: {formatRemaining(nextFetchMs)}
              </span>
              {isAdmin&&(
                <button onClick={handleRerun} title="Admin only — force refresh data from Open-Meteo Ensemble API" style={{padding:'8px 12px',borderRadius:10,background:'rgba(245,158,11,0.12)',border:'1px solid rgba(245,158,11,0.40)',color:'#f59e0b',fontSize:'0.74rem',fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
                  <RefreshCw style={{width:13,height:13}}/> Refresh Data (Admin)
                </button>
              )}
              {isAdmin&&(
                <button onClick={handleRunAIFallback} title="Admin only — generate forecast using AI (bypasses Open-Meteo entirely)" style={{padding:'8px 12px',borderRadius:10,background:'rgba(167,139,250,0.12)',border:'1px solid rgba(167,139,250,0.40)',color:'#a78bfa',fontSize:'0.74rem',fontWeight:700,cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
                  <Activity style={{width:13,height:13}}/> AI Fallback (Admin)
                </button>
              )}
            </div>
          </div>
        </Card>

        {loading&&(
          <Card style={{padding:18,marginBottom:20}}>
            <div style={{display:'flex',alignItems:'center',gap:12}}>
              <Loader2 className="animate-spin" style={{width:18,height:18,color:'#38bdf8'}}/>
              <div style={{flex:1}}>
                <div style={{fontSize:'0.82rem',fontWeight:700,color:t.textSecondary}}>Loading forecast data…</div>
                <div style={{fontSize:'0.68rem',color:t.textMuted,marginTop:2}}>Blending ECMWF + UKMO + AROME</div>
                <div style={{height:4,background:'rgba(255,255,255,0.05)',borderRadius:99,marginTop:8}}>
                  <motion.div animate={{width:`${Math.round(progress*100)}%`}} transition={{duration:0.3}} style={{height:'100%',background:'linear-gradient(90deg,#38bdf8,#a78bfa)',borderRadius:99}}/>
                </div>
              </div>
            </div>
          </Card>
        )}

        {data?.source==='ai-fallback'&&(
          <Card style={{padding:'10px 14px',marginBottom:14,border:'1px solid rgba(167,139,250,0.40)',background:'rgba(167,139,250,0.08)'}}>
            <div style={{display:'flex',alignItems:'center',gap:10,flexWrap:'wrap'}}>
              <Activity style={{width:14,height:14,color:'#a78bfa'}}/>
              <span style={{fontSize:'0.76rem',fontWeight:700,color:'#a78bfa'}}>AI Forecast Active</span>
              <span style={{fontSize:'0.68rem',color:t.textMuted}}>
                Generated by AI meteorologist · {data.aiAnchorsReturned ?? '–'}/{data.aiAnchorsRequested ?? '–'} anchors · {data.cellCount} cells
              </span>
              {data.synopticSummary&&<span style={{flexBasis:'100%',fontSize:'0.72rem',color:t.textSecondary,lineHeight:1.5,marginTop:4}}>{data.synopticSummary}</span>}
            </div>
          </Card>
        )}
        <RiskLegend riskType={riskType}/>
        {isAdmin&&<AIAuthCard verdict={aiVerdict} loading={aiLoading} tokens={t}/>}
        {isAdmin&&<TCMApiStatus tokens={t}/>}

        <MainMapSection
          data={data||{grid:[]}}
          region={region}
          riskType={riskType}
          dayIdx={dayIdx}
          run={run}
          onClickPoint={setClickPoint}
        />

        <DayOverview
          data={data}
          summary={data?.summary?.[dayIdx]}
          riskType={riskType}
          regionLabel={REGIONS[region].label}
          dayLabel={dayLabels[dayIdx]}
          dayIdx={dayIdx}
          run={run}
        />

        <TCMLightningVerification data={data} region={region} dayIdx={dayIdx}/>
        <RiskDetail summary={data?.summary?.[dayIdx]}/>
        <TCMArchive region={region}/>

        <div style={{textAlign:'center',padding:'20px 0',color:t.textMuted,fontSize:'0.7rem',fontFamily:"'DM Mono',monospace"}}>
          TCM · Built {data?.builtAt?new Date(data.builtAt).toLocaleString():'—'} · ECMWF · UKMO · AROME · MyWeatherUK
        </div>
      </div>
      <LocationPanel data={data} riskType={riskType} dayIdx={dayIdx} run={run} point={clickPoint} onClose={()=>setClickPoint(null)}/>
    </div>
  );
}