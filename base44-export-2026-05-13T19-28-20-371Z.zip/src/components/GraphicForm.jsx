const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import RichTextEditor from '@/components/RichTextEditor';
import { Switch } from "@/components/ui/switch";
import { Upload, X, Loader2, MapPin, Plus, Check } from 'lucide-react';

const IMPACT_LEVELS = ['Low', 'SLGT', 'Moderate', 'High'];
const IMPACT_CONFIG = {
  Low:      { active: 'bg-green-500 text-white border-green-500', inactive: 'border-green-500/50 text-green-400 hover:bg-green-500/10' },
  SLGT:     { active: 'bg-yellow-500 text-slate-900 border-yellow-500', inactive: 'border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10' },
  Moderate: { active: 'bg-orange-500 text-white border-orange-500', inactive: 'border-orange-500/50 text-orange-400 hover:bg-orange-500/10' },
  High:     { active: 'bg-red-500 text-white border-red-500', inactive: 'border-red-500/50 text-red-400 hover:bg-red-500/10' },
};

export default function GraphicForm({ graphic, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState({
    title: graphic?.title || '',
    description: graphic?.description || '',
    image_url: graphic?.image_url || '',
    is_featured: graphic?.is_featured || false,
    published: graphic?.published !== false,
    impact_level: graphic?.impact_level || '',
    impact_levels: graphic?.impact_levels || [],
    in_force_from: graphic?.in_force_from ? graphic.in_force_from.slice(0, 16) : '',
    expires_at: graphic?.expires_at ? graphic.expires_at.slice(0, 16) : '',
    locations_impacted: graphic?.locations_impacted || [],
    update_reason: '',
  });
  const [uploading, setUploading] = useState(false);
  const [locationInput, setLocationInput] = useState('');

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    setFormData(prev => ({ ...prev, image_url: file_url }));
    setUploading(false);
  };

  const addLocation = () => {
    const val = locationInput.trim();
    if (!val || formData.locations_impacted.includes(val)) return;
    setFormData(prev => ({ ...prev, locations_impacted: [...prev.locations_impacted, val] }));
    setLocationInput('');
  };

  const removeLocation = (loc) => {
    setFormData(prev => ({ ...prev, locations_impacted: prev.locations_impacted.filter(l => l !== loc) }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      in_force_from: formData.in_force_from || null,
      expires_at: formData.expires_at || null,
      impact_level: formData.impact_levels.length === 1 ? formData.impact_levels[0] : (formData.impact_levels.length > 1 ? formData.impact_levels[formData.impact_levels.length - 1] : null),
      impact_levels: formData.impact_levels,
      update_reason: formData.update_reason || null,
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="grid grid-cols-2 gap-5">
        {/* Left column */}
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="title">Title *</Label>
            <Input id="title" value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="e.g., Storm Warning Graphic" required />
          </div>

          <div className="space-y-1.5">
            <Label>Description</Label>
            <RichTextEditor
              value={formData.description}
              onChange={(html) => setFormData(prev => ({ ...prev, description: html }))}
              placeholder="Add a caption or details..."
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="in_force_from">In Force From</Label>
              <Input id="in_force_from" type="datetime-local" value={formData.in_force_from}
                onChange={(e) => setFormData(prev => ({ ...prev, in_force_from: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="expires_at">Expires At</Label>
              <Input id="expires_at" type="datetime-local" value={formData.expires_at}
                onChange={(e) => setFormData(prev => ({ ...prev, expires_at: e.target.value }))} />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Impact Level <span className="text-slate-400 font-normal">(select all that apply)</span></Label>
            <div className="flex flex-wrap gap-2">
              {IMPACT_LEVELS.map(level => {
                const cfg = IMPACT_CONFIG[level];
                const sel = formData.impact_levels.includes(level);
                return (
                  <button key={level} type="button"
                    onClick={() => setFormData(prev => ({
                      ...prev,
                      impact_levels: sel
                        ? prev.impact_levels.filter(l => l !== level)
                        : [...prev.impact_levels, level]
                    }))}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border-2 text-xs font-bold transition-all ${sel ? cfg.active : cfg.inactive}`}
                  >
                    {sel && <Check className="w-3.5 h-3.5" />}{level}
                  </button>
                );
              })}
            </div>
          </div>

          {graphic && (
            <div className="space-y-1.5">
              <Label htmlFor="update_reason">Reason for Update</Label>
              <Textarea id="update_reason" value={formData.update_reason}
                onChange={(e) => setFormData(prev => ({ ...prev, update_reason: e.target.value }))}
                placeholder="e.g. Updated expiry time, revised impact area..." rows={2} />
            </div>
          )}

          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
            <div>
              <Label htmlFor="featured" className="cursor-pointer">Feature on Homepage</Label>
              <p className="text-xs text-slate-500">Show this graphic prominently</p>
            </div>
            <Switch id="featured" checked={formData.is_featured}
              onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_featured: checked }))} />
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>Image *</Label>
            {formData.image_url ? (
              <div className="relative rounded-xl overflow-hidden">
                <img src={formData.image_url} alt="Preview" className="w-full h-44 object-cover" />
                <Button type="button" size="icon" variant="destructive" className="absolute top-2 right-2"
                  onClick={() => setFormData(prev => ({ ...prev, image_url: '' }))}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full h-44 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer hover:border-sky-500 hover:bg-sky-50/50 transition-colors">
                {uploading ? <Loader2 className="w-8 h-8 text-sky-500 animate-spin" /> : (
                  <>
                    <Upload className="w-7 h-7 text-slate-400 mb-2" />
                    <span className="text-sm text-slate-500">Click to upload image</span>
                  </>
                )}
                <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} disabled={uploading} />
              </label>
            )}
          </div>

          <div className="space-y-2">
            <Label>Locations Impacted</Label>
            <div className="flex gap-2">
              <Input placeholder="Add a location..." value={locationInput}
                onChange={e => setLocationInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addLocation())} />
              <Button type="button" size="icon" variant="outline" onClick={addLocation}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {formData.locations_impacted.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {formData.locations_impacted.map(loc => (
                  <span key={loc} className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 border border-slate-200 text-sm text-slate-700">
                    <MapPin className="w-3 h-3 text-slate-400" />{loc}
                    <button type="button" onClick={() => removeLocation(loc)} className="ml-0.5 hover:text-red-500">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3 pt-5 mt-5 border-t border-slate-200">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1" disabled={isLoading}>
          Cancel
        </Button>
        <Button type="submit" className="flex-1 bg-sky-600 hover:bg-sky-700"
          disabled={isLoading || !formData.title || !formData.image_url}>
          {isLoading && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
          {graphic ? 'Update' : 'Add'} Graphic
        </Button>
      </div>
    </form>
  );
}