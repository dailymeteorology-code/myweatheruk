import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, MapPin, Plus, Clock, Save, Loader2, AlertTriangle, Wind, Droplets, Zap } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { format, isValid } from 'date-fns';
import ImpactDrawingMap from './ImpactDrawingMap';

const IMPACT_LEVELS = ['Low', 'SLGT', 'Moderate', 'High'];

const IMPACT_CONFIG = {
  Low:      {
    gradient: 'from-emerald-500/20 to-emerald-600/5',
    border: 'border-emerald-500/40',
    activeBg: 'bg-emerald-500',
    activeText: 'text-white',
    dot: 'bg-emerald-400',
    text: 'text-emerald-400',
    glow: 'shadow-emerald-500/20',
  },
  SLGT:     {
    gradient: 'from-amber-400/20 to-amber-500/5',
    border: 'border-amber-400/40',
    activeBg: 'bg-amber-400',
    activeText: 'text-slate-900',
    dot: 'bg-amber-400',
    text: 'text-amber-400',
    glow: 'shadow-amber-400/20',
  },
  Moderate: {
    gradient: 'from-orange-500/20 to-orange-600/5',
    border: 'border-orange-500/40',
    activeBg: 'bg-orange-500',
    activeText: 'text-white',
    dot: 'bg-orange-400',
    text: 'text-orange-400',
    glow: 'shadow-orange-500/20',
  },
  High:     {
    gradient: 'from-red-500/20 to-red-600/5',
    border: 'border-red-500/40',
    activeBg: 'bg-red-500',
    activeText: 'text-white',
    dot: 'bg-red-400',
    text: 'text-red-400',
    glow: 'shadow-red-500/20',
  },
};

const STORM_RISKS = [
  { key: 'tornado_risk',      label: 'Tornadoes',      icon: '🌪',  bar: 'bg-gradient-to-r from-red-600 to-red-400',     badge: 'border-red-500/50 text-red-400' },
  { key: 'hail_risk',         label: 'Hail',           icon: '🧊',  bar: 'bg-gradient-to-r from-sky-600 to-sky-400',     badge: 'border-sky-500/50 text-sky-400' },
  { key: 'flash_flood_risk',  label: 'Flash Flood',    icon: '🌊',  bar: 'bg-gradient-to-r from-blue-600 to-blue-400',   badge: 'border-blue-500/50 text-blue-400' },
  { key: 'strong_winds_risk', label: 'Strong Winds',   icon: '💨',  bar: 'bg-gradient-to-r from-teal-600 to-teal-400',   badge: 'border-teal-500/50 text-teal-400' },
  { key: 'supercell_risk',    label: 'Supercells',     icon: '⚡',  bar: 'bg-gradient-to-r from-purple-600 to-purple-400', badge: 'border-purple-500/50 text-purple-400' },
];

const STORM_BADGES = [
  { key: 'high_lightning', label: 'High Lightning', icon: <Zap className="w-3 h-3" />,           cls: 'bg-yellow-400/10 border-yellow-400/40 text-yellow-300' },
  { key: 'severe',         label: 'Severe',          icon: <AlertTriangle className="w-3 h-3" />, cls: 'bg-orange-500/10 border-orange-500/40 text-orange-300' },
  { key: 'heavy_rain',     label: 'Heavy Rain',      icon: <Droplets className="w-3 h-3" />,      cls: 'bg-blue-500/10 border-blue-500/40 text-blue-300' },
];

function AnimatedBar({ value, colorClass, delay = 0 }) {
  const [width, setWidth] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setWidth(value), delay + 100);
    return () => clearTimeout(t);
  }, [value, delay]);

  return (
    <div className="relative h-1.5 rounded-full bg-slate-800 overflow-hidden">
      <div
        className={`absolute inset-y-0 left-0 rounded-full transition-all duration-700 ease-out ${colorClass}`}
        style={{ width: `${width}%` }}
      />
    </div>
  );
}

function SectionLabel({ icon, children }) {
  return (
    <div className="flex items-center gap-2 mb-3">
      {icon && <span className="text-slate-500">{icon}</span>}
      <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">{children}</span>
      <div className="flex-1 h-px bg-slate-800" />
    </div>
  );
}

function DateField({ label, value, isOwner, onChange }) {
  const parsed = value && isValid(new Date(value)) ? new Date(value) : null;

  return (
    <div className="flex-1 space-y-1.5">
      <p className="text-[10px] font-bold uppercase tracking-[0.12em] text-slate-500">{label}</p>
      {isOwner ? (
        <Input
          type="datetime-local"
          value={value}
          onChange={e => onChange(e.target.value)}
          className="h-9 bg-slate-900 border-slate-700/60 text-slate-200 text-sm focus:border-sky-500/60 focus:ring-0 rounded-xl"
        />
      ) : parsed ? (
        <div className="flex items-baseline gap-2">
          <span className="text-white font-semibold text-sm">{format(parsed, 'dd MMM yyyy')}</span>
          <span className="text-slate-400 text-xs font-mono">{format(parsed, 'HH:mm')}</span>
        </div>
      ) : (
        <span className="text-slate-600 text-sm italic">Not set</span>
      )}
    </div>
  );
}

export default function ForecastFurtherInfo({ forecast, isOwner, onClose, onUpdate }) {
  const [editData, setEditData] = useState({
    impact_level:       forecast.impact_level || '',
    in_force_from:      forecast.in_force_from ? forecast.in_force_from.slice(0, 16) : '',
    expires_at:         forecast.expires_at    ? forecast.expires_at.slice(0, 16)    : '',
    locations_impacted: forecast.locations_impacted || [],
    impact_drawing:     forecast.impact_drawing || '',
  });
  const [locationInput, setLocationInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  const update = (key, value) => {
    setEditData(prev => ({ ...prev, [key]: value }));
    setDirty(true);
  };

  const addLocation = () => {
    const val = locationInput.trim();
    if (!val || editData.locations_impacted.includes(val)) return;
    update('locations_impacted', [...editData.locations_impacted, val]);
    setLocationInput('');
  };

  const removeLocation = loc =>
    update('locations_impacted', editData.locations_impacted.filter(l => l !== loc));

  const handleSave = async () => {
    setSaving(true);
    await onUpdate({
      impact_level:       editData.impact_level || null,
      in_force_from:      editData.in_force_from || null,
      expires_at:         editData.expires_at    || null,
      locations_impacted: editData.locations_impacted,
    });
    setSaving(false);
    setDirty(false);
  };

  const handlePaths = newPaths =>
    update('impact_drawing', JSON.stringify(newPaths));

  const availableLevels = forecast.weather_condition === 'Thunderstorms'
    ? IMPACT_LEVELS
    : IMPACT_LEVELS.filter(l => l !== 'SLGT');

  const td = forecast.thunderstorm_data || {};
  const hasThunderstormData = Object.keys(td).length > 0;
  const activeStormRisks = STORM_RISKS.filter(r => td[r.key] != null);
  const activeBadges = STORM_BADGES.filter(b => td[b.key]);

  const selectedImpact = IMPACT_CONFIG[editData.impact_level];

  return (
    <AnimatePresence>
      <motion.div
        key="backdrop"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="fixed inset-0 z-50 bg-black/70 backdrop-blur-lg flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          key="panel"
          initial={{ opacity: 0, scale: 0.94, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 8 }}
          transition={{ duration: 0.28, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="w-full max-w-[620px] max-h-[92vh] overflow-y-auto rounded-[28px] bg-[#0e1520] border border-white/[0.06] shadow-2xl"
          style={{ scrollbarWidth: 'none' }}
          onClick={e => e.stopPropagation()}
        >

          {/* ── Hero header ── */}
          <div className="relative overflow-hidden rounded-t-[28px]">

            {/* Ambient glow behind header */}
            {selectedImpact && (
              <div
                className={`absolute inset-0 opacity-20 bg-gradient-to-br ${selectedImpact.gradient} pointer-events-none`}
              />
            )}

            <div className="relative px-6 pt-6 pb-5">

              {/* Top row */}
              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {forecast.weather_condition && (
                      <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-slate-500">
                        {forecast.weather_condition}
                      </span>
                    )}
                    {forecast.updated_date && (
                      <>
                        <span className="text-slate-700">·</span>
                        <span className="text-[10px] text-slate-600 font-mono">
                          Updated {format(new Date(forecast.updated_date), 'dd MMM, HH:mm')}
                        </span>
                      </>
                    )}
                  </div>
                  <h2 className="text-xl font-bold text-white leading-snug truncate">
                    {forecast.title}
                  </h2>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {isOwner && dirty && (
                    <motion.div
                      initial={{ opacity: 0, x: 8 }}
                      animate={{ opacity: 1, x: 0 }}
                    >
                      <Button
                        size="sm"
                        onClick={handleSave}
                        disabled={saving}
                        className="h-8 px-3 bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold gap-1.5 rounded-xl border-0"
                      >
                        {saving
                          ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          : <Save className="w-3.5 h-3.5" />}
                        Save
                      </Button>
                    </motion.div>
                  )}
                  <button
                    onClick={onClose}
                    className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all flex items-center justify-center"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Impact level selector */}
              <div className="flex flex-wrap gap-2">
                {availableLevels.map(level => {
                  const cfg = IMPACT_CONFIG[level];
                  const isSelected = editData.impact_level === level;
                  return (
                    <button
                      key={level}
                      type="button"
                      onClick={() => isOwner && update('impact_level', isSelected ? '' : level)}
                      disabled={!isOwner}
                      className={`flex items-center gap-2 px-3.5 py-1.5 rounded-full border text-xs font-bold transition-all duration-200 ${
                        isSelected
                          ? `${cfg.activeBg} ${cfg.activeText} border-transparent shadow-lg ${cfg.glow}`
                          : `bg-transparent ${cfg.border} ${cfg.text} ${isOwner ? 'hover:bg-white/5 cursor-pointer' : 'cursor-default'}`
                      }`}
                    >
                      {isSelected
                        ? <Check className="w-3 h-3" />
                        : <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot} opacity-70`} />
                      }
                      {level}
                    </button>
                  );
                })}
                {!isOwner && !editData.impact_level && (
                  <span className="text-slate-600 text-xs italic py-1.5">No impact level set</span>
                )}
              </div>
            </div>
          </div>

          {/* ── Body ── */}
          <div className="px-6 pb-8 space-y-7">

            {/* Divider */}
            <div className="h-px bg-white/[0.04]" />

            {/* Time fields */}
            <div>
              <SectionLabel icon={<Clock className="w-3.5 h-3.5" />}>Timeline</SectionLabel>
              <div className="flex gap-4">
                <DateField
                  label="In Force From"
                  value={editData.in_force_from}
                  isOwner={isOwner}
                  onChange={v => update('in_force_from', v)}
                />
                <div className="w-px bg-slate-800 self-stretch" />
                <DateField
                  label="Expires At"
                  value={editData.expires_at}
                  isOwner={isOwner}
                  onChange={v => update('expires_at', v)}
                />
              </div>
            </div>

            {/* Locations */}
            <div>
              <SectionLabel icon={<MapPin className="w-3.5 h-3.5" />}>Locations Impacted</SectionLabel>

              {isOwner && (
                <div className="flex gap-2 mb-3">
                  <Input
                    placeholder="Add a location…"
                    value={locationInput}
                    onChange={e => setLocationInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addLocation())}
                    className="h-9 bg-slate-900 border-slate-700/60 text-slate-200 placeholder:text-slate-600 text-sm focus:border-sky-500/60 focus:ring-0 rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={addLocation}
                    className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-slate-300 hover:text-white transition-all flex items-center justify-center shrink-0"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              )}

              {editData.locations_impacted.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {editData.locations_impacted.map(loc => (
                    <motion.span
                      key={loc}
                      layout
                      initial={{ opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.85 }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/60 text-xs text-slate-300"
                    >
                      <MapPin className="w-3 h-3 text-slate-500" />
                      {loc}
                      {isOwner && (
                        <button
                          onClick={() => removeLocation(loc)}
                          className="ml-0.5 text-slate-600 hover:text-red-400 transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </motion.span>
                  ))}
                </div>
              ) : (
                <p className="text-slate-600 italic text-sm">No locations specified</p>
              )}
            </div>

            {/* Thunderstorm data */}
            {hasThunderstormData && (
              <div>
                <SectionLabel icon={<Zap className="w-3.5 h-3.5 text-purple-400" />}>
                  <span className="text-purple-500">Thunderstorm Risk</span>
                </SectionLabel>

                <div className="rounded-2xl bg-slate-900/60 border border-white/[0.04] overflow-hidden">

                  {/* Risk bars */}
                  {activeStormRisks.length > 0 && (
                    <div className="p-4 space-y-4">
                      {activeStormRisks.map(({ key, label, icon, bar, badge }, i) => {
                        const val = td[key];
                        return (
                          <div key={key} className="space-y-1.5">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-sm">{icon}</span>
                                <span className="text-xs font-semibold text-slate-300">{label}</span>
                              </div>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border bg-slate-900 ${badge}`}>
                                {val}%
                              </span>
                            </div>
                            <AnimatedBar value={val} colorClass={bar} delay={i * 80} />
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Numeric stat cards */}
                  {(td.wind_speed_mph != null || td.rain_mm_per_hour != null || td.hail_diameter_mm != null || td.tornado_intensity) && (
                    <div className="grid grid-cols-2 gap-px bg-white/[0.04] border-t border-white/[0.04]">
                      {[
                        td.wind_speed_mph    != null && { label: 'Wind Speed', value: `${td.wind_speed_mph} mph`,  icon: <Wind className="w-3.5 h-3.5" />,     color: 'text-teal-400' },
                        td.rain_mm_per_hour  != null && { label: 'Rainfall',   value: `${td.rain_mm_per_hour} mm/hr`, icon: <Droplets className="w-3.5 h-3.5" />, color: 'text-blue-400' },
                        td.hail_diameter_mm  != null && { label: 'Hail Size',  value: `${td.hail_diameter_mm} mm`,    icon: '🧊',                                   color: 'text-sky-400' },
                        td.tornado_intensity         && { label: 'Tornado',    value: td.tornado_intensity,           icon: '🌪',                                   color: 'text-red-400' },
                      ].filter(Boolean).map(({ label, value, icon, color }) => (
                        <div key={label} className="bg-slate-900/80 px-4 py-3">
                          <div className={`flex items-center gap-1.5 mb-1 ${color}`}>
                            {typeof icon === 'string'
                              ? <span className="text-sm">{icon}</span>
                              : icon}
                            <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
                          </div>
                          <p className="text-white font-bold text-sm font-mono">{value}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Active hazard badges */}
                  {activeBadges.length > 0 && (
                    <div className="flex flex-wrap gap-2 p-4 border-t border-white/[0.04]">
                      {activeBadges.map(({ key, label, icon, cls }) => (
                        <span key={key} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-bold ${cls}`}>
                          {icon}
                          {label}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}