const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CloudSun, Pencil, Save, X, Upload, Loader2, Trash2,
  Clock, ChevronRight, MapPin, Check, Plus, Archive,
  AlertTriangle, Zap, Wind, Droplets, Snowflake, Flame
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { useMutation, useQueryClient } from '@tanstack/react-query';
import { format, isValid, formatDistanceToNow, isPast } from 'date-fns';
import ForecastFurtherInfo from './ForecastFurtherInfo';
import ThunderstormPanel from './ThunderstormPanel';
import ArchivedGraphicsModal from './ArchivedGraphicsModal';

/* ─────────────────────────────────────────────
   DESIGN TOKENS
───────────────────────────────────────────── */
const CONDITION_CONFIG = {
  Snow:         { accent: '#7dd3fc', dim: 'rgba(125,211,252,0.1)',  border: 'rgba(125,211,252,0.2)',  text: '#bae6fd', Icon: Snowflake  },
  Ice:          { accent: '#67e8f9', dim: 'rgba(103,232,249,0.1)',  border: 'rgba(103,232,249,0.2)',  text: '#a5f3fc', Icon: Droplets   },
  Thunderstorms:{ accent: '#c084fc', dim: 'rgba(192,132,252,0.1)', border: 'rgba(192,132,252,0.2)', text: '#e9d5ff', Icon: Zap        },
  Rain:         { accent: '#60a5fa', dim: 'rgba(96,165,250,0.1)',   border: 'rgba(96,165,250,0.2)',   text: '#bfdbfe', Icon: Droplets   },
  Wind:         { accent: '#2dd4bf', dim: 'rgba(45,212,191,0.1)',   border: 'rgba(45,212,191,0.2)',   text: '#99f6e4', Icon: Wind       },
  'Daily Risks':{ accent: '#fbbf24', dim: 'rgba(251,191,36,0.1)',   border: 'rgba(251,191,36,0.2)',   text: '#fde68a', Icon: AlertTriangle },
};
const DEFAULT_CFG = { accent: '#94a3b8', dim: 'rgba(148,163,184,0.1)', border: 'rgba(148,163,184,0.2)', text: '#cbd5e1', Icon: CloudSun };

const IMPACT_CONFIG = {
  Low:      { bg: 'rgba(34,197,94,0.1)',  border: 'rgba(34,197,94,0.3)',  text: '#86efac', dot: '#22c55e' },
  SLGT:     { bg: 'rgba(234,179,8,0.1)',  border: 'rgba(234,179,8,0.3)',  text: '#fde047', dot: '#eab308' },
  Moderate: { bg: 'rgba(249,115,22,0.1)', border: 'rgba(249,115,22,0.3)', text: '#fdba74', dot: '#f97316' },
  High:     { bg: 'rgba(239,68,68,0.1)',  border: 'rgba(239,68,68,0.3)',  text: '#fca5a5', dot: '#ef4444' },
};

const CONDITIONS = Object.keys(CONDITION_CONFIG);

/* ─────────────────────────────────────────────
   TINY HELPERS
───────────────────────────────────────────── */
function formatExpiry(iso) {
  if (!iso) return null;
  const d = new Date(iso);
  return isValid(d) ? format(d, 'dd MMM yyyy, HH:mm') : null;
}

function TimeChip({ icon: Icon, label, value, highlight }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
      <Icon size={11} style={{ color: 'rgba(148,163,184,0.6)', flexShrink: 0 }} />
      <span style={{ fontFamily: 'monospace', fontSize: 10, color: 'rgba(148,163,184,0.6)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
        {label}
      </span>
      <span style={{ fontFamily: 'monospace', fontSize: 10, color: highlight || '#cbd5e1' }}>
        {value}
      </span>
    </div>
  );
}

function Badge({ cfg, label, size = 'sm' }) {
  const pad = size === 'sm' ? '3px 10px' : '4px 13px';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: pad, borderRadius: 999,
      background: cfg.dim, border: `1px solid ${cfg.border}`,
      fontFamily: 'monospace', fontSize: 10, letterSpacing: '0.08em',
      textTransform: 'uppercase', color: cfg.text, whiteSpace: 'nowrap',
    }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: cfg.accent, flexShrink: 0 }} />
      {label}
    </span>
  );
}

/* ─────────────────────────────────────────────
   FORECAST CARD
───────────────────────────────────────────── */
function ForecastCard({ forecast, index, isOwner, onEdit, onArchive, onFurtherInfo, onUpdateImage }) {
  const condCfg = CONDITION_CONFIG[forecast.weather_condition] || DEFAULT_CFG;
  const impCfg  = IMPACT_CONFIG[forecast.impact_level];

  const issuedAt    = forecast.created_date ? format(new Date(forecast.created_date), 'dd MMM, HH:mm') : null;
  const expiresAt   = formatExpiry(forecast.expires_at);
  const inForceAt   = forecast.in_force_from && isValid(new Date(forecast.in_force_from))
    ? format(new Date(forecast.in_force_from), 'dd MMM, HH:mm') : null;
  const wasEdited   = forecast.updated_date && forecast.created_date &&
    new Date(forecast.updated_date).getTime() - new Date(forecast.created_date).getTime() > 5000;
  const lastUpdatedAt = wasEdited ? format(new Date(forecast.updated_date), 'dd MMM, HH:mm') : null;
  const hasDetails  = forecast.impact_level || forecast.locations_impacted?.length > 0 || forecast.in_force_from;
  const expiringSoon = forecast.expires_at && !isPast(new Date(forecast.expires_at)) &&
    new Date(forecast.expires_at) - Date.now() < 3 * 60 * 60 * 1000;

  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.07, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
      style={{
        background: 'rgba(8,13,26,0.96)',
        border: `1px solid ${condCfg.border}`,
        borderRadius: 20,
        overflow: 'hidden',
        display: 'flex', flexDirection: 'column',
        boxShadow: `0 4px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.04)`,
        transition: 'border-color 0.3s, box-shadow 0.3s',
      }}
    >
      {/* Accent line at top */}
      <div style={{ height: 2, background: `linear-gradient(90deg, ${condCfg.accent}, ${condCfg.accent}55, transparent)` }} />

      {/* HEADER */}
      <div style={{ padding: '16px 18px 12px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
            <div style={{
              width: 32, height: 32, borderRadius: 10, flexShrink: 0,
              background: condCfg.dim, border: `1px solid ${condCfg.border}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <condCfg.Icon size={15} style={{ color: condCfg.accent }} />
            </div>
            <h3 style={{
              fontFamily: "'DM Sans', 'Outfit', system-ui, sans-serif",
              fontSize: 15, fontWeight: 700, color: '#f1f5f9',
              letterSpacing: '-0.02em', lineHeight: 1.25, margin: 0,
            }}>
              {forecast.title || 'Forecast'}
            </h3>
          </div>

          {isOwner && (
            <div style={{ display: 'flex', gap: 5, flexShrink: 0 }}>
              <label style={{
                width: 28, height: 28, borderRadius: 8, cursor: 'pointer',
                background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'background 0.2s',
              }}
                onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.1)'}
                onMouseLeave={e => e.currentTarget.style.background = 'rgba(255,255,255,0.05)'}
                title="Replace image"
              >
                <Upload size={12} style={{ color: '#94a3b8' }} />
                <input type="file" style={{ display: 'none' }} accept="image/*" onChange={(e) => onUpdateImage(e, forecast)} />
              </label>
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={() => onArchive(forecast.id)}
                title="Archive"
                style={{
                  width: 28, height: 28, borderRadius: 8, cursor: 'pointer',
                  background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'background 0.2s', color: '#94a3b8',
                }}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(251,191,36,0.15)'; e.currentTarget.style.color = '#fbbf24'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = '#94a3b8'; }}
              >
                <Archive size={12} />
              </motion.button>
            </div>
          )}
        </div>

        {/* Badge row */}
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {forecast.weather_conditions?.length > 0
            ? forecast.weather_conditions.map(c => (
                <Badge key={c} cfg={CONDITION_CONFIG[c] || DEFAULT_CFG} label={c} />
              ))
            : forecast.weather_condition && (
                <Badge cfg={condCfg} label={forecast.weather_condition} />
              )
          }
          {forecast.impact_levels?.length > 0
            ? forecast.impact_levels.map(l => impCfg && <Badge key={l} cfg={IMPACT_CONFIG[l] || IMPACT_CONFIG.Low} label={l} />)
            : forecast.impact_level && impCfg && (
                <Badge cfg={impCfg} label={forecast.impact_level} />
              )
          }
          {expiringSoon && (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 4,
              padding: '3px 9px', borderRadius: 999,
              background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)',
              fontFamily: 'monospace', fontSize: 10, color: '#fca5a5', letterSpacing: '0.06em',
            }}>
              <span style={{ width: 5, height: 5, borderRadius: '50%', background: '#ef4444', animation: 'pulse 1s infinite' }} />
              EXPIRING SOON
            </span>
          )}
        </div>
      </div>

      {/* IMAGE */}
      <div style={{ margin: '0 12px', borderRadius: 14, overflow: 'hidden', background: 'rgba(0,0,0,0.3)', position: 'relative' }}>
        {forecast.image_url ? (
          <img
            src={forecast.image_url}
            alt="Forecast graphic"
            style={{ width: '100%', display: 'block', objectFit: 'contain' }}
            loading="lazy"
          />
        ) : (
          <div style={{ aspectRatio: '16/9', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 8 }}>
            <CloudSun size={28} style={{ color: 'rgba(148,163,184,0.3)' }} />
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: 'rgba(148,163,184,0.3)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>No graphic</span>
          </div>
        )}
      </div>

      {/* DESCRIPTION */}
      <ForecastDescription forecast={forecast} isOwner={isOwner} onEdit={onEdit} />

      {/* LOCATIONS */}
      {forecast.locations_impacted?.length > 0 && (
        <div style={{ padding: '0 18px 12px', display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
          <MapPin size={11} style={{ color: 'rgba(148,163,184,0.4)', flexShrink: 0 }} />
          {forecast.locations_impacted.slice(0, 3).map(loc => (
            <span key={loc} style={{
              fontFamily: 'monospace', fontSize: 10, color: '#94a3b8',
              background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)',
              padding: '2px 9px', borderRadius: 999, letterSpacing: '0.04em',
            }}>{loc}</span>
          ))}
          {forecast.locations_impacted.length > 3 && (
            <span style={{ fontFamily: 'monospace', fontSize: 10, color: 'rgba(148,163,184,0.4)' }}>
              +{forecast.locations_impacted.length - 3} more
            </span>
          )}
        </div>
      )}

      {/* UPDATE NOTE */}
      {forecast.update_reason && lastUpdatedAt && (
        <div style={{ margin: '0 12px 12px' }}>
          <div style={{
            padding: '9px 13px', borderRadius: 12,
            background: 'rgba(96,165,250,0.07)', border: '1px solid rgba(96,165,250,0.18)',
          }}>
            <p style={{ fontFamily: 'monospace', fontSize: 9, color: '#60a5fa', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 3 }}>Update note</p>
            <p style={{ fontSize: 12, color: '#cbd5e1', lineHeight: 1.6, margin: 0 }}>{forecast.update_reason}</p>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <div style={{
        padding: '10px 18px 14px',
        borderTop: '1px solid rgba(255,255,255,0.05)',
        display: 'flex', flexWrap: 'wrap', alignItems: 'center',
        justifyContent: 'space-between', gap: 10,
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          {inForceAt  && <TimeChip icon={Clock} label="In force" value={inForceAt} />}
          {issuedAt   && <TimeChip icon={Clock} label="Issued"   value={issuedAt} />}
          {expiresAt  && <TimeChip icon={Clock} label="Expires"  value={expiresAt} highlight={isPast(new Date(forecast.expires_at)) ? '#f87171' : '#fbbf24'} />}
          {lastUpdatedAt && <TimeChip icon={Clock} label="Updated" value={lastUpdatedAt} highlight="#60a5fa" />}
        </div>

        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => onFurtherInfo(forecast)}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 7,
            padding: '7px 14px', borderRadius: 100,
            background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
            fontFamily: 'monospace', fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em',
            color: '#94a3b8', cursor: 'pointer', transition: 'background 0.2s, color 0.2s',
            whiteSpace: 'nowrap',
          }}
          onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.08)'; e.currentTarget.style.color = '#f1f5f9'; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = '#94a3b8'; }}
        >
          Further Info
          {hasDetails && <span style={{ width: 5, height: 5, borderRadius: '50%', background: '#60a5fa' }} />}
          <ChevronRight size={12} style={{ opacity: 0.5 }} />
        </motion.button>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────
   DESCRIPTION (inline edit)
───────────────────────────────────────────── */
function ForecastDescription({ forecast, isOwner, onEdit }) {
  const [editing, setEditing] = useState(false);
  const [desc, setDesc] = useState(forecast.description || '');
  const [reason, setReason] = useState('');
  const { mutate, isPending } = useMutation({
    mutationFn: (data) => onEdit(forecast.id, data),
    onSuccess: () => setEditing(false),
  });

  if (!isOwner && !forecast.description) return null;

  return (
    <div style={{ padding: '4px 18px 12px' }}>
      <AnimatePresence mode="wait">
        {editing ? (
          <motion.div
            key="edit"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{ display: 'flex', flexDirection: 'column', gap: 8 }}
          >
            <Textarea
              value={desc}
              onChange={e => setDesc(e.target.value)}
              rows={3}
              placeholder="Description…"
              style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: '#e2e8f0', fontSize: 13, padding: '8px 12px', resize: 'vertical', fontFamily: 'inherit' }}
            />
            <Input
              value={reason}
              onChange={e => setReason(e.target.value)}
              placeholder="Reason for update…"
              style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: '#e2e8f0', fontSize: 12, padding: '6px 12px', fontFamily: 'monospace' }}
            />
            <div style={{ display: 'flex', gap: 6 }}>
              <button onClick={() => setEditing(false)} style={{ padding: '6px 14px', borderRadius: 8, background: 'transparent', border: '1px solid rgba(255,255,255,0.1)', color: '#64748b', fontSize: 11, cursor: 'pointer', fontFamily: 'monospace' }}>
                Cancel
              </button>
              <button
                onClick={() => mutate({ description: desc, update_reason: reason || null })}
                disabled={isPending}
                style={{ padding: '6px 14px', borderRadius: 8, background: 'rgba(96,165,250,0.15)', border: '1px solid rgba(96,165,250,0.3)', color: '#93c5fd', fontSize: 11, cursor: 'pointer', fontFamily: 'monospace', display: 'flex', alignItems: 'center', gap: 5 }}
              >
                {isPending ? <Loader2 size={11} style={{ animation: 'spin 1s linear infinite' }} /> : <Save size={11} />}
                Save
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div key="view" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}
          >
            <p style={{ flex: 1, fontSize: 13, color: forecast.description ? '#94a3b8' : 'rgba(100,116,139,0.5)', lineHeight: 1.7, margin: 0, fontStyle: forecast.description ? 'normal' : 'italic' }}>
              {forecast.description || 'No description'}
            </p>
            {isOwner && (
              <button
                onClick={() => { setEditing(true); setDesc(forecast.description || ''); setReason(''); }}
                style={{ padding: 5, borderRadius: 7, background: 'transparent', border: '1px solid transparent', color: 'rgba(148,163,184,0.3)', cursor: 'pointer', transition: 'all 0.2s', flexShrink: 0 }}
                onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = '#94a3b8'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'rgba(148,163,184,0.3)'; e.currentTarget.style.borderColor = 'transparent'; }}
              >
                <Pencil size={12} />
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─────────────────────────────────────────────
   ADD NEW MODAL
───────────────────────────────────────────── */
const EMPTY_GRAPHIC = {
  title: '', image_url: '', description: '',
  weather_condition: '', weather_conditions: [],
  expires_at: '', in_force_from: '',
  impact_level: '', impact_levels: [],
  locations_impacted: [], impact_drawing: '', thunderstorm_data: {},
};

function AddForecastModal({ onClose, onCreate, uploading, onUpload }) {
  const [form, setForm] = useState(EMPTY_GRAPHIC);
  const [locationInput, setLocationInput] = useState('');
  const set = (key, val) => setForm(p => ({ ...p, [key]: val }));

  const toggleArr = (key, val) => setForm(p => ({
    ...p,
    [key]: p[key].includes(val) ? p[key].filter(x => x !== val) : [...p[key], val],
  }));

  const addLocation = () => {
    const v = locationInput.trim();
    if (v && !form.locations_impacted.includes(v)) {
      set('locations_impacted', [...form.locations_impacted, v]);
      setLocationInput('');
    }
  };

  const inputStyle = {
    background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.09)',
    borderRadius: 10, color: '#e2e8f0', fontSize: 13,
    padding: '8px 12px', width: '100%', fontFamily: 'inherit',
    outline: 'none', transition: 'border-color 0.2s',
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 50,
        background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(10px)',
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      }}
    >
      <motion.div
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 60, opacity: 0 }}
        transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: 740,
          maxHeight: '90vh', overflowY: 'auto',
          background: '#08101e',
          border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: '20px 20px 0 0',
          boxShadow: '0 -24px 80px rgba(0,0,0,0.7)',
        }}
      >
        {/* Drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 12, paddingBottom: 4 }}>
          <div style={{ width: 36, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.12)' }} />
        </div>

        <div style={{ padding: '16px 24px 32px' }}>
          {/* Modal header */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
            <div>
              <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: '#f1f5f9', letterSpacing: '-0.02em' }}>New Forecast Graphic</h3>
              <p style={{ margin: '2px 0 0', fontSize: 11, color: 'rgba(148,163,184,0.6)', fontFamily: 'monospace' }}>Fill in the details below</p>
            </div>
            <button
              onClick={onClose}
              style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b' }}
              onMouseEnter={e => e.currentTarget.style.color = '#94a3b8'}
              onMouseLeave={e => e.currentTarget.style.color = '#64748b'}
            >
              <X size={14} />
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
            {/* LEFT */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>

              <FormField label="Title *">
                <input
                  style={inputStyle} placeholder="e.g. South England Rain Warning"
                  value={form.title} onChange={e => set('title', e.target.value)}
                  onFocus={e => e.target.style.borderColor = 'rgba(148,163,184,0.3)'}
                  onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.09)'}
                />
              </FormField>

              <FormField label="Weather Conditions" hint="select all that apply">
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {CONDITIONS.map(c => {
                    const cfg = CONDITION_CONFIG[c];
                    const sel = form.weather_conditions.includes(c);
                    return (
                      <button key={c} type="button" onClick={() => toggleArr('weather_conditions', c)}
                        style={{
                          padding: '4px 12px', borderRadius: 999, fontSize: 11, fontFamily: 'monospace',
                          letterSpacing: '0.06em', textTransform: 'uppercase', cursor: 'pointer',
                          background: sel ? cfg.dim : 'transparent',
                          border: `1px solid ${sel ? cfg.border : 'rgba(255,255,255,0.1)'}`,
                          color: sel ? cfg.text : 'rgba(148,163,184,0.5)',
                          transform: sel ? 'scale(1.04)' : 'scale(1)',
                          transition: 'all 0.18s',
                        }}
                      >
                        {c}
                      </button>
                    );
                  })}
                </div>
              </FormField>

              <FormField label="Description">
                <textarea
                  style={{ ...inputStyle, resize: 'vertical', minHeight: 72 }}
                  placeholder="Brief description of the forecast…"
                  value={form.description} onChange={e => set('description', e.target.value)}
                  onFocus={e => e.target.style.borderColor = 'rgba(148,163,184,0.3)'}
                  onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.09)'}
                  rows={3}
                />
              </FormField>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                <FormField label="In Force From">
                  <input type="datetime-local" style={{ ...inputStyle, fontSize: 11 }}
                    value={form.in_force_from} onChange={e => set('in_force_from', e.target.value)} />
                </FormField>
                <FormField label="Expires At">
                  <input type="datetime-local" style={{ ...inputStyle, fontSize: 11 }}
                    value={form.expires_at} onChange={e => set('expires_at', e.target.value)} />
                </FormField>
              </div>

              <FormField label="Impact Level" hint="select all that apply">
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {['Low', 'SLGT', 'Moderate', 'High'].map(level => {
                    const cfg = IMPACT_CONFIG[level];
                    const sel = form.impact_levels.includes(level);
                    return (
                      <button key={level} type="button" onClick={() => toggleArr('impact_levels', level)}
                        style={{
                          display: 'inline-flex', alignItems: 'center', gap: 5,
                          padding: '5px 13px', borderRadius: 999, fontSize: 11,
                          fontFamily: 'monospace', letterSpacing: '0.06em', textTransform: 'uppercase',
                          cursor: 'pointer',
                          background: sel ? cfg.bg : 'transparent',
                          border: `1px solid ${sel ? cfg.border : 'rgba(255,255,255,0.1)'}`,
                          color: sel ? cfg.text : 'rgba(148,163,184,0.5)',
                          transition: 'all 0.18s',
                        }}
                      >
                        {sel && <Check size={10} />}
                        {level}
                      </button>
                    );
                  })}
                </div>
              </FormField>

              {form.weather_conditions.includes('Thunderstorms') && (
                <ThunderstormPanel
                  data={form.thunderstorm_data || {}}
                  onChange={td => set('thunderstorm_data', td)} />
              )}
            </div>

            {/* RIGHT */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
              {/* Image upload */}
              {form.image_url ? (
                <div style={{ position: 'relative', borderRadius: 14, overflow: 'hidden', background: 'rgba(0,0,0,0.3)' }}>
                  <img src={form.image_url} alt="Preview" style={{ width: '100%', maxHeight: 200, objectFit: 'contain', display: 'block' }} />
                  <button
                    onClick={() => set('image_url', '')}
                    style={{
                      position: 'absolute', top: 8, right: 8,
                      width: 28, height: 28, borderRadius: 8,
                      background: 'rgba(0,0,0,0.7)', border: '1px solid rgba(255,255,255,0.15)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      cursor: 'pointer', color: '#94a3b8',
                    }}
                  >
                    <X size={12} />
                  </button>
                </div>
              ) : (
                <label style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                  height: 180, borderRadius: 14, cursor: 'pointer',
                  border: '1.5px dashed rgba(255,255,255,0.1)',
                  background: 'rgba(255,255,255,0.02)',
                  transition: 'border-color 0.2s, background 0.2s',
                  gap: 8,
                }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(148,163,184,0.3)'; e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'; e.currentTarget.style.background = 'rgba(255,255,255,0.02)'; }}
                >
                  {uploading ? (
                    <Loader2 size={24} style={{ color: '#60a5fa', animation: 'spin 1s linear infinite' }} />
                  ) : (
                    <>
                      <Upload size={22} style={{ color: 'rgba(148,163,184,0.4)' }} />
                      <span style={{ fontFamily: 'monospace', fontSize: 10, color: 'rgba(148,163,184,0.4)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
                        Upload graphic
                      </span>
                    </>
                  )}
                  <input type="file" style={{ display: 'none' }} accept="image/*"
                    onChange={async e => {
                      const url = await onUpload(e, true);
                      if (url) set('image_url', url);
                    }} />
                </label>
              )}

              {/* Locations */}
              <FormField label="Locations Impacted">
                <div style={{ display: 'flex', gap: 6 }}>
                  <input
                    style={{ ...inputStyle, flex: 1 }}
                    placeholder="Add a location…"
                    value={locationInput}
                    onChange={e => setLocationInput(e.target.value)}
                    onFocus={e => e.target.style.borderColor = 'rgba(148,163,184,0.3)'}
                    onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.09)'}
                    onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addLocation(); } }}
                  />
                  <button type="button" onClick={addLocation}
                    style={{
                      width: 36, height: 36, borderRadius: 10, flexShrink: 0,
                      background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      cursor: 'pointer', color: '#94a3b8', transition: 'all 0.2s',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.1)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'rgba(255,255,255,0.05)'}
                  >
                    <Plus size={14} />
                  </button>
                </div>
                {form.locations_impacted.length > 0 && (
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, marginTop: 8 }}>
                    {form.locations_impacted.map(loc => (
                      <span key={loc} style={{
                        display: 'inline-flex', alignItems: 'center', gap: 5,
                        padding: '3px 10px', borderRadius: 999,
                        background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.09)',
                        fontFamily: 'monospace', fontSize: 10, color: '#94a3b8',
                      }}>
                        <MapPin size={9} style={{ color: 'rgba(148,163,184,0.5)' }} />
                        {loc}
                        <button
                          type="button"
                          onClick={() => set('locations_impacted', form.locations_impacted.filter(l => l !== loc))}
                          style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'rgba(148,163,184,0.4)', display: 'flex', lineHeight: 1 }}
                          onMouseEnter={e => e.currentTarget.style.color = '#f87171'}
                          onMouseLeave={e => e.currentTarget.style.color = 'rgba(148,163,184,0.4)'}
                        >
                          <X size={9} />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </FormField>
            </div>
          </div>

          {/* Footer */}
          <div style={{
            display: 'flex', gap: 10, marginTop: 24,
            paddingTop: 18, borderTop: '1px solid rgba(255,255,255,0.06)',
          }}>
            <button onClick={onClose} style={{
              flex: 1, padding: '10px 0', borderRadius: 12,
              background: 'transparent', border: '1px solid rgba(255,255,255,0.08)',
              color: '#64748b', fontSize: 12, fontFamily: 'monospace', letterSpacing: '0.06em',
              textTransform: 'uppercase', cursor: 'pointer', transition: 'all 0.2s',
            }}
              onMouseEnter={e => e.currentTarget.style.color = '#94a3b8'}
              onMouseLeave={e => e.currentTarget.style.color = '#64748b'}
            >
              Cancel
            </button>
            <button
              onClick={() => onCreate(form)}
              disabled={!form.image_url}
              style={{
                flex: 1, padding: '10px 0', borderRadius: 12,
                background: form.image_url ? 'rgba(96,165,250,0.15)' : 'rgba(255,255,255,0.03)',
                border: `1px solid ${form.image_url ? 'rgba(96,165,250,0.35)' : 'rgba(255,255,255,0.06)'}`,
                color: form.image_url ? '#93c5fd' : 'rgba(148,163,184,0.3)',
                fontSize: 12, fontFamily: 'monospace', letterSpacing: '0.06em',
                textTransform: 'uppercase', cursor: form.image_url ? 'pointer' : 'not-allowed',
                transition: 'all 0.2s',
              }}
            >
              Add Forecast
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function FormField({ label, hint, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label style={{ fontFamily: 'monospace', fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'rgba(148,163,184,0.5)' }}>
        {label}
        {hint && <span style={{ marginLeft: 5, color: 'rgba(100,116,139,0.5)', textTransform: 'none', letterSpacing: 0 }}>— {hint}</span>}
      </label>
      {children}
    </div>
  );
}

/* ─────────────────────────────────────────────
   MAIN SECTION
───────────────────────────────────────────── */
export default function ForecastSection({ forecasts = [], isOwner }) {
  const [showAddNew, setShowAddNew] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showArchive, setShowArchive] = useState(false);
  const [furtherInfoForecast, setFurtherInfoForecast] = useState(null);
  const queryClient = useQueryClient();

  const activeForecasts   = forecasts.filter(f => !f.is_archived && (!f.expires_at || !isPast(new Date(f.expires_at))));
  const archivedForecasts = forecasts.filter(f => f.is_archived || (f.expires_at && isPast(new Date(f.expires_at))));

  /* mutations */
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => db.entities.WeatherGraphic.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['forecasts'] }),
  });

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.WeatherGraphic.create({ ...data, is_forecast: true, published: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['forecasts'] });
      setShowAddNew(false);
    },
  });

  const archiveMutation = useMutation({
    mutationFn: (id) => db.entities.WeatherGraphic.update(id, { is_archived: true }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['forecasts'] }),
  });

  const handleImageUpload = async (e, isNew = false) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    setUploading(false);
    return file_url;
  };

  const handleUpdateImage = async (e, forecast) => {
    const url = await handleImageUpload(e);
    if (url) updateMutation.mutate({ id: forecast.id, data: { image_url: url } });
  };

  const handleFurtherInfoUpdate = async (data) => {
    if (!furtherInfoForecast) return;
    await db.entities.WeatherGraphic.update(furtherInfoForecast.id, data);
    queryClient.invalidateQueries({ queryKey: ['forecasts'] });
    setFurtherInfoForecast(prev => ({ ...prev, ...data }));
  };

  const handleCreate = (form) => {
    createMutation.mutate({
      title: form.title || 'Forecast',
      image_url: form.image_url,
      description: form.description,
      weather_condition:  form.weather_conditions[0] ?? undefined,
      weather_conditions: form.weather_conditions.length  ? form.weather_conditions  : undefined,
      expires_at:         form.expires_at   || undefined,
      in_force_from:      form.in_force_from || undefined,
      impact_level:       form.impact_levels.length === 1 ? form.impact_levels[0] : form.impact_levels.at(-1) ?? undefined,
      impact_levels:      form.impact_levels.length ? form.impact_levels : undefined,
      locations_impacted: form.locations_impacted.length ? form.locations_impacted : undefined,
      impact_drawing:     form.impact_drawing || undefined,
      thunderstorm_data:  form.weather_conditions.includes('Thunderstorms') && Object.keys(form.thunderstorm_data || {}).length
        ? form.thunderstorm_data : undefined,
    });
  };

  return (
    <section style={{ maxWidth: 1000, margin: '0 auto', padding: '40px 20px 80px', fontFamily: "'DM Sans', 'Outfit', system-ui, sans-serif" }}>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } } @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }`}</style>

      {/* SECTION HEADER */}
      <motion.div
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 36 }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 42, height: 42, borderRadius: 13,
            background: 'rgba(167,139,250,0.1)', border: '1px solid rgba(167,139,250,0.2)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <CloudSun size={20} style={{ color: '#c084fc' }} />
          </div>
          <div>
            <h2 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: '#f1f5f9', letterSpacing: '-0.02em' }}>
              Weather Graphics
            </h2>
            <p style={{ margin: '1px 0 0', fontFamily: 'monospace', fontSize: 10, color: 'rgba(148,163,184,0.5)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
              {activeForecasts.length} active {activeForecasts.length === 1 ? 'graphic' : 'graphics'}
            </p>
          </div>
        </div>

        {isOwner && (
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => setShowAddNew(true)}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 7,
              padding: '8px 16px', borderRadius: 12,
              background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
              color: '#94a3b8', fontFamily: 'monospace', fontSize: 11,
              textTransform: 'uppercase', letterSpacing: '0.08em', cursor: 'pointer',
              transition: 'all 0.2s',
            }}
            onMouseEnter={e => { e.currentTarget.style.background = 'rgba(167,139,250,0.1)'; e.currentTarget.style.borderColor = 'rgba(167,139,250,0.3)'; e.currentTarget.style.color = '#c084fc'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'; e.currentTarget.style.color = '#94a3b8'; }}
          >
            <Plus size={13} />
            Add graphic
          </motion.button>
        )}
      </motion.div>

      {/* GRID */}
      {activeForecasts.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 20 }}>
          {activeForecasts.map((forecast, index) => (
            <ForecastCard
              key={forecast.id}
              forecast={forecast}
              index={index}
              isOwner={isOwner}
              onEdit={(id, data) => updateMutation.mutate({ id, data })}
              onArchive={(id) => archiveMutation.mutate(id)}
              onFurtherInfo={setFurtherInfoForecast}
              onUpdateImage={handleUpdateImage}
            />
          ))}
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          style={{
            padding: '64px 24px', borderRadius: 20,
            background: 'rgba(255,255,255,0.02)', border: '1px dashed rgba(255,255,255,0.07)',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
          }}
        >
          <CloudSun size={36} style={{ color: 'rgba(167,139,250,0.3)' }} />
          <p style={{ fontFamily: 'monospace', fontSize: 11, color: 'rgba(148,163,184,0.4)', textTransform: 'uppercase', letterSpacing: '0.1em', margin: 0 }}>
            No active graphics
          </p>
        </motion.div>
      )}

      {/* ARCHIVE BUTTON */}
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: 28 }}>
        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => setShowArchive(true)}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '9px 20px', borderRadius: 100,
            background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)',
            color: 'rgba(148,163,184,0.5)', fontFamily: 'monospace', fontSize: 10,
            textTransform: 'uppercase', letterSpacing: '0.1em', cursor: 'pointer',
            transition: 'all 0.2s',
          }}
          onMouseEnter={e => { e.currentTarget.style.color = '#94a3b8'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.14)'; }}
          onMouseLeave={e => { e.currentTarget.style.color = 'rgba(148,163,184,0.5)'; e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'; }}
        >
          <Archive size={12} />
          Archived graphics
          {archivedForecasts.length > 0 && (
            <span style={{
              padding: '1px 8px', borderRadius: 999,
              background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.09)',
              fontSize: 9, color: '#64748b',
            }}>
              {archivedForecasts.length}
            </span>
          )}
        </motion.button>
      </div>

      {/* MODALS */}
      <AnimatePresence>
        {isOwner && showAddNew && (
          <AddForecastModal
            onClose={() => setShowAddNew(false)}
            onCreate={handleCreate}
            uploading={uploading}
            onUpload={handleImageUpload}
          />
        )}
      </AnimatePresence>

      {showArchive && (
        <ArchivedGraphicsModal
          graphics={archivedForecasts}
          isOwner={isOwner}
          onClose={() => setShowArchive(false)}
          onDelete={id => db.entities.WeatherGraphic.delete(id).then(() => queryClient.invalidateQueries({ queryKey: ['forecasts'] }))}
        />
      )}

      {furtherInfoForecast && (
        <ForecastFurtherInfo
          forecast={furtherInfoForecast}
          isOwner={isOwner}
          onClose={() => setFurtherInfoForecast(null)}
          onUpdate={handleFurtherInfoUpdate}
        />
      )}
    </section>
  );
}