import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

// ─── All sky gradient configs, matching WeatherAtmosphere SKY_CONFIGS ──────
const SKY_CONFIGS = {
  'Sunny':                    { day: 'linear-gradient(180deg, #1a6bc8 0%, #2d8de0 40%, #87ceeb 80%, #dff2ff 100%)', night: 'linear-gradient(180deg, #020b18 0%, #071a30 40%, #0d2545 100%)', sunrise: 'linear-gradient(180deg, #1a3a6e 0%, #e8794a 40%, #f5c06a 70%, #fffbe8 100%)', sunset: 'linear-gradient(180deg, #2a1a5e 0%, #8b3a8b 30%, #e8562a 55%, #f5a040 75%, #ffd580 100%)', particles: null },
  'Clear Night':              { day: 'linear-gradient(180deg, #020b18 0%, #071a30 40%, #0d2545 100%)', night: 'linear-gradient(180deg, #020b18 0%, #071a30 40%, #0d2545 100%)', sunrise: 'linear-gradient(180deg, #0d1a2e 0%, #c05a30 50%, #f0a040 80%, #ffd580 100%)', sunset: 'linear-gradient(180deg, #200d40 0%, #6b2a6b 30%, #c0401a 55%, #e07030 80%, #ffd580 100%)', particles: null },
  'Sunny Intervals':          { day: 'linear-gradient(180deg, #2070c0 0%, #4090d8 40%, #90c8e8 80%, #d8f0ff 100%)', night: 'linear-gradient(180deg, #060e1e 0%, #0e2238 50%, #182f50 100%)', sunrise: 'linear-gradient(180deg, #1a3a6e 0%, #d87040 40%, #f0c060 70%, #fff8d0 100%)', sunset: 'linear-gradient(180deg, #2a2060 0%, #904870 30%, #d85030 55%, #f0a030 78%, #f8d880 100%)', particles: null },
  'Sunny Intervals Night':    { day: 'linear-gradient(180deg, #060e1e 0%, #0e2238 50%, #182f50 100%)', night: 'linear-gradient(180deg, #060e1e 0%, #0e2238 50%, #182f50 100%)', sunrise: 'linear-gradient(180deg, #0a1828 0%, #b04828 50%, #e09040 80%, #fad070 100%)', sunset: 'linear-gradient(180deg, #180c30 0%, #581848 30%, #a03018 55%, #d07020 80%, #f0c050 100%)', particles: null },
  'Partly Cloudy':            { day: 'linear-gradient(180deg, #2a78c8 0%, #5098d8 40%, #98cce8 80%, #d8efff 100%)', night: 'linear-gradient(180deg, #080f20 0%, #101a30 50%, #182840 100%)', sunrise: 'linear-gradient(180deg, #203868 0%, #d06838 40%, #e8a850 70%, #fff0d0 100%)', sunset: 'linear-gradient(180deg, #302268 0%, #904878 30%, #d04828 55%, #e89030 78%, #f8d870 100%)', particles: null },
  'Partly Cloudy Night':      { day: 'linear-gradient(180deg, #080f20 0%, #101a30 50%, #182840 100%)', night: 'linear-gradient(180deg, #080f20 0%, #101a30 50%, #182840 100%)', sunrise: 'linear-gradient(180deg, #0c1428 0%, #b04030 50%, #d88040 80%, #f0c060 100%)', sunset: 'linear-gradient(180deg, #200a38 0%, #601838 30%, #a02818 55%, #c86818 80%, #e8b040 100%)', particles: null },
  'Cloudy':                   { day: 'linear-gradient(180deg, #6a7f8e 0%, #8098a8 40%, #a0b8c8 80%, #c8d8e0 100%)', night: 'linear-gradient(180deg, #1a1f28 0%, #252c38 50%, #303848 100%)', sunrise: 'linear-gradient(180deg, #3a4858 0%, #987060 40%, #c8a870 70%, #e0c898 100%)', sunset: 'linear-gradient(180deg, #3a3050 0%, #806070 30%, #a06050 55%, #c08050 78%, #d8a870 100%)', particles: null },
  'Overcast':                 { day: 'linear-gradient(180deg, #5a6878 0%, #707e8e 40%, #8898a8 80%, #a0b0be 100%)', night: 'linear-gradient(180deg, #141820 0%, #1e2430 50%, #282e3c 100%)', sunrise: 'linear-gradient(180deg, #303840 0%, #806858 40%, #a08868 70%, #c0a878 100%)', sunset: 'linear-gradient(180deg, #302838 0%, #685060 30%, #885060 55%, #a07055 78%, #c09068 100%)', particles: null },
  'Mist':                     { day: 'linear-gradient(180deg, #8898a8 0%, #9eb0c0 50%, #b8cad8 100%)', night: 'linear-gradient(180deg, #202830 0%, #2c3840 50%, #364048 100%)', sunrise: 'linear-gradient(180deg, #606878 0%, #989080 40%, #c0a888 70%, #d8c0a0 100%)', sunset: 'linear-gradient(180deg, #383038 0%, #786070 30%, #907060 55%, #a08060 78%, #b89870 100%)', particles: 'fog' },
  'Fog':                      { day: 'linear-gradient(180deg, #9aaab8 0%, #b0c0cc 50%, #c8d4dc 100%)', night: 'linear-gradient(180deg, #282e34 0%, #333c44 50%, #3e4850 100%)', sunrise: 'linear-gradient(180deg, #686e76 0%, #a09080 40%, #c0a888 70%, #d8c0a0 100%)', sunset: 'linear-gradient(180deg, #403848 0%, #806070 30%, #907060 55%, #a08060 78%, #b09070 100%)', particles: 'fog' },
  'Windy':                    { day: 'linear-gradient(180deg, #2068b8 0%, #4088d0 40%, #80bce0 80%, #c0e0f8 100%)', night: 'linear-gradient(180deg, #06101e 0%, #0e1e30 50%, #181e30 100%)', sunrise: 'linear-gradient(180deg, #182860 0%, #c06040 40%, #e0a050 70%, #ffe8c0 100%)', sunset: 'linear-gradient(180deg, #281858 0%, #804068 30%, #c03828 55%, #e08028 78%, #f0c060 100%)', particles: 'wind' },
  // Rain
  'Drizzle':                  { day: 'linear-gradient(180deg, #5a6e80 0%, #6e8090 45%, #8298a8 80%, #9ab0be 100%)', night: 'linear-gradient(180deg, #0e1620 0%, #18222e 50%, #222e3c 100%)', sunrise: 'linear-gradient(180deg, #303c48 0%, #806858 40%, #a08068 70%, #c09878 100%)', sunset: 'linear-gradient(180deg, #282030 0%, #605060 30%, #806058 55%, #9c7858 78%, #b09068 100%)', particles: 'drizzle', count: 30 },
  'Drizzle Night':            { day: 'linear-gradient(180deg, #0e1620 0%, #18222e 50%, #222e3c 100%)', night: 'linear-gradient(180deg, #0e1620 0%, #18222e 50%, #222e3c 100%)', sunrise: 'linear-gradient(180deg, #303c48 0%, #806858 40%, #a08068 70%, #c09878 100%)', sunset: 'linear-gradient(180deg, #282030 0%, #605060 30%, #806058 55%, #9c7858 78%, #b09068 100%)', particles: 'drizzle', count: 30 },
  'Light Rain':               { day: 'linear-gradient(180deg, #485e70 0%, #5c7080 45%, #7088a0 80%, #8898b0 100%)', night: 'linear-gradient(180deg, #0c1420 0%, #141e2c 50%, #1e2838 100%)', sunrise: 'linear-gradient(180deg, #283040 0%, #705850 40%, #907060 70%, #b09070 100%)', sunset: 'linear-gradient(180deg, #201828 0%, #584860 30%, #785055 55%, #906855 78%, #a08060 100%)', particles: 'rain', count: 55 },
  'Light Rain Night':         { day: 'linear-gradient(180deg, #0c1420 0%, #141e2c 50%, #1e2838 100%)', night: 'linear-gradient(180deg, #0c1420 0%, #141e2c 50%, #1e2838 100%)', sunrise: 'linear-gradient(180deg, #283040 0%, #705850 40%, #907060 70%, #b09070 100%)', sunset: 'linear-gradient(180deg, #201828 0%, #584860 30%, #785055 55%, #906855 78%, #a08060 100%)', particles: 'rain', count: 55 },
  'Moderate Rain':            { day: 'linear-gradient(180deg, #384e60 0%, #4c6070 45%, #606880 80%, #78808e 100%)', night: 'linear-gradient(180deg, #080e18 0%, #101822 50%, #181e2c 100%)', sunrise: 'linear-gradient(180deg, #202830 0%, #605048 40%, #786858 70%, #908868 100%)', sunset: 'linear-gradient(180deg, #181028 0%, #483848 30%, #604040 55%, #785048 78%, #907058 100%)', particles: 'rain', count: 90, speed: 9 },
  'Moderate Rain Night':      { day: 'linear-gradient(180deg, #080e18 0%, #101822 50%, #181e2c 100%)', night: 'linear-gradient(180deg, #080e18 0%, #101822 50%, #181e2c 100%)', sunrise: 'linear-gradient(180deg, #202830 0%, #605048 40%, #786858 70%, #908868 100%)', sunset: 'linear-gradient(180deg, #181028 0%, #483848 30%, #604040 55%, #785048 78%, #907058 100%)', particles: 'rain', count: 90, speed: 9 },
  'Heavy Rain':               { day: 'linear-gradient(180deg, #283040 0%, #384050 45%, #485060 80%, #585e6e 100%)', night: 'linear-gradient(180deg, #050a10 0%, #0c1018 50%, #121620 100%)', sunrise: 'linear-gradient(180deg, #181e28 0%, #503830 40%, #685040 70%, #806050 100%)', sunset: 'linear-gradient(180deg, #100a20 0%, #382838 30%, #502828 55%, #683830 78%, #785040 100%)', particles: 'torrential', count: 180, speed: 13 },
  'Heavy Rain Night':         { day: 'linear-gradient(180deg, #050a10 0%, #0c1018 50%, #121620 100%)', night: 'linear-gradient(180deg, #050a10 0%, #0c1018 50%, #121620 100%)', sunrise: 'linear-gradient(180deg, #181e28 0%, #503830 40%, #685040 70%, #806050 100%)', sunset: 'linear-gradient(180deg, #100a20 0%, #382838 30%, #502828 55%, #683830 78%, #785040 100%)', particles: 'torrential', count: 180, speed: 13 },
  'Torrential Rain':          { day: 'linear-gradient(180deg, #1e2830 0%, #283038 45%, #303840 80%, #404048 100%)', night: 'linear-gradient(180deg, #040608 0%, #080c10 50%, #0c1018 100%)', sunrise: 'linear-gradient(180deg, #101418 0%, #3c2820 40%, #503830 70%, #604838 100%)', sunset: 'linear-gradient(180deg, #0c0818 0%, #282028 30%, #38181c 55%, #4c2820 78%, #5c3828 100%)', particles: 'torrential', count: 320, speed: 17 },
  'Torrential Rain Night':    { day: 'linear-gradient(180deg, #040608 0%, #080c10 50%, #0c1018 100%)', night: 'linear-gradient(180deg, #040608 0%, #080c10 50%, #0c1018 100%)', sunrise: 'linear-gradient(180deg, #101418 0%, #3c2820 40%, #503830 70%, #604838 100%)', sunset: 'linear-gradient(180deg, #0c0818 0%, #282028 30%, #38181c 55%, #4c2820 78%, #5c3828 100%)', particles: 'torrential', count: 320, speed: 17 },
  'Rain Shower':              { day: 'linear-gradient(180deg, #4a6070 0%, #607280 45%, #7890a0 80%, #8ca0ae 100%)', night: 'linear-gradient(180deg, #0a1218 0%, #141e28 50%, #1c2830 100%)', sunrise: 'linear-gradient(180deg, #283040 0%, #726050 40%, #8c7860 70%, #a89070 100%)', sunset: 'linear-gradient(180deg, #201828 0%, #584860 30%, #705050 55%, #8a6850 78%, #a08060 100%)', particles: 'rain', count: 75 },
  'Rain Shower Night':        { day: 'linear-gradient(180deg, #0a1218 0%, #141e28 50%, #1c2830 100%)', night: 'linear-gradient(180deg, #0a1218 0%, #141e28 50%, #1c2830 100%)', sunrise: 'linear-gradient(180deg, #283040 0%, #726050 40%, #8c7860 70%, #a89070 100%)', sunset: 'linear-gradient(180deg, #201828 0%, #584860 30%, #705050 55%, #8a6850 78%, #a08060 100%)', particles: 'rain', count: 75 },
  'Rain Shower Cloud':        { day: 'linear-gradient(180deg, #5a7080 0%, #6e8090 45%, #8098a8 80%, #90a8b8 100%)', night: 'linear-gradient(180deg, #0e1620 0%, #18222e 50%, #202c38 100%)', sunrise: 'linear-gradient(180deg, #2c3848 0%, #787060 40%, #909070 70%, #a89a80 100%)', sunset: 'linear-gradient(180deg, #201828 0%, #604858 30%, #706050 55%, #887060 78%, #a08870 100%)', particles: 'rain', count: 75 },
  'Heavy Showers':            { day: 'linear-gradient(180deg, #384858 0%, #485868 45%, #586070 80%, #686870 100%)', night: 'linear-gradient(180deg, #080e18 0%, #101820 50%, #181e28 100%)', sunrise: 'linear-gradient(180deg, #202830 0%, #604848 40%, #785858 70%, #906868 100%)', sunset: 'linear-gradient(180deg, #180e28 0%, #503040 30%, #684040 55%, #7c5040 78%, #906050 100%)', particles: 'torrential', count: 200, speed: 12 },
  'Heavy Showers Night':      { day: 'linear-gradient(180deg, #080e18 0%, #101820 50%, #181e28 100%)', night: 'linear-gradient(180deg, #080e18 0%, #101820 50%, #181e28 100%)', sunrise: 'linear-gradient(180deg, #202830 0%, #604848 40%, #785858 70%, #906868 100%)', sunset: 'linear-gradient(180deg, #180e28 0%, #503040 30%, #684040 55%, #7c5040 78%, #906050 100%)', particles: 'torrential', count: 200, speed: 12 },
  'Heavy Showers Cloud':      { day: 'linear-gradient(180deg, #485868 0%, #586070 45%, #686878 80%, #787880 100%)', night: 'linear-gradient(180deg, #0a1018 0%, #121820 50%, #1a2028 100%)', sunrise: 'linear-gradient(180deg, #242c38 0%, #645a50 40%, #806860 70%, #987870 100%)', sunset: 'linear-gradient(180deg, #1c1028 0%, #564048 30%, #684848 55%, #7c5848 78%, #906860 100%)', particles: 'torrential', count: 200, speed: 12 },
  // Snow
  'Flurry':                   { day: 'linear-gradient(180deg, #6e8098 0%, #8498a8 45%, #9ab0c0 80%, #b0c4d0 100%)', night: 'linear-gradient(180deg, #121820 0%, #1c2430 50%, #242c38 100%)', sunrise: 'linear-gradient(180deg, #383e48 0%, #907868 40%, #a89080 70%, #c0a890 100%)', sunset: 'linear-gradient(180deg, #2a2038 0%, #685868 30%, #806860 55%, #988070 78%, #b09880 100%)', particles: 'snow', count: 35 },
  'Flurry Night':             { day: 'linear-gradient(180deg, #121820 0%, #1c2430 50%, #242c38 100%)', night: 'linear-gradient(180deg, #121820 0%, #1c2430 50%, #242c38 100%)', sunrise: 'linear-gradient(180deg, #383e48 0%, #907868 40%, #a89080 70%, #c0a890 100%)', sunset: 'linear-gradient(180deg, #2a2038 0%, #685868 30%, #806860 55%, #988070 78%, #b09880 100%)', particles: 'snow', count: 35 },
  'Flurry Cloud':             { day: 'linear-gradient(180deg, #7888a0 0%, #8898b0 45%, #98aac0 80%, #a8b8ce 100%)', night: 'linear-gradient(180deg, #161e28 0%, #1e2a34 50%, #262e3c 100%)', sunrise: 'linear-gradient(180deg, #3a4050 0%, #948070 40%, #aca090 70%, #c4b8a0 100%)', sunset: 'linear-gradient(180deg, #2c2240 0%, #6e6070 30%, #847870 55%, #9c8c78 78%, #b0a488 100%)', particles: 'snow', count: 35 },
  'Light Snow':               { day: 'linear-gradient(180deg, #7888a0 0%, #8a9ab0 45%, #9eb0c0 80%, #b0c0ce 100%)', night: 'linear-gradient(180deg, #101820 0%, #1a2430 50%, #222c38 100%)', sunrise: 'linear-gradient(180deg, #3a4050 0%, #988878 40%, #b09888 70%, #c8b098 100%)', sunset: 'linear-gradient(180deg, #2c2240 0%, #706070 30%, #887068 55%, #a08878 78%, #b8a088 100%)', particles: 'snow', count: 75, speed: 1.0 },
  'Light Snow Night':         { day: 'linear-gradient(180deg, #101820 0%, #1a2430 50%, #222c38 100%)', night: 'linear-gradient(180deg, #101820 0%, #1a2430 50%, #222c38 100%)', sunrise: 'linear-gradient(180deg, #3a4050 0%, #988878 40%, #b09888 70%, #c8b098 100%)', sunset: 'linear-gradient(180deg, #2c2240 0%, #706070 30%, #887068 55%, #a08878 78%, #b8a088 100%)', particles: 'snow', count: 75, speed: 1.0 },
  'Light Snow Cloud':         { day: 'linear-gradient(180deg, #8898b0 0%, #9aaac0 45%, #aabace 80%, #b8c8d8 100%)', night: 'linear-gradient(180deg, #161e28 0%, #202a34 50%, #28323e 100%)', sunrise: 'linear-gradient(180deg, #3c4450 0%, #9a8880 40%, #b09888 70%, #c8b098 100%)', sunset: 'linear-gradient(180deg, #2e2440 0%, #726070 30%, #8a7268 55%, #a28878 78%, #b8a088 100%)', particles: 'snow', count: 75, speed: 1.0 },
  'Snow':                     { day: 'linear-gradient(180deg, #8090a8 0%, #909eb8 45%, #a0b0c4 80%, #b0bed0 100%)', night: 'linear-gradient(180deg, #121a22 0%, #1c2630 50%, #242e38 100%)', sunrise: 'linear-gradient(180deg, #3e4658 0%, #9c9080 40%, #b4a090 70%, #c8b8a0 100%)', sunset: 'linear-gradient(180deg, #302448 0%, #746470 30%, #8c7470 55%, #a48878 78%, #b8a088 100%)', particles: 'snow', count: 100, speed: 1.2 },
  'Snow Night':               { day: 'linear-gradient(180deg, #121a22 0%, #1c2630 50%, #242e38 100%)', night: 'linear-gradient(180deg, #121a22 0%, #1c2630 50%, #242e38 100%)', sunrise: 'linear-gradient(180deg, #3e4658 0%, #9c9080 40%, #b4a090 70%, #c8b8a0 100%)', sunset: 'linear-gradient(180deg, #302448 0%, #746470 30%, #8c7470 55%, #a48878 78%, #b8a088 100%)', particles: 'snow', count: 100, speed: 1.2 },
  'Snow Cloud':               { day: 'linear-gradient(180deg, #909ab0 0%, #a0aac0 45%, #b0bace 80%, #c0c8d8 100%)', night: 'linear-gradient(180deg, #181e28 0%, #222c36 50%, #2c3440 100%)', sunrise: 'linear-gradient(180deg, #404858 0%, #9e9282 40%, #b6a492 70%, #caba9e 100%)', sunset: 'linear-gradient(180deg, #322648 0%, #766670 30%, #8e7670 55%, #a68878 78%, #bea888 100%)', particles: 'snow', count: 100, speed: 1.2 },
  'Heavy Snow':               { day: 'linear-gradient(180deg, #8898b0 0%, #9aa8c0 45%, #a8b8cc 80%, #b8c4d4 100%)', night: 'linear-gradient(180deg, #141c24 0%, #1e2830 50%, #283038 100%)', sunrise: 'linear-gradient(180deg, #404858 0%, #a09080 40%, #b8a090 70%, #ccb8a0 100%)', sunset: 'linear-gradient(180deg, #302448 0%, #786870 30%, #907870 55%, #a88c80 78%, #bcaa90 100%)', particles: 'heavySnow', count: 200, speed: 1.5 },
  'Heavy Snow Night':         { day: 'linear-gradient(180deg, #141c24 0%, #1e2830 50%, #283038 100%)', night: 'linear-gradient(180deg, #141c24 0%, #1e2830 50%, #283038 100%)', sunrise: 'linear-gradient(180deg, #404858 0%, #a09080 40%, #b8a090 70%, #ccb8a0 100%)', sunset: 'linear-gradient(180deg, #302448 0%, #786870 30%, #907870 55%, #a88c80 78%, #bcaa90 100%)', particles: 'heavySnow', count: 200, speed: 1.5 },
  'Heavy Snow Cloud':         { day: 'linear-gradient(180deg, #98a0b8 0%, #a8b0c4 45%, #b4bcd0 80%, #c4cce0 100%)', night: 'linear-gradient(180deg, #181e28 0%, #222a34 50%, #2c3440 100%)', sunrise: 'linear-gradient(180deg, #444c58 0%, #a29282 40%, #baa292 70%, #cebaa0 100%)', sunset: 'linear-gradient(180deg, #342848 0%, #7a6a70 30%, #927870 55%, #aa8e80 78%, #bea890 100%)', particles: 'heavySnow', count: 200, speed: 1.5 },
  'Blizzard':                 { day: 'linear-gradient(180deg, #707888 0%, #808890 45%, #909098 100%)', night: 'linear-gradient(180deg, #0c1018 0%, #141820 50%, #1c2028 100%)', sunrise: 'linear-gradient(180deg, #303840 0%, #807060 40%, #988070 70%, #b09888 100%)', sunset: 'linear-gradient(180deg, #201a30 0%, #604858 30%, #785858 55%, #8c6858 78%, #a08068 100%)', particles: 'blizzard', count: 320, speed: 4.5, wind: true },
  'Blizzard Night':           { day: 'linear-gradient(180deg, #0c1018 0%, #141820 50%, #1c2028 100%)', night: 'linear-gradient(180deg, #0c1018 0%, #141820 50%, #1c2028 100%)', sunrise: 'linear-gradient(180deg, #303840 0%, #807060 40%, #988070 70%, #b09888 100%)', sunset: 'linear-gradient(180deg, #201a30 0%, #604858 30%, #785858 55%, #8c6858 78%, #a08068 100%)', particles: 'blizzard', count: 320, speed: 4.5, wind: true },
  'Blizzard Cloud':           { day: 'linear-gradient(180deg, #8090a0 0%, #909aa8 45%, #a0a8b4 80%, #b0b4bc 100%)', night: 'linear-gradient(180deg, #141c24 0%, #1c2430 50%, #242c38 100%)', sunrise: 'linear-gradient(180deg, #383e4a 0%, #9a8a80 40%, #b09c90 70%, #c8b4a4 100%)', sunset: 'linear-gradient(180deg, #261a38 0%, #6c5c6a 30%, #867070 55%, #9c8880 78%, #b4a494 100%)', particles: 'blizzard', count: 320, speed: 4.5, wind: true },
  // Sleet
  'Light Sleet':              { day: 'linear-gradient(180deg, #607080 0%, #708090 45%, #8090a0 80%, #90a0ae 100%)', night: 'linear-gradient(180deg, #0e1620 0%, #181e2c 50%, #202830 100%)', sunrise: 'linear-gradient(180deg, #2c3440 0%, #786860 40%, #909070 70%, #a89880 100%)', sunset: 'linear-gradient(180deg, #241820 0%, #605060 30%, #787060 55%, #8a7860 78%, #a09070 100%)', particles: 'sleet', count: 55 },
  'Light Sleet Night':        { day: 'linear-gradient(180deg, #0e1620 0%, #181e2c 50%, #202830 100%)', night: 'linear-gradient(180deg, #0e1620 0%, #181e2c 50%, #202830 100%)', sunrise: 'linear-gradient(180deg, #2c3440 0%, #786860 40%, #909070 70%, #a89880 100%)', sunset: 'linear-gradient(180deg, #241820 0%, #605060 30%, #787060 55%, #8a7860 78%, #a09070 100%)', particles: 'sleet', count: 55 },
  'Light Sleet Cloud':        { day: 'linear-gradient(180deg, #708090 0%, #8090a0 45%, #90a0b0 80%, #a0b0be 100%)', night: 'linear-gradient(180deg, #141e28 0%, #1e2830 50%, #283038 100%)', sunrise: 'linear-gradient(180deg, #303c48 0%, #7c7068 40%, #949278 70%, #acaa88 100%)', sunset: 'linear-gradient(180deg, #282030 0%, #645860 30%, #7c7062 55%, #8e7c62 78%, #a29272 100%)', particles: 'sleet', count: 55 },
  'Sleet':                    { day: 'linear-gradient(180deg, #586070 0%, #687080 45%, #788090 80%, #888e9e 100%)', night: 'linear-gradient(180deg, #0c1418 0%, #141c24 50%, #1c242c 100%)', sunrise: 'linear-gradient(180deg, #283038 0%, #706258 40%, #888070 70%, #a09888 100%)', sunset: 'linear-gradient(180deg, #201620 0%, #584858 30%, #705858 55%, #887060 78%, #9c8870 100%)', particles: 'sleet', count: 90 },
  'Sleet Night':              { day: 'linear-gradient(180deg, #0c1418 0%, #141c24 50%, #1c242c 100%)', night: 'linear-gradient(180deg, #0c1418 0%, #141c24 50%, #1c242c 100%)', sunrise: 'linear-gradient(180deg, #283038 0%, #706258 40%, #888070 70%, #a09888 100%)', sunset: 'linear-gradient(180deg, #201620 0%, #584858 30%, #705858 55%, #887060 78%, #9c8870 100%)', particles: 'sleet', count: 90 },
  'Sleet Cloud':              { day: 'linear-gradient(180deg, #6a7888 0%, #788898 45%, #8898a8 80%, #9aa8b8 100%)', night: 'linear-gradient(180deg, #101820 0%, #1a2430 50%, #222c3a 100%)', sunrise: 'linear-gradient(180deg, #2c3440 0%, #726868 40%, #8a8272 70%, #a09a82 100%)', sunset: 'linear-gradient(180deg, #221828 0%, #5c4a5a 30%, #726060 55%, #887878 78%, #9e9080 100%)', particles: 'sleet', count: 90 },
  'Heavy Sleet':              { day: 'linear-gradient(180deg, #485668 0%, #586070 45%, #686e80 80%, #787e8e 100%)', night: 'linear-gradient(180deg, #0a1018 0%, #121820 50%, #1a1e28 100%)', sunrise: 'linear-gradient(180deg, #242c38 0%, #645e58 40%, #80786a 70%, #988e7a 100%)', sunset: 'linear-gradient(180deg, #1e1428 0%, #544858 30%, #686060 55%, #807862 78%, #969070 100%)', particles: 'sleet', count: 160, speed: 10 },
  'Heavy Sleet Night':        { day: 'linear-gradient(180deg, #0a1018 0%, #121820 50%, #1a1e28 100%)', night: 'linear-gradient(180deg, #0a1018 0%, #121820 50%, #1a1e28 100%)', sunrise: 'linear-gradient(180deg, #242c38 0%, #645e58 40%, #80786a 70%, #988e7a 100%)', sunset: 'linear-gradient(180deg, #1e1428 0%, #544858 30%, #686060 55%, #807862 78%, #969070 100%)', particles: 'sleet', count: 160, speed: 10 },
  'Heavy Sleet Cloud':        { day: 'linear-gradient(180deg, #58687a 0%, #687282 45%, #788086 80%, #888e96 100%)', night: 'linear-gradient(180deg, #0e1420 0%, #18202a 50%, #20282e 100%)', sunrise: 'linear-gradient(180deg, #282e3a 0%, #685e58 40%, #82786c 70%, #9a9078 100%)', sunset: 'linear-gradient(180deg, #201428 0%, #564858 30%, #6a6060 55%, #80786a 78%, #989070 100%)', particles: 'sleet', count: 160, speed: 10 },
  // Hail
  'Light Hail':               { day: 'linear-gradient(180deg, #5a7080 0%, #6a8090 45%, #7a90a0 80%, #8aa0ae 100%)', night: 'linear-gradient(180deg, #0e1620 0%, #181e2c 50%, #202830 100%)', sunrise: 'linear-gradient(180deg, #2c3440 0%, #746860 40%, #8c8270 70%, #a49a80 100%)', sunset: 'linear-gradient(180deg, #221828 0%, #5c5060 30%, #746860 55%, #8a7e60 78%, #9e9470 100%)', particles: 'hail', count: 35 },
  'Light Hail Night':         { day: 'linear-gradient(180deg, #0e1620 0%, #181e2c 50%, #202830 100%)', night: 'linear-gradient(180deg, #0e1620 0%, #181e2c 50%, #202830 100%)', sunrise: 'linear-gradient(180deg, #2c3440 0%, #746860 40%, #8c8270 70%, #a49a80 100%)', sunset: 'linear-gradient(180deg, #221828 0%, #5c5060 30%, #746860 55%, #8a7e60 78%, #9e9470 100%)', particles: 'hail', count: 35 },
  'Light Hail Cloud':         { day: 'linear-gradient(180deg, #6a8090 0%, #7a9098 45%, #8a9ea8 80%, #9aaab4 100%)', night: 'linear-gradient(180deg, #141e28 0%, #1e2830 50%, #283038 100%)', sunrise: 'linear-gradient(180deg, #303c48 0%, #7a7268 40%, #928c78 70%, #aca490 100%)', sunset: 'linear-gradient(180deg, #261828 0%, #605860 30%, #787268 55%, #8e8468 78%, #a29878 100%)', particles: 'hail', count: 35 },
  'Hail':                     { day: 'linear-gradient(180deg, #485e70 0%, #586070 45%, #687080 80%, #787a88 100%)', night: 'linear-gradient(180deg, #0c1420 0%, #141e28 50%, #1c2630 100%)', sunrise: 'linear-gradient(180deg, #283040 0%, #6c6060 40%, #847872 70%, #9c9082 100%)', sunset: 'linear-gradient(180deg, #201828 0%, #584c58 30%, #706060 55%, #887868 78%, #9c9070 100%)', particles: 'hail', count: 60 },
  'Hail Night':               { day: 'linear-gradient(180deg, #0c1420 0%, #141e28 50%, #1c2630 100%)', night: 'linear-gradient(180deg, #0c1420 0%, #141e28 50%, #1c2630 100%)', sunrise: 'linear-gradient(180deg, #283040 0%, #6c6060 40%, #847872 70%, #9c9082 100%)', sunset: 'linear-gradient(180deg, #201828 0%, #584c58 30%, #706060 55%, #887868 78%, #9c9070 100%)', particles: 'hail', count: 60 },
  'Hail Cloud':               { day: 'linear-gradient(180deg, #586878 0%, #687280 45%, #788088 80%, #888a90 100%)', night: 'linear-gradient(180deg, #101820 0%, #181e28 50%, #202830 100%)', sunrise: 'linear-gradient(180deg, #2a3240 0%, #6e6460 40%, #867e72 70%, #9e9882 100%)', sunset: 'linear-gradient(180deg, #221828 0%, #5c5060 30%, #726060 55%, #887c68 78%, #9e9470 100%)', particles: 'hail', count: 60 },
  'Heavy Hail':               { day: 'linear-gradient(180deg, #384858 0%, #485060 45%, #565e6a 80%, #646870 100%)', night: 'linear-gradient(180deg, #080e18 0%, #101620 50%, #181e28 100%)', sunrise: 'linear-gradient(180deg, #202830 0%, #605458 40%, #786a68 70%, #908070 100%)', sunset: 'linear-gradient(180deg, #180e28 0%, #4e3a50 30%, #644848 55%, #7c6050 78%, #907868 100%)', particles: 'hail', count: 110 },
  'Heavy Hail Night':         { day: 'linear-gradient(180deg, #080e18 0%, #101620 50%, #181e28 100%)', night: 'linear-gradient(180deg, #080e18 0%, #101620 50%, #181e28 100%)', sunrise: 'linear-gradient(180deg, #202830 0%, #605458 40%, #786a68 70%, #908070 100%)', sunset: 'linear-gradient(180deg, #180e28 0%, #4e3a50 30%, #644848 55%, #7c6050 78%, #907868 100%)', particles: 'hail', count: 110 },
  'Heavy Hail Cloud':         { day: 'linear-gradient(180deg, #485868 0%, #586068 45%, #646870 80%, #727078 100%)', night: 'linear-gradient(180deg, #0c1020 0%, #141820 50%, #1c2028 100%)', sunrise: 'linear-gradient(180deg, #242c38 0%, #625858 40%, #7a6e6a 70%, #928270 100%)', sunset: 'linear-gradient(180deg, #1c1028 0%, #524050 30%, #664a4a 55%, #7e6252 78%, #928068 100%)', particles: 'hail', count: 110 },
  // Thunder
  'Thundery Shower':          { day: 'linear-gradient(180deg, #202a38 0%, #2c3848 45%, #384050 80%, #444858 100%)', night: 'linear-gradient(180deg, #060810 0%, #0c1018 50%, #10141c 100%)', sunrise: 'linear-gradient(180deg, #181e28 0%, #483830 40%, #584840 70%, #685850 100%)', sunset: 'linear-gradient(180deg, #100c20 0%, #3a2838 30%, #4c3038 55%, #5c3e38 78%, #704e40 100%)', particles: 'torrential', count: 120, lightning: true },
  'Thundery Shower Night':    { day: 'linear-gradient(180deg, #060810 0%, #0c1018 50%, #10141c 100%)', night: 'linear-gradient(180deg, #060810 0%, #0c1018 50%, #10141c 100%)', sunrise: 'linear-gradient(180deg, #181e28 0%, #483830 40%, #584840 70%, #685850 100%)', sunset: 'linear-gradient(180deg, #100c20 0%, #3a2838 30%, #4c3038 55%, #5c3e38 78%, #704e40 100%)', particles: 'torrential', count: 120, lightning: true },
  'Thundery Shower Cloud':    { day: 'linear-gradient(180deg, #282e3a 0%, #343a48 45%, #404858 80%, #4e5460 100%)', night: 'linear-gradient(180deg, #080c18 0%, #10141e 50%, #14181e 100%)', sunrise: 'linear-gradient(180deg, #1c2030 0%, #4c3c38 40%, #5c4c40 70%, #6c5c50 100%)', sunset: 'linear-gradient(180deg, #140a20 0%, #3e2c3c 30%, #4e3438 55%, #604040 78%, #724e44 100%)', particles: 'torrential', count: 120, lightning: true },
  'Isolated Thunderstorms':   { day: 'linear-gradient(180deg, #1a2230 0%, #262e3c 45%, #32384a 80%, #3e4050 100%)', night: 'linear-gradient(180deg, #04060e 0%, #080c14 50%, #0c1018 100%)', sunrise: 'linear-gradient(180deg, #141a28 0%, #402e28 40%, #4e3c30 70%, #5e4c3e 100%)', sunset: 'linear-gradient(180deg, #0e0c1e 0%, #322234 30%, #402a30 55%, #503836 78%, #624840 100%)', particles: 'torrential', count: 170, lightning: true, speed: 14 },
  'Scattered Thunderstorms':  { day: 'linear-gradient(180deg, #141e2c 0%, #202830 45%, #2c3040 80%, #38383e 100%)', night: 'linear-gradient(180deg, #020408 0%, #060810 50%, #0a0e14 100%)', sunrise: 'linear-gradient(180deg, #10161e 0%, #382820 40%, #463430 70%, #584040 100%)', sunset: 'linear-gradient(180deg, #0c0a1a 0%, #2c1c28 30%, #38222a 55%, #482e2e 78%, #584038 100%)', particles: 'torrential', count: 230, lightning: true, speed: 15 },
  'Thunderstorms':            { day: 'linear-gradient(180deg, #10181e 0%, #1a2028 45%, #222830 80%, #2c2c34 100%)', night: 'linear-gradient(180deg, #020406 0%, #040608 50%, #080c10 100%)', sunrise: 'linear-gradient(180deg, #0e1218 0%, #302018 40%, #3c2c24 70%, #4c3c30 100%)', sunset: 'linear-gradient(180deg, #080618 0%, #24182c 30%, #30201e 55%, #3e2c28 78%, #4c3a30 100%)', particles: 'torrential', count: 300, lightning: true, speed: 16 },
};

const SOUND_LABELS = {
  null: '—',
  drizzle: '🌧 Drizzle',
  rain: '🌧 Rain',
  torrential: '🌧 Heavy Rain',
  snow: '❄️ Snow',
  heavySnow: '❄️ Heavy Snow',
  blizzard: '🌨 Blizzard',
  sleet: '🌨 Sleet',
  hail: '🌩 Hail',
  fog: '🌫 Mist',
  wind: '💨 Wind',
  lightning: '⚡ Thunder',
};

const PHASES = ['day', 'sunrise', 'sunset', 'night'];
const PHASE_LABELS = { day: 'Day', sunrise: 'Sunrise', sunset: 'Sunset', night: 'Night' };

const CATEGORIES = [
  { label: 'Clear & Sunny', keys: ['Sunny', 'Clear Night', 'Sunny Intervals', 'Sunny Intervals Night', 'Partly Cloudy', 'Partly Cloudy Night'] },
  { label: 'Cloud & Atmosphere', keys: ['Cloudy', 'Overcast', 'Mist', 'Fog', 'Windy'] },
  { label: 'Rain — Day', keys: ['Drizzle', 'Light Rain', 'Moderate Rain', 'Heavy Rain', 'Torrential Rain', 'Rain Shower', 'Heavy Showers'] },
  { label: 'Rain — Night', keys: ['Drizzle Night', 'Light Rain Night', 'Moderate Rain Night', 'Heavy Rain Night', 'Torrential Rain Night', 'Rain Shower Night', 'Heavy Showers Night'] },
  { label: 'Rain — Cloud', keys: ['Rain Shower Cloud', 'Heavy Showers Cloud'] },
  { label: 'Snow — Day', keys: ['Flurry', 'Light Snow', 'Snow', 'Heavy Snow', 'Blizzard'] },
  { label: 'Snow — Night', keys: ['Flurry Night', 'Light Snow Night', 'Snow Night', 'Heavy Snow Night', 'Blizzard Night'] },
  { label: 'Snow — Cloud', keys: ['Flurry Cloud', 'Light Snow Cloud', 'Snow Cloud', 'Heavy Snow Cloud', 'Blizzard Cloud'] },
  { label: 'Sleet — Day', keys: ['Light Sleet', 'Sleet', 'Heavy Sleet'] },
  { label: 'Sleet — Night', keys: ['Light Sleet Night', 'Sleet Night', 'Heavy Sleet Night'] },
  { label: 'Sleet — Cloud', keys: ['Light Sleet Cloud', 'Sleet Cloud', 'Heavy Sleet Cloud'] },
  { label: 'Hail — Day', keys: ['Light Hail', 'Hail', 'Heavy Hail'] },
  { label: 'Hail — Night', keys: ['Light Hail Night', 'Hail Night', 'Heavy Hail Night'] },
  { label: 'Hail — Cloud', keys: ['Light Hail Cloud', 'Hail Cloud', 'Heavy Hail Cloud'] },
  { label: 'Thunderstorms', keys: ['Thundery Shower', 'Thundery Shower Night', 'Thundery Shower Cloud', 'Isolated Thunderstorms', 'Scattered Thunderstorms', 'Thunderstorms'] },
];

function useLightning(active) {
  const [flash, setFlash] = React.useState(false);
  useEffect(() => {
    if (!active) return;
    let t;
    function schedule() {
      t = setTimeout(() => {
        setFlash(true);
        setTimeout(() => setFlash(false), 100);
        schedule();
      }, 3000 + Math.random() * 8000);
    }
    schedule();
    return () => clearTimeout(t);
  }, [active]);
  return flash;
}

function AnimatedSwatch({ name, gradient, phase, cfg, playSound }) {
  const canvasRef = useRef(null);
  const lightning = useLightning(!!(cfg?.lightning));
  const audioCtxRef = useRef(null);

  // Sound preview on click
  const handleSoundPreview = (e) => {
    e.stopPropagation();
    if (!playSound || !cfg) return;
    try {
      if (audioCtxRef.current) { try { audioCtxRef.current.close(); } catch {} }
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      audioCtxRef.current = ctx;
      const bufferSize = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      src.loop = false;
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      const pType = cfg.particles;
      filter.frequency.value = pType === 'blizzard' || pType === 'wind' ? 280 : pType === 'snow' || pType === 'heavySnow' ? 320 : pType === 'torrential' ? 700 : pType === 'rain' ? 1400 : pType === 'drizzle' ? 2200 : pType === 'hail' ? 1800 : pType === 'sleet' ? 1500 : pType === 'fog' ? 600 : 1000;
      filter.Q.value = 1;
      const gain = ctx.createGain();
      const intensity = pType === 'torrential' ? 0.5 : pType === 'blizzard' ? 0.3 : pType === 'heavySnow' ? 0.15 : 0.2;
      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(intensity, ctx.currentTime + 0.1);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 2);
      src.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      src.start();
      src.stop(ctx.currentTime + 2);
      if (cfg.lightning) {
        setTimeout(() => {
          if (ctx.state === 'closed') return;
          const osc = ctx.createOscillator();
          const g = ctx.createGain();
          osc.frequency.value = 50;
          osc.type = 'sawtooth';
          g.gain.setValueAtTime(0.4, ctx.currentTime);
          g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);
          osc.connect(g);
          g.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 1.2);
        }, 500 + Math.random() * 800);
      }
    } catch {}
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !cfg?.particles) return;

    canvas.width = canvas.offsetWidth || 120;
    canvas.height = canvas.offsetHeight || 64;
    const W = canvas.width;
    const H = canvas.height;
    const ctx = canvas.getContext('2d');
    const type = cfg.particles;
    const count = Math.round((cfg.count || 60) * (W * H) / (400 * 200));
    const spd = cfg.speed || (type === 'torrential' ? 15 : type === 'rain' ? 8 : type === 'sleet' ? 7 : type === 'blizzard' ? 4.5 : type === 'heavySnow' ? 1.5 : type === 'snow' ? 1.2 : type === 'hail' ? 10 : 1);

    const particles = Array.from({ length: count }, () => mkP(W, H, type, spd, true));

    function mkP(W, H, type, spd, init = false) {
      const x = Math.random() * W;
      const y = init ? Math.random() * H : -8;
      if (type === 'fog') {
        return { x, y: Math.random() * H, vx: 0.15 + Math.random() * 0.2, vy: 0, w: 40 + Math.random() * 60, op: 0.04 + Math.random() * 0.06 };
      }
      if (type === 'wind') {
        return { x, y: Math.random() * H, vx: 1 + Math.random() * 2, vy: (Math.random() - 0.5) * 0.3, len: 15 + Math.random() * 30, op: 0.04 + Math.random() * 0.08 };
      }
      if (type === 'snow' || type === 'heavySnow') {
        const bigFlake = type === 'heavySnow' && Math.random() < 0.3;
        return { x, y, r: bigFlake ? 2.5 + Math.random() * 2 : 1 + Math.random() * 2, vy: spd * (0.6 + Math.random()), vx: (Math.random() - 0.5) * 0.5, phase: Math.random() * Math.PI * 2, op: 0.5 + Math.random() * 0.5 };
      }
      if (type === 'blizzard') {
        return { x, y, r: 1 + Math.random() * 2.5, vy: spd * (0.7 + Math.random()), vx: -(1.5 + Math.random() * 2.5), phase: Math.random() * Math.PI * 2, op: 0.5 + Math.random() * 0.5 };
      }
      if (type === 'hail') {
        return { x, y, r: 1.5 + Math.random() * 2, vy: spd + Math.random() * 3, vx: (Math.random() - 0.5), op: 0.6 + Math.random() * 0.4 };
      }
      if (type === 'sleet') {
        return { x, y, vy: spd + Math.random() * 2, vx: -0.5 - Math.random(), len: 5 + Math.random() * 4, op: 0.4 + Math.random() * 0.4, isSnow: Math.random() < 0.35, r: 1 + Math.random() * 1.5 };
      }
      // rain / drizzle / torrential
      const len = type === 'torrential' ? 18 + Math.random() * 10 : type === 'drizzle' ? 4 + Math.random() * 3 : 8 + Math.random() * 6;
      const wx = type === 'torrential' ? -(0.8 + Math.random() * 0.5) : -0.2 - Math.random() * 0.3;
      return { x, y, vy: spd + Math.random() * (type === 'drizzle' ? 1.5 : 3), vx: wx, len, op: 0.3 + Math.random() * 0.5 };
    }

    let animId;
    let t = 0;
    function draw() {
      ctx.clearRect(0, 0, W, H);
      t += 0.016;
      for (const p of particles) {
        if (type === 'fog') {
          const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.w);
          g.addColorStop(0, `rgba(255,255,255,${p.op})`);
          g.addColorStop(1, `rgba(255,255,255,0)`);
          ctx.fillStyle = g;
          ctx.fillRect(p.x - p.w, p.y - p.w * 0.5, p.w * 2, p.w);
          p.x += p.vx;
          if (p.x > W + p.w) p.x = -p.w;
          continue;
        }
        if (type === 'wind') {
          p.x += p.vx;
          p.y += p.vy;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.len, p.y);
          ctx.strokeStyle = `rgba(200,220,255,${p.op})`;
          ctx.lineWidth = 0.7;
          ctx.stroke();
          if (p.x > W + p.len) { p.x = -p.len; p.y = Math.random() * H; }
          continue;
        }
        if (type === 'snow' || type === 'heavySnow') {
          p.x += p.vx + Math.sin(t + p.phase) * 0.3;
          p.y += p.vy;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(210,230,255,${p.op})`;
          ctx.fill();
          if (p.y > H + 4) Object.assign(p, mkP(W, H, type, spd));
          continue;
        }
        if (type === 'blizzard') {
          p.x += p.vx;
          p.y += p.vy + Math.sin(t + p.phase) * 0.4;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(220,235,255,${p.op})`;
          ctx.fill();
          if (p.y > H + 4 || p.x < -4) Object.assign(p, { ...mkP(W, H, type, spd), x: W + 4 });
          continue;
        }
        if (type === 'hail') {
          p.x += p.vx;
          p.y += p.vy;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(200,225,255,${p.op})`;
          ctx.strokeStyle = `rgba(150,200,240,${p.op * 0.7})`;
          ctx.lineWidth = 0.5;
          ctx.fill();
          ctx.stroke();
          if (p.y > H + 4) Object.assign(p, mkP(W, H, type, spd));
          continue;
        }
        if (type === 'sleet') {
          p.x += p.vx;
          p.y += p.vy;
          if (p.isSnow) {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(210,230,255,${p.op})`;
            ctx.fill();
          } else {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p.x - (p.vx / p.vy) * p.len, p.y - p.len);
            ctx.strokeStyle = `rgba(140,180,220,${p.op})`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
          if (p.y > H + 6) Object.assign(p, mkP(W, H, type, spd));
          continue;
        }
        // rain / drizzle / torrential
        p.x += p.vx;
        p.y += p.vy;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - (p.vx / p.vy) * p.len, p.y - p.len);
        ctx.strokeStyle = type === 'drizzle' ? `rgba(180,210,240,${p.op * 0.5})` : type === 'torrential' ? `rgba(100,140,200,${p.op * 0.85})` : `rgba(140,180,230,${p.op * 0.7})`;
        ctx.lineWidth = type === 'drizzle' ? 0.6 : type === 'torrential' ? 2.0 : 1.2;
        ctx.stroke();
        if (p.y > H + 20) Object.assign(p, mkP(W, H, type, spd));
      }
      animId = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(animId);
  }, [cfg?.particles, cfg?.count, cfg?.speed]);

  const soundType = cfg?.particles;
  const hasSound = !!soundType;

  return (
    <div className="flex flex-col items-center gap-1">
      <div
        className="relative w-full h-20 rounded-lg border border-white/10 shadow-inner overflow-hidden"
        style={{ background: gradient }}
        title={`${name} — ${PHASE_LABELS[phase]}`}
      >
        {cfg?.particles && (
          <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
        )}
        {lightning && (
          <div className="absolute inset-0 bg-white/25 pointer-events-none transition-opacity" />
        )}
        {hasSound && (
          <button
            onClick={handleSoundPreview}
            className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-black/40 border border-white/20 flex items-center justify-center text-white/70 hover:text-white hover:bg-black/60 transition-colors text-[10px]"
            title="Preview sound"
          >
            ♪
          </button>
        )}
      </div>
      <span className="text-[10px] text-slate-400">{PHASE_LABELS[phase]}</span>
    </div>
  );
}

export default function WeatherBackgroundsLibrary() {
  const [activePhase, setActivePhase] = useState('all');
  const [soundEnabled, setSoundEnabled] = useState(true);

  const phasesToShow = activePhase === 'all' ? PHASES : [activePhase];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Weather Backgrounds Library</h2>
          <p className="text-slate-500 text-sm mt-1">All sky gradients with animations. Click ♪ on any swatch to preview its sound.</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setSoundEnabled(v => !v)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5 ${soundEnabled ? 'bg-sky-600 text-white' : 'bg-slate-200 text-slate-600'}`}
          >
            {soundEnabled ? '🔊' : '🔇'} Sound Preview
          </button>
          {['all', ...PHASES].map(p => (
            <button
              key={p}
              onClick={() => setActivePhase(p)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${activePhase === p ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              {p === 'all' ? 'All' : PHASE_LABELS[p]}
            </button>
          ))}
        </div>
      </div>

      {CATEGORIES.map(cat => (
        <motion.div
          key={cat.label}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-900 rounded-2xl p-5 space-y-4"
        >
          <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">{cat.label}</h3>
          <div className="space-y-4">
            {cat.keys.map(conditionName => {
              const cfg = SKY_CONFIGS[conditionName];
              if (!cfg) return null;
              return (
                <div key={conditionName} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <p className="text-xs font-medium text-slate-400">{conditionName}</p>
                    {cfg.particles && <span className="text-[10px] text-slate-500">{SOUND_LABELS[cfg.particles] || cfg.particles}{cfg.lightning ? ' + ⚡' : ''}</span>}
                  </div>
                  <div className={`grid gap-2 ${phasesToShow.length === 4 ? 'grid-cols-4' : phasesToShow.length === 2 ? 'grid-cols-2' : 'grid-cols-1'}`}>
                    {phasesToShow.map(phase => (
                      <AnimatedSwatch
                        key={phase}
                        name={conditionName}
                        gradient={cfg[phase] || cfg.day}
                        phase={phase}
                        cfg={cfg}
                        playSound={soundEnabled}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      ))}
    </div>
  );
}