import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Cloud } from 'lucide-react';

function getTimeLeft(target) {
  const diff = new Date(target) - new Date();
  if (diff <= 0) return null;
  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
    minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
    seconds: Math.floor((diff % (1000 * 60)) / 1000),
  };
}

function TimeBlock({ value, label }) {
  return (
    <motion.div
      className="flex flex-col items-center bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl px-6 py-4 min-w-[80px]"
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
    >
      <span className="text-4xl md:text-5xl font-bold text-white tabular-nums">
        {String(value).padStart(2, '0')}
      </span>
      <span className="text-xs text-slate-300 mt-1 uppercase tracking-widest">{label}</span>
    </motion.div>
  );
}

export default function CountdownDisplay({ settings }) {
  const [timeLeft, setTimeLeft] = useState(getTimeLeft(settings?.countdown_target));

  useEffect(() => {
    if (!settings?.countdown_target) return;
    const interval = setInterval(() => {
      setTimeLeft(getTimeLeft(settings.countdown_target));
    }, 1000);
    return () => clearInterval(interval);
  }, [settings?.countdown_target]);

  if (!settings) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-sky-900 flex flex-col items-center justify-center px-4 text-center">
      {/* Animated orbs */}
      <motion.div
        className="absolute top-20 left-1/4 w-96 h-96 rounded-full bg-sky-500/10 blur-3xl pointer-events-none"
        animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.7, 0.4] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute bottom-20 right-1/4 w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none"
        animate={{ scale: [1.2, 1, 1.2], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
      />

      <motion.div
        className="relative z-10 space-y-8 max-w-2xl"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <Cloud className="w-16 h-16 text-sky-400 mx-auto" />

        <div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            {settings.countdown_title || 'Coming Soon'}
          </h1>
          {settings.countdown_description && (
            <p className="text-lg text-slate-300 max-w-lg mx-auto">
              {settings.countdown_description}
            </p>
          )}
        </div>

        {timeLeft ? (
          <div className="flex flex-wrap justify-center gap-4">
            <TimeBlock value={timeLeft.days} label="Days" />
            <TimeBlock value={timeLeft.hours} label="Hours" />
            <TimeBlock value={timeLeft.minutes} label="Minutes" />
            <TimeBlock value={timeLeft.seconds} label="Seconds" />
          </div>
        ) : (
          <motion.p
            className="text-2xl text-sky-400 font-semibold"
            animate={{ opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            We're live!
          </motion.p>
        )}
      </motion.div>
    </div>
  );
}