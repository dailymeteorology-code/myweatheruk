import React from 'react';
import { motion } from 'framer-motion';
import { Pencil, Trash2, Star, StarOff } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { format } from 'date-fns';

export default function GraphicCard({ graphic, onEdit, onDelete, onToggleFeatured, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.05 }}
      className="group relative bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300"
    >
      <div className="aspect-video overflow-hidden">
        <img 
          src={graphic.image_url} 
          alt={graphic.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </div>
      
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
        <div className="flex gap-2">
          <Button 
            size="sm" 
            variant="secondary"
            onClick={() => onEdit(graphic)}
            className="flex-1"
          >
            <Pencil className="w-4 h-4 mr-1" /> Edit
          </Button>
          <Button 
            size="sm" 
            variant="secondary"
            onClick={() => onToggleFeatured(graphic)}
          >
            {graphic.is_featured ? <StarOff className="w-4 h-4" /> : <Star className="w-4 h-4" />}
          </Button>
          <Button 
            size="sm" 
            variant="destructive"
            onClick={() => onDelete(graphic.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-slate-800 line-clamp-1">{graphic.title}</h3>
          {graphic.is_featured && (
            <Star className="w-4 h-4 text-amber-500 fill-amber-500 flex-shrink-0" />
          )}
        </div>
        {graphic.description && (
          <p className="text-sm text-slate-500 mt-1 line-clamp-2">{graphic.description}</p>
        )}
        <p className="text-xs text-slate-400 mt-2">
          {format(new Date(graphic.created_date), 'MMM d, yyyy · h:mm a')}
        </p>
      </div>
    </motion.div>
  );
}