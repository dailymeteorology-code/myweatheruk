/* connectBlitzortung — extracted from pages/TCM */

const RENDER_WORKER_HOST = 'blitzortungworker-3.onrender.com';
const RENDER_WORKER_WS   = `wss://${RENDER_WORKER_HOST}`;
const BLITZORTUNG_DIRECT_SERVERS = [
  'wss://ws1.blitzortung.org',
  'wss://ws7.blitzortung.org',
  'wss://ws8.blitzortung.org',
];

const GEO_BOUNDS_EU = { latMin: 34.0, latMax: 72.0, lonMin: -25.0, lonMax: 45.0 };
function inEU(lat, lon) {
  return lat >= GEO_BOUNDS_EU.latMin && lat <= GEO_BOUNDS_EU.latMax && lon >= GEO_BOUNDS_EU.lonMin && lon <= GEO_BOUNDS_EU.lonMax;
}

function blitzortungDecode(raw) {
  try {
    const d = Array.from(raw);
    if (!d.length) return null;
    const e = {};
    let c = d[0], f = c;
    const g = [c];
    let h = 256, o = h;
    for (let i = 1; i < d.length; i++) {
      const code = d[i].charCodeAt(0);
      let a;
      if (h > code)                   a = d[i];
      else if (e[code] !== undefined) a = e[code];
      else                            a = f + c;
      g.push(a);
      c = a[0];
      e[o] = f + c;
      o++;
      f = a;
    }
    return JSON.parse(g.join(''));
  } catch (_) { return null; }
}

export function connectBlitzortung(onStrike, onStatusChange) {
  let stopped = false;
  let activeWs = null;
  let pendingWs = null;
  let serverIdx = 0;
  let reconnectTimer = null;
  let pingInterval = null;
  let consecutiveFailures = 0;

  function connect() {
    if (stopped) return;
    const url = consecutiveFailures >= 3
      ? RENDER_WORKER_WS
      : BLITZORTUNG_DIRECT_SERVERS[serverIdx % BLITZORTUNG_DIRECT_SERVERS.length];
    serverIdx++;

    let ws;
    try { ws = new WebSocket(url); } catch (_) { scheduleReconnect(); return; }
    pendingWs = ws;

    ws.onopen = () => {
      if (stopped) { ws.close(); return; }
      consecutiveFailures = 0;
      onStatusChange('live');
      if (activeWs && activeWs !== ws) { try { activeWs.close(); } catch (_) {} }
      activeWs = ws;
      pendingWs = null;
      try { ws.send(JSON.stringify({ a: 111 })); } catch (_) {}
      clearInterval(pingInterval);
      pingInterval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) { try { ws.send(JSON.stringify({ a: 111 })); } catch (_) {} }
        else { clearInterval(pingInterval); }
      }, 25000);
    };

    ws.onmessage = evt => {
      if (stopped || ws !== activeWs) return;
      try {
        let parsed = null;
        try { parsed = JSON.parse(evt.data); } catch (_) {}
        if (!parsed) parsed = blitzortungDecode(evt.data);
        if (!parsed) return;
        const strikes = parsed.strikes || (parsed.lat !== undefined ? [parsed] : null);
        if (!strikes) return;
        const nowMs = Date.now();
        strikes.forEach(s => {
          const timeMs = s.time ? (s.time > 1e12 ? Math.floor(s.time / 1e6) : s.time * 1000) : nowMs;
          let lat = s.lat, lon = s.lon;
          if (Math.abs(lat) > 90)  lat = lat / 1e7;
          if (Math.abs(lon) > 180) lon = lon / 1e7;
          if (isNaN(lat) || isNaN(lon)) return;
          if (!inEU(lat, lon)) return;
          onStrike({ lat, lon, time: timeMs, amp: s.mamp || 0 });
        });
      } catch (_) {}
    };

    ws.onerror = () => {
      consecutiveFailures++;
      clearInterval(pingInterval);
      if (ws === activeWs) { onStatusChange('connecting'); scheduleReconnect(2000); }
      else scheduleReconnect(4000);
    };

    ws.onclose = () => {
      clearInterval(pingInterval);
      if (stopped) return;
      if (ws === activeWs) { onStatusChange('connecting'); scheduleReconnect(2000); }
    };
  }

  function scheduleReconnect(ms = 4000) {
    if (stopped) return;
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(connect, ms);
  }

  const preconnectInterval = setInterval(() => {
    if (!stopped && activeWs?.readyState === WebSocket.OPEN) connect();
  }, 4 * 60 * 1000);

  connect();

  return () => {
    stopped = true;
    clearInterval(pingInterval);
    clearTimeout(reconnectTimer);
    clearInterval(preconnectInterval);
    try { activeWs?.close(); } catch (_) {}
    try { pendingWs?.close(); } catch (_) {}
  };
}