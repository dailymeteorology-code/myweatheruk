import { useEffect, useRef } from 'react';

// SPC-style colour ramp — matches your reference screenshot
export const RISK_LEVELS = [
  { threshold: 60, label: 'High',     color: '#dc2626', fillOpacity: 0.55 },
  { threshold: 45, label: 'Moderate', color: '#f97316', fillOpacity: 0.50 },
  { threshold: 30, label: 'Enhanced', color: '#facc15', fillOpacity: 0.45 },
  { threshold: 15, label: 'Slight',   color: '#a3e635', fillOpacity: 0.40 },
  { threshold: 5,  label: 'Marginal', color: '#7dd3fc', fillOpacity: 0.32 },
  { threshold: 1,  label: 'Very Low', color: '#475569', fillOpacity: 0.20 },
  { threshold: 0,  label: 'No Risk',  color: '#1e293b', fillOpacity: 0.08 },
];

function colorFor(p) {
  for (const lvl of RISK_LEVELS) if (p >= lvl.threshold) return lvl;
  return RISK_LEVELS[RISK_LEVELS.length - 1];
}

/**
 * Renders a probability grid as semi-transparent rectangles on a Leaflet map.
 *
 * @param {Object} props
 * @param {Object} props.map               — Leaflet map instance
 * @param {Array}  props.cells             — [{lat, lon, p}]
 * @param {Array}  props.polygons          — [{level, coords:[[lat,lon],...]}]
 * @param {Boolean} props.showCells        — render grid cells
 * @param {Boolean} props.showPolygons     — render contour polygons (the "drawn risk areas")
 */
export default function RiskGridLayer({ map, cells = [], polygons = [], showCells = true, showPolygons = true }) {
  const layerRef = useRef(null);

  useEffect(() => {
    const L = window.L;
    if (!L || !map) return;
    if (!layerRef.current) layerRef.current = L.layerGroup().addTo(map);
    const layer = layerRef.current;
    layer.clearLayers();

    const CELL_HALF = 0.15; // matches grid step

    if (showCells) {
      cells.forEach(c => {
        const lvl = colorFor(c.p);
        if (!lvl.color || lvl.color === 'transparent') return;
        L.rectangle(
          [[c.lat - CELL_HALF, c.lon - CELL_HALF * 1.4], [c.lat + CELL_HALF, c.lon + CELL_HALF * 1.4]],
          { color: 'transparent', fillColor: lvl.color, fillOpacity: lvl.fillOpacity * 0.7, weight: 0, interactive: false }
        ).addTo(layer);
      });
    }

    if (showPolygons) {
      // Render from lowest level outward so higher levels stack on top
      const sorted = [...polygons].sort((a, b) => a.level - b.level);
      sorted.forEach(poly => {
        const lvl = colorFor(poly.level);
        L.polygon(poly.coords, {
          color: lvl.color, fillColor: lvl.color,
          fillOpacity: lvl.fillOpacity * 0.6,
          weight: 1.5, opacity: 0.75,
          interactive: false,
        }).addTo(layer);
      });
    }

    return () => {
      try { layer.clearLayers(); } catch (_) {}
    };
  }, [map, cells, polygons, showCells, showPolygons]);

  useEffect(() => {
    return () => {
      if (layerRef.current && map) {
        try { map.removeLayer(layerRef.current); } catch (_) {}
        layerRef.current = null;
      }
    };
  }, [map]);

  return null;
}