// ── Meteorological Risk Level Configuration ───────────────────────────────────
// SPC + SOTUK style: Marginal → Slight → Moderate → High → Severe (+ Very Low, Low)

export const RISK_META = [
  { level: 'No Risk',  description: 'No appreciable convective threat.' },
  { level: 'Very Low', description: 'Very isolated storm activity possible, little impact.' },
  { level: 'Low',      description: 'Isolated storms possible, low impact.' },
  { level: 'Marginal', description: 'Isolated, generally non-severe storms possible. Like TSTMS on SPC.' },
  { level: 'Slight',   description: 'Organised storms possible, some may be severe.' },
  { level: 'Moderate', description: 'Widespread severe storms expected with high impact.' },
  { level: 'High',     description: 'Extreme severe weather outbreak. Life-threatening conditions.' },
  { level: 'Severe',   description: 'Catastrophic outbreak possible. Extremely dangerous conditions.' },
];

export const RISK_INDEX = Object.fromEntries(RISK_META.map((r, i) => [r.level, i]));

// Score → level mapping (0–100 engine score)
export const LEVEL_RANGE = {
  'No Risk':  [0,  5],
  'Very Low': [5,  12],
  'Low':      [12, 22],
  'Marginal': [22, 35],
  'Slight':   [35, 50],
  'Moderate': [50, 65],
  'High':     [65, 80],
  'Severe':   [80, 100],
};

export function scoreToLevel(s) {
  if (s < 5)  return 'No Risk';
  if (s < 12) return 'Very Low';
  if (s < 22) return 'Low';
  if (s < 35) return 'Marginal';
  if (s < 50) return 'Slight';
  if (s < 65) return 'Moderate';
  if (s < 80) return 'High';
  return 'Severe';
}

export const fmtRange = (lvl) => {
  const [a, b] = LEVEL_RANGE[lvl] || [0, 0];
  return `${a}–${b}`;
};

// SPC/SOTUK colours — matches photo 1 legend
// Thunderstorms: green shades. Severe: hatched black outline, no fill.
export const RISK_PALETTES = {
  thunderstorm: {
    'No Risk':  { color: '#64748b', fill: 'rgba(100,116,139,0)',    border: 'rgba(100,116,139,0)' },
    'Very Low': { color: '#6ee7b7', fill: 'rgba(110,231,183,0.30)', border: 'rgba(34,197,94,0.75)' },
    'Low':      { color: '#22c55e', fill: 'rgba(34,197,94,0.38)',   border: 'rgba(22,163,74,0.88)' },
    'Marginal': { color: '#eab308', fill: 'rgba(234,179,8,0.50)',   border: 'rgba(202,138,4,0.95)' },
    'Slight':   { color: '#f97316', fill: 'rgba(249,115,22,0.55)',  border: 'rgba(234,88,12,0.96)' },
    'Moderate': { color: '#dc2626', fill: 'rgba(220,38,38,0.60)',   border: 'rgba(185,28,28,0.97)' },
    'High':     { color: '#9333ea', fill: 'rgba(147,51,234,0.65)',  border: 'rgba(126,34,206,0.98)' },
    'Severe':   { color: '#000000', fill: 'rgba(0,0,0,0.04)',       border: 'rgba(0,0,0,0.90)' },
  },
  hail: {
    'No Risk':  { color: '#64748b', fill: 'rgba(100,116,139,0)',    border: 'rgba(100,116,139,0)' },
    'Very Low': { color: '#bae6fd', fill: 'rgba(186,230,253,0.28)', border: 'rgba(125,211,252,0.75)' },
    'Low':      { color: '#7dd3fc', fill: 'rgba(125,211,252,0.35)', border: 'rgba(56,189,248,0.85)' },
    'Marginal': { color: '#38bdf8', fill: 'rgba(56,189,248,0.42)',  border: 'rgba(14,165,233,0.90)' },
    'Slight':   { color: '#0ea5e9', fill: 'rgba(14,165,233,0.48)',  border: 'rgba(2,132,199,0.93)' },
    'Moderate': { color: '#0369a1', fill: 'rgba(3,105,161,0.53)',   border: 'rgba(30,64,175,0.95)' },
    'High':     { color: '#1e40af', fill: 'rgba(30,64,175,0.58)',   border: 'rgba(91,33,182,0.97)' },
    'Severe':   { color: '#000000', fill: 'rgba(0,0,0,0.04)',       border: 'rgba(0,0,0,0.90)' },
  },
  tornado: {
    'No Risk':  { color: '#64748b', fill: 'rgba(100,116,139,0)',    border: 'rgba(100,116,139,0)' },
    'Very Low': { color: '#fde68a', fill: 'rgba(253,230,138,0.28)', border: 'rgba(252,211,77,0.75)' },
    'Low':      { color: '#fcd34d', fill: 'rgba(252,211,77,0.35)',  border: 'rgba(250,204,21,0.85)' },
    'Marginal': { color: '#f97316', fill: 'rgba(249,115,22,0.42)',  border: 'rgba(234,88,12,0.90)' },
    'Slight':   { color: '#ea580c', fill: 'rgba(234,88,12,0.48)',   border: 'rgba(220,38,38,0.93)' },
    'Moderate': { color: '#dc2626', fill: 'rgba(220,38,38,0.53)',   border: 'rgba(185,28,28,0.95)' },
    'High':     { color: '#9f1239', fill: 'rgba(159,18,57,0.58)',   border: 'rgba(159,18,57,0.97)' },
    'Severe':   { color: '#000000', fill: 'rgba(0,0,0,0.04)',       border: 'rgba(0,0,0,0.90)' },
  },
  lightning: {
    'No Risk':  { color: '#64748b', fill: 'rgba(100,116,139,0)',    border: 'rgba(100,116,139,0)' },
    'Very Low': { color: '#fef08a', fill: 'rgba(254,240,138,0.28)', border: 'rgba(202,138,4,0.70)' },
    'Low':      { color: '#facc15', fill: 'rgba(250,204,21,0.35)',  border: 'rgba(202,138,4,0.82)' },
    'Marginal': { color: '#eab308', fill: 'rgba(234,179,8,0.42)',   border: 'rgba(180,83,9,0.87)' },
    'Slight':   { color: '#f97316', fill: 'rgba(249,115,22,0.48)',  border: 'rgba(249,115,22,0.92)' },
    'Moderate': { color: '#a855f7', fill: 'rgba(168,85,247,0.53)',  border: 'rgba(126,34,206,0.95)' },
    'High':     { color: '#7c3aed', fill: 'rgba(124,58,237,0.58)',  border: 'rgba(91,33,182,0.97)' },
    'Severe':   { color: '#000000', fill: 'rgba(0,0,0,0.04)',       border: 'rgba(0,0,0,0.90)' },
  },
};

export const RISK_DESCRIPTIONS = {
  thunderstorm: Object.fromEntries(RISK_META.map(r => [r.level, r.description])),
  hail: {
    'No Risk': 'No hail expected.', 'Very Low': 'Graupel or tiny hail possible.',
    'Low': 'Small hail (<5mm) in isolated cells.',
    'Marginal': 'Small hail (<15mm) possible.', 'Slight': 'Hail to 20–30mm possible.',
    'Moderate': 'Large hail (30–50mm) likely.', 'High': 'Giant hail (>50mm) possible.',
    'Severe': 'Extraordinary hail event possible.',
  },
  tornado: {
    'No Risk': 'No tornado threat.', 'Very Low': 'Extremely isolated tornado not impossible.',
    'Low': 'Very isolated weak tornado possible.',
    'Marginal': 'Isolated weak tornado not impossible.', 'Slight': 'Brief weak tornado possible.',
    'Moderate': 'Organised T2–T3 tornado possible.', 'High': 'Strong T3–T4 tornado possible.',
    'Severe': 'Violent T5+ tornado possible.',
  },
  lightning: {
    'No Risk': 'No lightning expected.', 'Very Low': 'Very isolated lightning possible.',
    'Low': 'Isolated lightning in marginal convection.',
    'Marginal': 'Scattered lightning with occasional CG strikes.', 'Slight': 'Frequent lightning likely.',
    'Moderate': 'Very frequent lightning.', 'High': 'Extreme lightning rates.',
    'Severe': 'Extraordinary lightning density.',
  },
};

// Min score per level — used by geometry engine
export const MIN_SCORE_PER_LEVEL = {
  'Very Low': 5,
  'Low':      12,
  'Marginal': 22,
  'Slight':   35,
  'Moderate': 50,
  'High':     65,
  'Severe':   80,
};

// Graduated opacity — outermost translucent, innermost solid (like photo 1)
export const LEVEL_OPACITY = {
  'Very Low': 0.40,
  'Low':      0.52,
  'Marginal': 0.62,
  'Slight':   0.72,
  'Moderate': 0.82,
  'High':     0.92,
  'Severe':   1.00,
};

export const paletteOf = (rt) => RISK_PALETTES[rt] || RISK_PALETTES.thunderstorm;
export const RISK_COLOR  = (lvl, rt = 'thunderstorm') => paletteOf(rt)[lvl]?.color  || '#64748b';
export const RISK_FILL   = (lvl, rt = 'thunderstorm') => paletteOf(rt)[lvl]?.fill   || 'rgba(100,116,139,0)';
export const RISK_BORDER = (lvl, rt = 'thunderstorm') => paletteOf(rt)[lvl]?.border || 'rgba(100,116,139,0)';

export const descFor = (riskType, level) =>
  RISK_DESCRIPTIONS[riskType]?.[level] ||
  RISK_META.find(r => r.level === level)?.description || '';