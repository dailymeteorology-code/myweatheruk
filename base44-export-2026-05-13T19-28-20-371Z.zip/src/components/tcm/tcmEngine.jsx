const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

/**
 * TCM Scoring Engine & Data Fetching
 * Extracted from WeatherPatterns for maintainability.
 */

const OPEN_METEO_HOSTS = {
  forecast:   'https://api.open-meteo.com',
  historical: 'https://historical-forecast-api.open-meteo.com',
};

export const REGIONS = {
  uk: {
    id: 'uk',
    label: 'United Kingdom & Ireland',
    flag: '🇬🇧',
    bbox: { latMin: 49.5, latMax: 61.2, lonMin: -11.2, lonMax: 2.2 },
    gridStep: 0.30,
    // Open-Meteo high-res UK models from Met Office and Météo-France
    models: ['ecmwf_ifs025', 'ukmo_seamless', 'ukmo_uk_deterministic_2km', 'meteofrance_arome_france_hd'],
    ensembleModels: ['ecmwf_ifs025_ensemble'],
    // Met Office DataHub grid sampling disabled — free tier quota too low for grid coverage
    ukmoGridStep: null,
  },
  europe: {
    id: 'europe',
    label: 'Europe',
    flag: '🌍',
    bbox: { latMin: 35.0, latMax: 71.5, lonMin: -12.0, lonMax: 32.0 },
    gridStep: 0.55,
    models: ['ecmwf_ifs025', 'meteofrance_arome_france_hd'],
    ensembleModels: ['ecmwf_ifs025_ensemble'],
    ukmoGridStep: null,
  },
};

export const FORECAST_VARS = [
  'cape', 'wind_speed_10m', 'wind_gusts_10m',
  'wind_speed_500hPa', 'wind_speed_850hPa',
  'temperature_500hPa', 'temperature_850hPa',
  'dewpoint_2m', 'temperature_2m',
  'freezing_level_height', 'precipitation',
];
export const ENSEMBLE_VARS = ['cape', 'precipitation', 'wind_gusts_10m'];

export const HOURS_PER_STEP = 3;
export const STEPS_PER_DAY = 24 / HOURS_PER_STEP; // 8
export const TOTAL_STEPS   = STEPS_PER_DAY * 4;   // 32

function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function scaleLin(v, lo, hi) {
  if (v == null || isNaN(v)) return 0;
  return clamp((v - lo) / (hi - lo), 0, 1);
}
function maxNonNull(arr) {
  let m = -Infinity; for (const v of arr) if (v != null && v > m) m = v;
  return m === -Infinity ? null : m;
}
function meanNonNull(arr) {
  const a = arr.filter((v) => v != null && !isNaN(v));
  return a.length ? a.reduce((s, v) => s + v, 0) / a.length : null;
}

export function stepPeak(hourly, stepIdx, hours = HOURS_PER_STEP) {
  const start = stepIdx * hours;
  return maxNonNull((hourly ?? []).slice(start, start + hours));
}
export function stepMean(hourly, stepIdx, hours = HOURS_PER_STEP) {
  const start = stepIdx * hours;
  return meanNonNull((hourly ?? []).slice(start, start + hours));
}

function bulkShear(u500, u850, u10) {
  if (u500 == null || u10 == null) return 0;
  return Math.abs(u500 - u10);
}

function hailDiameter(cape, shear, fz) {
  if (cape == null || cape < 200) return 0;
  const fzPenalty = fz != null ? clamp(1 - (fz - 2500) / 2500, 0.4, 1.2) : 1;
  return clamp(Math.sqrt(cape) * 0.18 * (1 + shear / 25) * fzPenalty, 0, 80);
}

function torroScale(cape, shear, srh) {
  if (cape == null || cape < 400 || shear < 12) return 0;
  const t = (Math.log10(Math.max(cape, 1)) - 2.6) * 5 + (shear - 10) * 0.25 + (srh / 60);
  return clamp(Math.round(t), 0, 11);
}

/**
 * Convert composite atmospheric features → per-risk score 0-100.
 * Calibrated for UK/EU: 500 J/kg CAPE + 12°C dew → Marginal (score ~38).
 */
export function engineScores(f) {
  const cape = clamp(f.cape ?? 0, 0, 6000);
  const li   = f.li   ?? 0;
  const cin  = f.cin  ?? 0;
  const sh   = f.shear ?? 0;
  const sh01 = f.shear01 ?? 0;
  const wgs  = (f.gust ?? 0) * 2.23694;
  const w10  = (f.wind10 ?? 0) * 2.23694;
  const pr   = f.precip ?? 0;
  const fz   = f.freezing ?? 3000;
  const t850 = f.t850 ?? 0;
  const t500 = f.t500 ?? -15;
  const td   = f.dew  ?? 0;
  const t2   = f.temp ?? 15;
  const lapse = (t850 - t500);
  const tdSpread = Math.max(0, t2 - td);

  const cinPen = clamp(1 - scaleLin(cin, 50, 250) * 0.7, 0.3, 1);

  // UK calibration (recalibrated): 300 J/kg → capeS ~38, 500 J/kg → ~58, 800 J/kg → ~80
  const capeS    = scaleLin(cape, 30, 900) * 100;
  const liS      = scaleLin(li, -1, 8) * 100;
  const moistS   = scaleLin(td, 7, 16) * 100;
  const triggerS = scaleLin(pr, 0.05, 3) * 100;
  const lapseS   = scaleLin(lapse, 12, 23) * 100;

  // THUNDERSTORM: 300 J/kg + 11°C dew + 0.3mm/h → Marginal (~30); 500+ → Moderate
  let thunder = capeS * 0.50 + Math.max(triggerS, moistS * 0.60) * 0.35 + liS * 0.10 + lapseS * 0.05;
  thunder = thunder * cinPen;
  if (lapse > 15) thunder *= (1 + (lapse - 15) * 0.04);
  thunder = clamp(thunder, 0, 100);

  // LIGHTNING
  const lightningPotential = capeS * (fz < 4500 ? 1 : 0.65);
  let lightning = lightningPotential * 0.58 + triggerS * 0.28 + moistS * 0.14;
  if (lapse > 16) lightning *= (1 + (lapse - 16) * 0.035);
  lightning = clamp(lightning * cinPen, 0, 100);

  // HAIL
  const fzS    = scaleLin(4500 - fz, 0, 2000) * 100;
  const shHail = scaleLin(sh, 6, 20) * 100;
  let hail = capeS * 0.45 + shHail * 0.30 + lapseS * 0.15 + fzS * 0.10;
  hail = clamp(hail * cinPen * 0.85, 0, 100);

  // TORNADO
  const lclS  = scaleLin(8 - tdSpread, 0, 6) * 100;
  const sh01S = scaleLin(sh01, 3, 14) * 100;
  const sh06S = scaleLin(sh, 10, 24) * 100;
  let tornado = (capeS * 0.22 + sh01S * 0.42 + sh06S * 0.22 + lclS * 0.14) * cinPen;
  tornado = tornado < 30 ? tornado * 0.5 : (30 * 0.5 + (tornado - 30) * 1.0);
  tornado = clamp(tornado, 0, 100);

  const slowMotion = clamp(1 - scaleLin(sh, 8, 20) * 0.6, 0.4, 1);
  const flashFlood = clamp(scaleLin(pr, 1, 18) * 100 * 0.55 + scaleLin(td, 10, 18) * 100 * 0.25 + scaleLin(cape, 400, 2200) * 100 * 0.20, 0, 100) * slowMotion;
  const dryAloft = scaleLin(15 - td, 0, 12);
  const dcapeProxy = scaleLin(cape * (0.4 + 0.4 * dryAloft), 200, 1800) * 100;
  const strongWinds = clamp(scaleLin(wgs, 28, 100) * 100 * 0.55 + dcapeProxy * 0.25 + scaleLin(sh, 10, 28) * 100 * 0.20, 0, 100);
  const supercell = clamp(Math.sqrt(scaleLin(cape, 600, 2800) * 100 * scaleLin(sh, 12, 28) * 100), 0, 100);

  return {
    thunderstorm: Math.round(thunder),
    hail: Math.round(hail),
    tornado: Math.round(tornado),
    lightning: Math.round(lightning),
    sub: {
      tornado: Math.round(tornado), hail: Math.round(hail),
      flashFlood: Math.round(flashFlood), strongWinds: Math.round(strongWinds),
      supercell: Math.round(supercell),
    },
    metrics: {
      cape: Math.round(cape), shear: Math.round(sh), shear01: Math.round(sh01),
      wind10: Math.round(w10), gust: Math.round(wgs), precip: +pr.toFixed(1),
      hailMm: Math.round(hailDiameter(cape, sh, fz)),
      torro: torroScale(cape, sh, sh01 * 6),
      li: +(li).toFixed(1), cin: Math.round(cin), lapse: +lapse.toFixed(1),
      fz: Math.round(fz), tdSpread: +tdSpread.toFixed(1),
    },
  };
}

// Failover: only models that returned data contribute.
const MODEL_WEIGHTS = {
  ukmo_uk_deterministic_2km: 2.0,  // Met Office UKV 2km — official UK high-res model
  ukmo_seamless: 1.6,              // Met Office Seamless (UKV + Global blend)
  meteofrance_arome_france_hd: 1.4,
  ecmwf_ifs025: 1.0,
  ecmwf_ifs025_ensemble: 0.9,
};
export function combineModels(perModelFeatures) {
  const keys = ['cape', 'li', 'cin', 'shear', 'shear01', 'gust', 'wind10', 'precip', 'freezing', 't850', 't500', 'dew', 'temp'];
  const out = {};
  const availableModels = Object.entries(perModelFeatures).filter(([, f]) => f != null);
  for (const k of keys) {
    let wsum = 0, vsum = 0;
    for (const [m, f] of availableModels) {
      if (f[k] != null && !isNaN(f[k])) {
        const w = MODEL_WEIGHTS[m] ?? 1;
        wsum += w; vsum += w * f[k];
      }
    }
    out[k] = wsum > 0 ? vsum / wsum : null;
  }
  return out;
}

export function featuresFromHourly(hr, stepIdx) {
  if (!hr) return null;
  const cape = stepPeak(hr.cape, stepIdx);
  const w500 = stepPeak(hr.wind_speed_500hPa, stepIdx);
  const w850 = stepPeak(hr.wind_speed_850hPa, stepIdx);
  const w10  = stepPeak(hr.wind_speed_10m, stepIdx);
  const gust = stepPeak(hr.wind_gusts_10m, stepIdx);
  const pr   = stepPeak(hr.precipitation, stepIdx);
  const fz   = stepMean(hr.freezing_level_height, stepIdx);
  const t850 = stepMean(hr.temperature_850hPa, stepIdx);
  const t500 = stepMean(hr.temperature_500hPa, stepIdx);
  const dew  = stepPeak(hr.dewpoint_2m, stepIdx);
  const temp = stepPeak(hr.temperature_2m, stepIdx);
  const lapse = (t850 ?? 0) - (t500 ?? -15);
  const liProxy = clamp(lapse - 20, -10, 12);
  return {
    cape: cape ?? 0, li: liProxy, cin: 0,
    shear: Math.abs((w500 ?? 0) - (w10 ?? 0)),
    shear01: Math.abs((w850 ?? 0) - (w10 ?? 0)),
    gust: gust ?? 0, wind10: w10 ?? 0, precip: pr ?? 0,
    freezing: fz ?? 3000, t850: t850 ?? 0, t500: t500 ?? -10,
    dew: dew ?? 0, temp: temp ?? 0,
  };
}

export function aggregateDay(stepScoresArr) {
  const out = {
    thunderstorm: 0, hail: 0, tornado: 0, lightning: 0,
    sub: { tornado: 0, hail: 0, flashFlood: 0, strongWinds: 0, supercell: 0 },
    metrics: { cape: 0, shear: 0, shear01: 0, wind10: 0, gust: 0, precip: 0, hailMm: 0, torro: 0, li: 0, cin: 0, lapse: 0, fz: 9999, tdSpread: 99 },
  };
  for (const s of stepScoresArr) {
    if (!s) continue;
    out.thunderstorm = Math.max(out.thunderstorm, s.thunderstorm);
    out.hail = Math.max(out.hail, s.hail);
    out.tornado = Math.max(out.tornado, s.tornado);
    out.lightning = Math.max(out.lightning, s.lightning);
    for (const k of Object.keys(out.sub)) out.sub[k] = Math.max(out.sub[k], s.sub[k] ?? 0);
    for (const k of Object.keys(out.metrics)) {
      const v = s.metrics[k] ?? 0;
      if (k === 'fz' || k === 'tdSpread') out.metrics[k] = Math.min(out.metrics[k], v);
      else out.metrics[k] = Math.max(out.metrics[k], v);
    }
  }
  return out;
}

async function fetchModel({ model, points, run, ensemble = false, days = 4 }) {
  if (!points.length) return null;
  const lats = points.map((p) => p.lat).join(',');
  const lons = points.map((p) => p.lon).join(',');
  const vars = ensemble ? ENSEMBLE_VARS : FORECAST_VARS;
  const startDate = new Date(Date.UTC(run.getUTCFullYear(), run.getUTCMonth(), run.getUTCDate()));
  const endDate = new Date(startDate.getTime() + (days - 1) * 86400_000);
  const sd = startDate.toISOString().slice(0, 10);
  const ed = endDate.toISOString().slice(0, 10);
  const today = new Date(); today.setUTCHours(0, 0, 0, 0);
  const isPast = startDate.getTime() < today.getTime();
  const host = isPast ? `${OPEN_METEO_HOSTS.historical}/v1/forecast` : `${OPEN_METEO_HOSTS.forecast}/v1/forecast`;
  const url = `${host}?latitude=${lats}&longitude=${lons}&hourly=${vars.join(',')}&models=${model}&start_date=${sd}&end_date=${ed}&timezone=UTC`;
  try {
    const r = await fetch(url);
    if (!r.ok) { console.warn(`[TCM] ${model} HTTP ${r.status}`); return null; }
    const j = await r.json();
    return Array.isArray(j) ? j : [j];
  } catch (e) {
    console.warn(`[TCM] ${model} fetch error`, e);
    return null;
  }
}

async function pMap(items, mapper, concurrency = 5) {
  const out = new Array(items.length); let cursor = 0;
  const worker = async () => { while (true) { const i = cursor++; if (i >= items.length) return; out[i] = await mapper(items[i], i); } };
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
  return out;
}

const STORAGE_PREFIX = 'tcm_v5_';
const runKey = (d) => `${d.getUTCFullYear()}${(d.getUTCMonth()+1).toString().padStart(2,'0')}${d.getUTCDate().toString().padStart(2,'0')}_${d.getUTCHours().toString().padStart(2,'0')}Z`;

export function saveRun(region, run, payload) {
  try { localStorage.setItem(`${STORAGE_PREFIX}${region}_${runKey(run)}`, JSON.stringify(payload)); } catch (_) {}
}
export function loadRun(region, run) {
  try {
    const raw = localStorage.getItem(`${STORAGE_PREFIX}${region}_${runKey(run)}`);
    return raw ? JSON.parse(raw) : null;
  } catch (_) { return null; }
}
function listStoredRuns(region) {
  const out = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(`${STORAGE_PREFIX}${region}_`)) out.push(k);
    }
  } catch (_) {}
  return out;
}
export function pruneOldRuns(region, keepDays = 7) {
  const cutoff = Date.now() - keepDays * 24 * 3600_000;
  for (const key of listStoredRuns(region)) {
    const m = key.match(/_(\d{4})(\d{2})(\d{2})_(\d{2})Z$/);
    if (!m) continue;
    const t = Date.UTC(+m[1], +m[2]-1, +m[3], +m[4]);
    if (t < cutoff) { try { localStorage.removeItem(key); } catch (_) {} }
  }
}

function buildGrid(region) {
  const r = REGIONS[region];
  const pts = [];
  for (let lat = r.bbox.latMin; lat <= r.bbox.latMax + 1e-6; lat += r.gridStep) {
    for (let lon = r.bbox.lonMin; lon <= r.bbox.lonMax + 1e-6; lon += r.gridStep) {
      pts.push({ lat: +lat.toFixed(3), lon: +lon.toFixed(3) });
    }
  }
  return pts;
}

/**
 * Fetch Met Office DataHub data for a sparse grid, then spatially interpolate
 * to the full TCM grid. Returns a map: `${lat.toFixed(2)}_${lon.toFixed(2)}` → features[]
 * where features[] is indexed by stepIdx (3-hourly steps, same as Open-Meteo).
 *
 * Met Office returns hourly data; we take the peak/mean over each 3-hour window
 * to match the engine's step scheme.
 */
async function fetchMetOfficeGrid({ region, run }) {
  const r = REGIONS[region];
  // Met Office DataHub grid sampling disabled — free tier quota (360/day) is too low for grid coverage.
  // UK model data still comes via Open-Meteo's ukmo_seamless + ukmo_uk_deterministic_2km models.
  if (!r.ukmoGridStep) return null;

  // Build sparse sampling grid
  const sparsePoints = [];
  for (let lat = r.bbox.latMin; lat <= r.bbox.latMax + 1e-6; lat += r.ukmoGridStep) {
    for (let lon = r.bbox.lonMin; lon <= r.bbox.lonMax + 1e-6; lon += r.ukmoGridStep) {
      sparsePoints.push({ lat: +lat.toFixed(2), lon: +lon.toFixed(2) });
    }
  }

  try {
    const { base44 } = await import('@/api/base44Client');
    const res = await db.functions.invoke('getMetOfficeForecast', { points: sparsePoints });
    const results = res?.data?.results;
    if (!Array.isArray(results) || !results.length) {
      console.warn('[TCM] Met Office grid returned no results');
      return null;
    }

    // Convert each result's hourly arrays into per-step features
    // Met Office returns 1-hourly; group into HOURS_PER_STEP windows
    const runDateStr = run.toISOString().slice(0, 10);
    const sparseFeatures = new Map(); // key → features array [TOTAL_STEPS]

    for (const pt of results) {
      const { lat, lon, hourly } = pt;
      const key = `${lat.toFixed(2)}_${lon.toFixed(2)}`;
      const times = hourly.times || [];

      // Find the index corresponding to run start
      const runStart = run.getTime();
      const startIdx = Math.max(0, times.findIndex(t => {
        if (!t) return false;
        return new Date(t).getTime() >= runStart;
      }));

      const stepFeatures = [];
      for (let s = 0; s < TOTAL_STEPS; s++) {
        const i0 = startIdx + s * HOURS_PER_STEP;
        const window = hourly.temperature_2m?.slice(i0, i0 + HOURS_PER_STEP) || [];
        if (!window.length || window.every(v => v == null)) { stepFeatures.push(null); continue; }

        const peak  = (arr) => { if (!arr) return null; const w = arr.slice(i0, i0 + HOURS_PER_STEP).filter(v => v != null); return w.length ? Math.max(...w) : null; };
        const mean  = (arr) => { if (!arr) return null; const w = arr.slice(i0, i0 + HOURS_PER_STEP).filter(v => v != null); return w.length ? w.reduce((s,v) => s+v, 0) / w.length : null; };

        const t2   = mean(hourly.temperature_2m);
        const td   = mean(hourly.dewpoint_2m);
        const w10  = peak(hourly.wind_speed_10m);
        const gust = peak(hourly.wind_gusts_10m);
        const pr   = peak(hourly.precipitation);
        const hum  = mean(hourly.humidity);

        // Derive a CAPE proxy from thermodynamic parameters:
        // Convective available potential energy correlates strongly with:
        //   - dewpoint (moisture)
        //   - temperature-dewpoint spread (instability indicator)
        //   - lapse rate (approximated from near-surface temp alone here)
        // Using Bolton (1980) lifted condensation level proxy:
        const tdSpread = t2 != null && td != null ? Math.max(0, t2 - td) : 5;
        const moistBoost = Math.max(0, (td ?? 5) - 5); // dew above 5°C adds energy
        // Simple empirical CAPE proxy for UK (J/kg):
        // High dew (14°C) + warm surface (22°C) + low spread → ~800 J/kg
        // Modest dew (10°C) + warm (18°C) → ~400 J/kg
        const capeProxy = Math.max(0,
          (moistBoost * 35) + (Math.max(0, (t2 ?? 10) - 12) * 18) - (tdSpread * 22)
        );

        // Lapse rate proxy: use screen temp deviation from typical 15°C baseline
        // Higher surface temp with moisture = steeper effective lapse
        const lapseProxy = Math.max(13, Math.min(28, 20 + (moistBoost * 0.4)));

        stepFeatures.push({
          cape: capeProxy,
          li: 0,    // no LI from surface obs
          cin: 0,
          shear: Math.abs((w10 ?? 0) * 1.2),  // approximate 0-6km shear from 10m wind
          shear01: Math.abs((w10 ?? 0) * 0.6),
          gust: gust ?? 0,
          wind10: w10 ?? 0,
          precip: pr ?? 0,
          freezing: 3000,  // no freezing level from DataHub basic tier
          t850: (t2 ?? 10) - 8,   // rough 850hPa temp estimate
          t500: (t2 ?? 10) - lapseProxy * 5, // rough 500hPa temp estimate
          dew: td ?? 5,
          temp: t2 ?? 10,
        });
      }
      sparseFeatures.set(key, stepFeatures);
    }

    return sparseFeatures;
  } catch (e) {
    console.warn('[TCM] Met Office grid fetch failed:', e?.message);
    return null;
  }
}

/**
 * Nearest-neighbour lookup: find the closest sparse point to (lat, lon).
 */
function nearestSparse(sparseFeatures, lat, lon, maxDist = 1.2) {
  let best = null, bd = Infinity;
  const tLat = lat, tLon = lon;
  for (const [key, feats] of sparseFeatures) {
    const [sLat, sLon] = key.split('_').map(Number);
    const d = (sLat - tLat) ** 2 + (sLon - tLon) ** 2;
    if (d < bd) { bd = d; best = { key, feats, d }; }
  }
  return best && Math.sqrt(best.d) <= maxDist ? best.feats : null;
}

export async function runTCM({ region, run, onProgress }) {
  const r = REGIONS[region];
  const grid = buildGrid(region);
  const detModels = r.models;
  const ensModels = r.ensembleModels;
  const CHUNK = 150;
  const chunks = [];
  for (let i = 0; i < grid.length; i += CHUNK) chunks.push(grid.slice(i, i + CHUNK));

  const perPoint = grid.map(() => Array.from({ length: TOTAL_STEPS }, () => ({})));
  const tasks = [];
  chunks.forEach((chunk, cIdx) => {
    for (const model of detModels) tasks.push({ cIdx, chunk, model, ensemble: false });
    for (const model of ensModels) tasks.push({ cIdx, chunk, model, ensemble: true });
  });

  // Fetch Met Office DataHub grid in parallel with Open-Meteo tasks
  let done = 0;
  const totalTasks = tasks.length + 1; // +1 for Met Office
  const tick = () => onProgress?.(Math.min(0.99, done / totalTasks));

  const [_, ukmoSparseFeatures] = await Promise.all([
    pMap(tasks, async ({ cIdx, chunk, model, ensemble }) => {
      const data = await fetchModel({ model, points: chunk, run, ensemble });
      done++; tick();
      if (!data) return;
      data.forEach((entry, gi) => {
        const pIdx = cIdx * CHUNK + gi;
        const hr = entry?.hourly;
        if (!hr) return;
        if (!ensemble) {
          for (let s = 0; s < TOTAL_STEPS; s++) {
            const feat = featuresFromHourly(hr, s);
            if (feat) perPoint[pIdx][s][model] = feat;
          }
        } else {
          const reduced = {};
          for (const v of ENSEMBLE_VARS) {
            const memberKeys = Object.keys(hr).filter((k) => k === v || k.startsWith(`${v}_member`));
            const arrays = memberKeys.map((k) => hr[k]).filter(Array.isArray);
            if (!arrays.length) continue;
            const len = arrays[0].length;
            reduced[v] = new Array(len).fill(null).map((_, i) => {
              const vals = arrays.map((a) => a[i]).filter((x) => x != null);
              return vals.length ? vals.reduce((sum, x) => sum + x, 0) / vals.length : null;
            });
          }
          for (let s = 0; s < TOTAL_STEPS; s++) {
            perPoint[pIdx][s][model] = {
              cape: stepPeak(reduced.cape, s) ?? 0, li: 0, cin: 0,
              shear: 0, shear01: 0,
              gust: stepPeak(reduced.wind_gusts_10m, s) ?? 0,
              wind10: 0, precip: stepPeak(reduced.precipitation, s) ?? 0,
              freezing: 3000, t850: 0, t500: -10, dew: 0, temp: 0,
            };
          }
        }
      });
    }, 5),
    fetchMetOfficeGrid({ region, run }).then(res => { done++; tick(); return res; }),
  ]);

  // Blend Met Office DataHub features into each grid point (weight 2.0 — highest priority)
  if (ukmoSparseFeatures) {
    for (let pIdx = 0; pIdx < grid.length; pIdx++) {
      const { lat, lon } = grid[pIdx];
      const nearestFeats = nearestSparse(ukmoSparseFeatures, lat, lon, r.ukmoGridStep * 1.5);
      if (!nearestFeats) continue;
      for (let s = 0; s < TOTAL_STEPS; s++) {
        const f = nearestFeats[s];
        if (f) perPoint[pIdx][s]['ukmo_datahub'] = f;
      }
    }
  }

  const result = grid.map((p, pIdx) => {
    const perStep = [];
    for (let s = 0; s < TOTAL_STEPS; s++) {
      const combined = combineModels(perPoint[pIdx][s]);
      perStep.push({ features: combined, scores: engineScores(combined) });
    }
    const perDay = [];
    for (let d = 0; d < 4; d++) {
      const slice = perStep.slice(d * STEPS_PER_DAY, (d + 1) * STEPS_PER_DAY);
      perDay.push({ scores: aggregateDay(slice.map((x) => x.scores)) });
    }
    return { lat: p.lat, lon: p.lon, perStep, perDay };
  });

  const summary = [0, 1, 2, 3].map((d) => {
    const days = result.map((p) => p.perDay[d]).filter(Boolean);
    const top = (sel) => days.reduce((m, x) => Math.max(m, x.scores[sel] ?? 0), 0);
    const topSub = (k) => days.reduce((m, x) => Math.max(m, x.scores.sub[k] ?? 0), 0);
    const stormy = days.filter((x) => (x.scores.thunderstorm ?? 0) >= 10);
    const arr = (sel) => (stormy.length ? stormy.map((x) => x.scores.metrics[sel] ?? 0) : [0]);
    const minMax = (a) => ({ min: Math.min(...a), max: Math.max(...a) });
    return {
      thunderstorm: top('thunderstorm'), hail: top('hail'), tornado: top('tornado'), lightning: top('lightning'),
      sub: { tornado: topSub('tornado'), hail: topSub('hail'), flashFlood: topSub('flashFlood'), strongWinds: topSub('strongWinds'), supercell: topSub('supercell') },
      ranges: { cape: minMax(arr('cape')), shear: minMax(arr('shear')), wind: minMax(arr('wind10')), gust: minMax(arr('gust')), precip: minMax(arr('precip')), hailMm: minMax(arr('hailMm')), torro: minMax(arr('torro')), li: minMax(arr('li')), lapse: minMax(arr('lapse')) },
      stormyCells: stormy.length, totalCells: days.length,
    };
  });

  const payload = { region, run: run.toISOString(), grid: result, summary, builtAt: new Date().toISOString(), hasUkmo: !!ukmoSparseFeatures };
  saveRun(region, run, payload);
  pruneOldRuns(region, 7);
  onProgress?.(1);
  return payload;
}

export async function fetchSounding(lat, lon, targetDate) {
  const levels = [1000, 925, 850, 700, 500, 400, 300, 250, 200];
  const tVars = levels.map(L => `temperature_${L}hPa`).join(',');
  const dVars = levels.map(L => `dewpoint_${L}hPa`).join(',');
  const wVars = levels.flatMap(L => [`wind_speed_${L}hPa`,`wind_direction_${L}hPa`]).join(',');
  const target = targetDate ? new Date(targetDate) : new Date();
  const sd = new Date(Date.UTC(target.getUTCFullYear(),target.getUTCMonth(),target.getUTCDate())).toISOString().slice(0,10);
  const today = new Date(); today.setUTCHours(0,0,0,0);
  const host = new Date(sd) < today ? `${OPEN_METEO_HOSTS.historical}/v1/forecast` : `${OPEN_METEO_HOSTS.forecast}/v1/forecast`;
  const tryModel = async (model) => {
    try {
      const r = await fetch(`${host}?latitude=${lat.toFixed(3)}&longitude=${lon.toFixed(3)}&hourly=${tVars},${dVars},${wVars}&models=${model}&start_date=${sd}&end_date=${sd}&timezone=UTC`);
      if (!r.ok) return null;
      const j = await r.json();
      if (!j?.hourly?.time?.length) return null;
      let i = j.hourly.time.findIndex(s => s===`${sd}T15:00`);
      if (i < 0) i = Math.min(15, j.hourly.time.length - 1);
      const profile = levels.map(L => ({ pressure:L, temp:j.hourly[`temperature_${L}hPa`]?.[i]??null, dew:j.hourly[`dewpoint_${L}hPa`]?.[i]??null, wspd:j.hourly[`wind_speed_${L}hPa`]?.[i]??null, wdir:j.hourly[`wind_direction_${L}hPa`]?.[i]??null })).filter(l=>l.temp!=null);
      return profile.length >= 4 ? profile : null;
    } catch { return null; }
  };
  for (const m of ['ecmwf_ifs025','gfs_seamless','icon_seamless']) { const out = await tryModel(m); if (out) return out; }
  return null;
}

/** UKMO lightning risk chart URL for a given day offset (0=today, 1=tomorrow…) */
export function ukmoLightningRiskUrl(dayOffset = 0) {
  const day = Math.max(1, dayOffset + 1);
  return `https://www.metoffice.gov.uk/public/data/wef/charts/ukmo_global_10km_lightning_prob_d${day}.png`;
}