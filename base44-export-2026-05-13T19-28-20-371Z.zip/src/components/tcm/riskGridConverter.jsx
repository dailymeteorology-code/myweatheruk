/**
 * Converts getRiskGrid backend response into the WeatherPatterns TCM data format.
 * This lets the page consume the server-side cached grid instead of doing
 * hundreds of direct Open-Meteo calls from the browser (which get 429'd).
 */

// Map 0-100 probability → a score compatible with scoreToLevel()
// scoreToLevel thresholds: <5=NoRisk, <13=VeryLow, <25=Low, <42=Marginal, <60=Moderate, <80=High, >=80=Severe
// Keep this conservative — the backend probs are already calibrated
function probToScore(p) {
  if (p >= 60) return 78;  // High
  if (p >= 45) return 62;  // Moderate-High
  if (p >= 30) return 50;  // Moderate
  if (p >= 20) return 38;  // Marginal
  if (p >= 10) return 20;  // Low
  if (p >= 5)  return 10;  // Very Low
  if (p >= 1)  return 4;   // No Risk (below threshold)
  return 0;
}

export function convertRiskGridToTCMData(riskGridBody, region, run) {
  const { grid_data } = riskGridBody;
  if (!grid_data) return null;

  // Build a flat grid array in WeatherPatterns format
  // grid_data[day] = { lightning:[{lat,lon,p}], hail:[], tornado:[], wind:[] }
  const pointMap = {}; // key → point with perDay

  const days = [0, 1, 2];
  days.forEach(d => {
    const dayData = grid_data[d];
    if (!dayData) return;
    // Merge all risk types at each location
    const allPts = [
      ...(dayData.lightning || []).map(p => ({ ...p, type: 'lightning' })),
      ...(dayData.hail || []).map(p => ({ ...p, type: 'hail' })),
      ...(dayData.tornado || []).map(p => ({ ...p, type: 'tornado' })),
      ...(dayData.wind || []).map(p => ({ ...p, type: 'wind' })),
    ];
    allPts.forEach(({ lat, lon, p, type }) => {
      const key = `${lat}_${lon}`;
      if (!pointMap[key]) {
        pointMap[key] = {
          lat, lon,
          perStep: Array.from({ length: 32 }, () => ({
            features: {},
            scores: {
              thunderstorm: 0, hail: 0, tornado: 0, lightning: 0,
              sub: { tornado: 0, hail: 0, flashFlood: 0, strongWinds: 0, supercell: 0 },
              metrics: { cape: 0, shear: 0, shear01: 0, wind10: 0, gust: 0, precip: 0, hailMm: 0, torro: 0, li: 0, cin: 0, lapse: 0, fz: 3000, tdSpread: 5 },
            },
          })),
          perDay: [0, 1, 2, 3].map(() => ({
            scores: {
              thunderstorm: 0, hail: 0, tornado: 0, lightning: 0,
              sub: { tornado: 0, hail: 0, flashFlood: 0, strongWinds: 0, supercell: 0 },
              metrics: { cape: 0, shear: 0, shear01: 0, wind10: 0, gust: 0, precip: 0, hailMm: 0, torro: 0, li: 0, cin: 0, lapse: 0, fz: 3000, tdSpread: 5 },
            },
          })),
        };
      }
      const score = probToScore(p);
      const pt = pointMap[key];
      // wind stays as sub-hazard only — don't inflate thunderstorm from routine gusts
      const scoreKey = type === 'wind' ? 'thunderstorm' : type;
      // Only update thunderstorm from wind if it's a genuinely high wind score (Moderate+)
      if (type === 'wind' && score < 50) {
        // skip — low wind scores shouldn't pollute thunderstorm display
      } else {
        pt.perDay[d].scores[scoreKey] = Math.max(pt.perDay[d].scores[scoreKey], score);
      }
      // thunderstorm = max of lightning score only (most direct proxy)
      if (type === 'lightning') {
        pt.perDay[d].scores.thunderstorm = Math.max(pt.perDay[d].scores.thunderstorm, score);
      }
      // Propagate to per-step scores
      const stepStart = d * 8;
      for (let s = stepStart; s < stepStart + 8; s++) {
        if (type !== 'wind' || score >= 50) {
          pt.perStep[s].scores[scoreKey] = Math.max(pt.perStep[s].scores[scoreKey], score);
        }
        if (type === 'lightning') {
          pt.perStep[s].scores.thunderstorm = Math.max(pt.perStep[s].scores.thunderstorm, score);
        }
      }
    });
  });

  const grid = Object.values(pointMap);

  // Build summary (region-wide max scores per day)
  const summary = [0, 1, 2, 3].map(d => {
    const days = grid.map(p => p.perDay[d]);
    const top = key => days.reduce((m, x) => Math.max(m, x.scores[key] ?? 0), 0);
    return {
      thunderstorm: top('thunderstorm'),
      hail: top('hail'),
      tornado: top('tornado'),
      lightning: top('lightning'),
      sub: { tornado: 0, hail: 0, flashFlood: 0, strongWinds: 0, supercell: 0 },
      ranges: {
        cape:   { min: 0, max: 800 },
        shear:  { min: 0, max: 20 },
        wind:   { min: 0, max: 40 },
        gust:   { min: 0, max: 60 },
        precip: { min: 0, max: 10 },
        hailMm: { min: 0, max: 15 },
        torro:  { min: 0, max: 3 },
        li:     { min: -4, max: 2 },
        lapse:  { min: 18, max: 24 },
      },
      stormyCells: days.filter(x => (x.scores.thunderstorm ?? 0) >= 10).length,
      totalCells: days.length,
    };
  });

  return {
    region,
    run: run.toISOString(),
    grid,
    summary,
    builtAt: riskGridBody.generated_at || new Date().toISOString(),
    source: 'getRiskGrid', // marks this as backend-derived
    model_run: riskGridBody.model_run,
  };
}