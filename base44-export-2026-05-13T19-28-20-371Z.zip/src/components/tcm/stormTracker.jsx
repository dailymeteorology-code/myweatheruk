/* stormTracker — extracted from pages/TCM */
import { CITY_DB } from '@/components/tcm/cityDB';

export const STORM_RISK = {
  yellow: { label: 'Yellow', fullLabel: 'Yellow Thunderstorm Advisory', color: '#facc15', desc: 'Localised lightning and rainfall possible. Stay alert.', expiryMs: 30 * 60 * 1000 },
  amber:  { label: 'Amber',  fullLabel: 'Amber Thunderstorm Warning',   color: '#f97316', desc: 'Active thunderstorm. Flash flooding, strong gusts and hail possible. Move indoors.', expiryMs: 25 * 60 * 1000 },
  red:    { label: 'Red',    fullLabel: 'Red Severe Thunderstorm Warning', color: '#ef4444', desc: 'Dangerous thunderstorm. Structural damage, large hail and major flooding likely. Take cover immediately.', expiryMs: 15 * 60 * 1000 },
};

function nearestCityFull(lat, lon) {
  let best = null, bestDist = Infinity;
  CITY_DB.forEach(city => {
    const dLat = city.lat - lat;
    const dLon = (city.lon - lon) * Math.cos(lat * Math.PI / 180);
    const dist = dLat * dLat + dLon * dLon;
    if (dist < bestDist) { bestDist = dist; best = city; }
  });
  return best;
}
export function nearestCity(lat, lon) {
  const city = nearestCityFull(lat, lon);
  if (!city) return 'Unknown location';
  const dLat = city.lat - lat;
  const dLon = (city.lon - lon) * Math.cos(lat * Math.PI / 180);
  const km = Math.sqrt(dLat * dLat + dLon * dLon) * 111;
  if (km < 5) return `over ${city.name}, ${city.country}`;
  if (km < 15) return `near ${city.name}, ${city.country}`;
  return `${Math.round(km)} km from ${city.name}, ${city.country}`;
}
export function nearestCityShort(lat, lon) {
  const city = nearestCityFull(lat, lon);
  if (!city) return 'Unknown';
  const dLat = city.lat - lat;
  const dLon = (city.lon - lon) * Math.cos(lat * Math.PI / 180);
  const km = Math.sqrt(dLat * dLat + dLon * dLon) * 111;
  if (km < 5) return city.name;
  if (km < 20) return `nr ${city.name}`;
  return `${Math.round(km)}km from ${city.name}`;
}

export function convexHull(points) {
  if (points.length < 3) return points.slice();
  const pts = [...points].sort((a, b) => a.lon - b.lon || a.lat - b.lat);
  const cross = (O, A, B) => (A.lon - O.lon) * (B.lat - O.lat) - (A.lat - O.lat) * (B.lon - O.lon);
  const lower = [];
  for (const p of pts) {
    while (lower.length >= 2 && cross(lower[lower.length-2], lower[lower.length-1], p) <= 0) lower.pop();
    lower.push(p);
  }
  const upper = [];
  for (let i = pts.length - 1; i >= 0; i--) {
    const p = pts[i];
    while (upper.length >= 2 && cross(upper[upper.length-2], upper[upper.length-1], p) <= 0) upper.pop();
    upper.push(p);
  }
  upper.pop(); lower.pop();
  return lower.concat(upper);
}

export function bufferHull(hull, padDeg) {
  if (hull.length < 3) {
    if (!hull.length) return [];
    const p = hull[0];
    return Array.from({length:16},(_,i) => {
      const a = (i/16)*Math.PI*2;
      return [p.lat + Math.cos(a)*padDeg, p.lon + Math.sin(a)*padDeg*1.5];
    });
  }
  const cLat = hull.reduce((s,p) => s+p.lat,0) / hull.length;
  const cLon = hull.reduce((s,p) => s+p.lon,0) / hull.length;
  return hull.map(p => {
    const dLat = p.lat - cLat;
    const dLon = (p.lon - cLon);
    const mag = Math.sqrt(dLat*dLat + dLon*dLon) || 1;
    return [p.lat + (dLat/mag) * padDeg, p.lon + (dLon/mag) * padDeg * 1.4];
  });
}

export function pointInPolygon(lat, lon, polygon) {
  if (!polygon || polygon.length < 3) return false;
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const yi = polygon[i][0], xi = polygon[i][1];
    const yj = polygon[j][0], xj = polygon[j][1];
    const intersect = ((yi > lat) !== (yj > lat)) &&
      (lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-12) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

function dbscan(points, eps, minPts) {
  const labels = new Array(points.length).fill(-2);
  let cluster = 0;
  const nb = (idx) => {
    const p = points[idx]; const out = [];
    for (let i = 0; i < points.length; i++) {
      if (i === idx) continue;
      const q = points[i];
      const dLat = p.lat - q.lat;
      const dLon = (p.lon - q.lon) * Math.cos((p.lat * Math.PI) / 180);
      if (Math.sqrt(dLat * dLat + dLon * dLon) <= eps) out.push(i);
    }
    return out;
  };
  for (let i = 0; i < points.length; i++) {
    if (labels[i] !== -2) continue;
    const seeds = nb(i);
    if (seeds.length < minPts) { labels[i] = -1; continue; }
    labels[i] = cluster;
    for (let j = 0; j < seeds.length; j++) {
      const s = seeds[j];
      if (labels[s] === -1) labels[s] = cluster;
      if (labels[s] !== -2) continue;
      labels[s] = cluster;
      const nb2 = nb(s);
      if (nb2.length >= minPts) nb2.forEach(x => { if (!seeds.includes(x)) seeds.push(x); });
    }
    cluster++;
  }
  const clusters = {};
  for (let i = 0; i < points.length; i++) { const l = labels[i]; if (l < 0) continue; if (!clusters[l]) clusters[l] = []; clusters[l].push(points[i]); }
  return Object.values(clusters);
}

export function buildTtsString(risk, count, lat, lon) {
  const loc = nearestCity(lat, lon);
  if (risk === 'yellow') {
    return `Thunderstorm advisory. ${count} lightning strikes have been detected ${loc}. Localised lightning, sudden downpours, and gusty winds are possible over the next 30 minutes. Stay alert and avoid exposed areas such as open fields and hilltops.`;
  }
  if (risk === 'amber') {
    return `Amber thunderstorm warning. An active storm cell has been detected ${loc}, producing ${count} lightning strikes in the past 30 minutes. Flash flooding, strong wind gusts, and hail are likely. Move indoors now and keep away from windows.`;
  }
  return `Red severe thunderstorm warning. A dangerous and rapidly intensifying storm is occurring ${loc}. ${count} lightning strikes have been recorded in just 30 minutes. There is a high risk of structural damage, large hail, and significant flooding. Take cover immediately in a substantial building. Do not travel. This is an emergency.`;
}

export function createStormTracker() {
  let rolling = [];
  const cellHistory = {};
  function ingest(strike) { rolling.push(strike); }
  function pruneRolling() { const cutoff = Date.now() - 30 * 60 * 1000; rolling = rolling.filter(s => s.time > cutoff); }
  function cluster() {
    pruneRolling();
    if (rolling.length < 10) return [];
    const groups = dbscan(rolling, 0.28, 8);
    const now = Date.now();
    const out = [];
    groups.forEach((pts) => {
      const recentPts = pts.filter(p => now - p.time <= 10 * 60 * 1000);
      const recentCount = recentPts.length;
      if (recentCount < 3) return;
      const cLat = pts.reduce((s,p) => s+p.lat,0) / pts.length;
      const cLon = pts.reduce((s,p) => s+p.lon,0) / pts.length;
      const maxDist = Math.max(...pts.map(p => {
        const dLat = p.lat - cLat;
        const dLon = (p.lon - cLon) * Math.cos(cLat * Math.PI / 180);
        return Math.sqrt(dLat*dLat + dLon*dLon);
      }));
      if (maxDist > 0.50) return;
      const id = `storm-${Math.round(cLat*100)}-${Math.round(cLon*100)}`;
      if (!cellHistory[id]) cellHistory[id] = { history: [], createdAt: now, sustainCount: 0 };
      const h = cellHistory[id];
      h.history.push({ lat: cLat, lon: cLon, time: now, count: pts.length });
      if (h.history.length > 30) h.history.shift();
      h.sustainCount++;
      const count = pts.length;
      const avgAmp = pts.reduce((s,p) => s + Math.abs(p.amp || 0), 0) / pts.length;
      let risk = null;
      if (count >= 50 && recentCount >= 15 && avgAmp >= 60 && h.sustainCount >= 2) risk = 'red';
      else if (count >= 25 && recentCount >= 8 && avgAmp >= 30) risk = 'amber';
      else if (count >= 10 && recentCount >= 3) risk = 'yellow';
      else return;
      const RISK_RANK = { yellow: 0, amber: 1, red: 2 };
      const prevRisk = h._lastRisk;
      if (prevRisk && RISK_RANK[prevRisk] > RISK_RANK[risk]) risk = prevRisk;
      const riskChanged = prevRisk && prevRisk !== risk;
      h._lastRisk = risk;
      const hull = convexHull(pts);
      const padDeg = Math.max(0.04, Math.min(0.10, maxDist * 0.25));
      const corePolygon = bufferHull(hull, padDeg);
      const overlapsExisting = out.some(existing => existing.corePolygon && pointInPolygon(cLat, cLon, existing.corePolygon));
      if (overlapsExisting) return;
      out.push({
        id, risk, corePolygon, count, recentCount,
        avgAmp: Math.round(avgAmp),
        centroid: { lat: cLat, lon: cLon },
        locationLabel: nearestCityShort(cLat, cLon),
        startTime: new Date(h.createdAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
        endTime:   new Date(now + STORM_RISK[risk].expiryMs).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
        updatedAt: now,
        expiresAt: now + STORM_RISK[risk].expiryMs,
        riskChanged,
      });
    });
    return out;
  }
  function getRolling() { return rolling; }
  function resetDay() { const snap = [...rolling]; rolling = []; Object.keys(cellHistory).forEach(k => delete cellHistory[k]); return snap; }
  return { ingest, cluster, getRolling, resetDay };
}