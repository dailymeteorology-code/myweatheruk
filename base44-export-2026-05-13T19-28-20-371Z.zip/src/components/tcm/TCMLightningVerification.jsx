import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Zap } from 'lucide-react';

// These are re-exported from the page's module scope — we need them here too.
// Since this is a sub-component of WeatherPatterns, we accept them as props
// to avoid circular imports.

const LIGHTNING_STORAGE_KEY = 'tcm_lightning_v1';
const LIGHTNING_MAX_AGE_MS  = 6 * 3600_000;
const LIGHTNING_MAX_COUNT   = 800;
const LIGHTNING_VISIBLE_CAP = 400;
const LIGHTNING_RIPPLE_MS   = 60_000;

const LightningPlus = React.memo(function LightningPlus({ x, y, age, color = '#fde047' }) {
  const opacity = Math.max(0.18, 1 - age / LIGHTNING_MAX_AGE_MS);
  const size = 9;
  const showRipple = age < LIGHTNING_RIPPLE_MS;
  return (
    <g transform={`translate(${x.toFixed(1)},${y.toFixed(1)})`} opacity={opacity}>
      {showRipple && (
        <circle r={2} fill="none" stroke="#ffffff" strokeWidth={1.2}>
          <animate attributeName="r" from="2" to="22" dur="1.6s" repeatCount="indefinite" />
          <animate attributeName="opacity" from="0.85" to="0" dur="1.6s" repeatCount="indefinite" />
          <animate attributeName="stroke-width" from="1.6" to="0.2" dur="1.6s" repeatCount="indefinite" />
        </circle>
      )}
      <line x1={-size/2} x2={size/2} y1={0} y2={0} stroke={color} strokeWidth={1.6} strokeLinecap="round" />
      <line y1={-size/2} y2={size/2} x1={0} x2={0} stroke={color} strokeWidth={1.6} strokeLinecap="round" />
      <circle r={1.6} fill={color} opacity={0.6} />
    </g>
  );
});

export default function TCMLightningVerification({
  data, region, riskType, dayIdx,
  // Injected from parent (avoids re-importing large modules)
  useTCMTheme, REGIONS, regionAspectRatio, loadCountries, geoToSvgPath,
  buildRiskMatrix, HeatmapLayer, TitleCard, project, Section,
  useBlitzortung, LIGHTNING_BACKEND_PATH,
}) {
  const { t, lightMode } = useTCMTheme();
  const wrapRef = useRef(null);
  const [size, setSize] = useState({ w: 700, h: 600 });
  const [outline, setOutline] = useState('');
  const [status, setStatus] = useState('idle');
  const [enabled, setEnabled] = useState(true);
  const [strikes, setStrikes] = useState(() => {
    try {
      const raw = localStorage.getItem(LIGHTNING_STORAGE_KEY);
      const arr = raw ? JSON.parse(raw) : [];
      const cutoff = Date.now() - LIGHTNING_MAX_AGE_MS;
      return arr.filter((s) => s.time >= cutoff);
    } catch { return []; }
  });

  const bbox = REGIONS[region].bbox;

  useEffect(() => {
    if (!wrapRef.current) return;
    const compute = () => {
      if (!wrapRef.current) return;
      const containerW = wrapRef.current.clientWidth;
      const ratio = regionAspectRatio(REGIONS[region].bbox);
      const maxH = Math.max(360, Math.min(680, window.innerHeight * 0.62));
      let h = containerW * ratio, w = containerW;
      if (h > maxH) { h = maxH; w = h / ratio; }
      setSize({ w: Math.round(w), h: Math.round(h) });
    };
    compute();
    const ro = new ResizeObserver(compute);
    ro.observe(wrapRef.current);
    window.addEventListener('resize', compute);
    return () => { ro.disconnect(); window.removeEventListener('resize', compute); };
  }, [region]);

  useEffect(() => {
    let alive = true;
    loadCountries().then((fc) => {
      if (!alive || !fc) return;
      setOutline(geoToSvgPath(fc, REGIONS[region].bbox, size.w, size.h));
    });
    return () => { alive = false; };
  }, [region, size.w, size.h]);

  useEffect(() => {
    if (!LIGHTNING_BACKEND_PATH) return;
    const since = Date.now() - LIGHTNING_MAX_AGE_MS;
    fetch(`${LIGHTNING_BACKEND_PATH}?since=${since}`)
      .then((r) => r.ok ? r.json() : [])
      .then((arr) => {
        if (!Array.isArray(arr) || !arr.length) return;
        setStrikes((prev) => {
          const seen = new Set(prev.map((s) => `${s.time}_${s.lat}_${s.lon}`));
          const merged = [...prev];
          for (const s of arr) { const k = `${s.time}_${s.lat}_${s.lon}`; if (!seen.has(k)) merged.push(s); }
          return merged.slice(-LIGHTNING_MAX_COUNT);
        });
      }).catch(() => {});
  }, []);

  const addStrike = useCallback((strike) => {
    setStrikes((prev) => {
      const cutoff = Date.now() - LIGHTNING_MAX_AGE_MS;
      const next = [...prev.filter((s) => s.time >= cutoff), strike].slice(-LIGHTNING_MAX_COUNT);
      try { localStorage.setItem(LIGHTNING_STORAGE_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
    if (LIGHTNING_BACKEND_PATH) {
      fetch(LIGHTNING_BACKEND_PATH, { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify(strike) }).catch(() => {});
    }
  }, []);

  useBlitzortung({ enabled, bbox, onStrike: addStrike, onStatus: setStatus });

  const matrixData = useMemo(
    () => data?.grid ? buildRiskMatrix(data.grid, region, riskType, { dayIdx }) : null,
    [data, region, riskType, dayIdx],
  );

  const now = Date.now();
  const visibleStrikes = useMemo(() => {
    const cutoff = now - LIGHTNING_MAX_AGE_MS;
    const fresh = strikes.filter((s) => s.time >= cutoff);
    return fresh.length > LIGHTNING_VISIBLE_CAP ? fresh.slice(-LIGHTNING_VISIBLE_CAP) : fresh;
  }, [strikes, now]);

  const statusColor = { live:'#22c55e', connecting:'#eab308', reconnecting:'#eab308', error:'#dc2626', disabled:'#64748b', idle:'#64748b' }[status] || '#64748b';

  return (
    <Section title="Lightning Verification" icon={Zap}
      extra={
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <span style={{ display:'inline-flex', alignItems:'center', gap:6, fontSize:'0.7rem', fontWeight:700, color:statusColor, fontFamily:"'DM Mono',monospace" }}>
            <span style={{ width:7, height:7, borderRadius:99, background:statusColor, boxShadow:`0 0 8px ${statusColor}`, animation:status==='live'?'pulse 1.4s ease-in-out infinite':'none' }} />
            {status.toUpperCase()}
          </span>
          <span style={{ fontSize:'0.7rem', fontWeight:700, color:'#a78bfa', fontFamily:"'DM Mono',monospace" }}>{visibleStrikes.length} strikes · 6 h</span>
          <button onClick={() => setEnabled((e) => !e)} style={{ padding:'6px 10px', borderRadius:8, fontSize:'0.7rem', fontWeight:700, background:enabled?'rgba(220,38,38,0.15)':'rgba(34,197,94,0.15)', color:enabled?'#dc2626':'#22c55e', border:`1px solid ${enabled?'#dc2626':'#22c55e'}40`, cursor:'pointer' }}>
            {enabled ? 'Disconnect' : 'Connect'}
          </button>
        </div>
      }
    >
      <div ref={wrapRef} style={{ position:'relative', width:'100%', borderRadius:12, overflow:'hidden', background:t.mapSeaTop, border:'1px solid rgba(255,255,255,0.05)', display:'flex', justifyContent:'center', alignItems:'flex-start' }}>
        <svg width={size.w} height={size.h} style={{ display:'block' }}>
          <defs>
            <filter id="tcm-soften-light" x="-15%" y="-15%" width="130%" height="130%">
              <feGaussianBlur stdDeviation={Math.max(1.5, Math.min(size.w,size.h)/320)} />
              <feComponentTransfer><feFuncA type="linear" slope="1.7" intercept="-0.4" /></feComponentTransfer>
            </filter>
          </defs>
          <rect x={0} y={0} width={size.w} height={size.h} fill={t.mapSeaTop} />
          {outline && <path d={outline} fill={t.mapLand} stroke={t.mapBorder} strokeWidth={0.7} />}
          {matrixData && (
            <g opacity={0.55}>
              <HeatmapLayer matrix={matrixData.M} rows={matrixData.rows} cols={matrixData.cols} bbox={bbox} w={size.w} h={size.h} riskType={riskType} day={dayIdx} />
            </g>
          )}
          {outline && <path d={outline} fill="none" stroke={t.mapBorder} strokeWidth={0.9} pointerEvents="none" opacity={lightMode?1:0.6} />}
          {visibleStrikes.map((s, i) => {
            const [x, y] = project(s.lat, s.lon, bbox, size.w, size.h);
            return <LightningPlus key={`${s.time}_${i}`} x={x} y={y} age={now-s.time} />;
          })}
          <TitleCard w={Math.min(420,size.w-20)} x={10} y={10} title={`Lightning Verification · ${REGIONS[region].label}`} sub={`${visibleStrikes.length} strikes · last 6 h · Blitzortung`} />
        </svg>
      </div>
      <p style={{ margin:'10px 2px 0', fontSize:'0.7rem', color:t.textMuted, lineHeight:1.5 }}>
        Yellow plus marks are real cloud-to-ground strikes from the Blitzortung community network, plotted live and saved for the past six hours.
      </p>
    </Section>
  );
}