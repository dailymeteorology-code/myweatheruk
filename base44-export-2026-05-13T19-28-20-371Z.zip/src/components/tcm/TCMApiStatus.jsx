const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

// ── Admin-only API status panel ────────────────────────────────────────────
// Probes Open-Meteo Ensemble endpoints directly from the browser (no backend
// function needed). Shows ok/fail + latency for each model used by the TCM.
import React, { useEffect, useState, useCallback } from 'react';

import { Database, RefreshCw, CheckCircle2, XCircle, Loader2, ShieldAlert } from 'lucide-react';

// Endpoints we probe — each is a tiny single-point query to confirm liveness
const PROBES = [
  { name: 'Open-Meteo Ensemble (root)', url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=51.5&longitude=-0.1&hourly=cape&forecast_days=1&timezone=UTC' },
  { name: 'ECMWF IFS Ensemble',         url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=51.5&longitude=-0.1&hourly=cape&models=ecmwf_ifs025_ensemble&forecast_days=1&timezone=UTC' },
  { name: 'ECMWF AIFS Ensemble',        url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=51.5&longitude=-0.1&hourly=cape&models=ecmwf_aifs025_ensemble&forecast_days=1&timezone=UTC' },
  { name: 'UKMO UK 2km Ensemble',       url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=51.5&longitude=-0.1&hourly=cape&models=ukmo_uk_ensemble_2km&forecast_days=1&timezone=UTC' },
  { name: 'UKMO Global 20km Ensemble',  url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=51.5&longitude=-0.1&hourly=cape&models=ukmo_global_ensemble_20km&forecast_days=1&timezone=UTC' },
  { name: 'ICON Seamless EPS',          url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=51.5&longitude=-0.1&hourly=cape&models=icon_seamless_eps&forecast_days=1&timezone=UTC' },
  { name: 'ICON EU EPS',                url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=51.5&longitude=-0.1&hourly=cape&models=icon_eu_eps&forecast_days=1&timezone=UTC' },
  { name: 'MeteoSwiss ICON-CH1',        url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=46.9&longitude=8.5&hourly=cape&models=meteoswiss_icon_ch1_ensemble&forecast_days=1&timezone=UTC' },
  { name: 'NCEP GEFS 0.25°',            url: 'https://ensemble-api.open-meteo.com/v1/ensemble?latitude=51.5&longitude=-0.1&hourly=cape&models=ncep_gefs025&forecast_days=1&timezone=UTC' },
];

async function probe(p) {
  const t0 = performance.now();
  try {
    const res = await fetch(p.url, { method: 'GET' });
    const ms = Math.round(performance.now() - t0);
    return { name: p.name, ok: res.ok, status: res.status, ms };
  } catch (e) {
    const ms = Math.round(performance.now() - t0);
    return { name: p.name, ok: false, status: 0, ms, error: String(e?.message || e) };
  }
}

export default function TCMApiStatus({ tokens }) {
  const t = tokens;
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [checkedAt, setCheckedAt] = useState(null);
  const [isAdmin, setIsAdmin] = useState(null);

  useEffect(() => {
    (async () => {
      try { const u = await db.auth.me(); setIsAdmin(u?.role === 'admin'); }
      catch { setIsAdmin(false); }
    })();
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true);
    const r = await Promise.all(PROBES.map(probe));
    setResults(r);
    setCheckedAt(Date.now());
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!isAdmin) return;
    refresh();
    const id = setInterval(refresh, 60_000);
    return () => clearInterval(id);
  }, [isAdmin, refresh]);

  if (!isAdmin) return null;

  const okCount = results?.filter(r => r.ok).length ?? 0;
  const totalCount = results?.length ?? 0;
  const allOk = results && okCount === totalCount;

  return (
    <div style={{ padding: 16, marginBottom: 20, background: t.cardBg, border: `1px solid ${t.cardBorder}`, borderRadius: 16, backdropFilter: 'blur(12px)', boxShadow: t.cardShadow }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12, flexWrap: 'wrap' }}>
        <ShieldAlert style={{ width: 16, height: 16, color: '#f59e0b' }} />
        <span style={{ fontSize: '0.85rem', fontWeight: 700, color: t.textPrimary }}>API Connection Status</span>
        <span style={{ fontSize: '0.62rem', fontWeight: 700, color: '#f59e0b', padding: '2px 8px', borderRadius: 99, background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.3)' }}>ADMIN</span>
        {results && (
          <span style={{ fontSize: '0.66rem', fontWeight: 700, color: allOk ? '#22c55e' : okCount > 0 ? '#f59e0b' : '#dc2626', padding: '2px 8px', borderRadius: 99, background: allOk ? 'rgba(34,197,94,0.10)' : okCount > 0 ? 'rgba(245,158,11,0.10)' : 'rgba(220,38,38,0.10)', border: `1px solid ${allOk ? 'rgba(34,197,94,0.30)' : okCount > 0 ? 'rgba(245,158,11,0.30)' : 'rgba(220,38,38,0.30)'}`, fontFamily: "'DM Mono',monospace" }}>
            {okCount}/{totalCount} ONLINE
          </span>
        )}
        <div style={{ flex: 1 }} />
        <button onClick={refresh} disabled={loading} style={{ padding: '5px 9px', borderRadius: 8, fontSize: '0.7rem', fontWeight: 700, background: 'rgba(56,189,248,0.12)', border: '1px solid rgba(56,189,248,0.35)', color: '#38bdf8', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
          {loading ? <Loader2 className="animate-spin" style={{ width: 11, height: 11 }} /> : <RefreshCw style={{ width: 11, height: 11 }} />} Ping
        </button>
      </div>
      {results?.length ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 8 }}>
          {results.map(r => (
            <div key={r.name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', background: r.ok ? 'rgba(34,197,94,0.06)' : 'rgba(220,38,38,0.06)', border: `1px solid ${r.ok ? 'rgba(34,197,94,0.25)' : 'rgba(220,38,38,0.25)'}`, borderRadius: 8 }}>
              {r.ok ? <CheckCircle2 style={{ width: 14, height: 14, color: '#22c55e', flexShrink: 0 }} /> : <XCircle style={{ width: 14, height: 14, color: '#dc2626', flexShrink: 0 }} />}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: '0.75rem', fontWeight: 700, color: t.textPrimary, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.name}</div>
                <div style={{ fontSize: '0.62rem', color: t.textMuted, fontFamily: "'DM Mono',monospace" }}>{r.ok ? `${r.status} · ${r.ms} ms` : `FAIL${r.status ? ` · ${r.status}` : ''} · ${r.ms} ms`}</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: t.textMuted, fontSize: '0.78rem' }}>
          <Database style={{ width: 14, height: 14 }} /> {loading ? 'Pinging Open-Meteo Ensemble endpoints…' : 'Click Ping to test.'}
        </div>
      )}
      {checkedAt && (
        <div style={{ marginTop: 8, fontSize: '0.62rem', color: t.textMuted, fontFamily: "'DM Mono',monospace", textAlign: 'right' }}>
          Last check: {new Date(checkedAt).toLocaleTimeString()}
        </div>
      )}
    </div>
  );
}