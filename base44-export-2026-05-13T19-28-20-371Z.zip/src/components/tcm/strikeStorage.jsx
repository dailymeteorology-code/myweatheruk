/* Strike storage helpers extracted from pages/TCM */

export const STORE_KEY  = 'tcm_today_strikes';
export const DATE_KEY   = 'tcm_today_date';
export const ARCHIVE_KEY = 'tcm_lightning_archive';
export const STORM_STORE_KEY = 'tcm_storm_warnings';
export const SNAPSHOT_KEY = 'tcm_forced_snapshots';

export function todayDateStr() { return new Date().toISOString().slice(0, 10); }
export function localDateKey(ts) { return new Date(ts || Date.now()).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); }

export function loadStoredWarnings() {
  try {
    const arr = JSON.parse(localStorage.getItem(STORM_STORE_KEY) || '[]');
    return arr.filter(w => w.expiresAt && w.expiresAt > Date.now());
  } catch (_) { return []; }
}
export function saveWarnings(polys) {
  try {
    const live = (polys || []).filter(w => w.expiresAt && w.expiresAt > Date.now());
    localStorage.setItem(STORM_STORE_KEY, JSON.stringify(live));
  } catch (_) {}
}
export function broadcastWarnings(polys) {
  try {
    const live = (polys || []).filter(w => w.expiresAt && w.expiresAt > Date.now());
    localStorage.setItem(STORM_STORE_KEY, JSON.stringify(live));
    window.dispatchEvent(new StorageEvent('storage', { key: STORM_STORE_KEY, newValue: JSON.stringify(live), storageArea: localStorage }));
  } catch (_) {}
}
export function loadSnapshots() { try { return JSON.parse(localStorage.getItem(SNAPSHOT_KEY) || '[]'); } catch (_) { return []; } }
export function saveSnapshot(snap) {
  try {
    const all = loadSnapshots(); all.push(snap);
    const cutoff = Date.now() - 90 * 24 * 60 * 60 * 1000;
    const trimmed = all.filter(s => s.capturedAt && s.capturedAt > cutoff);
    localStorage.setItem(SNAPSHOT_KEY, JSON.stringify(trimmed));
  } catch (_) {}
}

export function loadTodayStrikes() {
  try {
    const cutoff24h = Date.now() - 25 * 60 * 60 * 1000;
    const stored = JSON.parse(localStorage.getItem(STORE_KEY) || '[]');
    const fresh = stored.filter(s => s && s.time && s.time > cutoff24h);
    if (fresh.length) return fresh;
    if (localStorage.getItem(STORE_KEY + '_isC') === 'true') {
      const compressed = JSON.parse(localStorage.getItem(STORE_KEY + '_c') || '[]');
      const restored = compressed.map(c => ({ lat: c[0], lon: c[1], time: c[2], amp: 0 })).filter(s => s.time > cutoff24h);
      localStorage.removeItem(STORE_KEY + '_isC');
      localStorage.removeItem(STORE_KEY + '_c');
      saveTodayStrikes(restored);
      return restored;
    }
    return [];
  } catch (_) { return []; }
}
export function saveTodayStrikes(strikes) {
  try {
    const cutoff24h = Date.now() - 25 * 60 * 60 * 1000;
    const filtered = strikes.filter(s => s.time && s.time > cutoff24h);
    filtered.sort((a, b) => a.time - b.time);
    localStorage.setItem(DATE_KEY, todayDateStr());
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(filtered));
      localStorage.setItem('tcm_strike_meta', JSON.stringify({
        count: filtered.length, savedAt: Date.now(),
        newestTs: filtered.length ? filtered[filtered.length - 1].time : 0,
        oldestTs: filtered.length ? filtered[0].time : 0,
      }));
    } catch (quotaErr) {
      const compressed = filtered.map(s => [Math.round(s.lat * 10000) / 10000, Math.round(s.lon * 10000) / 10000, s.time]);
      try {
        localStorage.setItem(STORE_KEY + '_c', JSON.stringify(compressed));
        localStorage.setItem(STORE_KEY + '_isC', 'true');
        localStorage.removeItem(STORE_KEY);
      } catch (_) {
        try { localStorage.setItem(STORE_KEY, JSON.stringify(filtered.slice(-30000))); } catch (_2) {}
      }
    }
  } catch (e) {}
}
export function loadNewStrikesSince(sinceTs) {
  try {
    const cutoff24h = Date.now() - 25 * 60 * 60 * 1000;
    const stored = JSON.parse(localStorage.getItem(STORE_KEY) || '[]');
    return stored.filter(s => s.time && s.time > cutoff24h && s.time > sinceTs);
  } catch (_) { return []; }
}
export function loadArchive()  { try { return JSON.parse(localStorage.getItem(ARCHIVE_KEY)  || '[]'); } catch (_) { return []; } }
export function saveArchive(a) { try { localStorage.setItem(ARCHIVE_KEY, JSON.stringify(a)); } catch (_) {} }