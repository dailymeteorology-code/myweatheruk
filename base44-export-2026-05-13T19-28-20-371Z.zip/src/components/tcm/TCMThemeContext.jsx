import { createContext, useContext } from 'react';

export const THEME_TOKENS = {
  light: { pageBg: 'linear-gradient(160deg, #e8edf5 0%, #ffffff 60%, #eef2ff 100%)', cardBg: 'rgba(255,255,255,0.78)', cardBorder: 'rgba(15,23,42,0.10)', cardShadow: '0 4px 24px rgba(15,23,42,0.06)', textPrimary: '#0f172a', textSecondary: '#475569', textMuted: '#94a3b8', inputBorder: 'rgba(15,23,42,0.10)', titleCardBg: 'rgba(255,255,255,0.93)', titleCardBorder: '#cbd5e1', titleCardText: '#0f172a', titleCardSub: '#475569' },
  dark: { pageBg: 'linear-gradient(160deg, #0a0f1e 0%, #0f1730 60%, #1a1040 100%)', cardBg: 'rgba(15,23,42,0.65)', cardBorder: 'rgba(255,255,255,0.07)', cardShadow: '0 4px 24px rgba(0,0,0,0.30)', textPrimary: '#f1f5f9', textSecondary: '#94a3b8', textMuted: '#64748b', inputBorder: 'rgba(255,255,255,0.08)', titleCardBg: 'rgba(15,23,42,0.92)', titleCardBorder: '#334155', titleCardText: '#f1f5f9', titleCardSub: '#94a3b8' }
};

export const TCMThemeContext = createContext({ lightMode: false, toggle: () => {}, t: THEME_TOKENS.dark });
export const useTCMTheme = () => useContext(TCMThemeContext);