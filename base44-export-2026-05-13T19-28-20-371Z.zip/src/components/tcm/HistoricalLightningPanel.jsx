import React, { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Camera, AlertTriangle } from 'lucide-react';

/* ═══════════════════════════════════════════════════════════════
   HISTORICAL LIGHTNING PANEL — Blitzortung archive
   ═══════════════════════════════════════════════════════════════ */

function todayDateStr() { return new Date().toISOString().slice(0, 10); }

function buildStrikeDensityGrid(strikes, cellDeg = 0.15) {
  const bins = {};
  strikes.forEach(s => {
    const latKey = Math.round(s.lat / cellDeg) * cellDeg;
    const lonKey = Math.round(s.lon / cellDeg) * cellDeg;
    const key = `${latKey.toFixed(3)}_${lonKey.toFixed(3)}`;
    if (!bins[key]) bins[key] = { lat: latKey, lon: lonKey, count: 0 };
    bins[key].count++;
  });
  return Object.values(bins);
}
function strikeDensityColor(count) {
  if (count >= 50) return { fill: '#ef4444', opacity: 0.75 };
  if (count >= 20) return { fill: '#f97316', opacity: 0.65 };
  if (count >= 8)  return { fill: '#facc15', opacity: 0.55 };
  if (count >= 3)  return { fill: '#a78bfa', opacity: 0.42 };
  if (count >= 1)  return { fill: '#7c3aed', opacity: 0.30 };
  return null;
}

function hexToRgb(hex) {
  if (!hex || hex[0] !== '#') return '148,163,184';
  return [parseInt(hex.slice(1,3),16), parseInt(hex.slice(3,5),16), parseInt(hex.slice(5,7),16)].join(',');
}

const STORM_RISK = {
  yellow: { color: '#facc15', fullLabel: 'Yellow Thunderstorm Advisory' },
  amber:  { color: '#f97316', fullLabel: 'Amber Thunderstorm Warning' },
  red:    { color: '#ef4444', fullLabel: 'Red Severe Thunderstorm Warning' },
};

const ForcedSnapshotMap = React.memo(function ForcedSnapshotMap({ snaps, histView = 'uk', showWarnings, warnings }) {
  const mapRef       = useRef(null);
  const mapInst      = useRef(null);
  const strikeLayer  = useRef(null);
  const warningLayer = useRef(null);
  const renderedKey  = useRef(null);

  const snapKey = useMemo(() => snaps.map(s => s.capturedAt).join('_'), [snaps]);

  const allStrikes = useMemo(() => {
    const seen = new Set();
    const out  = [];
    for (const snap of snaps) {
      for (const s of (snap.strikes || [])) {
        if (!s || s.lat == null || s.lon == null) continue;
        const key = `${Math.round(s.lat * 1000)}_${Math.round(s.lon * 1000)}_${s.time}`;
        if (seen.has(key)) continue;
        seen.add(key);
        out.push(s);
      }
    }
    return out;
  }, [snapKey]); // eslint-disable-line

  const densityGrid = useMemo(() => buildStrikeDensityGrid(allStrikes, 0.18), [allStrikes]);

  const sampledStrikes = useMemo(() => {
    if (allStrikes.length <= 3000) return allStrikes;
    const step = Math.ceil(allStrikes.length / 3000);
    return allStrikes.filter((_, i) => i % step === 0);
  }, [allStrikes]);

  const capturedAt = useMemo(() => Math.max(...snaps.map(s => s.capturedAt || 0)), [snaps]);

  useEffect(() => {
    const L = window.L;
    if (!L || !mapRef.current || mapInst.current) return;
    const v = histView === 'europe' ? { center: [52, 9], zoom: 4 } : { center: [54, -2], zoom: 5 };
    const renderer = L.canvas({ padding: 0.5, tolerance: 2 });
    const map = L.map(mapRef.current, {
      center: v.center, zoom: v.zoom, zoomControl: true, attributionControl: false,
      preferCanvas: true, renderer, fadeAnimation: false, markerZoomAnimation: false, zoomSnap: 0.5,
    });
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 10, subdomains: 'abcd', updateWhenIdle: true, updateWhenZooming: false, keepBuffer: 2,
    }).addTo(map);
    strikeLayer.current  = L.layerGroup().addTo(map);
    warningLayer.current = L.layerGroup().addTo(map);
    mapInst.current = map;
    return () => {
      map.remove();
      mapInst.current = null; strikeLayer.current = null; warningLayer.current = null; renderedKey.current = null;
    };
  }, []); // eslint-disable-line

  useEffect(() => {
    const L = window.L;
    if (!L || !strikeLayer.current || !mapInst.current) return;
    if (renderedKey.current === snapKey) return;
    renderedKey.current = snapKey;
    strikeLayer.current.clearLayers();
    densityGrid.sort((a, b) => a.count - b.count).forEach(cell => {
      const cfg = strikeDensityColor(cell.count);
      if (!cfg) return;
      const half = 0.09;
      L.rectangle(
        [[cell.lat - half, cell.lon - half * 1.4], [cell.lat + half, cell.lon + half * 1.4]],
        { color: 'transparent', fillColor: cfg.fill, fillOpacity: cfg.opacity * 0.5, weight: 0, interactive: false }
      ).addTo(strikeLayer.current);
    });
    sampledStrikes.forEach(s => {
      const ageMin = (capturedAt - s.time) / 60000;
      let color = '#4c1d95';
      if      (ageMin < 5)   color = '#ffffff';
      else if (ageMin < 10)  color = '#facc15';
      else if (ageMin < 30)  color = '#f97316';
      else if (ageMin < 60)  color = '#ef4444';
      else if (ageMin < 360) color = '#7f1d1d';
      else if (ageMin < 720) color = '#7c3aed';
      L.circleMarker([s.lat, s.lon], {
        radius: 2, color, fillColor: color, fillOpacity: 0.85, weight: 0, interactive: false,
      }).addTo(strikeLayer.current);
    });
  }, [snapKey, densityGrid, sampledStrikes, capturedAt]);

  useEffect(() => {
    const L = window.L;
    if (!L || !warningLayer.current) return;
    warningLayer.current.clearLayers();
    if (!showWarnings || !warnings?.length) return;
    warnings.forEach(w => {
      if (!w.corePolygon?.length) return;
      const cfg = STORM_RISK[w.risk];
      if (!cfg) return;
      L.polygon(w.corePolygon, { color: cfg.color, fillColor: cfg.color, fillOpacity: 0.18, weight: 2, interactive: false }).addTo(warningLayer.current);
    });
  }, [showWarnings, warnings]);

  return <div ref={mapRef} style={{ width: '100%', height: '100%', background: '#060d1a' }} />;
});

export default function HistoricalLightningPanel({ lightMode = false, archive = [], forcedSnapshots = [] }) {
  const [histFullscreen, setHistFullscreen] = useState(false);
  const [showWarnings, setShowWarnings] = useState(false);
  const [forcedMapDate, setForcedMapDate] = useState(null);
  const chartRef  = useRef(null);
  const chartInst = useRef(null);

  const archiveByDate = useMemo(() => {
    const out = {};
    archive.forEach(a => {
      const d = a.capturedAt ? new Date(a.capturedAt).toISOString().slice(0, 10) : null;
      if (!d) return;
      if (!out[d]) out[d] = [];
      out[d].push(a);
    });
    return out;
  }, [archive]);

  const forcedByDate = useMemo(() => {
    const out = {};
    forcedSnapshots.forEach(snap => {
      const d = snap.capturedAt ? new Date(snap.capturedAt).toISOString().slice(0, 10) : null;
      if (!d) return;
      if (!out[d]) out[d] = [];
      out[d].push(snap);
    });
    return out;
  }, [forcedSnapshots]);

  const allDays = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    allDays.push(d.toISOString().slice(0, 10));
  }
  const days = allDays.filter(d => {
    const archCount   = (archiveByDate[d] || []).reduce((s, a) => s + (a.strikes?.length || 0), 0);
    const forcedCount = (forcedByDate[d] || []).reduce((s, sn) => s + (sn.strikes?.length || 0), 0);
    return archCount > 0 || forcedCount > 0 || d === todayDateStr();
  });

  const getDayCount = (d) => {
    const arch   = (archiveByDate[d] || []).reduce((s, a) => s + (a.strikes?.length || 0), 0);
    const forced = (forcedByDate[d] || []).reduce((s, sn) => s + (sn.strikes?.length || 0), 0);
    return Math.max(arch, forced);
  };
  const maxTotal = Math.max(1, ...days.map(getDayCount));

  const handleSelectDay = (dateStr) => {
    setShowWarnings(false);
    if (forcedMapDate === dateStr) { setForcedMapDate(null); return; }
    setForcedMapDate(forcedByDate[dateStr]?.length || archiveByDate[dateStr]?.length ? dateStr : null);
  };

  useEffect(() => {
    const days7 = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      days7.push(d.toISOString().slice(0, 10));
    }
    function renderChart() {
      if (!chartRef.current || !window.Chart) return;
      if (chartInst.current) { chartInst.current.destroy(); chartInst.current = null; }
      const labels = days7.map(d => new Date(d + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }));
      const data = days7.map(getDayCount);
      chartInst.current = new window.Chart(chartRef.current, {
        type: 'bar',
        data: { labels, datasets: [{
          label: 'Blitzortung Strikes', data,
          backgroundColor: data.map(v =>
            v >= 50000 ? 'rgba(239,68,68,0.8)' :
            v >= 10000 ? 'rgba(249,115,22,0.8)' :
            v >= 2000  ? 'rgba(250,204,21,0.8)' :
            v >= 300   ? 'rgba(52,211,153,0.8)' : 'rgba(167,139,250,0.6)'),
          borderColor: 'transparent', borderRadius: 5,
        }] },
        options: {
          responsive: true, maintainAspectRatio: false,
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => ` ${ctx.parsed.y.toLocaleString()} strikes` } } },
          scales: {
            x: { ticks: { color: '#64748b', font: { size: 11 }, maxRotation: 30 }, grid: { color: 'rgba(255,255,255,0.04)' } },
            y: { ticks: { color: '#64748b', font: { size: 11 }, callback: v => v >= 1000 ? `${(v/1000).toFixed(0)}k` : v }, grid: { color: 'rgba(255,255,255,0.06)' }, beginAtZero: true },
          },
        },
      });
    }
    if (window.Chart) renderChart();
    else {
      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js';
      s.onload = renderChart;
      document.head.appendChild(s);
    }
    return () => { if (chartInst.current) { chartInst.current.destroy(); chartInst.current = null; } };
  }, [archive, forcedSnapshots]); // eslint-disable-line

  const bg = lightMode ? 'rgba(255,255,255,0.7)' : 'rgba(10,15,30,0.8)';
  const border = lightMode ? 'rgba(0,0,0,0.1)' : 'rgba(255,255,255,0.08)';
  const textMain = lightMode ? '#1e293b' : '#f1f5f9';
  const textSub  = lightMode ? '#64748b' : '#64748b';

  return (
    <motion.div initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }} className="mx-auto max-w-6xl px-6 mb-10">
      <div style={{ borderRadius:20, overflow:'hidden', border:`1px solid ${border}`, background:bg, backdropFilter:'blur(16px)' }}>
        <div style={{ padding:'18px 22px', borderBottom:`1px solid ${border}`, display:'flex', alignItems:'center', gap:12 }}>
          <div style={{ width:38, height:38, borderRadius:11, background:'rgba(250,204,21,0.12)', border:'1px solid rgba(250,204,21,0.3)', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <Zap style={{ width:18, height:18, color:'#facc15' }} />
          </div>
          <div>
            <h3 style={{ margin:0, fontSize:'1rem', fontWeight:700, color:textMain }}>Historical Lightning Activity</h3>
            <p style={{ margin:0, fontSize:'0.72rem', color:textSub }}>Daily 23:59 snapshots + forced snapshots · Click a day to view map</p>
          </div>
        </div>

        <div style={{ padding:'20px 22px' }}>
          <div style={{ position:'relative', width:'100%', height:160, marginBottom:20 }}>
            <canvas ref={chartRef} role="img" aria-label="Day by day lightning strike counts" />
          </div>

          {days.length === 0 ? (
            <div style={{ padding:32, textAlign:'center' }}>
              <p style={{ fontSize:'0.85rem', color:textSub, margin:0 }}>No archived lightning data yet — strikes appear here after the first daily or forced snapshot.</p>
            </div>
          ) : (
            <div style={{ display:'grid', gridTemplateColumns:`repeat(${Math.min(days.length,7)},1fr)`, gap:8 }}>
              {days.map((dateStr) => {
                const count = getDayCount(dateStr);
                const forcedSnaps = forcedByDate[dateStr] || [];
                const hasForced = forcedSnaps.length > 0;
                const barH = count > 0 ? Math.max(6, (count / maxTotal) * 100) : 4;
                const d = new Date(dateStr + 'T12:00:00');
                const dayName = d.toLocaleDateString('en-GB', { weekday:'short' });
                const dayNum  = d.toLocaleDateString('en-GB', { day:'numeric', month:'short' });
                const isToday = dateStr === todayDateStr();
                let barColor = '#a78bfa';
                const selected = forcedMapDate === dateStr;
                if (count >= 50000) barColor = '#ef4444';
                else if (count >= 10000) barColor = '#f97316';
                else if (count >= 2000)  barColor = '#facc15';
                else if (count >= 300)   barColor = '#34d399';
                return (
                  <button key={dateStr} onClick={() => handleSelectDay(dateStr)}
                    style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:6, padding:'10px 6px', borderRadius:12, background:selected?`rgba(250,204,21,0.1)`:lightMode?'rgba(0,0,0,0.04)':'rgba(255,255,255,0.03)', border:`1px solid ${selected?'rgba(250,204,21,0.5)':border}`, cursor:'pointer', transition:'all 0.2s' }}>
                    <span style={{ fontSize:'0.65rem', fontWeight:700, color:isToday?'#facc15':textSub, letterSpacing:'0.04em' }}>{dayName}</span>
                    <div style={{ width:'100%', height:100, display:'flex', alignItems:'flex-end', justifyContent:'center' }}>
                      <div style={{ width:'70%', height:`${barH}%`, minHeight:4, borderRadius:'4px 4px 0 0', background:barColor, opacity:count===0?0.25:1, transition:'height 0.5s ease', boxShadow:count>0?`0 0 8px ${barColor}44`:undefined }} />
                    </div>
                    <span style={{ fontSize:'0.58rem', color:textSub }}>{dayNum}</span>
                    <span style={{ fontSize:'0.68rem', fontWeight:700, color:count>0?barColor:textSub, fontFamily:'monospace' }}>
                      {count > 0 ? (count >= 1000 ? `${(count/1000).toFixed(1)}k` : count) : '—'}
                    </span>
                    {hasForced && (
                      <span style={{ fontSize:'0.58rem', fontWeight:700, color:'#f59e0b', fontFamily:'monospace', background:'rgba(245,158,11,0.12)', borderRadius:4, padding:'1px 5px', marginTop:2 }}>
                        📸 {forcedSnaps.length}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}

          <AnimatePresence>
            {forcedMapDate && (forcedByDate[forcedMapDate] || archiveByDate[forcedMapDate] || []).length > 0 && (() => {
              const snapsForDay = forcedByDate[forcedMapDate]?.length ? forcedByDate[forcedMapDate] : (archiveByDate[forcedMapDate] || []);
              const allWarnings = snapsForDay.flatMap(snap => snap.stormWarnings || []);
              const uniqueWarnings = allWarnings.filter((w, i, arr) => arr.findIndex(x => x.id === w.id) === i);
              return (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.35 }} style={{ overflow: 'hidden' }}>
                  <div style={{
                    position: histFullscreen ? 'fixed' : 'relative',
                    inset: histFullscreen ? 0 : undefined,
                    zIndex: histFullscreen ? 9997 : undefined,
                    marginTop: histFullscreen ? 0 : 14,
                    borderRadius: histFullscreen ? 0 : 16,
                    overflow: 'hidden',
                    border: `2px solid rgba(245,158,11,0.45)`,
                    background: 'linear-gradient(135deg, rgba(245,158,11,0.06), rgba(6,13,26,0.98))',
                    boxShadow: histFullscreen ? 'none' : '0 8px 32px rgba(0,0,0,0.5)',
                  }}>
                    <div style={{ padding: '12px 16px', background: 'rgba(245,158,11,0.10)', borderBottom: '1px solid rgba(245,158,11,0.2)', display: 'flex', alignItems: 'center', gap: 10, justifyContent: 'space-between' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <Camera style={{ width: 15, height: 15, color: '#f59e0b' }} />
                        <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#f59e0b' }}>
                          {new Date(forcedMapDate + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}
                        </span>
                        <span style={{ fontSize: '0.68rem', color: '#64748b', fontFamily: 'monospace', background: 'rgba(255,255,255,0.05)', padding: '2px 8px', borderRadius: 6 }}>
                          {snapsForDay.reduce((s, sn) => s + (sn.strikes?.length || 0), 0).toLocaleString()} strikes
                        </span>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        {uniqueWarnings.length > 0 && (
                          <button onClick={() => setShowWarnings(v => !v)}
                            style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 12px', borderRadius: 8, background: showWarnings ? 'rgba(249,115,22,0.18)' : 'rgba(255,255,255,0.05)', border: `1px solid ${showWarnings ? '#f97316' : 'rgba(255,255,255,0.12)'}`, color: showWarnings ? '#f97316' : '#94a3b8', fontSize: '0.71rem', fontWeight: 700, cursor: 'pointer' }}>
                            <AlertTriangle style={{ width: 11, height: 11 }} />
                            {showWarnings ? 'Hide' : 'Show'} Warnings ({uniqueWarnings.length})
                          </button>
                        )}
                        <button onClick={() => setHistFullscreen(v => !v)}
                          style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 12px', borderRadius: 8, background: histFullscreen ? 'rgba(56,189,248,0.18)' : 'rgba(255,255,255,0.05)', border: `1px solid ${histFullscreen ? '#38bdf8' : 'rgba(255,255,255,0.12)'}`, color: histFullscreen ? '#38bdf8' : '#94a3b8', fontSize: '0.71rem', fontWeight: 700, cursor: 'pointer' }}>
                          {histFullscreen ? '✕ Exit' : '⛶ Fullscreen'}
                        </button>
                      </div>
                    </div>

                    {showWarnings && uniqueWarnings.length > 0 && (
                      <div style={{ padding: '10px 16px', borderBottom: '1px solid rgba(245,158,11,0.15)', display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                        {uniqueWarnings.map((w, i) => {
                          const cfg = STORM_RISK[w.risk] || { color: '#f97316', fullLabel: w.risk };
                          return (
                            <div key={w.id || i} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 8, background: `rgba(${hexToRgb(cfg.color)},0.1)`, border: `1px solid rgba(${hexToRgb(cfg.color)},0.3)` }}>
                              <div style={{ width: 8, height: 8, borderRadius: 2, background: cfg.color }} />
                              <span style={{ fontSize: '0.68rem', fontWeight: 700, color: cfg.color }}>{cfg.fullLabel || w.risk}</span>
                              <span style={{ fontSize: '0.65rem', color: '#64748b' }}>{w.locationLabel} · {w.count} strikes</span>
                            </div>
                          );
                        })}
                      </div>
                    )}

                    <div style={{ height: histFullscreen ? 'calc(100vh - 56px)' : 420 }}>
                      <ForcedSnapshotMap snaps={snapsForDay} histView="uk" showWarnings={showWarnings} warnings={uniqueWarnings} />
                    </div>
                  </div>
                </motion.div>
              );
            })()}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}