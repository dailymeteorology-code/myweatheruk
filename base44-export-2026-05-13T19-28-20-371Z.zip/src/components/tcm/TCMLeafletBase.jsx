/**
 * TCMLeafletBase — real OpenStreetMap basemap (UK or Europe) used under every
 * TCM map. Uses a ResizeObserver to wait for real pixel dimensions before
 * exposing the projector, preventing the SVG overlay from rendering at 0,0.
 */
import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';

const LIGHT_TILES = 'https://{s}.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}{r}.png';
const DARK_TILES  = 'https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png';
const TILE_ATTR   = '© <a href="https://www.openstreetmap.org/">OSM</a> © <a href="https://carto.com/">CARTO</a>';

let leafletCSSLoaded = false;
function ensureLeafletCSS() {
  if (leafletCSSLoaded) return;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
  document.head.appendChild(link);
  leafletCSSLoaded = true;
}

let leafletPromise = null;
function loadLeaflet() {
  if (leafletPromise) return leafletPromise;
  leafletPromise = new Promise((resolve) => {
    if (window.L) { resolve(window.L); return; }
    ensureLeafletCSS();
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
    script.onload = () => resolve(window.L);
    document.head.appendChild(script);
  });
  return leafletPromise;
}

export default function TCMLeafletBase({ bbox, height = 540, lightMode, children, onMapReady }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const [projector, setProjector] = useState(null);
  const [mapObj, setMapObj] = useState(null);
  const [tick, setTick] = useState(0);

  const buildProjector = useCallback((map) => {
    const size = map.getSize();
    if (!size || size.x < 10 || size.y < 10) return null;
    return {
      project: (lat, lon) => {
        const p = map.latLngToContainerPoint([lat, lon]);
        return [p.x, p.y];
      },
      unproject: (x, y) => {
        const ll = map.containerPointToLatLng([x, y]);
        return [ll.lat, ll.lng];
      },
      size,
    };
  }, []);

  const refreshProjector = useCallback(() => {
    const map = mapRef.current;
    if (!map) return;
    const p = buildProjector(map);
    if (p) setProjector(p);
  }, [buildProjector]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    let map = null;

    loadLeaflet().then((L) => {
      if (!containerRef.current || mapRef.current) return;

      map = L.map(el, {
        zoomControl: false,
        attributionControl: false,
        dragging: true,
        scrollWheelZoom: true,
        touchZoom: true,
        doubleClickZoom: true,
      });

      const tileUrl = lightMode ? LIGHT_TILES : DARK_TILES;
      L.tileLayer(tileUrl, {
        attribution: TILE_ATTR,
        subdomains: ['a', 'b', 'c', 'd'],
        maxZoom: 11,
        minZoom: 3,
      }).addTo(map);

      map.fitBounds([[bbox.latMin, bbox.lonMin], [bbox.latMax, bbox.lonMax]], {
        animate: false,
        padding: [4, 4],
      });

      mapRef.current = map;
      onMapReady?.(map);
      setMapObj(map);

      const handle = () => {
        map.invalidateSize({ animate: false });
        refreshProjector();
        setTick(t => t + 1);
      };

      map.on('moveend zoomend resize', handle);

      // Wait for tiles + layout to settle
      map.invalidateSize({ animate: false });
      setTimeout(() => {
        if (!mapRef.current) return;
        map.invalidateSize({ animate: false });
        refreshProjector();
        setTick(t => t + 1);
      }, 120);
      setTimeout(() => {
        if (!mapRef.current) return;
        map.invalidateSize({ animate: false });
        refreshProjector();
        setTick(t => t + 1);
      }, 400);
    });

    // ResizeObserver — re-project when container resizes
    const ro = new ResizeObserver(() => {
      const m = mapRef.current;
      if (!m) return;
      m.invalidateSize({ animate: false });
      const p = buildProjector(m);
      if (p) setProjector(p);
      setTick(t => t + 1);
    });
    ro.observe(el);

    return () => {
      ro.disconnect();
      if (map) {
        map.remove();
        mapRef.current = null;
      }
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Only mount once

  // When bbox or lightMode changes, re-fit and re-tile
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !window.L) return;
    map.fitBounds([[bbox.latMin, bbox.lonMin], [bbox.latMax, bbox.lonMax]], {
      animate: false,
      padding: [4, 4],
    });
    setTimeout(() => {
      if (!mapRef.current) return;
      mapRef.current.invalidateSize({ animate: false });
      refreshProjector();
      setTick(t => t + 1);
    }, 80);
  }, [bbox, refreshProjector]);

  // Update tile layer when lightMode changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !window.L) return;
    map.eachLayer((layer) => {
      if (layer._url) map.removeLayer(layer);
    });
    window.L.tileLayer(lightMode ? LIGHT_TILES : DARK_TILES, {
      attribution: TILE_ATTR,
      subdomains: ['a', 'b', 'c', 'd'],
      maxZoom: 11,
      minZoom: 3,
    }).addTo(map);
  }, [lightMode]);

  return (
    <div
      style={{
        position: 'relative',
        width: '100%',
        height,
        borderRadius: 12,
        overflow: 'hidden',
        border: '1px solid rgba(255,255,255,0.05)',
        background: lightMode ? '#dbe6f3' : '#0a1426',
      }}
    >
      <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
      {projector && mapObj && children?.({ projector, map: mapObj })}
    </div>
  );
}