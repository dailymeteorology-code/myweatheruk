// ── UK & Ireland landmask ────────────────────────────────────────────────────
// Used to clip outlook risk areas so they don't bleed into France, Belgium,
// Netherlands or open Atlantic when the user is in the UK & Ireland view.
//
// Polygon coordinates are [lon, lat] tracing a generous outline around the
// British Isles. The outline includes a small offshore buffer (~30 km) so
// coastal storms remain visible.
//
// For the EU view we don't apply this mask — risks can extend continent-wide.

// Outer outline tracing UK + Ireland with offshore buffer.
// Anti-clockwise from SW Ireland → N Scotland → E England → S England.
const UK_IRELAND_OUTLINE = [
  // South-west Ireland
  [-10.7, 51.3], [-10.5, 51.7], [-10.2, 52.2], [-9.9, 52.7],
  // West coast Ireland
  [-10.3, 53.2], [-10.4, 53.8], [-10.3, 54.5], [-9.6, 55.4],
  // North Ireland → North Channel
  [-8.5, 55.5], [-7.5, 55.4], [-6.2, 55.4],
  // Western Isles / Outer Hebrides
  [-7.8, 56.5], [-8.8, 57.5], [-8.9, 58.7],
  // North Scotland / Orkney / Shetland
  [-4.5, 59.0], [-2.5, 59.5], [-0.5, 60.9],
  // North Sea coast (east Scotland → east England)
  [-0.8, 60.5], [-1.0, 59.0], [-1.0, 57.5], [-1.0, 56.0],
  [0.5, 55.0], [1.8, 53.5], [2.0, 52.5], [1.8, 51.5],
  // South coast England (East → West)
  [1.5, 51.0], [0.5, 50.6], [-1.0, 50.4], [-2.5, 50.4],
  [-3.8, 50.0], [-5.2, 49.8], [-6.5, 49.9],
  // South-west approaches → SW Ireland (Celtic Sea)
  [-7.5, 50.6], [-9.0, 51.0], [-10.7, 51.3],
];

// Point-in-polygon (ray-cast). Polygon is [lon, lat] pairs.
function pointInPolygon(lat, lon, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i][0], yi = poly[i][1];
    const xj = poly[j][0], yj = poly[j][1];
    const intersect = ((yi > lat) !== (yj > lat))
      && (lon < (xj - xi) * (lat - yi) / (yj - yi || 1e-12) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

export function isInUKIreland(lat, lon) {
  return pointInPolygon(lat, lon, UK_IRELAND_OUTLINE);
}

export function clipGridToUKIreland(grid) {
  return grid.filter(p => isInUKIreland(p.lat, p.lon));
}

export const UK_IRELAND_POLYGON = UK_IRELAND_OUTLINE;