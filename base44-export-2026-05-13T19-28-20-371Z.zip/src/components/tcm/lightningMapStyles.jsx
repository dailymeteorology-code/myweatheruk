/* CSS string for LightningMap, extracted from pages/TCM */
export const LIGHTNING_MAP_CSS = `
@keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
@keyframes livePulse  { 0%,100%{box-shadow:0 0 0 0 rgba(34,197,94,0.5)} 50%{box-shadow:0 0 0 6px rgba(34,197,94,0)} }
@keyframes stormPulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:0.5;transform:scale(1.1)} }
@keyframes alertSlide { 0%{transform:translateX(120%);opacity:0} 10%{transform:translateX(0);opacity:1} 82%{transform:translateX(0);opacity:1} 100%{transform:translateX(120%);opacity:0} }
@keyframes spin { to { transform: rotate(360deg); } }
body.tcm-map-fullscreen #tcm-title-block { display: none !important; }
body.tcm-map-fullscreen .tcm-hamburger-btn { display: none !important; }
.leaflet-container, .leaflet-tile-pane, .leaflet-map-pane, .leaflet-pane, .leaflet-tile, .leaflet-tile-container, .leaflet-layer { background: #060d1a !important; }
.live-dot-green { width:8px;height:8px;border-radius:50%;background:#22c55e;animation:livePulse 1.8s ease infinite; }
.live-dot-amber { width:8px;height:8px;border-radius:50%;background:#f97316; }
.alert-banner { animation: alertSlide 7s ease forwards; }
.leaflet-control-attribution { background:rgba(6,13,26,0.75)!important;color:rgba(148,163,184,0.45)!important;font-size:9px!important;backdrop-filter:blur(8px);border-radius:6px 0 0 0!important;padding:2px 8px!important; }
.leaflet-control-attribution a { color:rgba(148,163,184,0.55)!important; }
.blitz-popup .leaflet-popup-content-wrapper { background:transparent!important;border:none!important;box-shadow:none!important;padding:0!important; }
.blitz-popup .leaflet-popup-content { margin:0!important; }
.blitz-popup .leaflet-popup-tip-container { display:none!important; }
@media (max-width: 768px) {
  .map-risk-legend { position: static !important; max-height: none !important; width: 100% !important; border-radius: 0 0 13px 13px !important; }
}
@media (max-width: 640px) {
  .tcm-hero-header h2 { font-size: 1.15rem !important; }
  .tcm-hero-header p  { font-size: 0.68rem !important; }
  .tcm-stat-strip     { grid-template-columns: repeat(2, 1fr) !important; }
  .tcm-map-topbar     { padding: 8px 8px !important; gap: 5px !important; }
  .tcm-map-row1       { flex-wrap: wrap !important; gap: 5px !important; }
  .tcm-map-row2       { gap: 4px !important; }
  .tcm-map-row2 button { padding: 4px 8px !important; font-size: 0.62rem !important; }
  .tcm-view-toggle button { padding: 5px 10px !important; font-size: 0.67rem !important; }
  .tcm-sound-toggles button { padding: 5px 7px !important; }
  .tcm-warning-cards  { grid-template-columns: 1fr !important; }
  .leaflet-control-zoom { display: none !important; }
}
`;