// ── Smooth Blob Path Builder ─────────────────────────────────────────────────
// Produces organic, hexagon-free, loop-free SVG paths for risk outline blobs.
//
// Pipeline:
//   1. Convex hull of input lat/lon points
//   2. Inflate hull outward from centroid (organic padding)
//   3. Chaikin corner-cutting subdivision (3 passes → 8× more vertices)
//      — this guarantees rounded corners and prevents the "hexagon" look
//   4. Project to screen
//   5. Render as a single closed quadratic-Bézier path through midpoints
//      — this prevents Catmull-Rom overshoot loops on concave shapes
//
// Result: smooth, professional, met-office-grade risk blobs.

function convexHull(pts) {
  if (pts.length <= 2) return pts.slice();
  const p = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o, a, b) =>
    (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lo = [], up = [];
  for (const x of p) {
    while (lo.length >= 2 && cross(lo[lo.length - 2], lo[lo.length - 1], x) <= 0) lo.pop();
    lo.push(x);
  }
  for (let i = p.length - 1; i >= 0; i--) {
    const x = p[i];
    while (up.length >= 2 && cross(up[up.length - 2], up[up.length - 1], x) <= 0) up.pop();
    up.push(x);
  }
  lo.pop(); up.pop();
  return lo.concat(up);
}

// Inflate polygon outward from its centroid by padDeg.
function inflatePoly(pts, padDeg) {
  if (!pts.length) return pts;
  const cx = pts.reduce((s, p) => s + p[0], 0) / pts.length;
  const cy = pts.reduce((s, p) => s + p[1], 0) / pts.length;
  return pts.map(([x, y]) => {
    const dx = x - cx, dy = y - cy;
    const len = Math.hypot(dx, dy) || 1;
    return [x + (dx / len) * padDeg, y + (dy / len) * padDeg];
  });
}

// Chaikin corner-cutting — one pass. Each edge contributes two new vertices
// at 1/4 and 3/4. Repeated application converges to a smooth curve.
function chaikin(pts) {
  const n = pts.length;
  if (n < 3) return pts;
  const out = [];
  for (let i = 0; i < n; i++) {
    const p0 = pts[i];
    const p1 = pts[(i + 1) % n];
    out.push([
      0.75 * p0[0] + 0.25 * p1[0],
      0.75 * p0[1] + 0.25 * p1[1],
    ]);
    out.push([
      0.25 * p0[0] + 0.75 * p1[0],
      0.25 * p0[1] + 0.75 * p1[1],
    ]);
  }
  return out;
}

function chaikinN(pts, passes = 3) {
  let out = pts;
  for (let i = 0; i < passes; i++) out = chaikin(out);
  return out;
}

// Build a closed quadratic-Bézier path through midpoints of the polygon.
// This guarantees C1 continuity and CANNOT self-intersect / loop, unlike
// Catmull-Rom which can overshoot on tight concave sections.
function quadPathClosed(screen) {
  if (!screen.length) return '';
  if (screen.length === 1) {
    const [x, y] = screen[0]; const r = 16;
    return `M${x - r},${y} a${r},${r} 0 1,0 ${r * 2},0 a${r},${r} 0 1,0 -${r * 2},0`;
  }
  const n = screen.length;
  // Start at the midpoint of the last→first edge.
  const startMid = [
    (screen[n - 1][0] + screen[0][0]) / 2,
    (screen[n - 1][1] + screen[0][1]) / 2,
  ];
  let d = `M${startMid[0].toFixed(1)},${startMid[1].toFixed(1)}`;
  for (let i = 0; i < n; i++) {
    const cur = screen[i];
    const next = screen[(i + 1) % n];
    const mid = [(cur[0] + next[0]) / 2, (cur[1] + next[1]) / 2];
    d += ` Q${cur[0].toFixed(1)},${cur[1].toFixed(1)} ${mid[0].toFixed(1)},${mid[1].toFixed(1)}`;
  }
  return d + ' Z';
}

/**
 * Build a smooth blob SVG path from a cluster of lat/lon points.
 *
 * @param {Array<{lat:number, lon:number}>} cluster
 * @param {{project: (lat:number, lon:number) => [number, number]}} projector
 * @param {number} gridStep   — grid spacing in degrees; used to size padding
 * @param {number} padScale   — multiplier on gridStep for inflation (default 2.0)
 * @returns {string} SVG path "d" attribute
 */
export function smoothBlobPath(cluster, projector, gridStep = 0.3, padScale = 2.0) {
  if (!cluster?.length) return '';

  const lonLat = cluster.map(p => [p.lon, p.lat]);
  const padDeg = gridStep * padScale;

  // Single point or tiny cluster: synthesise a small ring of points around centroid.
  if (lonLat.length <= 2) {
    const cx = lonLat.reduce((s, p) => s + p[0], 0) / lonLat.length;
    const cy = lonLat.reduce((s, p) => s + p[1], 0) / lonLat.length;
    const ring = [];
    for (let k = 0; k < 12; k++) {
      const a = (k / 12) * Math.PI * 2;
      ring.push([cx + Math.cos(a) * padDeg, cy + Math.sin(a) * padDeg]);
    }
    const screen = ring.map(([ln, lt]) => projector.project(lt, ln));
    return quadPathClosed(chaikinN(screen, 2));
  }

  const hull = convexHull(lonLat);
  if (hull.length < 3) {
    // Degenerate hull (collinear): synthesise ring around centroid as above
    const cx = lonLat.reduce((s, p) => s + p[0], 0) / lonLat.length;
    const cy = lonLat.reduce((s, p) => s + p[1], 0) / lonLat.length;
    const ring = [];
    for (let k = 0; k < 12; k++) {
      const a = (k / 12) * Math.PI * 2;
      ring.push([cx + Math.cos(a) * padDeg, cy + Math.sin(a) * padDeg]);
    }
    const screen = ring.map(([ln, lt]) => projector.project(lt, ln));
    return quadPathClosed(chaikinN(screen, 2));
  }

  const inflated = inflatePoly(hull, padDeg);
  // Project to screen first, THEN smooth — this keeps the smoothing isotropic
  // in pixel space (so it looks even regardless of latitude).
  const screen = inflated.map(([lon, lat]) => projector.project(lat, lon));
  // 3 passes of Chaikin → 8× vertices → smooth round shape, no hexagons.
  const smoothed = chaikinN(screen, 3);
  return quadPathClosed(smoothed);
}