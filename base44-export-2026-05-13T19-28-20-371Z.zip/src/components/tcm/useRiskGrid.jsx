const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useCallback } from 'react';

/**
 * Hook that fetches the cached UK convective risk grid from the backend.
 * Auto-refreshes every 30 min in the browser; server caches for 6h.
 */
export default function useRiskGrid() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchGrid = useCallback(async (force = false) => {
    setLoading(true);
    setError(null);
    try {
      const res = await db.functions.invoke('getRiskGrid', force ? { force: 1 } : {});
      const body = res?.data || res;
      if (!body?.ok) throw new Error(body?.error || 'risk grid fetch failed');
      setData(body);
    } catch (e) {
      setError(e.message || 'failed to load risk grid');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchGrid(false);
    const iv = setInterval(() => fetchGrid(false), 30 * 60 * 1000);
    return () => clearInterval(iv);
  }, [fetchGrid]);

  return { data, loading, error, refresh: () => fetchGrid(true) };
}