import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { BarChart2 } from 'lucide-react';
import { useTCMTheme } from './TCMThemeContext';
import { scoreToLevel, RISK_COLOR, RISK_FILL } from './riskConfig';

const HOURS_PER_STEP = 3;
const STEPS_PER_DAY = 8;

export default function DiurnalTimingSection({ data, dayIdx, riskType, peakStep, peakLocation, summary }) {
  const { t, lightMode } = useTCMTheme();

  const stepData = useMemo(() => {
    return Array.from({ length: STEPS_PER_DAY }).map((_, si) => {
      const globalStep = dayIdx * STEPS_PER_DAY + si;
      const hour = si * HOURS_PER_STEP;
      let stepMax = 0, capeSum = 0, shearSum = 0, liSum = 0, count = 0, stormyCount = 0;
      for (const p of (data?.grid || [])) {
        const sc = p.perStep?.[globalStep]?.scores?.[riskType] ?? 0;
        if (sc > stepMax) stepMax = sc;
        const m = p.perStep?.[globalStep]?.scores?.metrics;
        if (m) { capeSum += m.cape || 0; shearSum += m.shear || 0; liSum += m.li || 0; count++; }
        if (sc >= 10) stormyCount++;
      }
      const avgCape = count ? Math.round(capeSum / count) : 0;
      const avgShear = count ? Math.round(shearSum / count * 10) / 10 : 0;
      const avgLi = count ? Math.round(liSum / count * 10) / 10 : 0;
      const lvl = scoreToLevel(stepMax);
      const phase = hour < 6 ? 'Night' : hour < 12 ? 'Morning' : hour < 18 ? 'Afternoon' : 'Evening';
      const phaseColor = hour < 6 ? '#4f46e5' : hour < 12 ? '#0ea5e9' : hour < 18 ? '#f59e0b' : '#f97316';
      const phaseIcon = hour < 6 ? '🌙' : hour < 12 ? '🌤' : hour < 18 ? '☀️' : '🌇';
      return { si, hour, stepMax, avgCape, avgShear, avgLi, stormyCount, lvl, phase, phaseColor, phaseIcon, isPeak: si === peakStep };
    });
  }, [data, dayIdx, riskType, peakStep]);

  const maxCape = Math.max(...stepData.map(d => d.avgCape), 1);
  const maxShear = Math.max(...stepData.map(d => d.avgShear), 1);
  const peakHrs = peakStep != null
    ? `${(peakStep * HOURS_PER_STEP).toString().padStart(2, '0')}–${(((peakStep * HOURS_PER_STEP) + HOURS_PER_STEP) % 24).toString().padStart(2, '0')}Z`
    : 'afternoon';

  const BAR_H = 100;
  const ATMOS_H = 36;
  const barColor = (lvl, rt) => RISK_COLOR(lvl, rt) === '#64748b' ? 'rgba(255,255,255,0.08)' : RISK_COLOR(lvl, rt);
  const barFill = (lvl, rt) => RISK_FILL(lvl, rt) === 'rgba(100,116,139,0)' ? 'rgba(255,255,255,0.04)' : RISK_FILL(lvl, rt);

  return (
    <div style={{ paddingTop: 8 }}>
      <div style={{ display: 'flex', gap: 2, marginBottom: 6 }}>
        {stepData.map(d => (
          <div key={d.si} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
            <div style={{ fontSize: '0.55rem', color: d.phaseColor, fontWeight: 700, opacity: 0.8 }}>{d.phaseIcon}</div>
            <div style={{ height: 3, width: '100%', borderRadius: 2, background: d.phaseColor, opacity: d.si === peakStep ? 1 : 0.35 }} />
          </div>
        ))}
      </div>

      <div style={{ position: 'relative', height: BAR_H + 52, marginBottom: 8 }}>
        {[25, 50, 75].map(v => (
          <div key={v} style={{ position: 'absolute', left: 0, right: 0, bottom: 40 + (v / 100) * BAR_H, borderTop: `1px dashed ${lightMode ? 'rgba(0,0,0,0.07)' : 'rgba(255,255,255,0.06)'}`, pointerEvents: 'none', display: 'flex', alignItems: 'center' }}>
            <span style={{ fontSize: '0.46rem', color: t.textMuted, fontFamily: "'DM Mono',monospace", background: lightMode ? 'rgba(255,255,255,0.8)' : 'rgba(10,15,30,0.8)', padding: '0 3px', borderRadius: 2, marginLeft: 2, lineHeight: 1.4 }}>{v}</span>
          </div>
        ))}
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, top: 0, display: 'flex', gap: 3, alignItems: 'flex-end', paddingBottom: 40 }}>
          {stepData.map(d => {
            const barH = Math.max(3, Math.round((d.stepMax / 100) * BAR_H));
            const bc = barColor(d.lvl, riskType);
            const isActive = d.stepMax >= 3;
            return (
              <div key={d.si} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative' }}>
                {d.isPeak && isActive && (
                  <div style={{ position: 'absolute', bottom: barH + 40 + 6, left: '50%', transform: 'translateX(-50%)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1, zIndex: 2 }}>
                    <div style={{ fontSize: '0.52rem', fontWeight: 900, color: bc, whiteSpace: 'nowrap', textShadow: `0 0 8px ${bc}88` }}>▲ PEAK</div>
                    <div style={{ width: 1, height: 6, background: bc, opacity: 0.6 }} />
                  </div>
                )}
                <div style={{ fontSize: '0.52rem', fontWeight: 800, color: isActive ? bc : 'transparent', fontFamily: "'DM Mono',monospace", marginBottom: 2, height: 14, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
                  {isActive ? Math.round(d.stepMax) : ''}
                </div>
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: barH, opacity: 1 }} transition={{ duration: 0.55, delay: d.si * 0.04, ease: [0.22, 1, 0.36, 1] }}
                  style={{ width: '100%', borderRadius: '4px 4px 0 0', background: isActive ? `linear-gradient(0deg, ${bc}44 0%, ${bc}99 60%, ${bc}cc 100%)` : lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.04)', border: `1.5px solid ${isActive ? bc + '88' : 'transparent'}`, borderBottom: 'none', boxShadow: d.isPeak ? `0 0 18px ${bc}55` : 'none', position: 'relative', overflow: 'hidden' }}>
                  {d.isPeak && isActive && <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(255,255,255,0.18) 0%, transparent 100%)', borderRadius: '4px 4px 0 0' }} />}
                </motion.div>
              </div>
            );
          })}
        </div>
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 40, display: 'flex', gap: 3 }}>
          {stepData.map(d => (
            <div key={d.si} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start', paddingTop: 3, gap: 2 }}>
              <div style={{ width: 1, height: 5, background: t.textMuted, opacity: 0.3 }} />
              <div style={{ fontSize: '0.52rem', color: t.textMuted, fontFamily: "'DM Mono',monospace", lineHeight: 1 }}>{d.hour.toString().padStart(2, '0')}Z</div>
              <div style={{ fontSize: '0.46rem', fontWeight: 700, color: d.phaseColor, opacity: 0.7 }}>{d.phase.slice(0, 3).toUpperCase()}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 3, marginBottom: 14 }}>
        {stepData.map(d => {
          const bc = barColor(d.lvl, riskType);
          const bf = barFill(d.lvl, riskType);
          const isActive = d.stepMax >= 3;
          return (
            <div key={d.si} style={{ flex: 1, padding: '3px 2px', background: isActive ? bf : 'transparent', border: `1px solid ${isActive ? bc + '55' : 'transparent'}`, borderRadius: 4, textAlign: 'center', boxShadow: d.isPeak && isActive ? `0 0 10px ${bc}33` : 'none' }}>
              {isActive && <div style={{ fontSize: '0.44rem', fontWeight: 800, color: bc, fontFamily: "'DM Mono',monospace", letterSpacing: '0.04em', lineHeight: 1.3, overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>
                {d.lvl === 'No Risk' ? '—' : d.lvl.slice(0, 4).toUpperCase()}
              </div>}
            </div>
          );
        })}
      </div>

      <div style={{ background: lightMode ? 'rgba(0,0,0,0.03)' : 'rgba(255,255,255,0.025)', border: `1px solid ${t.cardBorder}`, borderRadius: 10, padding: '10px 12px', marginBottom: 12 }}>
        <div style={{ fontSize: '0.6rem', fontWeight: 800, color: t.textMuted, textTransform: 'uppercase', letterSpacing: '0.10em', fontFamily: "'DM Mono',monospace", marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
          <BarChart2 style={{ width: 10, height: 10 }} /> Atmospheric Trend
        </div>
        <div style={{ display: 'flex', gap: 3, alignItems: 'flex-end', height: ATMOS_H, marginBottom: 4 }}>
          {stepData.map(d => {
            const cH = Math.max(1, Math.round((d.avgCape / Math.max(maxCape, 1)) * ATMOS_H));
            const isActive = d.avgCape > 50;
            return (
              <div key={d.si} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', height: ATMOS_H }}>
                <motion.div initial={{ height: 0 }} animate={{ height: cH }} transition={{ duration: 0.5, delay: d.si * 0.04 }}
                  style={{ width: '100%', borderRadius: '2px 2px 0 0', background: isActive ? 'linear-gradient(0deg, #ef444466, #ef4444aa)' : lightMode ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.04)', border: `1px solid ${isActive ? '#ef444455' : 'transparent'}`, borderBottom: 'none' }} />
              </div>
            );
          })}
        </div>
        <div style={{ display: 'flex', gap: 3, alignItems: 'flex-end', height: ATMOS_H * 0.6, marginBottom: 4 }}>
          {stepData.map(d => {
            const sH = Math.max(1, Math.round((d.avgShear / Math.max(maxShear, 1)) * (ATMOS_H * 0.6)));
            return (
              <div key={d.si} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', height: ATMOS_H * 0.6 }}>
                <motion.div initial={{ height: 0 }} animate={{ height: sH }} transition={{ duration: 0.5, delay: d.si * 0.04 }}
                  style={{ width: '70%', borderRadius: '2px 2px 0 0', background: 'linear-gradient(0deg, #38bdf455, #38bdf4aa)', border: '1px solid #38bdf455', borderBottom: 'none' }} />
              </div>
            );
          })}
        </div>
        <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
          {[{ color: '#ef4444', label: 'CAPE (J/kg)', max: Math.max(...stepData.map(d => d.avgCape)) }, { color: '#38bdf8', label: 'Shear (m/s)', max: Math.round(Math.max(...stepData.map(d => d.avgShear)) * 10) / 10 }].map(item => (
            <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <div style={{ width: 22, height: 4, borderRadius: 2, background: item.color }} />
              <span style={{ fontSize: '0.58rem', color: t.textMuted, fontFamily: "'DM Mono',monospace" }}>{item.label} <span style={{ color: t.textSecondary, fontWeight: 700 }}>max {item.max}</span></span>
            </div>
          ))}
        </div>
      </div>

      {peakStep != null && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', background: lightMode ? 'rgba(167,139,250,0.08)' : 'rgba(167,139,250,0.10)', border: '1px solid rgba(167,139,250,0.25)', borderRadius: 10, flexWrap: 'wrap' }}>
          <div style={{ width: 8, height: 8, borderRadius: 99, background: '#a78bfa', boxShadow: '0 0 10px #a78bfa', flexShrink: 0 }} />
          <div style={{ flex: 1, minWidth: 180 }}>
            <div style={{ fontSize: '0.68rem', fontWeight: 700, color: '#a78bfa', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 2 }}>Peak Convective Window</div>
            <div style={{ fontSize: '0.78rem', color: t.textSecondary, lineHeight: 1.5 }}>
              <strong style={{ color: t.textPrimary }}>{peakHrs}</strong>
              {peakLocation?.bearing && <> · Focus: <strong style={{ color: t.textPrimary }}>{peakLocation.bearing}</strong></>}
              {stepData[peakStep] && <> · Peak score <strong style={{ color: barColor(stepData[peakStep].lvl, riskType) }}>{Math.round(stepData[peakStep].stepMax)}/100</strong> ({stepData[peakStep].lvl})</>}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {stepData[peakStep] && [{ label: 'CAPE', value: `${stepData[peakStep].avgCape}`, unit: 'J/kg', color: '#ef4444' }, { label: 'Shear', value: `${stepData[peakStep].avgShear}`, unit: 'm/s', color: '#38bdf8' }].map(m => (
              <div key={m.label} style={{ padding: '4px 8px', background: 'rgba(255,255,255,0.04)', border: `1px solid ${t.cardBorder}`, borderRadius: 7, textAlign: 'center' }}>
                <div style={{ fontSize: '0.50rem', color: t.textMuted, textTransform: 'uppercase', letterSpacing: '0.08em', fontFamily: "'DM Mono',monospace" }}>{m.label}</div>
                <div style={{ fontSize: '0.80rem', fontWeight: 800, color: m.color, fontFamily: "'DM Mono',monospace" }}>{m.value}<span style={{ fontSize: '0.56rem', fontWeight: 600 }}>{m.unit}</span></div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}