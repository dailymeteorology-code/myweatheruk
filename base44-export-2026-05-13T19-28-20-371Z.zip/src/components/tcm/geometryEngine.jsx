/**
 * TCM Professional Geometry Engine
 * 
 * Produces meteorologist-quality risk outlines for SPC/SOTUK-style outlooks.
 * Pipeline per cluster:
 *   1. Cluster grid points by spatial adjacency (connected components)
 *   2. Convex hull of each cluster in geographic space (lat/lon)
 *   3. Inflate outward by padDeg (≈ half a grid step) in lat/lon space
 *   4. Project to screen coordinates
 *   5. Smooth with Catmull-Rom → cubic Bezier spline
 *
 * Each risk level includes ALL grid points AT OR ABOVE its threshold so
 * higher levels nest inside lower ones with gradual downscale.
 */

// ── Graduated opacity per risk level ─────────────────────────────────────
// Very Low is barely tinted, Severe is strong opaque fill.
export const LEVEL_OPACITY = {
  'Very Low': 0.55, 'Low': 0.65, 'Marginal': 0.75,
  'Moderate': 0.85, 'High': 0.92, 'Severe': 1.0
};

// ── Graham scan convex hull — O(n log n) ─────────────────────────────────
export function convexHull(pts) {
  if (pts.length <= 2) return pts.slice();
  const p = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cross = (o, a, b) => (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0]);
  const lo = [], up = [];
  for (const x of p) { while (lo.length >= 2 && cross(lo[lo.length-2], lo[lo.length-1], x) <= 0) lo.pop(); lo.push(x); }
  for (let i = p.length-1; i >= 0; i--) { const x = p[i]; while (up.length >= 2 && cross(up[up.length-2], up[up.length-1], x) <= 0) up.pop(); up.push(x); }
  lo.pop(); up.pop(); return lo.concat(up);
}

// ── Inflate polygon outward from centroid in geographic space ─────────────
function inflatePoly(pts, padDeg) {
  if (!pts.length) return pts;
  const cx = pts.reduce((s, p) => s + p[0], 0) / pts.length;
  const cy = pts.reduce((s, p) => s + p[1], 0) / pts.length;
  return pts.map(([x, y]) => {
    const dx = x - cx, dy = y - cy;
    const len = Math.hypot(dx, dy) || 1;
    return [x + (dx / len) * padDeg, y + (dy / len) * padDeg];
  });
}

// ── Catmull-Rom smooth closed path ───────────────────────────────────────
function smoothClosedPath(pts, tension = 0.38) {
  if (!pts.length) return '';
  if (pts.length === 1) {
    const [x, y] = pts[0]; const r = 14;
    return `M${x-r},${y} a${r},${r} 0 1,0 ${r*2},0 a${r},${r} 0 1,0 -${r*2},0`;
  }
  if (pts.length === 2) {
    const [ax,ay] = pts[0], [bx,by] = pts[1];
    const mx = (ax+bx)/2, my = (ay+by)/2;
    const len = Math.hypot(bx-ax, by-ay) || 1;
    const px = -(by-ay)/len*12, py = (bx-ax)/len*12;
    return `M${ax},${ay} Q${mx+px},${my+py} ${bx},${by} Q${mx-px},${my-py} ${ax},${ay}Z`;
  }
  const n = pts.length;
  let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
  for (let i = 0; i < n; i++) {
    const p0 = pts[(i-1+n)%n], p1 = pts[i], p2 = pts[(i+1)%n], p3 = pts[(i+2)%n];
    const cp1x = p1[0] + tension * (p2[0] - p0[0]);
    const cp1y = p1[1] + tension * (p2[1] - p0[1]);
    const cp2x = p2[0] - tension * (p3[0] - p1[0]);
    const cp2y = p2[1] - tension * (p3[1] - p1[1]);
    d += ` C${cp1x.toFixed(1)},${cp1y.toFixed(1)} ${cp2x.toFixed(1)},${cp2y.toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
  }
  return d + ' Z';
}

// ── Cluster grid points by 8-directional adjacency ───────────────────────
export function clusterPoints(pts, gridStep, minClusterSize = 2) {
  if (!pts.length) return [];
  const visited = new Set();
  const key = p => `${p.lat.toFixed(3)},${p.lon.toFixed(3)}`;
  const map = new Map(pts.map(p => [key(p), p]));
  const clusters = [];
  const step = parseFloat(gridStep.toFixed(4));
  for (const p of pts) {
    const k = key(p);
    if (visited.has(k)) continue;
    const cluster = [];
    const queue = [p];
    while (queue.length) {
      const cur = queue.shift();
      const ck = key(cur);
      if (visited.has(ck)) continue;
      visited.add(ck);
      cluster.push(cur);
      for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const nk = `${(cur.lat + dy*step).toFixed(3)},${(cur.lon + dx*step).toFixed(3)}`;
          const nb = map.get(nk);
          if (nb && !visited.has(key(nb))) queue.push(nb);
        }
      }
    }
    if (cluster.length >= minClusterSize) clusters.push(cluster);
  }
  return clusters;
}

/**
 * Convert a cluster of lat/lon grid points into a smooth SVG path.
 *
 * padDeg controls how far the hull inflates outward in geographic degrees
 * before projection. Typically gridStep * 0.6 for outer levels, less for inner.
 */
export function clusterToPath(cluster, projector, padDeg = 0.18) {
  if (!cluster.length) return '';
  const lonLat = cluster.map(p => [p.lon, p.lat]);
  if (lonLat.length === 1) {
    const [x, y] = projector.project(lonLat[0][1], lonLat[0][0]);
    const r = 14;
    return `M${x-r},${y} a${r},${r} 0 1,0 ${r*2},0 a${r},${r} 0 1,0 -${r*2},0`;
  }
  const hull = convexHull(lonLat);
  const inflated = inflatePoly(hull, padDeg);
  const screen = inflated.map(([lon, lat]) => projector.project(lat, lon));
  return smoothClosedPath(screen, 0.36);
}

// ── Outlook layer builders ───────────────────────────────────────────────

const ORDERED_LEVELS = ['Very Low','Low','Marginal','Moderate','High','Severe'];
const MIN_SCORE = {'Very Low':3,'Low':10,'Marginal':22,'Moderate':38,'High':56,'Severe':76};

export function buildOutlookLayers(grid, riskType, dayIdx, gridStep) {
  const layers = [];
  for (const lvl of ORDERED_LEVELS) {
    const thresh = MIN_SCORE[lvl];
    const pts = grid.filter(p => (p.perDay?.[dayIdx]?.scores?.[riskType] ?? 0) >= thresh);
    if (pts.length < 2) continue;
    const clusters = clusterPoints(pts, gridStep, 2);
    if (!clusters.length) continue;
    layers.push({ level: lvl, clusters });
  }
  return layers;
}

export function buildOutlookLayersForStep(grid, riskType, stepIdx, gridStep) {
  const layers = [];
  for (const lvl of ORDERED_LEVELS) {
    const thresh = MIN_SCORE[lvl];
    const pts = grid.filter(p => (p.perStep?.[stepIdx]?.scores?.[riskType] ?? 0) >= thresh);
    if (pts.length < 2) continue;
    const clusters = clusterPoints(pts, gridStep, 2);
    if (!clusters.length) continue;
    layers.push({ level: lvl, clusters });
  }
  return layers;
}

// Legacy wrappers
export function buildBlobs(grid,riskType,dayIdx,gridStep){
  return buildOutlookLayers(grid,riskType,dayIdx,gridStep).map(l=>({level:l.level,points:l.clusters.flat()}));
}
export function buildBlobsForStep(grid,riskType,stepIdx,gridStep){
  return buildOutlookLayersForStep(grid,riskType,stepIdx,gridStep).map(l=>({level:l.level,points:l.clusters.flat()}));
}

export function buildProbabilityLayers(grid, riskType, dayIdx, colors, gridStep) {
  const layers = [];
  for (const band of colors) {
    const pts = grid.filter(p => (p.perDay?.[dayIdx]?.scores?.[riskType] ?? 0) >= band.min);
    if (pts.length < 2) continue;
    const clusters = clusterPoints(pts, gridStep, 2);
    if (!clusters.length) continue;
    layers.push({ ...band, clusters });
  }
  return layers;
}