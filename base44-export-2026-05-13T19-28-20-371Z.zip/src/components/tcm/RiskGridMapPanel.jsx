import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';
import RiskGridLayer from './RiskGridLayer';
import RiskMapControls from './RiskMapControls';
import useRiskGrid from './useRiskGrid';

/**
 * Self-contained risk-grid map panel.
 * Renders its own Leaflet map under the controls, no external map required.
 *
 * Why a self-contained map?
 * The existing LightningMap in pages/TCM.jsx is tightly coupled to live strike
 * data and storm clustering. Embedding a fresh, focused map for the risk-grid
 * outlook keeps the two concerns isolated and avoids bloating TCM.jsx further.
 */
export default function RiskGridMapPanel({ lightMode = false }) {
  const { data, loading, error, refresh } = useRiskGrid();
  const mapRef = useRef(null);
  const mapInstRef = useRef(null);
  const [mapReady, setMapReady] = useState(false);

  const [activeRiskType, setActiveRiskType] = useState('lightning');
  const [activeDay, setActiveDay] = useState(0);
  const [showPolygons, setShowPolygons] = useState(true);
  const [showCells, setShowCells] = useState(true);

  // Init Leaflet
  useEffect(() => {
    if (!document.getElementById('leaflet-css')) {
      const l = document.createElement('link');
      l.id = 'leaflet-css'; l.rel = 'stylesheet';
      l.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(l);
    }
    function ensureL() {
      if (window.L) { setMapReady(true); return; }
      const existing = document.querySelector('script[src*="leaflet@1.9.4"]');
      if (existing) { existing.addEventListener('load', () => setMapReady(true)); return; }
      const s = document.createElement('script');
      s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      s.onload = () => setMapReady(true);
      document.head.appendChild(s);
    }
    ensureL();
  }, []);

  useEffect(() => {
    if (!mapReady || !mapRef.current || mapInstRef.current) return;
    const L = window.L;
    const tile = lightMode
      ? 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png'
      : 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
    const map = L.map(mapRef.current, {
      center: [54.5, -3.0], zoom: 5,
      zoomControl: false, attributionControl: false,
      preferCanvas: true,
    });
    L.tileLayer(tile, { maxZoom: 9, subdomains: 'abcd' }).addTo(map);
    mapInstRef.current = map;
    return () => { map.remove(); mapInstRef.current = null; };
  }, [mapReady, lightMode]);

  const grid = data?.grid_data?.[activeDay]?.[activeRiskType] || [];
  const polys = data?.polygons?.[activeDay]?.[activeRiskType] || [];

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
      className="mx-auto max-w-6xl px-6 mb-10">
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(0, 1fr)',
        gap: 12,
      }}>
        <RiskMapControls
          activeRiskType={activeRiskType}
          onRiskTypeChange={setActiveRiskType}
          activeDay={activeDay}
          onDayChange={setActiveDay}
          showPolygons={showPolygons}
          onTogglePolygons={() => setShowPolygons(v => !v)}
          showCells={showCells}
          onToggleCells={() => setShowCells(v => !v)}
          onRefresh={refresh}
          loading={loading}
          generatedAt={data?.generated_at}
          modelRun={data?.model_run}
        />

        <div style={{
          position: 'relative',
          height: 'min(560px, 70vh)',
          borderRadius: 16,
          overflow: 'hidden',
          border: `1px solid ${lightMode ? 'rgba(0,0,0,0.08)' : 'rgba(255,255,255,0.07)'}`,
          background: lightMode ? '#e6edf5' : '#060d1a',
        }}>
          <div ref={mapRef} style={{ width: '100%', height: '100%' }} />
          {mapInstRef.current && (
            <RiskGridLayer
              map={mapInstRef.current}
              cells={grid}
              polygons={polys}
              showCells={showCells}
              showPolygons={showPolygons}
            />
          )}
          {(loading && !data) && (
            <div style={{
              position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: lightMode ? 'rgba(255,255,255,0.7)' : 'rgba(6,13,26,0.7)', gap: 10,
            }}>
              <Loader2 style={{ width: 18, height: 18, animation: 'spin 1s linear infinite', color: '#a78bfa' }} />
              <span style={{ fontSize: '0.8rem', color: lightMode ? '#475569' : '#94a3b8' }}>
                Building risk grid from ECMWF + ARPEGE + XWeather…
              </span>
            </div>
          )}
          {error && (
            <div style={{
              position: 'absolute', top: 12, left: 12, right: 12,
              padding: '10px 14px', borderRadius: 10,
              background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)',
              color: '#fca5a5', fontSize: '0.78rem',
            }}>
              ⚠ {error}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}