import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, CloudRain, Wind, Snowflake, Thermometer, Zap, Waves, X, Clock, MapPin, ChevronRight, Calendar, AlertCircle } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { format, isValid, formatDistanceToNow } from 'date-fns';

const formatDateTime = (dateStr) => {
  if (!dateStr) return 'N/A';
  const date = new Date(dateStr);
  if (!isValid(date)) return dateStr;
  return format(date, 'dd MMM yyyy, HH:mm');
};

const extractImpacts = (warning) => {
  const impacts = [];
  const text = `${warning.type} ${warning.description}`.toLowerCase();
  
  if (/travel|transport|rail|road|flight|delay|journey|disruption|traffic|commut/i.test(text)) {
    impacts.push('Travel Disruption');
  }
  if (/flood|water|inundat|wet|rain|drainage/i.test(text)) {
    impacts.push('Flood Risk');
  }
  if (/health|heat|cold|vulnerable|elderly|wind|danger|breathing|respiratory/i.test(text)) {
    impacts.push('Health Risk');
  }
  if (/power|electric|outage|blackout|supply/i.test(text)) {
    impacts.push('Power Outage Risk');
  }
  
  return impacts;
};

const timeRemaining = (dateStr, isUpcoming) => {
        if (!dateStr) return null;
        const date = new Date(dateStr);
        if (!isValid(date)) return null;
        const now = new Date();
        if (date < now) return isUpcoming ? 'Started' : 'Expired';
        return isUpcoming ? `Starts in ${formatDistanceToNow(date)}` : `Expires in ${formatDistanceToNow(date)}`;
      };

const severityColors = {
  Yellow: { card: 'bg-yellow-400/20 border-yellow-400/70 text-white', glow: 'shadow-yellow-500/20' },
  Amber:  { card: 'bg-orange-500/20 border-orange-500/70 text-white', glow: 'shadow-orange-500/20' },
  Red:    { card: 'bg-red-500/20 border-red-500/70 text-white',    glow: 'shadow-red-500/20' },
};

const severityBadge = {
  Yellow: 'bg-amber-400 text-slate-900 font-semibold',
  Amber:  'bg-orange-500 text-white font-semibold',
  Red:    'bg-red-500 text-white font-semibold',
};

const severityGradient = {
  Yellow: 'from-yellow-500/30 to-amber-600/30',
  Amber:  'from-orange-500/30 to-red-500/30',
  Red:    'from-red-500/40 to-rose-700/40',
};

const weatherIcons = {
  Rain:          CloudRain,
  Wind:          Wind,
  Snow:          Snowflake,
  Ice:           Snowflake,
  Thunderstorm:  Zap,
  'Extreme Heat': Thermometer,
  Fog:           CloudRain,
  Flood:         Waves,
};

export default function WarningCard({ warning, index, isUpcoming = false }) {
              const [expanded, setExpanded] = useState(false);
              const Icon = weatherIcons[warning.type] || AlertTriangle;
              const colors = severityColors[warning.severity] || severityColors.Yellow;
              const badgeClass = severityBadge[warning.severity] || severityBadge.Yellow;
              const gradient = severityGradient[warning.severity] || severityGradient.Yellow;
              const remaining = timeRemaining(isUpcoming ? warning.validFrom : warning.validTo, isUpcoming);
              const impacts = extractImpacts(warning);

  return (
    <>
      {/* Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.1, duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
        whileHover={{ y: -4, scale: 1.01, transition: { duration: 0.2 } }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setExpanded(true)}
        className={`rounded-2xl border-2 p-5 ${colors.card} cursor-pointer shadow-lg ${colors.glow} select-none`}
      >
        <div className="flex justify-between mb-3">
          <div className="flex gap-3">
            <motion.div
              whileHover={{ rotate: 10 }}
              className="p-3 rounded-xl bg-white/20 backdrop-blur-sm shrink-0"
            >
              <Icon className="w-6 h-6" />
            </motion.div>
            <div className="pt-1.5">
              <h3 className="font-bold text-lg leading-tight">{warning.type} Warning</h3>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge className={badgeClass}>{warning.severity}</Badge>
            <span className="text-xs opacity-50 flex items-center gap-1">
              <ChevronRight className="w-3 h-3" /> Tap for details
            </span>
          </div>
        </div>

        {warning.region && (
          <p className="text-sm opacity-75 flex items-center gap-1 mb-3">
            <MapPin className="w-3 h-3 shrink-0" /> {warning.region}
          </p>
        )}

        <p className="text-sm leading-relaxed opacity-90 line-clamp-2 mb-3">{warning.description}</p>

        <div className="flex items-center justify-between pt-3 border-t border-white/15 text-xs opacity-70">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" /> {remaining}
          </span>
          <span>{isUpcoming ? 'Starts' : 'Until'} {formatDateTime(isUpcoming ? warning.validFrom : warning.validTo)}</span>
        </div>

        {impacts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-white/15"
          >
            {impacts.map((impact) => (
              <motion.div
                key={impact}
                whileHover={{ scale: 1.05 }}
                className="flex items-center gap-1.5 bg-white/10 border border-white/20 rounded-full px-3 py-1.5 text-xs font-medium hover:bg-white/15 transition-colors"
              >
                <AlertCircle className="w-3 h-3" />
                {impact}
              </motion.div>
            ))}
          </motion.div>
        )}
        </motion.div>

      {/* Expanded overlay */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-black/60 backdrop-blur-md"
            onClick={() => setExpanded(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.88, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.88, y: 30 }}
              transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
              onClick={(e) => e.stopPropagation()}
              className={`relative w-full max-w-lg rounded-3xl border-2 ${colors.card} bg-gradient-to-br ${gradient} backdrop-blur-xl shadow-2xl overflow-hidden`}
            >
              {/* Header gradient bar */}
              <div className={`h-1.5 w-full bg-gradient-to-r ${gradient.replace('/30', '')}`} />

              <div className="p-6">
                {/* Top row */}
                <div className="flex items-start justify-between mb-5">
                  <div className="flex items-center gap-4">
                    <motion.div
                      initial={{ rotate: -15, scale: 0.7 }}
                      animate={{ rotate: 0, scale: 1 }}
                      transition={{ delay: 0.1, duration: 0.4, type: 'spring' }}
                      className="p-4 rounded-2xl bg-white/20 backdrop-blur-sm"
                    >
                      <Icon className="w-8 h-8" />
                    </motion.div>
                    <div>
                      <motion.h2
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.15 }}
                        className="font-bold text-2xl"
                      >
                        {warning.type} Warning
                      </motion.h2>
                      <Badge className={`mt-1 ${badgeClass}`}>{warning.severity} Warning</Badge>
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.1, backgroundColor: 'rgba(255,255,255,0.25)' }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setExpanded(false)}
                    className="p-2 rounded-xl bg-white/10 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </motion.button>
                </div>

                {/* Region */}
                {warning.region && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="flex items-start gap-2 mb-4 px-3 py-2 rounded-xl bg-white/10"
                  >
                    <MapPin className="w-4 h-4 opacity-70 shrink-0 mt-0.5 flex-shrink-0" />
                    <span className="text-sm font-medium">{warning.region}</span>
                  </motion.div>
                )}

                {/* Description */}
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25 }}
                  className="mb-5"
                >
                  <p className="text-xs uppercase tracking-widest opacity-50 mb-2">What to expect</p>
                  <p className="text-sm leading-relaxed opacity-95">{warning.description}</p>
                </motion.div>

                {/* Impact Tags */}
                {impacts.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.28 }}
                    className="mb-5"
                  >
                    <p className="text-xs uppercase tracking-widest opacity-50 mb-3">Expected impacts</p>
                    <div className="flex flex-wrap gap-2">
                      {impacts.map((impact) => (
                        <motion.div
                          key={impact}
                          whileHover={{ scale: 1.05 }}
                          className="flex items-center gap-1.5 bg-white/10 border border-white/20 rounded-full px-3 py-1.5 text-xs font-medium hover:bg-white/15 transition-colors"
                        >
                          <AlertCircle className="w-3 h-3" />
                          {impact}
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* Time details */}
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="grid grid-cols-2 gap-3 mb-5"
                >
                  <div className="bg-white/10 rounded-2xl p-4">
                    <p className="text-xs uppercase tracking-widest opacity-50 mb-1 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> Valid From
                    </p>
                    <p className="font-semibold text-sm">{formatDateTime(warning.validFrom)}</p>
                  </div>
                  <div className="bg-white/10 rounded-2xl p-4">
                    <p className="text-xs uppercase tracking-widest opacity-50 mb-1 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> Valid Until
                    </p>
                    <p className="font-semibold text-sm">{formatDateTime(warning.validTo)}</p>
                  </div>
                </motion.div>

                {/* Time remaining pill */}
                {remaining && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.35 }}
                    className="flex items-center justify-center gap-2 bg-white/10 rounded-2xl py-3 px-4 text-sm font-medium"
                  >
                    <Clock className="w-4 h-4 opacity-70" />
                    {remaining}
                  </motion.div>
                )}

                {/* Met Office link */}
                <motion.a
                  href="https://www.metoffice.gov.uk/weather/warnings-and-advice/uk-warnings"
                  target="_blank"
                  rel="noopener noreferrer"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center justify-center gap-2 mt-4 w-full py-3 rounded-2xl bg-white/10 hover:bg-white/20 transition-colors text-sm font-medium"
                >
                  View on Met Office <ChevronRight className="w-4 h-4" />
                </motion.a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}