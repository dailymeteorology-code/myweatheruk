const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { motion } from 'framer-motion';
import LocationSearch from '@/components/LocationSearch';

export default function FloatingSearchBar() {
  const [opacity, setOpacity] = useState(1);
  const [searchEnabled, setSearchEnabled] = useState(true);

  useEffect(() => {
    db.entities.SiteSettings.list().then(list => {
      const s = list[0];
      if (s && s.location_search_enabled === false) setSearchEnabled(false);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const heroHeight = 360;
      if (scrollY < heroHeight) {
        setOpacity(0.3 + (scrollY / heroHeight) * 0.7);
      } else {
        setOpacity(1);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!searchEnabled) return null;

  return (
    <motion.div
      className="fixed top-4 right-4 z-20"
      animate={{ opacity }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
    >
      <LocationSearch expandOnHover />
    </motion.div>
  );
}