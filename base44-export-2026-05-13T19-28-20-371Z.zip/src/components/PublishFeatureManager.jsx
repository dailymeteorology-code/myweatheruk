const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { toast } from 'sonner';
import { useTheme } from '@/components/ThemeContext';

const AVAILABLE_FEATURES = [
  { id: 'graphics', label: 'Graphics' },
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'countdown', label: 'Countdown' },
];

export default function PublishFeatureManager() {
  const { isDark } = useTheme();
  const queryClient = useQueryClient();

  const { data: features = [], isLoading } = useQuery({
    queryKey: ['publishedFeatures'],
    queryFn: async () => {
      const data = await db.entities.PublishedFeatures.list();
      // Ensure all features exist in the database
      for (const feature of AVAILABLE_FEATURES) {
        const exists = data.find(f => f.feature_name === feature.id);
        if (!exists) {
          await db.entities.PublishedFeatures.create({
            feature_name: feature.id,
            is_published: false,
          });
        }
      }
      return await db.entities.PublishedFeatures.list();
    },
  });

  const featureMap = React.useMemo(() => {
    const map = {};
    features.forEach(f => {
      map[f.feature_name] = f;
    });
    return map;
  }, [features]);

  const toggleMutation = useMutation({
    mutationFn: async (featureId) => {
      const feature = featureMap[featureId];
      await db.entities.PublishedFeatures.update(feature.id, {
        is_published: !feature.is_published,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['publishedFeatures'] });
      toast.success('Feature status updated');
    },
    onError: () => {
      toast.error('Failed to update feature');
    },
  });

  if (isLoading) {
    return <div className={`p-4 rounded-lg ${isDark ? 'bg-slate-800' : 'bg-white'}`}>Loading...</div>;
  }

  return (
    <div className="space-y-4">
      <h2 className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>
        Publish Features
      </h2>
      <p className={`text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
        Control which features are visible to regular users. Beta testers and admins see all features.
      </p>

      <div className="space-y-3">
        {AVAILABLE_FEATURES.map((feature) => {
          const featureData = featureMap[feature.id];
          const isPublished = featureData?.is_published ?? false;

          return (
            <Card
              key={feature.id}
              className={`p-4 flex items-center justify-between ${isDark ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'}`}
            >
              <div>
                <p className={`font-medium ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  {feature.label}
                </p>
                <p className={`text-sm ${isDark ? 'text-slate-500' : 'text-slate-600'}`}>
                  {isPublished ? 'Visible to all users' : 'Only visible to beta testers & admins'}
                </p>
              </div>
              <Switch
                checked={isPublished}
                onCheckedChange={() => toggleMutation.mutate(feature.id)}
                disabled={toggleMutation.isPending}
              />
            </Card>
          );
        })}
      </div>
    </div>
  );
}