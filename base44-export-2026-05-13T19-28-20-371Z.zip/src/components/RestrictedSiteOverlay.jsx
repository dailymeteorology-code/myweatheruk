import { useState, useEffect } from "react";
import { X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

function MiniCountdown({ target }) {
  const [timeLeft, setTimeLeft] = useState(null);

  useEffect(() => {
    const calc = () => {
      const diff = new Date(target) - new Date();
      if (diff <= 0) return setTimeLeft(null);
      setTimeLeft({
        h: Math.floor(diff / 3600000),
        m: Math.floor((diff % 3600000) / 60000),
        s: Math.floor((diff % 60000) / 1000),
      });
    };
    calc();
    const id = setInterval(calc, 1000);
    return () => clearInterval(id);
  }, [target]);

  if (!timeLeft) return null;

  return (
    <div className="flex gap-1.5 mt-2">
      {[['H', timeLeft.h], ['M', timeLeft.m], ['S', timeLeft.s]].map(([label, val]) => (
        <div key={label} className="flex flex-col items-center bg-white/10 rounded-lg px-2 py-1 min-w-[36px]">
          <span className="text-sm font-bold tabular-nums">{String(val).padStart(2, '0')}</span>
          <span className="text-[9px] text-white/40 uppercase">{label}</span>
        </div>
      ))}
    </div>
  );
}

export default function RestrictedSiteOverlay({ settings }) {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed || !settings) return null;

  const countdownEnabled = settings.countdown_enabled && settings.countdown_target;
  const message = settings.disabled_message || "Site temporarily unavailable";

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.9 }}
        transition={{ duration: 0.3 }}
        className="fixed bottom-4 right-4 z-50 max-w-[280px] bg-slate-900/95 border border-slate-700/60 rounded-2xl p-4 shadow-2xl backdrop-blur-md text-white"
      >
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-1.5">
            <span className="text-lg">🌧️</span>
            <span className="font-semibold text-sm">
              {countdownEnabled && settings.countdown_title ? settings.countdown_title : "Restricted Access"}
            </span>
          </div>
          <button
            onClick={() => setDismissed(true)}
            className="p-1 rounded-lg hover:bg-white/10 transition-colors text-white/50 hover:text-white flex-shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <p className="text-xs text-white/60 leading-relaxed">{message}</p>
        {countdownEnabled && <MiniCountdown target={settings.countdown_target} />}
      </motion.div>
    </AnimatePresence>
  );
}