import React from 'react';
import { motion } from 'framer-motion';

// Met Office weather symbols used in 5-day forecast
const weatherSymbols = [
  { code: 0,  label: 'Clear Night',           emoji: '🌙' },
  { code: 1,  label: 'Sunny Day',             emoji: '☀️' },
  { code: 2,  label: 'Partly Cloudy (Night)', emoji: '🌙' },
  { code: 3,  label: 'Partly Cloudy (Day)',   emoji: '⛅' },
  { code: 5,  label: 'Mist',                  emoji: '🌫️' },
  { code: 6,  label: 'Fog',                   emoji: '🌁' },
  { code: 7,  label: 'Cloudy',                emoji: '☁️' },
  { code: 8,  label: 'Overcast',              emoji: '☁️' },
  { code: 9,  label: 'Light Rain (Night)',    emoji: '🌧️' },
  { code: 10, label: 'Light Rain (Day)',      emoji: '🌦️' },
  { code: 11, label: 'Drizzle',               emoji: '🌧️' },
  { code: 12, label: 'Light Rain',            emoji: '🌧️' },
  { code: 13, label: 'Heavy Rain (Night)',    emoji: '🌧️' },
  { code: 14, label: 'Heavy Rain (Day)',      emoji: '🌧️' },
  { code: 15, label: 'Heavy Rain',            emoji: '🌧️' },
  { code: 16, label: 'Sleet (Night)',         emoji: '🌨️' },
  { code: 17, label: 'Sleet (Day)',           emoji: '🌨️' },
  { code: 18, label: 'Sleet',                 emoji: '🌨️' },
  { code: 19, label: 'Hail (Night)',          emoji: '🌨️' },
  { code: 20, label: 'Hail (Day)',            emoji: '🌨️' },
  { code: 21, label: 'Hail',                  emoji: '🌨️' },
  { code: 22, label: 'Light Snow (Night)',    emoji: '❄️' },
  { code: 23, label: 'Light Snow (Day)',      emoji: '🌨️' },
  { code: 24, label: 'Light Snow',            emoji: '❄️' },
  { code: 25, label: 'Heavy Snow (Night)',    emoji: '❄️' },
  { code: 26, label: 'Heavy Snow (Day)',      emoji: '❄️' },
  { code: 27, label: 'Heavy Snow',            emoji: '❄️' },
  { code: 28, label: 'Thunder (Night)',       emoji: '⛈️' },
  { code: 29, label: 'Thunder (Day)',         emoji: '⛈️' },
  { code: 30, label: 'Thunder',              emoji: '⛈️' },
];

// Group by category for better readability
const categories = [
  {
    name: 'Clear & Sunny',
    color: 'from-yellow-500/20 to-amber-500/10',
    border: 'border-yellow-500/30',
    dot: 'bg-yellow-400',
    symbols: weatherSymbols.filter(s => [0, 1, 2, 3].includes(s.code)),
  },
  {
    name: 'Cloudy & Misty',
    color: 'from-slate-500/20 to-slate-600/10',
    border: 'border-slate-500/30',
    dot: 'bg-slate-400',
    symbols: weatherSymbols.filter(s => [5, 6, 7, 8].includes(s.code)),
  },
  {
    name: 'Rain & Drizzle',
    color: 'from-blue-500/20 to-sky-500/10',
    border: 'border-blue-500/30',
    dot: 'bg-blue-400',
    symbols: weatherSymbols.filter(s => s.code >= 9 && s.code <= 15),
  },
  {
    name: 'Sleet & Hail',
    color: 'from-cyan-500/20 to-teal-500/10',
    border: 'border-cyan-500/30',
    dot: 'bg-cyan-400',
    symbols: weatherSymbols.filter(s => s.code >= 16 && s.code <= 21),
  },
  {
    name: 'Snow',
    color: 'from-indigo-500/20 to-purple-500/10',
    border: 'border-indigo-500/30',
    dot: 'bg-indigo-400',
    symbols: weatherSymbols.filter(s => s.code >= 22 && s.code <= 27),
  },
  {
    name: 'Thunder',
    color: 'from-purple-500/20 to-violet-500/10',
    border: 'border-purple-500/30',
    dot: 'bg-purple-400',
    symbols: weatherSymbols.filter(s => s.code >= 28),
  },
];

export default function WeatherSymbolsGuide() {
  return (
    <section className="max-w-6xl mx-auto px-4 py-12">
      <motion.div
        className="flex items-center gap-3 mb-8"
        initial={{ opacity: 0, x: -20 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
      >
        <div className="p-3 rounded-xl bg-sky-500/20 backdrop-blur-sm">
          <span className="text-2xl">☀️</span>
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white">Weather Symbols Guide</h2>
          <p className="text-slate-400 text-sm mt-0.5">Met Office symbols used in the 5-day forecast</p>
        </div>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {categories.map((cat, catIdx) => (
          <motion.div
            key={cat.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: catIdx * 0.07, duration: 0.5 }}
            className={`rounded-2xl border ${cat.border} bg-gradient-to-br ${cat.color} backdrop-blur-sm p-5`}
          >
            <div className="flex items-center gap-2 mb-4">
              <div className={`w-2.5 h-2.5 rounded-full ${cat.dot}`} />
              <h3 className="text-sm font-semibold text-white uppercase tracking-wide">{cat.name}</h3>
            </div>
            <div className="space-y-2">
              {cat.symbols.map((symbol, idx) => (
                <motion.div
                  key={symbol.code}
                  initial={{ opacity: 0, x: -8 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: catIdx * 0.07 + idx * 0.04 }}
                  className="flex items-center gap-3 py-1.5 px-2 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <span className="text-2xl w-8 text-center leading-none">{symbol.emoji}</span>
                  <span className="text-sm text-slate-300">{symbol.label}</span>
                  <span className="ml-auto text-xs text-slate-500 font-mono">#{symbol.code}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.5 }}
        className="text-center text-xs text-slate-500 mt-6"
      >
        Symbol codes follow the Met Office DataPoint WX classification system
      </motion.p>
    </section>
  );
}