const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Loader2, Lock } from 'lucide-react';
import { toast } from 'sonner';

const DEFAULT_SECTIONS = [
  { id: 'activeWarnings', label: 'Active Warnings' },
  { id: 'upcomingWarnings', label: 'Upcoming Warnings' },
  { id: 'forecasts', label: 'Forecasts' },
  { id: 'graphics', label: 'Latest Graphics' },
  { id: 'liveRadar', label: 'Live Radar' },
  { id: 'tcm', label: 'TCM (Thunderstorm Model)' },
];

export default function MenuItemsAdmin() {
  const queryClient = useQueryClient();

  const { data: items = [], isLoading } = useQuery({
    queryKey: ['menuItemConfigs'],
    queryFn: async () => {
      const data = await db.entities.MenuItemConfig.list();
      // Seed missing sections
      for (const section of DEFAULT_SECTIONS) {
        if (!data.find(d => d.section_id === section.id)) {
          await db.entities.MenuItemConfig.create({ section_id: section.id, label: section.label, is_coming_soon: false });
        }
      }
      return db.entities.MenuItemConfig.list();
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async (item) => db.entities.MenuItemConfig.update(item.id, { is_coming_soon: !item.is_coming_soon }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['menuItemConfigs'] }); toast.success('Updated'); },
    onError: () => toast.error('Failed to update'),
  });

  if (isLoading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-sky-500" /></div>;

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold text-slate-900">Menu Item Lock</h3>
        <p className="text-sm text-slate-500 mt-1">Mark sections as "Coming Soon" — they'll appear in the menu but be locked/unclickable for users.</p>
      </div>
      <div className="space-y-2">
        {DEFAULT_SECTIONS.map(section => {
          const item = items.find(i => i.section_id === section.id);
          const isComingSoon = item?.is_coming_soon ?? false;
          return (
            <Card key={section.id} className={`p-4 flex items-center justify-between ${isComingSoon ? 'border-orange-300 bg-orange-50' : ''}`}>
              <div className="flex items-center gap-3">
                {isComingSoon && <Lock className="w-4 h-4 text-orange-500" />}
                <div>
                  <p className="font-medium text-slate-800 text-sm">{section.label}</p>
                  <p className="text-xs text-slate-500">{isComingSoon ? 'Shown as "Coming Soon" to users' : 'Clickable and active'}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {isComingSoon && <span className="text-xs bg-orange-100 text-orange-700 border border-orange-300 px-2 py-0.5 rounded-full font-medium">Coming Soon</span>}
                <Switch checked={isComingSoon} onCheckedChange={() => item && toggleMutation.mutate(item)} disabled={toggleMutation.isPending || !item} />
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}