const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Save, Loader2, Power, Timer, Link } from 'lucide-react';
import { toast } from "sonner";

export default function SiteControlTab() {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    site_disabled: false,
    disabled_message: '',
    countdown_enabled: false,
    countdown_target: '',
    countdown_title: '',
    countdown_description: '',
    countdown_display: 'disabled_page',
    met_office_api_key: '',
    location_search_enabled: true,
  });

  const { data: settings, isLoading } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await db.entities.SiteSettings.list();
      return list[0] || null;
    },
  });

  useEffect(() => {
    if (settings) {
      setFormData({
        site_disabled: settings.site_disabled || false,
        disabled_message: settings.disabled_message || '',
        countdown_enabled: settings.countdown_enabled || false,
        countdown_target: settings.countdown_target
          ? new Date(settings.countdown_target).toISOString().slice(0, 16)
          : '',
        countdown_title: settings.countdown_title || '',
        countdown_description: settings.countdown_description || '',
        countdown_display: settings.countdown_display || 'disabled_page',
        met_office_api_key: settings.met_office_api_key || '',
        location_search_enabled: settings.location_search_enabled !== false,
      });
    }
  }, [settings]);

  const save = async (data) => {
    const payload = {
      ...data,
      countdown_target: data.countdown_target ? new Date(data.countdown_target).toISOString() : '',
    };
    if (settings) {
      await db.entities.SiteSettings.update(settings.id, payload);
    } else {
      await db.entities.SiteSettings.create({ site_name: 'My Site', ...payload });
    }
    queryClient.invalidateQueries({ queryKey: ['settings'] });
  };

  const saveMutation = useMutation({
    mutationFn: save,
    onSuccess: () => toast.success('Saved!'),
    onError: () => toast.error('Failed to save'),
  });

  // Auto-save when a toggle is flipped
  const handleToggle = (field, value) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);
    saveMutation.mutate(updated);
  };

  if (isLoading) {
    return <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-slate-400" /></div>;
  }

  return (
    <div className="space-y-6">
      {/* Disable Site */}
      <Card className={formData.site_disabled ? 'border-red-300 bg-red-50' : ''}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Power className={`w-5 h-5 ${formData.site_disabled ? 'text-red-600' : 'text-slate-500'}`} />
            Disable Website
          </CardTitle>
          <CardDescription>
            When enabled, visitors will see a maintenance page. Admins are not affected.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Switch
              checked={formData.site_disabled}
              onCheckedChange={(v) => handleToggle('site_disabled', v)}
            />
            <Label className={formData.site_disabled ? 'text-red-700 font-semibold' : ''}>
              {formData.site_disabled ? 'Site is DISABLED — visitors see maintenance page' : 'Site is enabled'}
            </Label>
          </div>
          <div className="space-y-2">
            <Label>Message shown to visitors</Label>
            <Textarea
              value={formData.disabled_message}
              onChange={(e) => setFormData(prev => ({ ...prev, disabled_message: e.target.value }))}
              placeholder="This website is temporarily unavailable."
              rows={2}
            />
          </div>
          <Button
            onClick={() => saveMutation.mutate(formData)}
            className="w-full h-10"
            disabled={saveMutation.isPending}
          >
            {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
            Save Message
          </Button>
        </CardContent>
      </Card>

      {/* Countdown */}
      <Card className={formData.countdown_enabled ? 'border-sky-300' : ''}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Timer className={`w-5 h-5 ${formData.countdown_enabled ? 'text-sky-600' : 'text-slate-500'}`} />
            Countdown Timer
          </CardTitle>
          <CardDescription>
            Show a countdown page to visitors with a custom title and message.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Switch
              checked={formData.countdown_enabled}
              onCheckedChange={(v) => handleToggle('countdown_enabled', v)}
            />
            <Label className={formData.countdown_enabled ? 'text-sky-700 font-semibold' : ''}>
              {formData.countdown_enabled ? 'Countdown is active' : 'Countdown is off'}
            </Label>
          </div>

          {formData.countdown_enabled && (
            <div className="space-y-4 pt-2 border-t border-slate-200">
            <div className="space-y-2">
              <Label>Countdown Display Location</Label>
              <div className="flex gap-3">
                {[{ value: 'disabled_page', label: 'Site Disabled Page' }, { value: 'homepage', label: 'Homepage' }].map(opt => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, countdown_display: opt.value }))}
                    className={`flex-1 py-2 px-3 rounded-lg border-2 text-sm font-medium transition-all ${
                      formData.countdown_display === opt.value
                        ? 'border-sky-500 bg-sky-50 text-sky-700'
                        : 'border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <Label>Countdown Target Date & Time</Label>
                <Input
                  type="datetime-local"
                  value={formData.countdown_target}
                  onChange={(e) => setFormData(prev => ({ ...prev, countdown_target: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Title</Label>
                <Input
                  value={formData.countdown_title}
                  onChange={(e) => setFormData(prev => ({ ...prev, countdown_title: e.target.value }))}
                  placeholder="e.g., Something big is coming..."
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  value={formData.countdown_description}
                  onChange={(e) => setFormData(prev => ({ ...prev, countdown_description: e.target.value }))}
                  placeholder="e.g., We're working on something exciting. Check back soon!"
                  rows={3}
                />
              </div>
              <Button
                onClick={() => saveMutation.mutate(formData)}
                className="w-full h-10 bg-sky-600 hover:bg-sky-700"
                disabled={saveMutation.isPending}
              >
                {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                Save Countdown Details
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      {/* Location Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link className="w-5 h-5 text-slate-500" />
            Location Search
          </CardTitle>
          <CardDescription>
            Show or hide the floating location weather search bar on the site.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3">
            <Switch
              checked={formData.location_search_enabled}
              onCheckedChange={(v) => handleToggle('location_search_enabled', v)}
            />
            <Label className={formData.location_search_enabled ? 'text-green-700 font-semibold' : ''}>
              {formData.location_search_enabled ? 'Search bar is visible' : 'Search bar is hidden'}
            </Label>
          </div>
        </CardContent>
      </Card>

      {/* Met Office API Key */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link className="w-5 h-5 text-slate-500" />
            Met Office API Key
          </CardTitle>
          <CardDescription>
            Your Met Office DataHub API key, used to fetch location weather forecasts.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>API Key</Label>
            <Input
              type="password"
              value={formData.met_office_api_key}
              onChange={(e) => setFormData(prev => ({ ...prev, met_office_api_key: e.target.value }))}
              placeholder="Paste your Met Office API key here..."
            />
          </div>
          <Button
            onClick={() => saveMutation.mutate(formData)}
            className="w-full h-10"
            disabled={saveMutation.isPending}
          >
            {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
            Save API Key
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}