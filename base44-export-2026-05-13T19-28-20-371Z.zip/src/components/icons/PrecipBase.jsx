import React from 'react';

// Standard precipitation cloud path — spans x:6-45, y:8-30
const CLOUD = "M12,30 C8,30 6,27 6,24 C6,20 9,17 13,16 C14,11 18,8 24,8 C30,8 34,11 36,16 C39,15 43,18 43,22 C45,23 45,28 42,30 Z";

/**
 * Base component for all precipitation icons.
 * Renders sun (day) or crescent moon (night) peeking from top-left,
 * overlaid by a cloud, with {children} as precipitation below.
 * When cloudOnly=true, no celestial body is rendered (plain cloud).
 */
export function PrecipBase({ night = false, dark = false, cloudOnly = false, size = 40, children }) {
  const cgId = dark ? 'scg' : 'pcg';
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        {night ? (
          <>
            <linearGradient id="pmg" x1="20%" y1="0%" x2="80%" y2="100%">
              <stop offset="0%" stopColor="#D8E8F4" />
              <stop offset="100%" stopColor="#8AAAC4" />
            </linearGradient>
            <mask id="pmm">
              <rect width="48" height="48" fill="white" />
              {/* Cutout circle creates crescent opening to the right */}
              <circle cx="21" cy="11" r="9" fill="black" />
            </mask>
          </>
        ) : (
          <radialGradient id="psg" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#FEF08A" />
            <stop offset="100%" stopColor="#F59E0B" />
          </radialGradient>
        )}
        <linearGradient id={cgId} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={dark ? "#B0BEC8" : "#F1F5F9"} />
          <stop offset="100%" stopColor={dark ? "#52626E" : "#CBD5E1"} />
        </linearGradient>
      </defs>

      {/* Celestial body behind cloud */}
      {!cloudOnly && (night ? (
        <circle cx="14" cy="16" r="11" fill="url(#pmg)" mask="url(#pmm)" />
      ) : (
        <>
          <circle cx="14" cy="16" r="11" fill="url(#psg)" />
          <line x1="14" y1="4"  x2="14" y2="1"  stroke="#FCD34D" strokeWidth="2" strokeLinecap="round" />
          <line x1="7"  y1="9"  x2="4"  y2="7"  stroke="#FCD34D" strokeWidth="2" strokeLinecap="round" />
          <line x1="3"  y1="16" x2="0"  y2="16" stroke="#FCD34D" strokeWidth="2" strokeLinecap="round" />
        </>
      ))}

      {/* Cloud — drawn on top, naturally hides ~55% of the celestial body */}
      <path d={CLOUD} fill={`url(#${cgId})`} />

      {/* Precipitation */}
      {children}
    </svg>
  );
}