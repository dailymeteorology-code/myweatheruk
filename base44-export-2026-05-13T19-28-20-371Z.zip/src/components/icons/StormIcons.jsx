import React from 'react';

/** Single cloud + one bolt + light rain — Isolated Thunderstorms */
export function IsolatedThunderstormsIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id="its_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#94A3B8" /><stop offset="100%" stopColor="#475569" />
        </linearGradient>
      </defs>
      {/* Storm cloud */}
      <path d="M8,28 C4,28 2,25 2,22 C2,18 5,15 9,14 C10,9 14,6 20,6 C26,6 30,9 32,14 C35,13 39,16 39,20 C39,25 35,28 31,28 Z" fill="url(#its_cg)" />
      {/* Light rain */}
      <line x1="10" y1="30" x2="11" y2="40" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="22" y1="30" x2="23" y2="40" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
      {/* Single bolt */}
      <path d="M26,29 L21,38 H27 L22,47 L33,36 H27 Z" fill="#FBBF24" />
    </svg>
  );
}

/** Two cloud forms + lightning + moderate rain — Scattered Thunderstorms */
export function ScatteredThunderstormsIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id="sts_bg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#94A3B8" /><stop offset="100%" stopColor="#5A6E82" />
        </linearGradient>
        <linearGradient id="sts_fg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#7A8E9E" /><stop offset="100%" stopColor="#3A4E5E" />
        </linearGradient>
      </defs>
      {/* Back cloud */}
      <path d="M14,22 C11,22 9,19 9,16 C9,12 12,9 16,8 C17,4 20,2 25,2 C30,2 33,5 34,8 C36,7 40,9 40,13 C40,17 37,22 32,22 Z" fill="url(#sts_bg)" />
      {/* Front cloud */}
      <path d="M4,34 C0,34 -1,31 0,28 C0,24 3,21 8,20 C8,15 13,12 19,12 C25,12 29,15 31,20 C34,19 38,22 38,26 C38,31 34,34 30,34 Z" fill="url(#sts_fg)" />
      {/* Rain */}
      <line x1="8"  y1="35" x2="9"  y2="44" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="17" y1="35" x2="18" y2="44" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
      {/* Bolt */}
      <path d="M26,33 L21,42 H27 L22,48 L33,40 H27 Z" fill="#FBBF24" />
    </svg>
  );
}

/** Large dominant cloud + two bolts + heavy rain — Thunderstorms */
export function ThunderstormsIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id="th_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#64748B" /><stop offset="100%" stopColor="#1E2A38" />
        </linearGradient>
      </defs>
      {/* Large dark cloud */}
      <path d="M4,28 C0,28 -1,24 1,21 C2,17 6,14 11,13 C11,7 16,4 23,4 C30,4 35,7 37,13 C40,12 45,15 45,20 C45,25 41,28 36,28 Z" fill="url(#th_cg)" />
      {/* Heavy rain */}
      <line x1="6"  y1="30" x2="9"  y2="43" stroke="#3B82F6" strokeWidth="3" strokeLinecap="round" />
      <line x1="14" y1="30" x2="17" y2="43" stroke="#3B82F6" strokeWidth="3" strokeLinecap="round" />
      <line x1="37" y1="30" x2="40" y2="43" stroke="#3B82F6" strokeWidth="3" strokeLinecap="round" />
      {/* Left bolt */}
      <path d="M21,29 L17,37 H22 L18,46 L28,36 H23 Z" fill="#FDE047" />
      {/* Right bolt */}
      <path d="M32,29 L29,37 H33 L30,45 L39,35 H35 Z" fill="#FDE047" opacity="0.85" />
    </svg>
  );
}