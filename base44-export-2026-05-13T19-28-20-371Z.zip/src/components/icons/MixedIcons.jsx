import React from 'react';
import { PrecipBase } from './PrecipBase';

/* ── Snowflake helper ──────────────────────────────────────────── */
function Sf({ cx, cy, r, c = "#7DD3FC", w = 1.8 }) {
  const a = r * 0.866, b = r * 0.5;
  return (
    <g stroke={c} strokeWidth={w} strokeLinecap="round">
      <line x1={cx}     y1={cy - r} x2={cx}     y2={cy + r} />
      <line x1={cx - a} y1={cy - b} x2={cx + a} y2={cy + b} />
      <line x1={cx + a} y1={cy - b} x2={cx - a} y2={cy + b} />
    </g>
  );
}

/* ── Hail pellet helper ─────────────────────────────────────────── */
function Hp({ cx, cy, r }) {
  return <circle cx={cx} cy={cy} r={r} fill="#E0F9FF" stroke="#38BDF8" strokeWidth="1.5" />;
}

/* ── Light Sleet: 2 rain + 1 snowflake ─────────────────────────── */
const lightSleet = (
  <>
    <line x1="14" y1="32" x2="15" y2="42" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="37" y1="32" x2="38" y2="42" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
    <Sf cx={26} cy={39} r={4} />
  </>
);
export function LightSleetIcon({ size = 40 }) { return <PrecipBase size={size}>{lightSleet}</PrecipBase>; }
export function LightSleetNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{lightSleet}</PrecipBase>; }
export function LightSleetCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{lightSleet}</PrecipBase>; }

/* ── Sleet (Moderate): 3 rain + 2 snowflakes ───────────────────── */
const sleet = (
  <>
    <line x1="11" y1="32" x2="12" y2="42" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="26" y1="32" x2="27" y2="42" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="41" y1="32" x2="42" y2="42" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <Sf cx={18} cy={39} r={3.5} />
    <Sf cx={34} cy={39} r={3.5} />
  </>
);
export function SleetIcon({ size = 40 }) { return <PrecipBase size={size}>{sleet}</PrecipBase>; }
export function SleetNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{sleet}</PrecipBase>; }
export function SleetCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{sleet}</PrecipBase>; }

/* ── Heavy Sleet: 4 rain + 3 snowflakes ────────────────────────── */
const heavySleet = (
  <>
    <line x1="9"  y1="32" x2="11" y2="43" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="21" y1="32" x2="23" y2="43" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="33" y1="32" x2="35" y2="43" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="44" y1="32" x2="45" y2="43" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
    <Sf cx={15} cy={41} r={3.5} />
    <Sf cx={27} cy={39} r={4}   />
    <Sf cx={39} cy={41} r={3.5} />
  </>
);
export function HeavySleetIcon({ size = 40 }) { return <PrecipBase size={size}>{heavySleet}</PrecipBase>; }
export function HeavySleetNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{heavySleet}</PrecipBase>; }
export function HeavySleetCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{heavySleet}</PrecipBase>; }

/* ── Light Hail: 3 small pellets ───────────────────────────────── */
const lightHail = (
  <>
    <Hp cx={15} cy={37} r={3} />
    <Hp cx={27} cy={40} r={3} />
    <Hp cx={38} cy={37} r={3} />
  </>
);
export function LightHailIcon({ size = 40 }) { return <PrecipBase size={size}>{lightHail}</PrecipBase>; }
export function LightHailNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{lightHail}</PrecipBase>; }
export function LightHailCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{lightHail}</PrecipBase>; }

/* ── Hail (Moderate): 5 pellets ────────────────────────────────── */
const hail = (
  <>
    <Hp cx={12} cy={36} r={3.5} />
    <Hp cx={22} cy={40} r={3.5} />
    <Hp cx={32} cy={36} r={3.5} />
    <Hp cx={42} cy={40} r={3.5} />
    <Hp cx={27} cy={44} r={3.5} />
  </>
);
export function HailIcon({ size = 40 }) { return <PrecipBase size={size}>{hail}</PrecipBase>; }
export function HailNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{hail}</PrecipBase>; }
export function HailCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{hail}</PrecipBase>; }

/* ── Heavy Hail: 7 larger pellets ──────────────────────────────── */
const heavyHail = (
  <>
    <Hp cx={10} cy={35} r={4} />
    <Hp cx={19} cy={38} r={4} />
    <Hp cx={28} cy={35} r={4} />
    <Hp cx={37} cy={38} r={4} />
    <Hp cx={44} cy={35} r={3.5} />
    <Hp cx={14} cy={44} r={3.5} />
    <Hp cx={32} cy={44} r={3.5} />
  </>
);
export function HeavyHailIcon({ size = 40 }) { return <PrecipBase size={size}>{heavyHail}</PrecipBase>; }
export function HeavyHailNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{heavyHail}</PrecipBase>; }
export function HeavyHailCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{heavyHail}</PrecipBase>; }