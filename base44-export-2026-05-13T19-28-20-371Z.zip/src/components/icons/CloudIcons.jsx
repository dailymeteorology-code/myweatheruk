import React from 'react';

/** Two soft layered clouds */
export function CloudyIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id="cld_bg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#D8E6F4" /><stop offset="100%" stopColor="#9AB0C8" />
        </linearGradient>
        <linearGradient id="cld_fg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#F8FAFC" /><stop offset="100%" stopColor="#CBD5E1" />
        </linearGradient>
      </defs>
      {/* Back cloud */}
      <path d="M4,26 C2,26 0,23 0,20 C0,17 3,14 7,13 C7,9 11,6 16,6 C21,6 25,9 26,13 C28,12 32,14 32,18 C32,22 28,26 24,26 Z" fill="url(#cld_bg)" />
      {/* Front cloud */}
      <path d="M12,40 C8,40 6,37 6,34 C6,30 9,27 13,26 C14,21 18,18 24,18 C30,18 34,21 36,26 C39,25 43,28 43,32 C43,37 39,40 35,40 Z" fill="url(#cld_fg)" />
    </svg>
  );
}

/** Single large heavy cloud */
export function OvercastIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id="ov_g" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#C4D2E0" /><stop offset="100%" stopColor="#7A8E9E" />
        </linearGradient>
      </defs>
      <path d="M8,38 C4,38 2,35 2,32 C2,28 5,25 9,24 C10,18 14,14 20,14 C24,14 28,16 30,20 C33,18 38,19 40,22 C44,22 46,26 46,30 C46,35 42,38 37,38 Z" fill="url(#ov_g)" />
    </svg>
  );
}

/** Cloud + 3 semi-transparent horizontal mist lines */
export function FogIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id="fg_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#D8E8F4" /><stop offset="100%" stopColor="#9AAEC4" />
        </linearGradient>
      </defs>
      <path d="M8,22 C5,22 3,19 3,16 C3,13 6,10 10,9 C10,5 14,2 19,2 C24,2 28,5 29,9 C31,8 35,10 35,14 C35,18 31,22 27,22 Z" fill="url(#fg_cg)" />
      <line x1="3"  y1="28" x2="43" y2="28" stroke="#7E9CB6" strokeWidth="2.5" strokeLinecap="round" opacity="0.80" />
      <line x1="6"  y1="36" x2="44" y2="36" stroke="#7E9CB6" strokeWidth="2.5" strokeLinecap="round" opacity="0.55" />
      <line x1="2"  y1="44" x2="38" y2="44" stroke="#7E9CB6" strokeWidth="2.5" strokeLinecap="round" opacity="0.35" />
    </svg>
  );
}

/** Lighter fog — cloud + 2 subtle mist lines */
export function MistIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id="mt_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#EEF5FC" /><stop offset="100%" stopColor="#BDD0E4" />
        </linearGradient>
      </defs>
      <path d="M8,22 C5,22 3,19 3,16 C3,13 6,10 10,9 C10,5 14,2 19,2 C24,2 28,5 29,9 C31,8 35,10 35,14 C35,18 31,22 27,22 Z" fill="url(#mt_cg)" />
      <line x1="4"  y1="31" x2="42" y2="31" stroke="#A0B8CE" strokeWidth="2" strokeLinecap="round" opacity="0.50" />
      <line x1="8"  y1="40" x2="44" y2="40" stroke="#A0B8CE" strokeWidth="2" strokeLinecap="round" opacity="0.33" />
    </svg>
  );
}

/** Cloud + curved airflow streaks */
export function WindyIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <linearGradient id="wd_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#D8E8F4" /><stop offset="100%" stopColor="#9AAEC4" />
        </linearGradient>
      </defs>
      <path d="M8,22 C5,22 3,19 3,16 C3,13 6,10 10,9 C10,5 14,2 19,2 C24,2 28,5 29,9 C31,8 35,10 35,14 C35,18 31,22 27,22 Z" fill="url(#wd_cg)" />
      {/* Wind streaks */}
      <path d="M2,30 Q12,26 22,30 Q32,34 42,30" stroke="#7DD3FC" strokeWidth="2.5" strokeLinecap="round" fill="none" />
      <path d="M1,39 Q11,35 21,39 Q31,43 41,39" stroke="#7DD3FC" strokeWidth="2"   strokeLinecap="round" fill="none" />
      <path d="M5,46 Q15,42 25,46" stroke="#7DD3FC" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.65" />
    </svg>
  );
}