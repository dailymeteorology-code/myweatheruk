import React from 'react';
import { PrecipBase } from './PrecipBase';

/* ── Snowflake helper ──────────────────────────────────────────
   Draws a 6-arm asterisk snowflake at (cx, cy) with arm length r */
function Sf({ cx, cy, r, c = "#7DD3FC", w = 1.8 }) {
  const a = r * 0.866, b = r * 0.5;
  return (
    <g stroke={c} strokeWidth={w} strokeLinecap="round">
      <line x1={cx}     y1={cy - r} x2={cx}     y2={cy + r} />
      <line x1={cx - a} y1={cy - b} x2={cx + a} y2={cy + b} />
      <line x1={cx + a} y1={cy - b} x2={cx - a} y2={cy + b} />
    </g>
  );
}

/* ── Flurry: tiny scattered dots ──────────────────────────────── */
const flurry = (
  <>
    <circle cx="15" cy="37" r="2.5" fill="#BAE6FD" />
    <circle cx="27" cy="41" r="2.5" fill="#BAE6FD" />
    <circle cx="38" cy="37" r="2.5" fill="#BAE6FD" />
  </>
);
export function FlurryIcon({ size = 40 }) { return <PrecipBase size={size}>{flurry}</PrecipBase>; }
export function FlurryNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{flurry}</PrecipBase>; }
export function FlurryCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{flurry}</PrecipBase>; }

/* ── Light Snow: 3 small flakes ────────────────────────────────── */
const lightSnow = (
  <>
    <Sf cx={15} cy={37} r={3.5} />
    <Sf cx={27} cy={35} r={3.5} />
    <Sf cx={39} cy={37} r={3.5} />
  </>
);
export function LightSnowIcon({ size = 40 }) { return <PrecipBase size={size}>{lightSnow}</PrecipBase>; }
export function LightSnowNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{lightSnow}</PrecipBase>; }
export function LightSnowCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{lightSnow}</PrecipBase>; }

/* ── Snow (Moderate): 5 medium flakes ─────────────────────────── */
const snow = (
  <>
    <Sf cx={12} cy={37} r={4}   />
    <Sf cx={23} cy={34} r={4.5} />
    <Sf cx={34} cy={37} r={4}   />
    <Sf cx={43} cy={34} r={3.5} />
    <Sf cx={17} cy={44} r={3.5} />
  </>
);
export function SnowIcon({ size = 40 }) { return <PrecipBase size={size}>{snow}</PrecipBase>; }
export function SnowNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{snow}</PrecipBase>; }
export function SnowCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{snow}</PrecipBase>; }

/* ── Heavy Snow: 6 large flakes ────────────────────────────────── */
const heavySnow = (
  <>
    <Sf cx={10} cy={35} r={5}   />
    <Sf cx={21} cy={33} r={5.5} />
    <Sf cx={32} cy={35} r={5}   />
    <Sf cx={42} cy={33} r={4.5} />
    <Sf cx={15} cy={44} r={4.5} />
    <Sf cx={30} cy={44} r={4.5} />
  </>
);
export function HeavySnowIcon({ size = 40 }) { return <PrecipBase size={size}>{heavySnow}</PrecipBase>; }
export function HeavySnowNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{heavySnow}</PrecipBase>; }
export function HeavySnowCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{heavySnow}</PrecipBase>; }

/* ── Blizzard: dense snow + diagonal wind streaks ──────────────── */
const blizzard = (
  <>
    <Sf cx={10} cy={34} r={4}   />
    <Sf cx={22} cy={32} r={4.5} />
    <Sf cx={34} cy={35} r={4}   />
    <Sf cx={43} cy={32} r={3.5} />
    <Sf cx={17} cy={43} r={4}   />
    {/* Wind streaks */}
    <path d="M4,39 Q12,36 20,39" stroke="#BAE6FD" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.75" />
    <path d="M8,45 Q16,42 24,45" stroke="#BAE6FD" strokeWidth="1.8" strokeLinecap="round" fill="none" opacity="0.55" />
  </>
);
export function BlizzardIcon({ size = 40 }) { return <PrecipBase size={size}>{blizzard}</PrecipBase>; }
export function BlizzardNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{blizzard}</PrecipBase>; }
export function BlizzardCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{blizzard}</PrecipBase>; }