import React from 'react';

/** Full bright sun, no clouds */
export function SunnyIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <radialGradient id="su_g" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FEF08A" /><stop offset="100%" stopColor="#F59E0B" />
        </radialGradient>
      </defs>
      {/* 8 rays */}
      <line x1="24" y1="13" x2="24" y2="7"  stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="35" y1="24" x2="41" y2="24" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="24" y1="35" x2="24" y2="41" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="13" y1="24" x2="7"  y2="24" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="32" y1="16" x2="36" y2="12" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="32" y1="32" x2="36" y2="36" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="16" y1="32" x2="12" y2="36" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="16" y1="16" x2="12" y2="12" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="24" cy="24" r="11" fill="url(#su_g)" />
    </svg>
  );
}

/** Crescent moon + subtle stars */
export function ClearNightIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <radialGradient id="cn_g" cx="28%" cy="22%" r="72%">
          <stop offset="0%" stopColor="#EAF2FA" /><stop offset="100%" stopColor="#6888A8" />
        </radialGradient>
      </defs>
      {/* Moon crescent — outer left arc + inner concave right */}
      <path
        d="M22,6 C10,6 4,14 4,24 C4,34 10,42 22,42 C17,38 14,32 14,24 C14,16 17,10 22,6 Z"
        fill="url(#cn_g)"
      />
      {/* Stars */}
      <circle cx="34" cy="10" r="2" fill="#C8D8E8" />
      <line x1="34" y1="6"  x2="34" y2="14" stroke="#C8D8E8" strokeWidth="1" strokeLinecap="round" opacity="0.55" />
      <line x1="30" y1="10" x2="38" y2="10" stroke="#C8D8E8" strokeWidth="1" strokeLinecap="round" opacity="0.55" />
      <circle cx="42" cy="26" r="1.5" fill="#C8D8E8" opacity="0.75" />
      <circle cx="38" cy="38" r="1.5" fill="#C8D8E8" opacity="0.55" />
    </svg>
  );
}

/** Sun ~70% visible, small cloud lower-right */
export function SunnyIntervalsIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <radialGradient id="si_sg" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FEF08A" /><stop offset="100%" stopColor="#F59E0B" />
        </radialGradient>
        <linearGradient id="si_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#F8FAFC" /><stop offset="100%" stopColor="#CBD5E1" />
        </linearGradient>
      </defs>
      {/* Sun — large, mostly visible */}
      <circle cx="18" cy="20" r="12" fill="url(#si_sg)" />
      <line x1="18" y1="7"  x2="18" y2="3"  stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="28" y1="10" x2="31" y2="7"  stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="31" y1="20" x2="35" y2="20" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="5"  y1="20" x2="1"  y2="20" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="8"  y1="10" x2="5"  y2="7"  stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="8"  y1="30" x2="5"  y2="33" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="18" y1="33" x2="18" y2="37" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      {/* Small cloud covering lower-right ~30% of sun */}
      <path d="M18,42 C14,42 12,39 12,36 C12,33 14,30 18,29 C19,25 22,22 26,22 C30,22 33,24 34,27 C36,26 40,28 40,32 C40,36 37,40 35,40 Z" fill="url(#si_cg)" />
    </svg>
  );
}

/** Moon ~70% visible, small cloud lower-right */
export function SunnyIntervalsNightIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <radialGradient id="sin_mg" cx="28%" cy="22%" r="72%">
          <stop offset="0%" stopColor="#EAF2FA" /><stop offset="100%" stopColor="#6888A8" />
        </radialGradient>
        <mask id="sin_mm">
          <rect width="48" height="48" fill="white" />
          <circle cx="27" cy="13" r="11" fill="black" />
        </mask>
        <linearGradient id="sin_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#F8FAFC" /><stop offset="100%" stopColor="#CBD5E1" />
        </linearGradient>
      </defs>
      {/* Moon crescent — mostly visible */}
      <circle cx="18" cy="20" r="12" fill="url(#sin_mg)" mask="url(#sin_mm)" />
      {/* Small cloud */}
      <path d="M18,42 C14,42 12,39 12,36 C12,33 14,30 18,29 C19,25 22,22 26,22 C30,22 33,24 34,27 C36,26 40,28 40,32 C40,36 37,40 35,40 Z" fill="url(#sin_cg)" />
    </svg>
  );
}

/** Sun between two layered clouds — V2 */
export function SunnyIntervalsV2Icon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <radialGradient id="si2_sg" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FEF08A" /><stop offset="100%" stopColor="#F59E0B" />
        </radialGradient>
        <linearGradient id="si2_bg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#D8E8F4" /><stop offset="100%" stopColor="#9CB4CC" />
        </linearGradient>
        <linearGradient id="si2_fg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#F8FAFC" /><stop offset="100%" stopColor="#CBD5E1" />
        </linearGradient>
      </defs>
      {/* Back cloud (slightly darker, upper-left) */}
      <path d="M0,24 C0,21 2,18 6,17 C6,13 9,10 14,10 C19,10 22,13 23,16 C25,15 28,17 28,20 C28,24 25,26 21,26 Z" fill="url(#si2_bg)" />
      {/* Sun */}
      <circle cx="26" cy="22" r="11" fill="url(#si2_sg)" />
      <line x1="26" y1="10" x2="26" y2="6"  stroke="#FCD34D" strokeWidth="2" strokeLinecap="round" />
      <line x1="36" y1="14" x2="38" y2="11" stroke="#FCD34D" strokeWidth="2" strokeLinecap="round" />
      <line x1="38" y1="22" x2="42" y2="22" stroke="#FCD34D" strokeWidth="2" strokeLinecap="round" />
      <line x1="36" y1="30" x2="38" y2="33" stroke="#FCD34D" strokeWidth="2" strokeLinecap="round" />
      <line x1="16" y1="14" x2="14" y2="11" stroke="#FCD34D" strokeWidth="2" strokeLinecap="round" />
      {/* Front cloud (main foreground) */}
      <path d="M12,42 C8,42 6,39 6,36 C6,32 9,29 13,28 C14,23 18,20 24,20 C30,20 34,23 36,28 C39,27 43,30 43,34 C43,39 39,42 35,42 Z" fill="url(#si2_fg)" />
    </svg>
  );
}

/** Large cloud ~50% obscures sun — Partly Cloudy Day */
export function PartlyCloudyIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <radialGradient id="pc_sg" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FEF08A" /><stop offset="100%" stopColor="#F59E0B" />
        </radialGradient>
        <linearGradient id="pc_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#F1F5F9" /><stop offset="100%" stopColor="#CBD5E1" />
        </linearGradient>
      </defs>
      {/* Sun upper-left */}
      <circle cx="13" cy="15" r="11" fill="url(#pc_sg)" />
      <line x1="13" y1="3"  x2="13" y2="0"  stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="6"  y1="8"  x2="3"  y2="5"  stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="2"  y1="15" x2="0"  y2="15" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="6"  y1="22" x2="3"  y2="25" stroke="#FCD34D" strokeWidth="2.5" strokeLinecap="round" />
      {/* Large cloud */}
      <path d="M12,36 C8,36 6,33 6,30 C6,26 9,23 13,22 C14,17 18,14 24,14 C30,14 34,17 36,22 C39,21 43,24 43,28 C43,33 39,36 35,36 Z" fill="url(#pc_cg)" />
    </svg>
  );
}

/** Large cloud ~50% obscures moon — Partly Cloudy Night */
export function PartlyCloudyNightIcon({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <defs>
        <radialGradient id="pcn_mg" cx="28%" cy="22%" r="72%">
          <stop offset="0%" stopColor="#D8EAF8" /><stop offset="100%" stopColor="#6080A0" />
        </radialGradient>
        <mask id="pcn_mm">
          <rect width="48" height="48" fill="white" />
          <circle cx="21" cy="9" r="9.5" fill="black" />
        </mask>
        <linearGradient id="pcn_cg" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#E4EEF8" /><stop offset="100%" stopColor="#AABCCE" />
        </linearGradient>
      </defs>
      {/* Moon crescent upper-left */}
      <circle cx="13" cy="15" r="11" fill="url(#pcn_mg)" mask="url(#pcn_mm)" />
      {/* Large cloud — cooler toned */}
      <path d="M12,36 C8,36 6,33 6,30 C6,26 9,23 13,22 C14,17 18,14 24,14 C30,14 34,17 36,22 C39,21 43,24 43,28 C43,33 39,36 35,36 Z" fill="url(#pcn_cg)" />
    </svg>
  );
}