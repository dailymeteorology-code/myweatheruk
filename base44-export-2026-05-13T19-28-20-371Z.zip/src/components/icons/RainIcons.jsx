import React from 'react';
import { PrecipBase } from './PrecipBase';

/* ── Drizzle: 3 very small sparse dots ─────────────────────── */
const drizzle = (
  <>
    <circle cx="15" cy="36" r="2.5" fill="#7DD3FC" />
    <circle cx="27" cy="40" r="2.5" fill="#7DD3FC" />
    <circle cx="38" cy="36" r="2.5" fill="#7DD3FC" />
  </>
);
export function DrizzleIcon({ size = 40 }) { return <PrecipBase size={size}>{drizzle}</PrecipBase>; }
export function DrizzleNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{drizzle}</PrecipBase>; }
export function DrizzleCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{drizzle}</PrecipBase>; }

/* ── Light Rain: 4 short drops ─────────────────────────────── */
const lightRain = (
  <>
    <line x1="13" y1="32" x2="14" y2="41" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="21" y1="32" x2="22" y2="41" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="29" y1="32" x2="30" y2="41" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="37" y1="32" x2="38" y2="41" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
  </>
);
export function LightRainIcon({ size = 40 }) { return <PrecipBase size={size}>{lightRain}</PrecipBase>; }
export function LightRainNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{lightRain}</PrecipBase>; }
export function LightRainCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{lightRain}</PrecipBase>; }

/* ── Moderate Rain: 5 medium drops, slight angle ────────────── */
const moderateRain = (
  <>
    <line x1="10" y1="32" x2="12" y2="43" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="18" y1="32" x2="20" y2="43" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="26" y1="32" x2="28" y2="43" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="34" y1="32" x2="36" y2="43" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="42" y1="32" x2="44" y2="43" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
  </>
);
export function ModerateRainIcon({ size = 40 }) { return <PrecipBase size={size}>{moderateRain}</PrecipBase>; }
export function ModerateRainNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{moderateRain}</PrecipBase>; }
export function ModerateRainCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{moderateRain}</PrecipBase>; }

/* ── Heavy Rain: 6 long drops, more angle ───────────────────── */
const heavyRain = (
  <>
    <line x1="9"  y1="32" x2="12" y2="45" stroke="#2563EB" strokeWidth="3" strokeLinecap="round" />
    <line x1="16" y1="32" x2="19" y2="45" stroke="#2563EB" strokeWidth="3" strokeLinecap="round" />
    <line x1="23" y1="32" x2="26" y2="45" stroke="#2563EB" strokeWidth="3" strokeLinecap="round" />
    <line x1="30" y1="32" x2="33" y2="45" stroke="#2563EB" strokeWidth="3" strokeLinecap="round" />
    <line x1="37" y1="32" x2="40" y2="45" stroke="#2563EB" strokeWidth="3" strokeLinecap="round" />
    <line x1="44" y1="32" x2="46" y2="45" stroke="#2563EB" strokeWidth="3" strokeLinecap="round" />
  </>
);
export function HeavyRainIcon({ size = 40 }) { return <PrecipBase size={size}>{heavyRain}</PrecipBase>; }
export function HeavyRainNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{heavyRain}</PrecipBase>; }
export function HeavyRainCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{heavyRain}</PrecipBase>; }

/* ── Torrential Rain: dense double-row drops ────────────────── */
const torrentialRain = (
  <>
    <line x1="8"  y1="32" x2="12" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="14" y1="32" x2="18" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="20" y1="32" x2="24" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="26" y1="32" x2="30" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="32" y1="32" x2="36" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="38" y1="32" x2="42" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="11" y1="37" x2="15" y2="46" stroke="#1D4ED8" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="23" y1="37" x2="27" y2="46" stroke="#1D4ED8" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="35" y1="37" x2="39" y2="46" stroke="#1D4ED8" strokeWidth="2.5" strokeLinecap="round" />
  </>
);
export function TorrentialRainIcon({ size = 40 }) { return <PrecipBase size={size}>{torrentialRain}</PrecipBase>; }
export function TorrentialRainNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{torrentialRain}</PrecipBase>; }
export function TorrentialRainCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{torrentialRain}</PrecipBase>; }

/* ── Rain Shower: 4 localized drops ─────────────────────────── */
const rainShower = (
  <>
    <line x1="14" y1="32" x2="15" y2="41" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="22" y1="32" x2="23" y2="41" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="30" y1="32" x2="31" y2="41" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="38" y1="32" x2="39" y2="41" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
  </>
);
export function RainShowerIcon({ size = 40 }) { return <PrecipBase size={size}>{rainShower}</PrecipBase>; }
export function RainShowerNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{rainShower}</PrecipBase>; }
export function RainShowerCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{rainShower}</PrecipBase>; }

/* ── Moderate Shower: 5 drops ────────────────────────────────── */
const moderateShower = (
  <>
    <line x1="10" y1="32" x2="12" y2="42" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="18" y1="32" x2="20" y2="42" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="26" y1="32" x2="28" y2="42" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="34" y1="32" x2="36" y2="42" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="42" y1="32" x2="44" y2="42" stroke="#2563EB" strokeWidth="2.5" strokeLinecap="round" />
  </>
);
export function ModerateShowerIcon({ size = 40 }) { return <PrecipBase size={size}>{moderateShower}</PrecipBase>; }
export function ModerateShowerNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{moderateShower}</PrecipBase>; }
export function ModerateShowerCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{moderateShower}</PrecipBase>; }

/* ── Heavy Showers: 6 dense drops ────────────────────────────── */
const heavyShowers = (
  <>
    <line x1="8"  y1="32" x2="11" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="15" y1="32" x2="18" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="22" y1="32" x2="25" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="29" y1="32" x2="32" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="36" y1="32" x2="39" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
    <line x1="43" y1="32" x2="45" y2="44" stroke="#1D4ED8" strokeWidth="3" strokeLinecap="round" />
  </>
);
export function HeavyShowersIcon({ size = 40 }) { return <PrecipBase size={size}>{heavyShowers}</PrecipBase>; }
export function HeavyShowersNightIcon({ size = 40 }) { return <PrecipBase night size={size}>{heavyShowers}</PrecipBase>; }
export function HeavyShowersCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly size={size}>{heavyShowers}</PrecipBase>; }

/* ── Thundery Shower: rain + lightning bolt (dark cloud) ─────── */
const thunderyShower = (
  <>
    <line x1="13" y1="32" x2="14" y2="41" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="37" y1="32" x2="38" y2="41" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" />
    {/* Lightning bolt */}
    <path d="M25,31 L20,40 H26 L21,47 L31,37 H25 Z" fill="#FBBF24" />
  </>
);
export function ThunderyShowerIcon({ size = 40 }) { return <PrecipBase dark size={size}>{thunderyShower}</PrecipBase>; }
export function ThunderyShowerNightIcon({ size = 40 }) { return <PrecipBase night dark size={size}>{thunderyShower}</PrecipBase>; }
export function ThunderyShowerCloudIcon({ size = 40 }) { return <PrecipBase cloudOnly dark size={size}>{thunderyShower}</PrecipBase>; }