import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CloudRain, Clock, AlertTriangle } from 'lucide-react';
import { format, isValid, formatDistanceToNow } from 'date-fns';
import WarningCard from './WarningCard';
 
const formatDateTime = (dateStr) => {
  if (!dateStr) return 'N/A';
  const date = new Date(dateStr);
  if (!isValid(date)) return dateStr;
  return format(date, 'dd MMM yyyy, HH:mm');
};
 
const timeAgo = (dateStr) => {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  if (!isValid(date)) return '';
  return formatDistanceToNow(date, { addSuffix: true });
};
 
export default function PastWarningsModal({ isOpen, onClose, warnings }) {
  const getPastWarnings = () => {
    const now = new Date();
    const fiveDaysAgo = new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000);
 
    return warnings.filter((w) => {
      const validTo = w.validTo ? new Date(w.validTo) : null;
      return validTo && validTo < now && validTo >= fiveDaysAgo;
    }).sort((a, b) => new Date(b.validTo) - new Date(a.validTo));
  };
 
  const pastWarnings = getPastWarnings();
 
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.88, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.88, y: 30 }}
            transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-2xl rounded-3xl overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, rgba(30,41,59,0.85) 0%, rgba(15,23,42,0.92) 100%)',
              border: '1px solid rgba(148,163,184,0.12)',
              boxShadow: '0 32px 64px rgba(0,0,0,0.5), 0 0 0 0.5px rgba(255,255,255,0.04) inset',
              backdropFilter: 'blur(24px)',
            }}
          >
            {/* Top accent bar — thicker, more intentional */}
            <div
              style={{
                height: '3px',
                background: 'linear-gradient(90deg, #3b82f6 0%, #60a5fa 40%, rgba(96,165,250,0.2) 100%)',
              }}
            />
 
            {/* Subtle radial glow behind content */}
            <div
              style={{
                position: 'absolute',
                top: '-60px',
                left: '-40px',
                width: '300px',
                height: '300px',
                background: 'radial-gradient(circle, rgba(59,130,246,0.06) 0%, transparent 70%)',
                pointerEvents: 'none',
              }}
            />
 
            <div className="p-6">
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.12 }}
                >
                  <p className="text-xs font-semibold tracking-widest uppercase mb-1"
                    style={{ color: 'rgba(96,165,250,0.7)', letterSpacing: '0.1em' }}>
                    Weather History
                  </p>
                  <h2 className="text-2xl font-bold text-white" style={{ letterSpacing: '-0.02em' }}>
                    Past Warnings
                  </h2>
                </motion.div>
 
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.15 }}
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.94 }}
                  onClick={onClose}
                  className="p-2 rounded-xl transition-colors"
                  style={{
                    background: 'rgba(255,255,255,0.06)',
                    border: '1px solid rgba(255,255,255,0.1)',
                  }}
                >
                  <X className="w-4 h-4" style={{ color: '#94a3b8' }} />
                </motion.button>
              </div>
 
              {/* Content */}
              {pastWarnings.length > 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="max-h-[70vh] overflow-y-auto space-y-3 pr-1"
                  style={{
                    scrollbarWidth: 'thin',
                    scrollbarColor: 'rgba(148,163,184,0.2) transparent',
                  }}
                >
                  {pastWarnings.map((warning, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 + index * 0.06, ease: [0.4, 0, 0.2, 1] }}
                    >
                      <WarningCard warning={warning} index={index} />
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.1 }}
                  className="flex flex-col items-center py-10 px-4"
                >
                  {/* Icon container with layered rings */}
                  <div className="relative mb-5">
                    {/* Outer glow ring */}
                    <motion.div
                      animate={{ scale: [1, 1.08, 1], opacity: [0.3, 0.15, 0.3] }}
                      transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                      className="absolute inset-0 rounded-full"
                      style={{
                        background: 'radial-gradient(circle, rgba(59,130,246,0.15) 0%, transparent 70%)',
                        margin: '-16px',
                      }}
                    />
 
                    {/* Icon background circle */}
                    <div
                      className="w-20 h-20 rounded-full flex items-center justify-center"
                      style={{
                        background: 'rgba(59,130,246,0.08)',
                        border: '1px solid rgba(59,130,246,0.15)',
                      }}
                    >
                      <motion.div
                        animate={{ y: [0, -5, 0] }}
                        transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
                      >
                        <CloudRain className="w-9 h-9" style={{ color: 'rgba(96,165,250,0.45)' }} />
                      </motion.div>
                    </div>
                  </div>
 
                  {/* Text */}
                  <p className="text-white font-semibold text-lg mb-1.5" style={{ letterSpacing: '-0.01em' }}>
                    All clear
                  </p>
                  <p className="text-center text-sm leading-relaxed mb-8" style={{ color: '#475569', maxWidth: '240px' }}>
                    No weather warnings have expired in the past 5 days for your region.
                  </p>
 
                  {/* Divider */}
                  <div className="w-full mb-6"
                    style={{ height: '1px', background: 'linear-gradient(90deg, transparent, rgba(148,163,184,0.1) 30%, rgba(148,163,184,0.1) 70%, transparent)' }}
                  />
 
                  {/* Meta info chips */}
                  <div className="flex gap-3 w-full">
                    {[
                      { label: 'Lookback period', value: '5 days' },
                      { label: 'Region', value: 'All areas' },
                      { label: 'Last checked', value: 'Just now' },
                    ].map((item, i) => (
                      <div
                        key={i}
                        className="flex-1 rounded-xl px-3 py-3 flex flex-col gap-1"
                        style={{
                          background: 'rgba(255,255,255,0.03)',
                          border: '1px solid rgba(255,255,255,0.06)',
                        }}
                      >
                        <span className="text-xs font-medium" style={{ color: '#334155', letterSpacing: '0.04em' }}>
                          {item.label}
                        </span>
                        <span className="text-sm font-semibold" style={{ color: '#64748b' }}>
                          {item.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
 