import React, { useRef, useState, useEffect, useCallback } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet';
import { Maximize2, Minimize2, Trash2, Pen, MousePointer } from 'lucide-react';
import 'leaflet/dist/leaflet.css';

const DRAW_COLORS = {
  Low: '#22c55e',
  SLGT: '#eab308',
  Moderate: '#f97316',
  High: '#ef4444',
};

function DrawingCanvas({ isDrawingMode, color, paths, onAddPath, containerRef }) {
  const canvasRef = useRef(null);
  const [currentPath, setCurrentPath] = useState([]);
  const [isPointerDown, setIsPointerDown] = useState(false);

  const syncCanvasSize = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;
    canvas.width = container.offsetWidth;
    canvas.height = container.offsetHeight;
  }, [containerRef]);

  useEffect(() => {
    syncCanvasSize();
    window.addEventListener('resize', syncCanvasSize);
    return () => window.removeEventListener('resize', syncCanvasSize);
  }, [syncCanvasSize]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const drawPath = (pts, col) => {
      if (pts.length < 2) return;
      ctx.beginPath();
      ctx.moveTo(pts[0].x * canvas.width, pts[0].y * canvas.height);
      pts.forEach(p => ctx.lineTo(p.x * canvas.width, p.y * canvas.height));
      ctx.closePath();
      // Filled shape with low opacity
      ctx.globalAlpha = 0.25;
      ctx.fillStyle = col;
      ctx.fill();
      // Crisp border
      ctx.globalAlpha = 0.75;
      ctx.strokeStyle = col;
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
      ctx.globalAlpha = 1;
    };

    paths.forEach(p => drawPath(p.points, p.color));
    if (currentPath.length > 1 && canvas.width > 0) {
      drawPath(currentPath.map(p => ({ x: p.x / canvas.width, y: p.y / canvas.height })), color);
    }
  }, [paths, currentPath, color]);

  const getPoint = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const src = e.touches?.[0] || e;
    return { x: src.clientX - rect.left, y: src.clientY - rect.top };
  };

  const handleDown = (e) => {
    if (!isDrawingMode) return;
    e.preventDefault();
    setIsPointerDown(true);
    const pt = getPoint(e);
    if (pt) setCurrentPath([pt]);
  };

  const handleMove = (e) => {
    if (!isDrawingMode || !isPointerDown) return;
    e.preventDefault();
    const pt = getPoint(e);
    if (pt) setCurrentPath(prev => [...prev, pt]);
  };

  const handleUp = () => {
    if (!isDrawingMode || !isPointerDown) return;
    setIsPointerDown(false);
    const canvas = canvasRef.current;
    if (currentPath.length > 1 && canvas) {
      onAddPath({
        points: currentPath.map(p => ({ x: p.x / canvas.width, y: p.y / canvas.height })),
        color,
      });
    }
    setCurrentPath([]);
  };

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{
        pointerEvents: isDrawingMode ? 'all' : 'none',
        cursor: isDrawingMode ? 'crosshair' : 'default',
        zIndex: 900,
      }}
      onMouseDown={handleDown}
      onMouseMove={handleMove}
      onMouseUp={handleUp}
      onMouseLeave={handleUp}
      onTouchStart={handleDown}
      onTouchMove={handleMove}
      onTouchEnd={handleUp}
    />
  );
}

export default function ImpactDrawingMap({ paths = [], onPathsChange, isOwner = false }) {
  const containerRef = useRef(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDrawingMode, setIsDrawingMode] = useState(false);
  const [currentColor, setCurrentColor] = useState(DRAW_COLORS.Low);
  const [mapKey, setMapKey] = useState(0);

  const toggleFullscreen = () => {
    setIsFullscreen(f => !f);
    setTimeout(() => setMapKey(k => k + 1), 50);
  };

  const handleAddPath = (path) => {
    onPathsChange?.([...paths, path]);
  };

  const mapContainerClass = isFullscreen
    ? 'fixed inset-0 z-[9999] bg-slate-900'
    : 'relative w-full h-64 rounded-2xl overflow-hidden border border-slate-700';

  return (
    <div className={mapContainerClass}>
      <div ref={containerRef} className="relative w-full h-full">
        <MapContainer
          key={mapKey}
          center={[54.5, -3.5]}
          zoom={5}
          style={{ width: '100%', height: isFullscreen ? '100vh' : '256px' }}
          zoomControl={!isDrawingMode}
          dragging={!isDrawingMode}
          scrollWheelZoom={!isDrawingMode}
          doubleClickZoom={!isDrawingMode}
        >
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://carto.com">CARTO</a>'
          />
        </MapContainer>

        <DrawingCanvas
          isDrawingMode={isDrawingMode}
          color={currentColor}
          paths={paths}
          onAddPath={handleAddPath}
          containerRef={containerRef}
        />

        {/* Top-right controls */}
        <div className="absolute top-3 right-3 z-[1001] flex flex-col gap-2">
          <button
            onClick={toggleFullscreen}
            className="p-2 bg-slate-900/90 backdrop-blur-sm rounded-lg border border-slate-600 text-white hover:bg-slate-700 transition-colors"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          {isOwner && (
            <>
              <button
                onClick={() => setIsDrawingMode(d => !d)}
                className={`p-2 rounded-lg border text-white backdrop-blur-sm transition-colors ${
                  isDrawingMode
                    ? 'bg-sky-500 border-sky-400'
                    : 'bg-slate-900/90 border-slate-600 hover:bg-slate-700'
                }`}
              >
                {isDrawingMode ? <Pen className="w-4 h-4" /> : <MousePointer className="w-4 h-4" />}
              </button>
              {paths.length > 0 && (
                <button
                  onClick={() => onPathsChange?.([])}
                  className="p-2 bg-red-600/80 backdrop-blur-sm rounded-lg border border-red-500 text-white hover:bg-red-600 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </>
          )}
        </div>

        {/* Drawing color picker */}
        {isOwner && isDrawingMode && (
          <div className="absolute bottom-3 left-3 z-[1001] flex items-center gap-2 bg-slate-900/90 backdrop-blur-sm rounded-xl px-3 py-2 border border-slate-600">
            <span className="text-xs text-slate-400 mr-1">Colour:</span>
            {Object.entries(DRAW_COLORS).map(([label, col]) => (
              <button
                key={label}
                onClick={() => setCurrentColor(col)}
                title={label}
                className={`w-6 h-6 rounded-full border-2 transition-transform ${
                  currentColor === col ? 'scale-125 border-white' : 'border-slate-700'
                }`}
                style={{ backgroundColor: col }}
              />
            ))}
          </div>
        )}

        {/* Drawing hint */}
        {isDrawingMode && (
          <div className="absolute top-3 left-3 z-[1001] bg-slate-900/90 backdrop-blur-sm rounded-lg px-3 py-1.5 text-xs text-sky-300 border border-sky-700">
            Draw mode — drag to mark impact areas
          </div>
        )}

        {/* Fullscreen close */}
        {isFullscreen && (
          <button
            onClick={toggleFullscreen}
            className="absolute top-4 left-4 z-[10000] bg-slate-900/90 backdrop-blur-sm rounded-xl px-4 py-2 text-sm text-white border border-slate-600 hover:bg-slate-800 flex items-center gap-2 transition-colors"
          >
            <Minimize2 className="w-4 h-4" /> Exit Fullscreen
          </button>
        )}
      </div>
    </div>
  );
}