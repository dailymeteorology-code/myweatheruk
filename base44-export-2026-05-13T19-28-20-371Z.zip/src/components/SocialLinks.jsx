import React from 'react';
import { Facebook, Instagram, Youtube } from 'lucide-react';

const DiscordIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.002.022.015.044.03.054a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
  </svg>
);

const XIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.259 5.632 5.905-5.632Zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
  </svg>
);

const socialIcons = {
  twitter_url: XIcon,
  facebook_url: Facebook,
  instagram_url: Instagram,
  youtube_url: Youtube,
  discord_url: DiscordIcon,
};

const socialLabels = {
  twitter_url: 'Twitter',
  facebook_url: 'Facebook',
  instagram_url: 'Instagram',
  youtube_url: 'YouTube',
  discord_url: 'Discord',
};

export default function SocialLinks({ settings, className = '' }) {
  const socials = ['twitter_url', 'facebook_url', 'instagram_url', 'youtube_url', 'discord_url']
    .filter(key => settings?.[key]);

  if (socials.length === 0) return null;

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {socials.map(key => {
        const Icon = socialIcons[key];
        return (
          <a
            key={key}
            href={settings[key]}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
            title={socialLabels[key]}
          >
            <Icon className="w-5 h-5" />
          </a>
        );
      })}
    </div>
  );
}