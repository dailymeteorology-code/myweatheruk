const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useSpring, useTransform } from 'framer-motion';
import {
  Menu, X, AlertTriangle, Clock, Image, CloudSun,
  Crown, LogIn, LogOut, UserPlus, ShieldAlert,
  CloudLightning, Lock, Sun, Moon, ChevronRight } from
'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useTheme } from './ThemeContext';
import { Link } from 'react-router-dom';

/* ─── Section definitions ─────────────────────────────────────── */
const sections = [
{ id: 'activeWarnings', label: 'Active Warnings', icon: AlertTriangle, color: '#ef4444', accent: 'rgba(239,68,68,0.12)' },
{ id: 'upcomingWarnings', label: 'Upcoming Warnings', icon: Clock, color: '#f97316', accent: 'rgba(249,115,22,0.12)' },
{ id: 'forecasts', label: 'MyWeather Graphics', icon: Image, color: '#38bdf8', accent: 'rgba(56,189,248,0.12)' },
{ id: 'tcmLightning', label: 'TCM Lightning', icon: CloudLightning, color: '#a78bfa', accent: 'rgba(167,139,250,0.12)', href: '/TCM' },
{ id: 'tcmOutlooks', label: 'TCM Outlooks', icon: CloudLightning, color: '#facc15', accent: 'rgba(250,204,21,0.12)', href: '/WeatherPatterns' },
{ id: 'liveRadar', label: 'Live Radar', icon: CloudSun, color: '#34d399', accent: 'rgba(52,211,153,0.12)' }];

/* ─── Animated radar ping on the menu button ─────────────────── */
function RadarPing() {
  return (
    <span style={{ position: 'absolute', top: 6, right: 6, display: 'flex', width: 8, height: 8 }}>
      <span style={{
        position: 'absolute', inset: 0, borderRadius: '50%',
        background: '#ef4444', opacity: 0.75,
        animation: 'ping 1.8s cubic-bezier(0,0,0.2,1) infinite'
      }} />
      <span style={{ position: 'relative', display: 'inline-flex', width: 8, height: 8, borderRadius: '50%', background: '#ef4444' }} />
    </span>);

}

/* ─── Single nav item ─────────────────────────────────────────── */
function NavItem({ section, index, locked, onClick, isActive }) {
  const Icon = section.icon;
  const [hovered, setHovered] = useState(false);

  const content =
  <motion.div
    initial={{ opacity: 0, x: -28 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: 0.06 + index * 0.055, duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
    onHoverStart={() => setHovered(true)}
    onHoverEnd={() => setHovered(false)}
    style={{ position: 'relative', marginBottom: 4 }}>
    
      {/* Active / hover background */}
      <AnimatePresence>
        {hovered && !locked &&
      <motion.div
        initial={{ opacity: 0, scaleX: 0.85 }}
        animate={{ opacity: 1, scaleX: 1 }}
        exit={{ opacity: 0, scaleX: 0.85 }}
        transition={{ duration: 0.18 }}
        style={{
          position: 'absolute', inset: 0, borderRadius: 14,
          background: section.accent,
          border: `1px solid ${section.color}28`,
          transformOrigin: 'left'
        }} />

      }
      </AnimatePresence>

      {/* Left accent bar */}
      <motion.div
      animate={{ scaleY: hovered && !locked ? 1 : 0, opacity: hovered && !locked ? 1 : 0 }}
      transition={{ duration: 0.18 }}
      style={{
        position: 'absolute', left: 0, top: '20%', bottom: '20%',
        width: 3, borderRadius: 99,
        background: section.color,
        transformOrigin: 'center'
      }} />
    

      <div style={{
      display: 'flex', alignItems: 'center', gap: 13,
      padding: '11px 14px 11px 18px',
      cursor: locked ? 'not-allowed' : 'pointer',
      userSelect: 'none',
      opacity: locked ? 0.4 : 1,
      position: 'relative'
    }}>
        {/* Icon container */}
        <motion.div
        animate={{ scale: hovered && !locked ? 1.12 : 1, rotate: hovered && !locked ? -6 : 0 }}
        transition={{ duration: 0.2 }}
        style={{
          width: 34, height: 34, borderRadius: 10, flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: hovered && !locked ? section.accent : 'rgba(255,255,255,0.05)',
          border: `1px solid ${hovered && !locked ? section.color + '40' : 'rgba(255,255,255,0.07)'}`,
          transition: 'background 0.2s, border-color 0.2s'
        }}>
        
          <Icon style={{ width: 15, height: 15, color: locked ? '#475569' : section.color }} />
        </motion.div>

        <span style={{
        fontSize: '0.85rem', fontWeight: 600, flex: 1,
        color: hovered && !locked ? '#f1f5f9' : '#94a3b8',
        letterSpacing: '-0.01em',
        transition: 'color 0.2s',
        fontFamily: "'DM Sans', system-ui, sans-serif"
      }}>
          {section.label}
        </span>

        {locked ?
      <span style={{
        display: 'flex', alignItems: 'center', gap: 4,
        fontSize: '0.62rem', fontWeight: 700, letterSpacing: '0.06em',
        color: '#f97316', background: 'rgba(249,115,22,0.1)',
        border: '1px solid rgba(249,115,22,0.25)',
        padding: '2px 8px', borderRadius: 99, textTransform: 'uppercase'
      }}>
            <Lock style={{ width: 9, height: 9 }} /> Soon
          </span> :
      section.href ?
      <motion.div
        animate={{ x: hovered ? 3 : 0, opacity: hovered ? 1 : 0.3 }}
        transition={{ duration: 0.18 }}>
        
            <ChevronRight style={{ width: 13, height: 13, color: section.color }} />
          </motion.div> :

      <motion.div
        animate={{ x: hovered ? 3 : 0, opacity: hovered ? 1 : 0.3 }}
        transition={{ duration: 0.18 }}>
        
            <ChevronRight style={{ width: 13, height: 13, color: '#64748b' }} />
          </motion.div>
      }
      </div>
    </motion.div>;

  if (section.href && !locked) {
    return <Link to={section.href} onClick={onClick} style={{ textDecoration: 'none', display: 'block' }}>{content}</Link>;
  }

  return <div onClick={() => !locked && onClick(section.id)}>{content}</div>;
}

/* ─── Utility nav item (auth, theme, admin) ───────────────────── */
function UtilItem({ icon: Icon, label, onClick, color = '#64748b', delay = 0 }) {
  const [hovered, setHovered] = useState(false);
  return (
    <motion.button
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay, duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
      onClick={onClick}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      style={{
        width: '100%', display: 'flex', alignItems: 'center', gap: 13,
        padding: '10px 14px 10px 18px', borderRadius: 12,
        background: hovered ? `rgba(255,255,255,0.04)` : 'transparent',
        border: 'none', cursor: 'pointer', textAlign: 'left',
        transition: 'background 0.18s', fontFamily: "'DM Sans', system-ui, sans-serif"
      }}>
      
      <div style={{
        width: 32, height: 32, borderRadius: 9, flexShrink: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: hovered ? `${color}18` : 'rgba(255,255,255,0.04)',
        border: `1px solid ${hovered ? color + '35' : 'rgba(255,255,255,0.06)'}`,
        transition: 'all 0.18s'
      }}>
        <Icon style={{ width: 14, height: 14, color: hovered ? color : '#64748b', transition: 'color 0.18s' }} />
      </div>
      <span style={{ fontSize: '0.82rem', fontWeight: 600, color: hovered ? '#e2e8f0' : '#64748b', transition: 'color 0.18s', letterSpacing: '-0.01em' }}>
        {label}
      </span>
    </motion.button>);

}

/* ─── Divider ─────────────────────────────────────────────────── */
function Divider({ label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 18px', margin: '4px 0' }}>
      <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
      {label && <span style={{ fontSize: '0.6rem', fontWeight: 700, color: 'rgba(255,255,255,0.2)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>{label}</span>}
      <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
    </div>);

}

/* ─── Main component ──────────────────────────────────────────── */
export default function SectionNavigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [authChecked, setChecked] = useState(false);
  const [hasWarnings, setHasWarnings] = useState(true); // show ping if active warnings exist
  const { isDark, toggleTheme } = useTheme();

  const { data: menuConfigs = [] } = useQuery({
    queryKey: ['menuItemConfigs'],
    queryFn: () => db.entities.MenuItemConfig.list()
  });

  const isLocked = (id) => menuConfigs.find((m) => m.section_id === id)?.is_coming_soon ?? false;

  useEffect(() => {
    db.auth.me().
    then((u) => {setUser(u);setChecked(true);}).
    catch(() => setChecked(true));
  }, []);

  // Close on escape
  useEffect(() => {
    const onKey = (e) => {if (e.key === 'Escape') setIsOpen(false);};
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setIsOpen(false);
  };

  const close = () => setIsOpen(false);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@500&display=swap');
        @keyframes ping {
          75%, 100% { transform: scale(2); opacity: 0; }
        }
        @keyframes shimmer {
          0% { background-position: -200% center; }
          100% { background-position: 200% center; }
        }
      `}</style>

      {/* ── Hamburger button ─────────────────────────────────── */}
      <motion.button
        onClick={() => setIsOpen((o) => !o)}
        whileTap={{ scale: 0.92 }}
        style={{
          position: 'fixed', top: 20, left: 20, zIndex: 50,
          width: 46, height: 46, borderRadius: 14,
          background: isOpen ?
          'rgba(15,23,42,0.95)' :
          'rgba(15,23,42,0.75)',
          border: `1px solid ${isOpen ? 'rgba(56,189,248,0.35)' : 'rgba(255,255,255,0.1)'}`,
          backdropFilter: 'blur(16px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
          boxShadow: isOpen ?
          '0 0 0 1px rgba(56,189,248,0.15), 0 8px 32px rgba(0,0,0,0.4)' :
          '0 4px 24px rgba(0,0,0,0.3)',
          transition: 'all 0.25s ease'
        }}>
        
        <AnimatePresence mode="wait">
          {isOpen ?
          <motion.div key="x"
          initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }}
          exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.18 }}>
              <X style={{ width: 18, height: 18, color: '#38bdf8' }} />
            </motion.div> :

          <motion.div key="m"
          initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }}
          exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.18 }}>
              <Menu style={{ width: 18, height: 18, color: '#94a3b8' }} />
            </motion.div>
          }
        </AnimatePresence>
      </motion.button>

      <AnimatePresence>
        {isOpen &&
        <>
            {/* ── Backdrop ───────────────────────────────────── */}
            <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.22 }}
            onClick={close}
            style={{
              position: 'fixed', inset: 0, zIndex: 40,
              background: 'rgba(2,6,15,0.7)',
              backdropFilter: 'blur(6px)'
            }} />
          

            {/* ── Sidebar panel ──────────────────────────────── */}
            <motion.div
            initial={{ x: -340, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -340, opacity: 0 }}
            transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
            style={{
              position: 'fixed', left: 0, top: 0, bottom: 0,
              width: 300, zIndex: 50,
              background: 'linear-gradient(180deg, #090f1e 0%, #0d1525 60%, #090f1e 100%)',
              borderRight: '1px solid rgba(255,255,255,0.07)',
              display: 'flex', flexDirection: 'column',
              overflow: 'hidden'
            }}>
            
              {/* Subtle top glow */}
              <div style={{
              position: 'absolute', top: -60, left: -40, width: 280, height: 280,
              borderRadius: '50%',
              background: 'radial-gradient(circle, rgba(56,189,248,0.07) 0%, transparent 70%)',
              pointerEvents: 'none'
            }} />
              <div style={{
              position: 'absolute', bottom: -60, right: -40, width: 220, height: 220,
              borderRadius: '50%',
              background: 'radial-gradient(circle, rgba(167,139,250,0.06) 0%, transparent 70%)',
              pointerEvents: 'none'
            }} />

              {/* ── Header ───────────────────────────────────── */}
              <motion.div
              initial={{ opacity: 0, y: -12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, duration: 0.35 }}
              style={{
                padding: '28px 20px 18px',
                borderBottom: '1px solid rgba(255,255,255,0.05)'
              }}>
              
                <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                  <div style={{
                  width: 36, height: 36, borderRadius: 10,
                  background: 'linear-gradient(135deg, rgba(56,189,248,0.2), rgba(167,139,250,0.2))',
                  border: '1px solid rgba(56,189,248,0.2)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  flexShrink: 0
                }}>
                    <CloudLightning style={{ width: 17, height: 17, color: '#38bdf8' }} />
                  </div>
                  <div>
                    <p style={{
                    margin: 0, fontSize: '0.95rem', fontWeight: 700,
                    color: '#f1f5f9', letterSpacing: '-0.02em',
                    fontFamily: "'DM Sans', system-ui, sans-serif",
                    background: 'linear-gradient(135deg, #f1f5f9 0%, #94a3b8 100%)',
                    WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'
                  }}>
                      Navigation
                    </p>
                    <p style={{
                    margin: 0, fontSize: '0.62rem', fontWeight: 600,
                    color: 'rgba(255,255,255,0.2)', letterSpacing: '0.1em',
                    textTransform: 'uppercase', fontFamily: "'DM Mono', monospace"
                  }}>
                      MyWeatherUK
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* ── Scrollable body ──────────────────────────── */}
              <div style={{ flex: 1, overflowY: 'auto', padding: '12px 8px', scrollbarWidth: 'none' }}>

                {/* Main nav */}
                <div style={{ marginBottom: 4 }}>
                  {sections.map((section, i) =>
                <NavItem
                  key={section.id}
                  section={section}
                  index={i}
                  locked={isLocked(section.id)}
                  onClick={scrollTo}
                  isActive={false} />

                )}
                </div>

                <Divider label="Account" />

                {/* Auth section */}
                {authChecked &&
              <div>
                    {user ?
                <>
                        {/* User chip */}
                        <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.38, duration: 0.32 }}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 10,
                      padding: '10px 18px', margin: '0 0 4px'
                    }}>
                    
                          <div style={{
                      width: 32, height: 32, borderRadius: '50%',
                      background: 'linear-gradient(135deg, #38bdf8, #818cf8)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0, fontSize: '0.78rem', fontWeight: 700, color: '#fff',
                      fontFamily: "'DM Sans', system-ui"
                    }}>
                            {user.email?.[0]?.toUpperCase() || '?'}
                          </div>
                          <div style={{ minWidth: 0 }}>
                            <p style={{ margin: 0, fontSize: '0.72rem', fontWeight: 600, color: '#94a3b8', fontFamily: "'DM Sans', system-ui", overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                              {user.email}
                            </p>
                            <p style={{ margin: 0, fontSize: '0.6rem', color: 'rgba(255,255,255,0.25)', fontFamily: "'DM Mono', monospace", letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                              {user.role || 'member'}
                            </p>
                          </div>
                        </motion.div>
                        <UtilItem icon={LogOut} label="Sign Out" color="#ef4444" delay={0.42}
                  onClick={() => {db.auth.logout();close();}} />
                      </> :

                <>
                        <UtilItem icon={LogIn} label="Sign In" color="#38bdf8" delay={0.38} onClick={() => {db.auth.redirectToLogin();close();}} />
                        <UtilItem icon={UserPlus} label="Sign Up" color="#34d399" delay={0.42} onClick={() => {db.auth.redirectToLogin();close();}} />
                      </>
                }
                  </div>
              }

                <Divider label="More" />

                {/* Extra links */}
                {user?.role === 'admin' &&
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.46, duration: 0.32 }}>
                
                    <Link to="/AdminSettings" onClick={close} style={{ textDecoration: 'none', display: 'block' }}>
                      <UtilItem icon={ShieldAlert} label="Admin Settings" color="#f59e0b" delay={0} onClick={() => {}} />
                    </Link>
                  </motion.div>
              }

                <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.49, duration: 0.32 }}>

                <UtilItem
                icon={isDark ? Sun : Moon}
                label={isDark ? 'Light Mode' : 'Dark Mode'}
                color="#38bdf8"
                delay={0.52}
                onClick={toggleTheme} />
              
              </motion.div>
              </div>

              {/* ── Footer ───────────────────────────────────── */}
              <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.55, duration: 0.3 }}
              style={{
                padding: '14px 20px',
                borderTop: '1px solid rgba(255,255,255,0.05)'
              }}>
              
                <p style={{
                margin: 0, fontSize: '0.62rem', fontWeight: 600,
                color: 'rgba(255,255,255,0.15)', letterSpacing: '0.1em',
                textTransform: 'uppercase', textAlign: 'center',
                fontFamily: "'DM Mono', monospace"
              }} className=" hidden">
                  Thunderstorm Convection Model
                </p>
              </motion.div>
            </motion.div>
          </>
        }
      </AnimatePresence>
    </>);

}