import React, { useState, useEffect } from 'react';
import { RefreshCw, Radar } from 'lucide-react';
import { Button } from "@/components/ui/button";

const LAYERS = [
{ id: 'radar', label: 'Live Radar', overlay: 'radar', product: 'radar' },
{ id: 'temp', label: 'Temperature', overlay: 'temp', product: 'ecmwf' },
{ id: 'wind', label: 'Wind', overlay: 'wind', product: 'ecmwf' },
{ id: 'pressure', label: 'Pressure', overlay: 'pressure', product: 'ecmwf' },
{ id: 'dewpoint', label: 'Dew Point', overlay: 'dewpoint', product: 'ecmwf' }];

export default function WindyRadarEmbed({ userRole }) {
  const isPro = userRole === 'pro' || userRole === 'developer' || userRole === 'admin';
  const REFRESH_INTERVAL = isPro ? 5 * 60 * 1000 : 15 * 60 * 1000;
  const BOUNDARY_MINS = isPro ? 5 : 15;

  const [activeLayer, setActiveLayer] = useState('radar');
  const [refreshKey, setRefreshKey] = useState(0);
  const [timeUntilRefresh, setTimeUntilRefresh] = useState(REFRESH_INTERVAL);

  useEffect(() => {
    const getNextRefreshTime = () => {
      const now = new Date();
      const minutes = now.getMinutes();
      let nextMinute = Math.floor(minutes / BOUNDARY_MINS) * BOUNDARY_MINS + BOUNDARY_MINS;
      const next = new Date(now);
      if (nextMinute >= 60) {
        next.setHours(next.getHours() + 1, nextMinute % 60, 0, 0);
      } else {
        next.setMinutes(nextMinute, 0, 0);
      }
      return next;
    };

    const scheduleNextRefresh = () => {
      const nextRefresh = getNextRefreshTime();
      const timeUntil = Math.max(1000, nextRefresh - new Date());
      const timeout = setTimeout(() => {
        setRefreshKey((prev) => prev + 1);
        setTimeUntilRefresh(REFRESH_INTERVAL);
        scheduleNextRefresh();
      }, timeUntil);
      return timeout;
    };

    const timeout = scheduleNextRefresh();
    return () => clearTimeout(timeout);
  }, [REFRESH_INTERVAL, BOUNDARY_MINS]);

  useEffect(() => {
    const countdown = setInterval(() => {
      setTimeUntilRefresh((prev) => {
        if (prev <= 1000) return REFRESH_INTERVAL;
        return prev - 1000;
      });
    }, 1000);
    return () => clearInterval(countdown);
  }, [REFRESH_INTERVAL]);

  const handleManualRefresh = () => {
    setRefreshKey((prev) => prev + 1);
    setTimeUntilRefresh(REFRESH_INTERVAL);
  };

  const layer = LAYERS.find((l) => l.id === activeLayer) || LAYERS[0];

  const windySrc = `https://embed.windy.com/embed.html?type=map&location=coordinates&metricRain=default&metricTemp=default&metricWind=default&zoom=5&overlay=${layer.overlay}&product=${layer.product}&level=surface&lat=54.75&lon=-1.362`;

  const minutes = Math.floor(timeUntilRefresh / 60000);
  const seconds = Math.floor(timeUntilRefresh % 60000 / 1000);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Radar className="w-6 h-6 text-sky-600 dark:text-sky-400" />
          <h2 className="text-slate-50 text-3xl font-bold dark:text-white">Live Radar</h2>
          {isPro &&
          <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full font-medium">
              5 min refresh
            </span>
          }
        </div>

        <div className="flex items-center gap-3">
          <div className="text-slate-50 text-sm dark:text-slate-300 whitespace-nowrap">
            Next update in{" "}
            <span className="text-slate-50 font-semibold dark:text-white">
              {minutes}:{seconds.toString().padStart(2, "0")}
            </span>
          </div>

          {(userRole === 'admin' || isPro) &&
          <Button
            onClick={handleManualRefresh}
            variant="outline"
            size="sm" className="bg-[hsl(var(--background))] px-3 text-xs font-medium rounded-[32px] inline-flex items-center justify-center whitespace-nowrap transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-input shadow-sm hover:bg-accent hover:text-accent-foreground h-8 gap-2">

            
              <RefreshCw className="w-4 h-4" />
              Refresh
            </Button>
          }
        </div>
      </div>

      {/* Layer selector */}
      <div className="flex flex-wrap gap-2 mb-1">
        {LAYERS.map((l) =>
        <button
          key={l.id}
          onClick={() => setActiveLayer(l.id)}
          className={`
              bg-white/5 text-gray-100 px-3 py-1.5 text-sm font-medium rounded-3xl
              transition-all border hover:text-white
              ${
          activeLayer === l.id ?
          "border-sky-400 shadow-[0_0_0_2px_rgba(56,189,248,0.7),0_0_14px_4px_rgba(56,189,248,0.5)]" :
          "border-slate-600 hover:border-sky-500"}
            `
          }>
          
            {l.label}
          </button>
        )}
      </div>

      <div className="flex justify-center">
        <div
          key={`${refreshKey}-${activeLayer}`}
          className="w-[650px] h-[450px] rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
          
          <iframe
            width="650"
            height="450"
            src={windySrc}
            frameBorder="0"
            title="Windy.com Weather Radar"
            className="opacity-100 rounded-sm" />
          
        </div>
      </div>
    </div>);

}