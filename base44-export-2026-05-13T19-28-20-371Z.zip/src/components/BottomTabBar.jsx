const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Settings } from 'lucide-react';

import { useTheme } from '@/components/ThemeContext';

const TABS = [
{ name: 'Settings', icon: Settings, path: '/Settings', requiresAuth: true }];

export default function BottomTabBar() {
  const location = useLocation();
  const { isDark } = useTheme();
  const [userRole, setUserRole] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    db.auth.me().
    then((user) => {setUserRole(user?.role);setIsAuthenticated(true);}).
    catch(() => {});
  }, []);

  const visibleTabs = TABS.filter((tab) => {
    if (tab.adminOnly && userRole !== 'admin') return false;
    if (tab.requiresAuth && !isAuthenticated) return false;
    return true;
  });

  const isActive = (path) =>
  location.pathname === path || path === '/Home' && location.pathname === '/';

  return (
    <nav
      className={`md:hidden fixed bottom-0 left-0 right-0 z-50 border-t ${
      isDark ? 'bg-slate-900/95 border-slate-700' : 'bg-white/95 border-slate-200'} backdrop-blur-lg`
      }
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
      
      <div className="flex items-stretch">
        {visibleTabs.map((tab) => null

        )}
      </div>
    </nav>);

}