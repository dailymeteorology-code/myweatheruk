const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useContext, useState, useEffect, createContext } from 'react';
import { Link } from 'react-router-dom';
import { Home, Image, Menu, X, UserCircle, ShieldAlert, LogIn, LogOut, Sun, Moon } from 'lucide-react';
import FloatingSearchBar from '@/components/FloatingSearchBar';
import BottomTabBar from '@/components/BottomTabBar';
import { AnimatePresence, motion } from 'framer-motion';

const ThemeContext = createContext();

export const useTheme = () => useContext(ThemeContext);

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    const stored = localStorage.getItem('theme');
    if (stored) return stored;

    // system fallback
    return window.matchMedia('(prefers-color-scheme: dark)').matches ?
    'dark' :
    'light';
  });

  const isDark = theme === 'dark';

  useEffect(() => {
    const root = document.documentElement;

    if (isDark) root.classList.add('dark');else
    root.classList.remove('dark');

    localStorage.setItem('theme', theme);
  }, [theme, isDark]);

  const toggleTheme = () => {
    setTheme((prev) => prev === 'dark' ? 'light' : 'dark');
  };

  return (
    <ThemeContext.Provider value={{ theme, isDark, toggleTheme }}>
      {children}
    </ThemeContext.Provider>);

}

function ThemeToggle() {
  const { isDark, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className={`p-2 rounded-lg transition ${
      isDark ?
      'bg-slate-800 text-yellow-400 hover:bg-slate-700' :
      'bg-slate-100 text-slate-700 hover:bg-slate-200'}`
      }>
      
      {isDark ? <Sun size={18} /> : <Moon size={18} />}
    </button>);

}

const navItems = [
{ name: 'Home', icon: Home, page: 'Home', requiresAuth: false },
{ name: 'Graphics', icon: Image, page: 'Graphics', requiresAuth: true, betaOnly: true },
{ name: 'Settings', icon: ShieldAlert, page: 'AdminSettings', requiresAuth: true, adminOnly: true }];

function HamburgerMenu({ userRole, isAuthenticated, publishedFeatures, currentPageName, isDark }) {
  const [open, setOpen] = useState(false);

  const isAdmin = userRole === 'admin';
  const isBetaOrAdmin = userRole === 'beta_tester' || isAdmin;

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        className={`p-2 rounded-lg ${isDark ? 'text-slate-300 hover:bg-slate-700' : 'text-slate-600 hover:bg-slate-100'}`}>
        
        {open ? <X size={20} /> : <Menu size={20} />}
      </button>

      <AnimatePresence>
        {open &&
        <>
            <motion.div
            onClick={() => setOpen(false)}
            className="fixed inset-0 bg-black/40 z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }} />
          

            <motion.div
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            className={`fixed left-0 top-0 h-screen w-64 z-50 ${isDark ? 'bg-slate-900' : 'bg-white'}`}>
            
              <div className="pt-16 px-4 flex flex-col gap-2">

                <Link to="/" onClick={() => setOpen(false)}>
                  Home
                </Link>

                {navItems.map((item) =>
              <Link key={item.page} to={`/${item.page}`} onClick={() => setOpen(false)}>
                    {item.name}
                  </Link>
              )}

                <div className="mt-4">
                  <ThemeToggle />
                </div>

                {isAuthenticated ?
              <button
                onClick={async () => {
                  const { base44 } = await import('@/api/base44Client');
                  db.auth.logout('/');
                }}>
                
                    <LogOut size={16} /> Logout
                  </button> :

              <button
                onClick={async () => {
                  const { base44 } = await import('@/api/base44Client');
                  db.auth.redirectToLogin();
                }}>
                
                    <LogIn size={16} /> Login
                  </button>
              }
              </div>
            </motion.div>
          </>
        }
      </AnimatePresence>
    </>);

}

function LayoutContent({ children, currentPageName }) {
  const { isDark } = useTheme();

  const [userRole, setUserRole] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [publishedFeatures, setPublishedFeatures] = useState({});

  useEffect(() => {
    const fetch = async () => {
      try {
        const { base44 } = await import('@/api/base44Client');
        const user = await db.auth.me();

        setUserRole(user?.role);
        setIsAuthenticated(true);
      } catch {
        setIsAuthenticated(false);
      }
    };
    fetch();
  }, []);

  return (
    <div className={isDark ? 'bg-slate-900 min-h-screen' : 'bg-slate-50 min-h-screen'}>
      <FloatingSearchBar />

      

      

      {children}

      <BottomTabBar />
    </div>);

}

export default function Layout({ children, currentPageName }) {
  return (
    <ThemeProvider>
      <LayoutContent currentPageName={currentPageName}>
        {children}
      </LayoutContent>
    </ThemeProvider>);

}