import { useState, useRef, useCallback } from 'react';

const THRESHOLD = 70;

export function usePullToRefresh(onRefresh) {
  const [isPulling, setIsPulling] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const startY = useRef(0);
  const triggered = useRef(false);

  const onTouchStart = useCallback((e) => {
    if (window.scrollY === 0) {
      startY.current = e.touches[0].clientY;
      triggered.current = false;
    }
  }, []);

  const onTouchMove = useCallback((e) => {
    if (window.scrollY > 0 || isRefreshing) return;
    const delta = e.touches[0].clientY - startY.current;
    if (delta > THRESHOLD && !triggered.current) {
      setIsPulling(true);
    } else if (delta <= 0) {
      setIsPulling(false);
    }
  }, [isRefreshing]);

  const onTouchEnd = useCallback(async () => {
    if (isPulling && !isRefreshing) {
      triggered.current = true;
      setIsPulling(false);
      setIsRefreshing(true);
      await onRefresh();
      setIsRefreshing(false);
    } else {
      setIsPulling(false);
    }
  }, [isPulling, isRefreshing, onRefresh]);

  return { isPulling, isRefreshing, onTouchStart, onTouchMove, onTouchEnd };
}