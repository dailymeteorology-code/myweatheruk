import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'
import { ThemeProvider } from '@/components/ThemeContext' // ✅ ADD

ReactDOM.createRoot(document.getElementById('root')).render(
  <ThemeProvider>   {/* ✅ ADD */}
    <App />
  </ThemeProvider>
)
