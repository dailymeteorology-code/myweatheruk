const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import NavigationTracker from '@/lib/NavigationTracker'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import SiteDisabled from '@/pages/SiteDisabled';
import RestrictedSiteOverlay from '@/components/RestrictedSiteOverlay';
import AdminSettings from '@/pages/AdminSettings';
import TCM from '@/pages/TCM';
import WeatherCriteria from '@/pages/WeatherCriteria';
import WeatherPatterns from '@/pages/WeatherPatterns';
import { useState, useEffect } from 'react';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout
  ? <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin, user, isAuthenticated } = useAuth();
  const [siteSettings, setSiteSettings] = useState(null);
  const [accessGranted, setAccessGranted] = useState(() => localStorage.getItem('site_access_granted') === 'true');

  useEffect(() => {
    const checkAndLoad = async () => {
      const list = await db.entities.SiteSettings.list().catch(() => []);
      const s = list[0] || null;
      if (s && s.site_disabled && s.countdown_enabled && s.countdown_target && new Date(s.countdown_target) <= new Date()) {
        await db.entities.SiteSettings.update(s.id, { site_disabled: false }).catch(() => {});
        setSiteSettings({ ...s, site_disabled: false });
      } else {
        setSiteSettings(s);
      }
    };
    checkAndLoad();
    // Poll every 30s to auto-re-enable when countdown expires
    const interval = setInterval(async () => {
      setSiteSettings(prev => {
        if (prev && prev.site_disabled && prev.countdown_enabled && prev.countdown_target && new Date(prev.countdown_target) <= new Date()) {
          db.entities.SiteSettings.update(prev.id, { site_disabled: false }).catch(() => {});
          return { ...prev, site_disabled: false };
        }
        return prev;
      });
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (siteSettings?.site_disabled && (!isAuthenticated || user?.role !== 'admin') && !accessGranted) {
    return <SiteDisabled settings={siteSettings} onAccessGranted={() => setAccessGranted(true)} />;
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  const isRestrictedUser = accessGranted && siteSettings?.site_disabled && (!isAuthenticated || user?.role !== 'admin');

  return (
    <div>
      {isRestrictedUser && <RestrictedSiteOverlay settings={siteSettings} />}
      <Routes>
        <Route path="/" element={
          <LayoutWrapper currentPageName={mainPageKey}>
            <MainPage />
          </LayoutWrapper>
        } />
        {Object.entries(Pages).map(([path, Page]) => (
          <Route
            key={path}
            path={`/${path}`}
            element={
              <LayoutWrapper currentPageName={path}>
                <Page />
              </LayoutWrapper>
            }
          />
        ))}
        <Route path="/AdminSettings" element={
          <LayoutWrapper currentPageName="AdminSettings">
            <AdminSettings />
          </LayoutWrapper>
        } />
        <Route path="/TCM" element={
          <LayoutWrapper currentPageName="TCM">
            <TCM />
          </LayoutWrapper>
        } />
        <Route path="/WeatherCriteria" element={
          <LayoutWrapper currentPageName="WeatherCriteria">
            <WeatherCriteria />
          </LayoutWrapper>
        } />
        <Route path="/WeatherPatterns" element={
          <LayoutWrapper currentPageName="WeatherPatterns">
            <WeatherPatterns />
          </LayoutWrapper>
        } />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <NavigationTracker />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;