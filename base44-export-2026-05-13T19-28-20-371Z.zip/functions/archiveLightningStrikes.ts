const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * archiveLightningStrikes
 * ----------------------------------------------------------------------------
 * Runs daily at 23:59 UTC. Takes a snapshot of all LightningStrike records
 * for today, summarises them, and writes a single LightningArchive record
 * that powers the "Historical Lightning Activity" panel on the TCM page.
 *
 * Older LightningStrike records (>2 days old) are then deleted to keep the
 * primary entity small — the archive entity holds the long-term history.
 */

const UK_BBOX = { latMin: 49.5, latMax: 61.0, lonMin: -10.8, lonMax: 2.5 };
const EU_BBOX = { latMin: 34.0, latMax: 72.0, lonMin: -25.0, lonMax: 45.0 };

const inBBox = (lat, lon, b) =>
  lat >= b.latMin && lat <= b.latMax && lon >= b.lonMin && lon <= b.lonMax;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const now = new Date();
    const todayStart = new Date(now);
    todayStart.setUTCHours(0, 0, 0, 0);
    const todayStartMs = todayStart.getTime();
    const todayDateStr = todayStart.toISOString().slice(0, 10);

    // Pull all today's strikes (paged via -created_date)
    const PAGE_SIZE = 5000;
    const collected = [];
    const page = await db.asServiceRole.entities.LightningStrike.list(
      '-created_date',
      PAGE_SIZE
    ).catch(() => []);

    for (const s of page) {
      const t = Number(s.time);
      if (!Number.isFinite(t)) continue;
      if (t < todayStartMs) continue;
      if (typeof s.lat !== 'number' || typeof s.lon !== 'number') continue;
      if (!inBBox(s.lat, s.lon, EU_BBOX)) continue;
      collected.push({ lat: s.lat, lon: s.lon, time: t, amp: s.amp || 0 });
    }

    // De-dupe
    const seen = new Set();
    const unique = [];
    for (const s of collected) {
      const k = `${s.time}_${s.lat.toFixed(4)}_${s.lon.toFixed(4)}`;
      if (seen.has(k)) continue;
      seen.add(k);
      unique.push(s);
    }

    const ukCount = unique.filter(s => inBBox(s.lat, s.lon, UK_BBOX)).length;
    const euCount = unique.length;

    // Peak hour
    const hourBuckets = {};
    for (const s of unique) {
      const h = new Date(s.time).getUTCHours();
      hourBuckets[h] = (hourBuckets[h] || 0) + 1;
    }
    const peakEntry = Object.entries(hourBuckets).sort((a, b) => b[1] - a[1])[0];
    const peakHour = peakEntry ? `${String(peakEntry[0]).padStart(2, '0')}:00` : '—';

    // Avoid duplicate archive for same date
    const existing = await db.asServiceRole.entities.LightningArchive.filter(
      { date: todayDateStr, region: 'global' },
      '-created_date',
      1
    ).catch(() => []);

    const payload = {
      date: todayDateStr,
      region: 'global',
      captured_at: now.getTime(),
      strike_count: unique.length,
      uk_count: ukCount,
      eu_count: euCount,
      peak_hour: peakHour,
      strikes: unique,
    };

    if (existing.length) {
      await db.asServiceRole.entities.LightningArchive.update(existing[0].id, payload);
      console.log(`[archiveLightning] updated existing archive for ${todayDateStr} (${unique.length} strikes)`);
    } else {
      await db.asServiceRole.entities.LightningArchive.create(payload);
      console.log(`[archiveLightning] created archive for ${todayDateStr} (${unique.length} strikes)`);
    }

    // Cleanup old LightningStrike records (>2 days) — cap per run to avoid timeouts.
    // The archive entity holds long-term history; next runs will clean up the rest.
    const cutoffMs = Date.now() - 2 * 24 * 60 * 60 * 1000;
    const CLEANUP_BUDGET_MS = 30000; // 30s cap
    const cleanupStart = Date.now();
    let cleaned = 0;
    try {
      const oldStrikes = await db.asServiceRole.entities.LightningStrike.filter(
        { time: { $lt: cutoffMs } },
        '-created_date',
        500
      );
      // Delete in small parallel batches with a short pause to avoid rate limits.
      const CONCURRENCY = 5;
      for (let i = 0; i < oldStrikes.length; i += CONCURRENCY) {
        if (Date.now() - cleanupStart > CLEANUP_BUDGET_MS) break;
        const batch = oldStrikes.slice(i, i + CONCURRENCY);
        const results = await Promise.allSettled(
          batch.map(s => db.asServiceRole.entities.LightningStrike.delete(s.id))
        );
        cleaned += results.filter(r => r.status === 'fulfilled').length;
        await new Promise(r => setTimeout(r, 250));
      }
    } catch (e) {
      console.warn('[archiveLightning] cleanup error', e?.message);
    }

    return Response.json({
      ok: true,
      date: todayDateStr,
      archived: unique.length,
      ukCount,
      euCount,
      peakHour,
      cleanedOldRecords: cleaned,
    });
  } catch (error) {
    console.error('[archiveLightning] ERROR', error?.message, error?.stack);
    return Response.json(
      { ok: false, error: error?.message || 'archiveLightningStrikes failed' },
      { status: 500 }
    );
  }
});