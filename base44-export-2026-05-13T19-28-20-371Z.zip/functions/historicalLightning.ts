const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * historicalLightning
 * ----------------------------------------------------------------------------
 * Returns today's lightning strikes from the DB for the requested region.
 * Region can be 'uk' (default, UK & Ireland) or 'europe' (continental).
 * Used by the TCM page on mount to load all strikes collected by the
 * server-side poller while no user was on the site.
 */

const REGION_BBOX = {
  uk:     { latMin: 49.5, latMax: 61.0, lonMin: -10.8, lonMax: 2.5 },
  europe: { latMin: 34.0, latMax: 72.0, lonMin: -25.0, lonMax: 45.0 },
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const region = REGION_BBOX[body?.region] ? body.region : 'europe';
    const bbox = REGION_BBOX[region];

    const todayStart = new Date();
    todayStart.setUTCHours(0, 0, 0, 0);
    const todayStartMs = todayStart.getTime();
    const nowMs = Date.now();

    // Page through recent records ordered by -created_date.
    const PAGE_SIZE = 5000;
    const page = await db.asServiceRole.entities.LightningStrike.list(
      '-created_date',
      PAGE_SIZE
    );

    const collectedToday = [];
    for (const s of (page || [])) {
      const cd = s.created_date ? new Date(s.created_date).getTime() : 0;
      if (cd < todayStartMs - 3 * 3600_000) break; // safety stop
      const t = Number(s.time);
      if (!Number.isFinite(t)) continue;
      if (t < todayStartMs || t > nowMs + 24 * 3600_000) continue;
      if (typeof s.lat !== 'number' || typeof s.lon !== 'number') continue;
      if (s.lat < bbox.latMin || s.lat > bbox.latMax) continue;
      if (s.lon < bbox.lonMin || s.lon > bbox.lonMax) continue;
      collectedToday.push(s);
    }

    // Dedup
    const seen = new Set();
    const unique = [];
    for (const s of collectedToday) {
      const k = s.dedup_key || `${s.time}_${s.lat}_${s.lon}`;
      if (seen.has(k)) continue;
      seen.add(k);
      unique.push(s);
    }

    const formatted = unique.map(s => ({
      lat: s.lat,
      lon: s.lon,
      time: s.time,
      amp: s.amp || 0,
      dedup_key: s.dedup_key,
    }));

    console.log(`[historicalLightning] region=${region} scanned=${(page || []).length} todayInBbox=${collectedToday.length} unique=${formatted.length}`);

    return Response.json({
      ok: true,
      region,
      strikes: formatted,
      count: formatted.length,
      fetchedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[historicalLightning]', error?.message, error?.stack);
    return Response.json(
      { ok: false, error: error?.message || 'Failed to fetch historical lightning' },
      { status: 500 }
    );
  }
});