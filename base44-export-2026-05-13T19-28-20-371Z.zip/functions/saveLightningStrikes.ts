const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Save batch of lightning strikes to DB (server-side dedup)
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const strikes = Array.isArray(body?.strikes) ? body.strikes : [];

    if (!strikes.length) {
      return Response.json({ ok: true, saved: 0, skipped: 0 });
    }

    // Build dedup keys & filter invalid records
    const todayStart = new Date();
    todayStart.setUTCHours(0, 0, 0, 0);
    const todayStartMs = todayStart.getTime();

    const valid = strikes
      .filter(s =>
        typeof s.lat === 'number' && typeof s.lon === 'number' &&
        typeof s.time === 'number' && s.time >= todayStartMs
      )
      .map(s => ({
        lat: Math.round(s.lat * 10000) / 10000,
        lon: Math.round(s.lon * 10000) / 10000,
        time: Math.floor(s.time),
        amp: s.amp || 0,
        dedup_key: `${Math.floor(s.time)}_${(Math.round(s.lat * 10000) / 10000).toFixed(4)}_${(Math.round(s.lon * 10000) / 10000).toFixed(4)}`
      }));

    if (!valid.length) {
      return Response.json({ ok: true, saved: 0, skipped: strikes.length });
    }

    // De-dupe against existing records in DB
    const keys = valid.map(v => v.dedup_key);
    const existing = await db.asServiceRole.entities.LightningStrike.filter(
      { dedup_key: { $in: keys } },
      '-time',
      keys.length
    );
    const existingKeys = new Set(existing.map(e => e.dedup_key));
    const toInsert = valid.filter(v => !existingKeys.has(v.dedup_key));

    if (!toInsert.length) {
      return Response.json({ ok: true, saved: 0, skipped: valid.length, alreadyExisted: existing.length });
    }

    await db.asServiceRole.entities.LightningStrike.bulkCreate(toInsert);

    console.log(`[saveLightningStrikes] saved ${toInsert.length} new strikes (${existing.length} already existed)`);

    return Response.json({
      ok: true,
      saved: toInsert.length,
      skipped: valid.length - toInsert.length,
      total: valid.length
    });
  } catch (error) {
    console.error('[saveLightningStrikes]', error?.message, error?.stack);
    return Response.json(
      { ok: false, error: error?.message || 'Failed to save strikes' },
      { status: 500 }
    );
  }
});