const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

async function fetchWarningsPage() {
    const response = await fetch('https://www.metoffice.gov.uk/weather/warnings-and-advice/accessible-uk-warnings', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; WeatherBot/1.0)',
            'Accept': 'text/html,application/xhtml+xml',
        }
    });
    if (!response.ok) throw new Error(`Failed to fetch Met Office page: ${response.status}`);
    return await response.text();
}

// Generate a stable key to deduplicate warnings
function warningKey(w) {
    const regions = Array.isArray(w.regions) ? w.regions.join(',') : (w.region || '');
    return `${w.type}|${w.severity}|${regions}|${w.validFrom}|${w.validTo}`;
}

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);

        const now = new Date();

        const pageHtml = await fetchWarningsPage();

        const pageText = pageHtml
            .replace(/<script[\s\S]*?<\/script>/gi, '')
            .replace(/<style[\s\S]*?<\/style>/gi, '')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s{2,}/g, ' ')
            .trim()
            .slice(0, 20000);

        const result = await db.asServiceRole.integrations.Core.InvokeLLM({
            prompt: `Below is the content of the Met Office accessible UK weather warnings page, fetched right now (${now.toISOString()} UTC).

Parse ALL weather warnings from this page content and return them as structured JSON.

PAGE CONTENT:
${pageText}

For each warning extract:
- "type": Warning type (e.g. Rain, Wind, Snow, Ice, Thunderstorm, Fog, Flood, Extreme Heat)
- "severity": Severity level (Yellow, Amber, or Red)
- "regions": Array of affected regions/areas (e.g. ["Scotland", "Northern England"] or ["South West England"])
- "description": A brief description of the warning
- "validFrom": Start date/time in ISO 8601 UTC format (e.g. 2026-02-18T06:00:00Z)
- "validTo": End date/time in ISO 8601 UTC format (e.g. 2026-02-18T18:00:00Z)
- "impacts": Optional string describing the impacts of this warning

Rules:
- Include EVERY warning listed — do not skip any.
- Do NOT combine multiple warnings into one.
- regions MUST be an array (even if only one region affected)
- If no warnings are found, return { "all_warnings": [] }.
- For validFrom/validTo, use the current year (${now.getFullYear()}) if no year is given on the page.`,
            response_json_schema: {
                type: "object",
                properties: {
                    all_warnings: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                type: { type: "string" },
                                severity: { type: "string" },
                                regions: { type: "array", items: { type: "string" } },
                                description: { type: "string" },
                                validFrom: { type: "string" },
                                validTo: { type: "string" },
                                impacts: { type: "string" }
                            }
                        }
                    }
                }
            }
        });

        const freshWarnings = Array.isArray(result?.all_warnings) ? result.all_warnings : [];
        const fetchedAt = now.toISOString();

        // Load the existing cached record so we can preserve historical warnings
        const existing = await db.asServiceRole.entities.CachedWarnings.list();
        const existingRecord = existing[0] || null;
        const previousWarnings = Array.isArray(existingRecord?.all_warnings) ? existingRecord.all_warnings : [];

        // Cut-off: only keep historical warnings from the last 5 days
        const fiveDaysAgo = new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000);

        // Build a set of keys for the fresh warnings
        const freshKeys = new Set(freshWarnings.map(warningKey));

        // From previous warnings, keep only those that:
        //   1. Are NOT in the fresh set (i.e. truly historical / no longer published by Met Office)
        //   2. Have expired (validTo < now) — these are the "past" ones worth keeping
        //   3. Expired within the last 5 days — trim anything older
        const historicalWarnings = previousWarnings.filter(w => {
            if (freshKeys.has(warningKey(w))) return false; // already in fresh list
            const validTo = w.validTo ? new Date(w.validTo) : null;
            if (!validTo) return false;
            if (validTo >= now) return false;           // not yet expired
            if (validTo < fiveDaysAgo) return false;    // too old
            return true;
        });

        // Merge: fresh warnings first, then historical expired ones
        const mergedWarnings = [...freshWarnings, ...historicalWarnings];

        // Update or create the single cached record
        if (existingRecord) {
            await db.asServiceRole.entities.CachedWarnings.update(existingRecord.id, {
                all_warnings: mergedWarnings,
                fetched_at: fetchedAt
            });
        } else {
            await db.asServiceRole.entities.CachedWarnings.create({
                all_warnings: mergedWarnings,
                fetched_at: fetchedAt
            });
        }

        return Response.json({ all_warnings: mergedWarnings, fetched_at: fetchedAt });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});