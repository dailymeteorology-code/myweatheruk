const DATAHUB_API_KEY = "eyJ4NXQjUzI1NiI6Ik5XVTVZakUxTkRjeVl6a3hZbUl4TkdSaFpqSmpOV1l6T1dGaE9XWXpNMk0yTWpRek5USm1OVEE0TXpOaU9EaG1NVFJqWVdNellXUm1ZalUyTTJJeVpBPT0iLCJraWQiOiJnYXRld2F5X2NlcnRpZmljYXRlX2FsaWFzIiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ==.eyJzdWIiOiJvbGFmX3d5QGljbG91ZC5jb21AY2FyYm9uLnN1cGVyIiwiYXBwbGljYXRpb24iOnsib3duZXIiOiJvbGFmX3d5QGljbG91ZC5jb20iLCJ0aWVyUXVvdGFUeXBlIjpudWxsLCJ0aWVyIjoiVW5saW1pdGVkIiwibmFtZSI6InNpdGVfc3BlY2lmaWMtZjMwMjg4YWItMjFmYi00NTBiLTliNTgtYWM0MWQ2M2E0YWU2IiwiaWQiOjQ2MzU1LCJ1dWlkIjoiNWIwMjUzOGMtY2U0ZS00NzBjLTk5MzUtNjY1ZGZmM2JkMDVjIn0sImlzcyI6Imh0dHBzOlwvXC9hcGktbWFuYWdlci5hcGktbWFuYWdlbWVudC5tZXRvZmZpY2UuY2xvdWQ6NDQzXC9vYXV0aDJcL3Rva2VuIiwidGllckluZm8iOnsid2RoX3NpdGVfc3BlY2lmaWNfZnJlZSI6eyJ0aWVyUXVvdGFUeXBlIjoicmVxdWVzdENvdW50IiwiZ3JhcGhRTE1heENvbXBsZXhpdHkiOjAsImdyYXBoUUxNYXhEZXB0aCI6MCwic3RvcE9uUXVvdGFSZWFjaCI6dHJ1ZSwic3Bpa2VBcnJlc3RMaW1pdCI6MCwic3Bpa2VBcnJlc3RVbml0Ijoic2VjIn19LCJrZXl0eXBlIjoiUFJPRFVDVElPTiIsInN1YnNjcmliZWRBUElzIjpbeyJzdWJzY3JpYmVyVGVuYW50RG9tYWluIjoiY2FyYm9uLnN1cGVyIiwibmFtZSI6IlNpdGVTcGVjaWZpY0ZvcmVjYXN0IiwiY29udGV4dCI6Ilwvc2l0ZXNwZWNpZmljXC92MCIsInB1Ymxpc2hlciI6IkphZ3Vhcl9DSSIsInZlcnNpb24iOiJ2MCIsInN1YnNjcmlwdGlvblRpZXIiOiJ3ZGhfc2l0ZV9zcGVjaWZpY19mcmVlIn1dLCJ0b2tlbl90eXBlIjoiYXBpS2V5IiwiaWF0IjoxNzc3MTQwNDEwLCJqdGkiOiI2OWFmN2Y4YS1lMDVkLTRiMDAtYTQ5OC0xNTc3NDM4YTJiYTQifQ==.UxMbOv3Kg5ZVTiVJg1OX-00bYQQXkYe1aKMspMcbgAiJzW_REOZj9H89gxrhYU_of11LQjWu0gLwhUTqCAPBkd5zZDSoWdILzfRw8nhTB0Thkdx24zfiTir3hF7esN2asnba7EXavIOA39yXbFqs4S4ZCASo6J2vbenbpQCWh58C4OVwchaqbwGlVmVgYZiZxU3RF6rt_55IIbpKJtxNGBpgoTM-tCVMQDRUlWv17Opt0mUacQbXyTJLr1lzjozYSi5dEdDTeHJ8Juc1_YJuIDTjn3KnwLhwyHmwIN3a47c-DnhUS6QsvA-pKVCze_6sbEmewbMp8cCYUvhkN7wR0Q==";

Deno.serve(async (req) => {
  try {
    const body = await req.json();
    const { location } = body;

    if (!location || typeof location !== 'string') {
      return Response.json({ error: 'Location parameter required' }, { status: 400 });
    }

    // 1. Geocode the location using Nominatim
    const locationData = await searchLocation(location);
    if (!locationData) {
      return Response.json(
        { error: `Location "${location}" not found. Please check the spelling and try again.` },
        { status: 404 }
      );
    }

    const { latitude, longitude, name } = locationData;

    // 1b. Look up the IANA timezone for this location using Open-Meteo (free, no key needed)
    let locationTimeZone = 'UTC';
    try {
      const tzRes = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&timezone=auto&hourly=temperature_2m&forecast_days=1`,
        { signal: AbortSignal.timeout(4000) }
      );
      if (tzRes.ok) {
        const tzData = await tzRes.json();
        if (tzData?.timezone) locationTimeZone = tzData.timezone;
      }
    } catch (tzErr) {
      console.warn('Timezone lookup failed, using UTC:', tzErr.message);
    }

    // 2. Fetch hourly + daily from DataHub, and Open-Meteo 15-min precip in parallel
    const [hourlyRes, dailyRes, hourAheadPrecip] = await Promise.all([
      fetch(
        `https://data.hub.api.metoffice.gov.uk/sitespecific/v0/point/hourly?datasource=BD1&includeLocationName=true&latitude=${latitude}&longitude=${longitude}&excludeParameterMetadata=true`,
        { headers: { apikey: DATAHUB_API_KEY } }
      ),
      fetch(
        `https://data.hub.api.metoffice.gov.uk/sitespecific/v0/point/daily?datasource=BD1&includeLocationName=true&latitude=${latitude}&longitude=${longitude}&excludeParameterMetadata=true`,
        { headers: { apikey: DATAHUB_API_KEY } }
      ),
      buildHourAheadPrecip(latitude, longitude),
    ]);

    if (!hourlyRes.ok) {
      const errText = await hourlyRes.text();
      console.error('DataHub hourly error:', hourlyRes.status, errText);
      return Response.json({ error: `Met Office API error: ${hourlyRes.status}` }, { status: 502 });
    }
    if (!dailyRes.ok) {
      const errText = await dailyRes.text();
      console.error('DataHub daily error:', dailyRes.status, errText);
      return Response.json({ error: `Met Office API error: ${dailyRes.status}` }, { status: 502 });
    }

    const hourlyData = await hourlyRes.json();
    const dailyData = await dailyRes.json();

    // 3. Parse and shape the data
    const result = parseWeatherData(hourlyData, dailyData, name, latitude, longitude, locationTimeZone);
    result.hourAheadPrecip = Array.isArray(hourAheadPrecip) ? hourAheadPrecip : [];

    return Response.json(result);
  } catch (error) {
    console.error('Error fetching Met Office weather:', error);
    return Response.json({ error: 'Failed to fetch weather data. Please try again.' }, { status: 500 });
  }
});

// Build precipitation chart using Open-Meteo 15-min data for the next 4 hours
async function buildHourAheadPrecip(latitude, longitude) {
  const now = new Date();

  try {
    const omUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&minutely_15=precipitation,snowfall,rain&forecast_minutely_15=32&timezone=UTC`;
    const omRes = await fetch(omUrl);

    if (!omRes.ok) {
      console.warn('Open-Meteo error:', omRes.status, await omRes.text());
      return [];
    }

    const omData = await omRes.json();
    const times = omData?.minutely_15?.time ?? [];
    const precip = omData?.minutely_15?.precipitation ?? [];
    const snow = omData?.minutely_15?.snowfall ?? [];

    if (times.length === 0) {
      console.warn('Open-Meteo returned no data');
      return [];
    }

    const omSlots = times.map((timeStr, i) => {
      const r = precip[i] ?? 0;   // mm per 15-min interval (rain + snow liquid equiv)
      const s = snow[i] ?? 0;     // cm per 15-min interval (snowfall depth)
      // Convert to mm/hr: multiply by 4 (intervals per hour)
      const rainRate = r * 4;
      const snowRate = s * 4;     // cm/hr snowfall (keep separate for type detection)
      // Use snowfall to detect snow (s > 0 means snow is falling)
      const type = rainRate > 0 && snowRate > 0 ? 'sleet' : snowRate > 0 ? 'snow' : rainRate > 0 ? 'rain' : 'none';
      // For display rate: use rain for rain/sleet, convert snow cm/hr → mm/hr (×10) for display
      const rate = type === 'snow'
        ? Math.round(snowRate * 10 * 10) / 10   // cm/hr → mm/hr liquid equiv
        : Math.round(rainRate * 10) / 10;
      return {
        // Open-Meteo timestamps are ISO strings like "2024-01-01T12:00" - append Z for UTC
        time: new Date(timeStr + ':00Z'),
        precipRate: rate,
        type,
      };
    });

    console.log(`Open-Meteo: ${omSlots.length} slots, first=${omSlots[0]?.time?.toISOString()}, precipRate=${omSlots[0]?.precipRate}`);

    const nowUTC = new Date(now);
    nowUTC.setUTCSeconds(0, 0);

    let startIdx = 0;
    while (startIdx < omSlots.length && omSlots[startIdx].time < nowUTC) startIdx++;

    const slice = omSlots.slice(startIdx, startIdx + 16);

    const slots = slice.map((s, i) => {
      const hh = String(s.time.getUTCHours()).padStart(2, '0');
      const mm = String(s.time.getUTCMinutes()).padStart(2, '0');
      const label = i === 0 ? 'Now' : `${hh}:${mm}`;
      const rate = s.precipRate > 0 ? s.precipRate : 0;
      const type = rate > 0 ? s.type : 'none';
      return {
        label,
        minuteOffset: i * 15,
        precipRate: rate,
        type,
      };
    });

    const rainySlots = slots.filter(s => s.precipRate > 0).length;
    console.log(`hourAheadPrecip: ${rainySlots}/${slots.length} slots have precipitation`);
    return slots;

  } catch (err) {
    console.error('buildHourAheadPrecip failed:', err);
    return [];
  }
}

async function searchLocation(query) {
  try {
    // First try worldwide search (no country restriction)
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=1&addressdetails=1`,
      { headers: { 'User-Agent': 'WeatherApp/1.0' } }
    );
    if (!response.ok) throw new Error('Location search failed');
    const results = await response.json();
    if (!results || results.length === 0) return null;
    const result = results[0];
    return {
      name: result.display_name?.split(',')[0] || result.name || query,
      latitude: parseFloat(result.lat),
      longitude: parseFloat(result.lon),
    };
  } catch (error) {
    console.error('Location search error:', error);
    return null;
  }
}

// Met Office significant weather codes → description strings
// Even codes = night variants, odd codes = day variants (for shower types)
function significantWeatherCodeToDescription(code, isNight = false) {
  const map = {
    0: isNight ? 'Clear Night' : 'Sunny',
    1: 'Sunny',
    2: 'Partly Cloudy',
    3: 'Partly Cloudy',
    4: 'Dusty',
    5: 'Mist',
    6: 'Fog',
    7: 'Cloudy',
    8: 'Overcast',
    9: 'Light Showers',
    10: 'Light Showers',
    11: 'Drizzle',
    12: 'Light Rain',
    13: 'Heavy Showers',
    14: 'Heavy Showers',
    15: 'Heavy Rain',
    16: 'Sleet Showers',
    17: 'Sleet Showers',
    18: 'Sleet',
    19: 'Hail Showers',
    20: 'Hail Showers',
    21: 'Hail',
    22: 'Light Snow Showers',
    23: 'Light Snow Showers',
    24: 'Light Snow',
    25: 'Heavy Snow Showers',
    26: 'Heavy Snow Showers',
    27: 'Heavy Snow',
    28: 'Thundery Shower',
    29: 'Thundery Shower',
    30: 'Thunderstorm with Hail',
  };
  return map[code] ?? 'Cloudy';
}

function weatherCodeToIconKey(code, isNight, precipProb) {
  if (code == null) return 'Cloudy';
  // For partly cloudy, show sun/moon when precip ≤ 50%
  const showCelestialPartly = (precipProb ?? 0) <= 50;
  // For shower/precipitation icons, only show sun/moon peeking when precip ≤ 50%
  const showCelestialShower = (precipProb ?? 100) <= 50;

  switch (code) {
    case 0: case 1:
      return isNight ? 'Clear Night' : 'Sunny';
    case 2: return showCelestialPartly ? (isNight ? 'Sunny Intervals Night' : 'Sunny Intervals') : 'Cloudy';
    case 3: return showCelestialPartly ? (isNight ? 'Sunny Intervals Night' : 'Sunny Intervals') : 'Cloudy';
    case 4: return 'Cloudy';
    case 5: return 'Mist';
    case 6: return 'Fog';
    case 7: return 'Cloudy';
    case 8: return 'Overcast';
    case 9: return showCelestialShower ? (isNight ? 'Rain Shower Night' : 'Rain Shower') : 'Rain Shower Cloud';
    case 10: return showCelestialShower ? (isNight ? 'Rain Shower Night' : 'Rain Shower') : 'Rain Shower Cloud';
    case 11: return isNight ? 'Drizzle Night' : 'Drizzle';
    case 12: return isNight ? 'Light Rain Night' : 'Light Rain';
    case 13: return showCelestialShower ? (isNight ? 'Heavy Showers Night' : 'Heavy Showers') : 'Heavy Showers Cloud';
    case 14: return showCelestialShower ? (isNight ? 'Heavy Showers Night' : 'Heavy Showers') : 'Heavy Showers Cloud';
    case 15: return isNight ? 'Heavy Rain Night' : 'Heavy Rain';
    case 16: return showCelestialShower ? (isNight ? 'Sleet Night' : 'Sleet') : 'Sleet Cloud';
    case 17: return showCelestialShower ? (isNight ? 'Sleet Night' : 'Sleet') : 'Sleet Cloud';
    case 18: return isNight ? 'Sleet Night' : 'Sleet';
    case 19: return showCelestialShower ? (isNight ? 'Hail Night' : 'Hail') : 'Hail Cloud';
    case 20: return showCelestialShower ? (isNight ? 'Hail Night' : 'Hail') : 'Hail Cloud';
    case 21: return isNight ? 'Hail Night' : 'Hail';
    case 22: return showCelestialShower ? (isNight ? 'Light Snow Night' : 'Light Snow') : 'Light Snow Cloud';
    case 23: return showCelestialShower ? (isNight ? 'Light Snow Night' : 'Light Snow') : 'Light Snow Cloud';
    case 24: return isNight ? 'Light Snow Night' : 'Light Snow';
    case 25: return showCelestialShower ? (isNight ? 'Heavy Snow Night' : 'Heavy Snow') : 'Heavy Snow Cloud';
    case 26: return showCelestialShower ? (isNight ? 'Heavy Snow Night' : 'Heavy Snow') : 'Heavy Snow Cloud';
    case 27: return isNight ? 'Heavy Snow Night' : 'Heavy Snow';
    case 28: return showCelestialShower ? (isNight ? 'Thundery Shower Night' : 'Thundery Shower') : 'Thundery Shower Cloud';
    case 29: return showCelestialShower ? (isNight ? 'Thundery Shower Night' : 'Thundery Shower') : 'Thundery Shower Cloud';
    case 30: return 'Thunderstorms';
    default: return 'Cloudy';
  }
}

// Calculate sunrise/sunset using the sunrise equation for a given lat/lon and date
function calcSunriseSunset(lat, lon, dateStr) {
  const date = new Date(dateStr + 'T12:00:00Z');
  const JD = date / 86400000 + 2440587.5;
  const n = Math.round(JD - 2451545.0 - 0.0009 - lon / 360);
  const Jstar = 2451545.0 + 0.0009 + lon / 360 + n;
  const M = (357.5291 + 0.98560028 * (Jstar - 2451545)) % 360;
  const Mr = M * Math.PI / 180;
  const C = 1.9148 * Math.sin(Mr) + 0.02 * Math.sin(2 * Mr) + 0.0003 * Math.sin(3 * Mr);
  const lambda = (M + C + 180 + 102.9372) % 360;
  const lr = lambda * Math.PI / 180;
  const Jtransit = Jstar + 0.0053 * Math.sin(Mr) - 0.0069 * Math.sin(2 * lr);
  const sinDec = Math.sin(lr) * Math.sin(23.45 * Math.PI / 180);
  const cosDec = Math.cos(Math.asin(sinDec));
  const latr = lat * Math.PI / 180;
  const cosHa = (Math.sin(-0.8333 * Math.PI / 180) - Math.sin(latr) * sinDec) / (Math.cos(latr) * cosDec);
  if (cosHa < -1 || cosHa > 1) return { sunrise: null, sunset: null };
  const Ha = Math.acos(cosHa) * 180 / Math.PI;
  const Jrise = Jtransit - Ha / 360;
  const Jset = Jtransit + Ha / 360;
  const toISO = (jd) => {
    const ms = (jd - 2440587.5) * 86400000;
    return new Date(ms).toISOString();
  };
  return { sunrise: toISO(Jrise), sunset: toISO(Jset) };
}

function getWindDirection(degrees) {
  if (degrees == null) return 'N/A';
  const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  const index = Math.round(degrees / 22.5) % 16;
  return directions[index];
}

function formatHour(hour) {
  const period = hour >= 12 ? 'PM' : 'AM';
  const h12 = hour % 12 === 0 ? 12 : hour % 12;
  return `${h12}:00 ${period}`;
}

function mpsToMph(mps) {
  if (mps == null) return null;
  return Math.round(mps * 2.23694);
}

// Pre-compute sun times for all dates in the dataset to avoid repeated calls
function buildSunTimesCache(lat, lon, dates) {
  const cache = {};
  for (const dateStr of dates) {
    cache[dateStr] = calcSunriseSunset(lat, lon, dateStr);
  }
  return cache;
}

function parseWeatherData(hourlyGeoJson, dailyGeoJson, locationName, lat, lon, locationTimeZone) {
  const hourlyProps = hourlyGeoJson?.features?.[0]?.properties || {};
  const dailyProps = dailyGeoJson?.features?.[0]?.properties || {};

  const hourlyTimeSeries = hourlyProps.timeSeries || [];
  const dailyTimeSeries = dailyProps.timeSeries || [];

  // Use the detected timezone from Open-Meteo (accurate for any global location)
  // Fallback chain: detected -> Met Office metadata -> UTC
  const timeZone = locationTimeZone || hourlyProps.metadata?.location?.timeZone || 'UTC';

  const now = new Date();
  // Use local date string (not UTC) so todayStr matches the localDateStr grouping
  const todayStr = new Intl.DateTimeFormat('en-GB', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone })
    .format(now).split('/').reverse().join('-');
  const nowHour = Number(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone }).format(now));

  // Pre-compute sun times for every unique date in the hourly series
  const allDates = [...new Set(hourlyTimeSeries.map(h => h.time.split('T')[0]))];
  const sunCache = buildSunTimesCache(lat, lon, allDates);

  const hourlyByDate = {};
  let nextHourRain = null;
  let currentHourData = null;

  for (const h of hourlyTimeSeries) {
    const t = new Date(h.time);
    // Use the LOCAL date for grouping (so 11 PM local doesn't flip to next UTC day)
    const localDateStr = new Intl.DateTimeFormat('en-GB', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone })
      .format(t).split('/').reverse().join('-');
    const hour = Number(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone }).format(t));

    const isRelevant = (localDateStr === todayStr && hour >= nowHour) || localDateStr > todayStr;

    if (isRelevant) {
      if (!hourlyByDate[localDateStr]) hourlyByDate[localDateStr] = [];

      const windDeg = h.windDirectionFrom10m ?? null;
      const precipProb = Math.min(100, Math.round(h.probOfPrecipitation ?? 0));
      const code = h.significantWeatherCode;

      // Determine isNight using calculated sunrise/sunset
      // Use the UTC date for sun lookup since calcSunriseSunset works in UTC
      const utcDateStr = h.time.split('T')[0];
      const sunTimes = sunCache[utcDateStr] || calcSunriseSunset(lat, lon, utcDateStr);
      let isNight = false;
      if (sunTimes.sunrise && sunTimes.sunset) {
        const slotTime = t.getTime();
        const sunriseMs = new Date(sunTimes.sunrise).getTime();
        const sunsetMs = new Date(sunTimes.sunset).getTime();
        isNight = slotTime < sunriseMs || slotTime >= sunsetMs;
      } else {
        isNight = hour < 6 || hour >= 21;
      }

      hourlyByDate[localDateStr].push({
        time: h.time,
        hour: formatHour(hour),
        temp: h.screenTemperature != null ? Math.round(h.screenTemperature) : null,
        rainChance: precipProb,
        precipRate: h.precipitationRate != null ? Math.round(h.precipitationRate * 10) / 10 : null,
        windSpeed: mpsToMph(h.windSpeed10m),
        windGust: mpsToMph(h.windGustSpeed10m),
        windDeg,
        windDirection: getWindDirection(windDeg),
        humidity: h.screenRelativeHumidity != null ? Math.round(h.screenRelativeHumidity) : null,
        visibility: h.visibility ?? null,
        description: significantWeatherCodeToDescription(code, isNight),
        iconKey: weatherCodeToIconKey(code, isNight, precipProb),
        significantWeatherCode: code,
        isNight,
      });

      if (hour === nowHour) currentHourData = h;
      if (hour === nowHour + 1) nextHourRain = precipProb;
    }
  }

  const hourly = hourlyByDate[todayStr] || [];

  // Past 24h rain
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  let past24hRain = 0;
  for (const h of hourlyTimeSeries) {
    const t = new Date(h.time);
    const dateStr = t.toISOString().split('T')[0];
    const hour = t.getUTCHours();
    const isYesterday = dateStr === yesterdayStr && hour >= nowHour;
    const isToday = dateStr === todayStr && hour <= nowHour;
    if ((isYesterday || isToday) && h.precipitationRate != null) {
      past24hRain += h.precipitationRate;
    }
  }
  past24hRain = Math.round(past24hRain * 10) / 10;

  // Daily forecast
  const forecast = [];
  const dailyByDate = {};
  for (const d of dailyTimeSeries) {
    const dateStr = d.time.split('T')[0];
    if (!dailyByDate[dateStr]) dailyByDate[dateStr] = [];
    dailyByDate[dateStr].push(d);
  }

  const sortedDates = Object.keys(dailyByDate).filter(d => d >= todayStr).sort().slice(0, 5);

  for (const date of sortedDates) {
    const dayEntry = dailyByDate[date][0];
    const isToday = date === todayStr;

    const maxTemp = dayEntry?.dayMaxScreenTemperature ?? null;
    const minTemp = dayEntry?.nightMinScreenTemperature ?? null;
    const rainChance = dayEntry?.dayProbabilityOfPrecipitation ?? 0;
    const windSpeedMps = dayEntry?.midday10MWindSpeed ?? dayEntry?.midnight10MWindSpeed ?? null;
    const windSpeed = mpsToMph(windSpeedMps);
    const windGustMps = dayEntry?.midday10MWindGust ?? dayEntry?.midnight10MWindGust ?? null;
    const windGust = mpsToMph(windGustMps);
    const windDeg = dayEntry?.midday10MWindDirection ?? dayEntry?.midnight10MWindDirection ?? null;
    const sunTimes = calcSunriseSunset(lat, lon, date);

    // Determine isNight for the daily card icon (only for today, based on current time vs sunrise/sunset)
    let dailyIsNight = false;
    if (date === todayStr && sunTimes.sunrise && sunTimes.sunset) {
      const nowMs = now.getTime();
      const sunriseMs = new Date(sunTimes.sunrise).getTime();
      const sunsetMs = new Date(sunTimes.sunset).getTime();
      dailyIsNight = nowMs < sunriseMs || nowMs >= sunsetMs;
    }

    // Use night code + isNight flag after sunset today; day code otherwise
    const daySigCode = dayEntry?.daySignificantWeatherCode ?? null;
    const nightSigCode = dayEntry?.nightSignificantWeatherCode ?? null;
    const significantCode = dailyIsNight ? (nightSigCode ?? daySigCode) : (daySigCode ?? nightSigCode);
    const description = significantWeatherCodeToDescription(significantCode, dailyIsNight);
    const iconKey = weatherCodeToIconKey(significantCode, dailyIsNight, Math.round(rainChance));
    const uvIndex = dayEntry?.maxUvIndex ?? null;
    const humidity = dayEntry?.middayRelativeHumidity ?? dayEntry?.midnightRelativeHumidity ?? null;
    const visibility = dayEntry?.middayVisibility ?? dayEntry?.midnightVisibility ?? null;
    const pressure = dayEntry?.middayMslp != null ? Math.round(dayEntry.middayMslp / 100) : null;

    const dayForecast = {
      date,
      dayName: new Date(date + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'long' }),
      temperature: {
        max: maxTemp != null ? Math.round(maxTemp) : null,
        min: minTemp != null ? Math.round(minTemp) : null,
      },
      rainChance: Math.round(rainChance),
      precipitation: dayEntry?.dayPrecipitationAmount != null ? Math.round(dayEntry.dayPrecipitationAmount * 10) / 10 : null,
      snowfall: dayEntry?.daySnowfallAmount != null ? Math.round(dayEntry.daySnowfallAmount * 10) / 10 : null,
      windSpeed: windSpeed ?? 0,
      windSpeedMax: windSpeed ?? 0,
      windDirection: getWindDirection(windDeg),
      windDeg,
      windGust: windGust ?? 0,
      description,
      iconKey,
      significantWeatherCode: significantCode,
      uvIndex,
      sunrise: sunTimes.sunrise,
      sunset: sunTimes.sunset,
      humidity: humidity != null ? Math.round(humidity) : null,
      pressure,
      visibility,
      aqi: null,
      aqiLabel: 'Unknown',
    };

    if (isToday) {
      dayForecast.nextHourRain = nextHourRain;
      dayForecast.feelsLike = currentHourData?.screenTemperature != null
        ? Math.round(currentHourData.screenTemperature)
        : null;
    }

    dayForecast.hourly = hourlyByDate[date] || [];
    forecast.push(dayForecast);
  }

  return {
    location: {
      name: locationName,
      latitude: hourlyGeoJson?.features?.[0]?.geometry?.coordinates?.[1] ?? null,
      longitude: hourlyGeoJson?.features?.[0]?.geometry?.coordinates?.[0] ?? null,
    },
    forecast,
    hourly,
    past24h: { rain: past24hRain, snow: 0 },
    dataSource: 'Met Office DataHub',
  };
}