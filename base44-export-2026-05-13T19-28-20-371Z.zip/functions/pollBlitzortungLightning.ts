const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

/**
 * pollBlitzortungLightning
 * ----------------------------------------------------------------------------
 * Server-side 24/7 lightning ingestion. Connects to Blitzortung's public
 * WebSocket for ~50 seconds, captures strikes inside the Europe bbox (covers
 * both UK & Ireland and continental Europe), and bulk-inserts new strikes
 * into the LightningStrike entity. Runs every 5 minutes via the
 * "Blitzortung Lightning Poll (1 min)" scheduled automation.
 *
 * This guarantees lightning data is collected even when no user has the site
 * open — strikes persist in the database and are loaded when users visit.
 */

// Wider bbox: includes UK, Ireland and continental Europe
const EU_BBOX = { latMin: 34.0, latMax: 72.0, lonMin: -25.0, lonMax: 45.0 };
const POLL_DURATION_MS = 50_000;
const SERVERS = [
  'wss://ws1.blitzortung.org',
  'wss://ws7.blitzortung.org',
  'wss://ws8.blitzortung.org',
];

// LZW decode from blitzortung.org's official client
function blitzortungDecode(raw) {
  try {
    const d = Array.from(raw);
    if (!d.length) return null;
    const e = {};
    let c = d[0], f = c;
    const g = [c];
    let h = 256, o = h;
    for (let i = 1; i < d.length; i++) {
      const code = d[i].charCodeAt(0);
      let a;
      if (h > code) a = d[i];
      else if (e[code] !== undefined) a = e[code];
      else a = f + c;
      g.push(a);
      c = a[0];
      e[o] = f + c;
      o++;
      f = a;
    }
    return JSON.parse(g.join(''));
  } catch { return null; }
}

function collectStrikes(serverUrl) {
  return new Promise((resolve) => {
    const collected = [];
    let ws;
    let closed = false;
    const finish = () => {
      if (closed) return;
      closed = true;
      try { ws?.close(); } catch {}
      resolve(collected);
    };
    try {
      ws = new WebSocket(serverUrl);
    } catch (e) {
      console.error('[pollBlitz] ws construct failed', e?.message);
      resolve([]);
      return;
    }
    const timeout = setTimeout(finish, POLL_DURATION_MS);
    let pingInterval;
    ws.onopen = () => {
      try { ws.send(JSON.stringify({ a: 111 })); } catch {}
      pingInterval = setInterval(() => {
        try { if (ws.readyState === 1) ws.send(JSON.stringify({ a: 111 })); } catch {}
      }, 25_000);
    };
    ws.onmessage = (evt) => {
      if (closed) return;
      let parsed = null;
      try { parsed = JSON.parse(evt.data); } catch {}
      if (!parsed) parsed = blitzortungDecode(evt.data);
      if (!parsed) return;
      const strikes = parsed.strikes || (parsed.lat !== undefined ? [parsed] : null);
      if (!strikes) return;
      for (const s of strikes) {
        let lat = s.lat, lon = s.lon;
        if (Math.abs(lat) > 90) lat = lat / 1e7;
        if (Math.abs(lon) > 180) lon = lon / 1e7;
        if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
        if (lat < EU_BBOX.latMin || lat > EU_BBOX.latMax || lon < EU_BBOX.lonMin || lon > EU_BBOX.lonMax) continue;
        const time = s.time
          ? (s.time > 1e12 ? Math.floor(s.time / 1e6) : s.time * 1000)
          : Date.now();
        collected.push({ lat, lon, time, amp: s.mamp || 0 });
      }
    };
    ws.onerror = () => { clearInterval(pingInterval); clearTimeout(timeout); finish(); };
    ws.onclose = () => { clearInterval(pingInterval); clearTimeout(timeout); finish(); };
  });
}

Deno.serve(async (req) => {
  const startedAt = Date.now();
  try {
    const base44 = createClientFromRequest(req);

    // Pick a server (rotate over time using minute-of-hour)
    const serverIdx = new Date().getUTCMinutes() % SERVERS.length;
    const serverUrl = SERVERS[serverIdx];
    console.log(`[pollBlitz] connecting to ${serverUrl} for ${POLL_DURATION_MS}ms`);

    const raw = await collectStrikes(serverUrl);
    console.log(`[pollBlitz] collected ${raw.length} raw strikes`);
    if (!raw.length) {
      return Response.json({ ok: true, saved: 0, collected: 0, server: serverUrl });
    }

    // Filter to today's UTC window + build dedup keys
    const todayStart = new Date();
    todayStart.setUTCHours(0, 0, 0, 0);
    const todayStartMs = todayStart.getTime();
    const nowMs = Date.now();

    const valid = [];
    const seenKeys = new Set();
    for (const s of raw) {
      if (s.time < todayStartMs || s.time > nowMs + 60_000) continue;
      const lat = Math.round(s.lat * 10000) / 10000;
      const lon = Math.round(s.lon * 10000) / 10000;
      const dedup_key = `${Math.floor(s.time)}_${lat.toFixed(4)}_${lon.toFixed(4)}`;
      if (seenKeys.has(dedup_key)) continue;
      seenKeys.add(dedup_key);
      valid.push({ lat, lon, time: Math.floor(s.time), amp: s.amp || 0, dedup_key });
    }

    if (!valid.length) {
      return Response.json({ ok: true, saved: 0, collected: raw.length, deduped: 0 });
    }

    // De-dupe against DB in chunks of 200 keys
    const existingKeys = new Set();
    const keys = valid.map(v => v.dedup_key);
    for (let i = 0; i < keys.length; i += 200) {
      const chunk = keys.slice(i, i + 200);
      const existing = await db.asServiceRole.entities.LightningStrike.filter(
        { dedup_key: { $in: chunk } },
        '-time',
        chunk.length
      ).catch(() => []);
      for (const e of existing) existingKeys.add(e.dedup_key);
    }

    const toInsert = valid.filter(v => !existingKeys.has(v.dedup_key));
    if (toInsert.length) {
      // Insert in batches of 500
      for (let i = 0; i < toInsert.length; i += 500) {
        const batch = toInsert.slice(i, i + 500);
        await db.asServiceRole.entities.LightningStrike.bulkCreate(batch);
      }
    }

    const elapsed = Date.now() - startedAt;
    console.log(`[pollBlitz] saved=${toInsert.length} dupes=${existingKeys.size} collected=${raw.length} elapsed=${elapsed}ms`);

    return Response.json({
      ok: true,
      collected: raw.length,
      validToday: valid.length,
      alreadyExisted: existingKeys.size,
      saved: toInsert.length,
      elapsedMs: elapsed,
      server: serverUrl,
    });
  } catch (error) {
    console.error('[pollBlitz] ERROR', error?.message, error?.stack);
    return Response.json(
      { ok: false, error: error?.message || 'pollBlitzortungLightning failed' },
      { status: 500 }
    );
  }
});