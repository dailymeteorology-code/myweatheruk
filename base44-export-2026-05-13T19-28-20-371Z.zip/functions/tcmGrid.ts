const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

// TCM Grid Builder — 4-day convective forecast at 3-hourly resolution
// ────────────────────────────────────────────────────────────────────
// Returns per-cell atmospheric metrics + scored risks for UK or EU regions.
// Data source: Open-Meteo (free, no auth, blends ECMWF/UKMO/ARPEGE/AROME server-side).
// Cached server-side in RiskGridCache for 3h.
//
// POST body: { region: 'uk'|'eu', force?: 1 }
// Response: { ok, cached, builtAt, region, run, grid:[{lat,lon,perStep:[{scores,metrics}]}], summary:[4] }

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const CACHE_TTL_MS = 6 * 60 * 60 * 1000;       // grid cache (6h — model runs 4×/day)
const POINT_CACHE_TTL_MS = 6 * 60 * 60 * 1000; // per-point cache (6h)
const HOURS_PER_STEP = 3;
const STEPS_PER_DAY = 8;
const TOTAL_STEPS = 32;

// In-memory per-point cache keyed by `${region}:${lat}_${lon}` → { data, expiresAt }
// Survives across invocations within the same warm container.
const POINT_CACHE = globalThis.__TCM_POINT_CACHE__ || (globalThis.__TCM_POINT_CACHE__ = new Map());
function pointCacheGet(region, lat, lon) {
  const e = POINT_CACHE.get(`${region}:${lat}_${lon}`);
  if (e && e.expiresAt > Date.now()) return e.data;
  return null;
}
function pointCacheSet(region, lat, lon, data) {
  POINT_CACHE.set(`${region}:${lat}_${lon}`, { data, expiresAt: Date.now() + POINT_CACHE_TTL_MS });
}

const REGIONS = {
  uk: { bbox: { lonMin:-11.0, lonMax:2.5, latMin:49.5, latMax:61.0 }, step: 0.85 }, // ~60km, ~225 points
  eu: { bbox: { lonMin:-12.0, lonMax:32.0, latMin:35.0, latMax:62.0 }, step: 1.50 }, // ~120km, ~300 points
};

function buildGrid(region) {
  const r = REGIONS[region];
  if (!r) return [];
  const pts = [];
  for (let lat = r.bbox.latMin; lat <= r.bbox.latMax + 0.001; lat += r.step) {
    for (let lon = r.bbox.lonMin; lon <= r.bbox.lonMax + 0.001; lon += r.step) {
      pts.push({ lat: +lat.toFixed(2), lon: +lon.toFixed(2) });
    }
  }
  return pts;
}

// Build the per-cell metric array (length TOTAL_STEPS) from Open-Meteo hourly data.
function buildPerStep(d) {
  const hourly = d?.hourly || {};
  const cape = hourly.cape || [];
  const li = hourly.lifted_index || [];
  const cin = hourly.convective_inhibition || [];
  const td = hourly.dew_point_2m || [];
  const t2 = hourly.temperature_2m || [];
  const fz = hourly.freezing_level_height || [];
  const precip = hourly.precipitation || [];
  const gust = hourly.wind_gusts_10m || [];
  const wind = hourly.wind_speed_10m || [];
  const shear500 = hourly.wind_speed_500hPa || [];
  const shear850 = hourly.wind_speed_850hPa || [];
  const wind10 = hourly.wind_speed_10m || [];

  const perStep = [];
  for (let s = 0; s < TOTAL_STEPS; s++) {
    const h0 = s * HOURS_PER_STEP;
    // Peak/avg over the 3h window
    let cMax = 0, liMin = 10, cinMax = 0, fzMin = 9999, pMax = 0, gMax = 0, wMax = 0;
    let s500 = 0, s850 = 0, w10 = 0, tdAvg = 0, t2Avg = 0, n = 0;
    for (let h = h0; h < h0 + HOURS_PER_STEP; h++) {
      const c = cape[h]; if (c != null && c > cMax) cMax = c;
      const lv = li[h]; if (lv != null && lv < liMin) liMin = lv;
      const cv = cin[h]; if (cv != null && Math.abs(cv) > cinMax) cinMax = Math.abs(cv);
      const fv = fz[h]; if (fv != null && fv < fzMin) fzMin = fv;
      const pv = precip[h]; if (pv != null && pv > pMax) pMax = pv;
      const gv = gust[h]; if (gv != null && gv > gMax) gMax = gv;
      const wv = wind[h]; if (wv != null && wv > wMax) wMax = wv;
      if (shear500[h] != null) s500 += shear500[h];
      if (shear850[h] != null) s850 += shear850[h];
      if (wind10[h] != null) w10 += wind10[h];
      if (td[h] != null) tdAvg += td[h];
      if (t2[h] != null) t2Avg += t2[h];
      n++;
    }
    if (n === 0) n = 1;
    s500 /= n; s850 /= n; w10 /= n; tdAvg /= n; t2Avg /= n;
    if (fzMin === 9999) fzMin = 3500;

    // Bulk shear estimate (m/s): magnitude of upper-vs-surface wind difference.
    // (Open-Meteo gives km/h at pressure levels; convert.)
    const shear06 = Math.abs((s500 - w10)) / 3.6;
    const shear01 = Math.abs((s850 - w10)) / 3.6;
    const helicity01 = shear01 * 30 + 20; // crude SRH proxy

    const tdSpread = Math.max(0.5, t2Avg - tdAvg);
    const td_c = tdAvg;
    const cape_v = cMax;
    const li_v = liMin;

    perStep.push({
      metrics: {
        cape: Math.round(cape_v),
        li: +li_v.toFixed(1),
        cin: Math.round(cinMax),
        td: +td_c.toFixed(1),
        tdSpread: +tdSpread.toFixed(1),
        fz: Math.round(fzMin),
        precip: +pMax.toFixed(1),
        gust: Math.round(gMax * 0.621371), // km/h → mph
        wind: Math.round(wMax * 0.621371),
        shear: +shear06.toFixed(1),
        shear01: +shear01.toFixed(1),
        helicity01: Math.round(helicity01),
      },
      scores: engineScores({
        cape: cape_v, shear: shear06, li: li_v, cin: cinMax,
        td: td_c, tdSpread, fzLvl: fzMin, precip: pMax,
        gust: gMax * 0.621371, wind: wMax * 0.621371,
        helicity01, shear01,
      }),
    });
  }
  return perStep;
}

// Scoring engine — UK-calibrated thresholds (300/500/800 J/kg = Low/Marginal/Moderate)
function engineScores({ cape, shear, li, cin, td, tdSpread, fzLvl, precip, gust, wind, helicity01, shear01 }) {
  const trigger = Math.max(0, 1 - cin / 80);
  const moistFactor = Math.max(0, td - 4) / 14;
  const capeTerm = Math.min(1, cape / 2200);

  let ts = 0;
  if (cape > 80 && tdSpread < 10) {
    const shearMod = 0.7 + Math.min(0.5, shear / 50);
    // Boost low-CAPE response so UK marginal setups (CAPE 100-400) still register
    const capeBoost = Math.min(1, cape / 1500);
    ts = 100 * Math.max(capeTerm, capeBoost * 0.45) * Math.min(1, moistFactor * 1.4) * Math.max(0.3, trigger) * shearMod;
  }
  // LI-based fallback: if LI is negative but CAPE term is weak, still surface a baseline risk
  if (ts < 8 && li < 0 && cape > 50) {
    ts = Math.max(ts, Math.min(25, Math.abs(li) * 5 + cape / 80));
  }
  ts = Math.max(0, Math.min(100, ts));

  let hail = 0;
  if (ts > 25 && fzLvl < 4200) {
    const c = Math.min(1, Math.max(0, cape - 800) / 1800);
    const f = Math.max(0, (4200 - fzLvl) / 1800);
    const s = Math.min(1, shear / 25);
    hail = 100 * c * f * s;
  }
  hail = Math.max(0, Math.min(100, hail));

  let tor = 0;
  if (ts > 35 && tdSpread < 4 && shear01 > 6) {
    const lcl = Math.max(0, (4 - tdSpread) / 4);
    const s01 = Math.min(1, (shear01 - 6) / 10);
    const hel = Math.min(1, helicity01 / 250);
    tor = 100 * lcl * s01 * hel * capeTerm * 0.85;
  }
  tor = Math.max(0, Math.min(100, tor));

  let ltg = 0;
  if (ts > 15) {
    const ice = Math.min(1, Math.max(0, 4500 - fzLvl) / 3000);
    ltg = ts * (0.7 + 0.3 * ice);
  }
  ltg = Math.max(0, Math.min(100, ltg));

  const slowSteer = Math.max(0, 1 - shear / 30);
  const flashFlood = Math.min(100, Math.max(0, (precip - 4) * 9 * (0.5 + 0.6 * slowSteer)));
  const strongWinds = Math.min(100, Math.max(0, (gust - 25) * 2 + (tdSpread > 6 ? capeTerm * 45 : 0)));
  let supercell = 0;
  if (shear > 18 && cape > 1000) supercell = Math.min(100, ((shear - 18) / 18) * 50 + (cape - 1000) / 25 + helicity01 / 10);

  // Hail diameter estimate (mm) — empirical Witt-style
  const hailMm = hail > 5 ? Math.round(Math.min(70, Math.pow(cape / 200, 0.5) * Math.min(1, shear / 20) * 12)) : 0;
  // TORRO scale estimate
  const torroScale = tor < 5 ? 0 : tor < 15 ? 1 : tor < 30 ? 2 : tor < 50 ? 3 : 4;

  return {
    thunderstorm: Math.round(ts),
    hail: Math.round(hail),
    tornado: Math.round(tor),
    lightning: Math.round(ltg),
    sub: {
      tornado: Math.round(tor),
      hail: Math.round(hail),
      flashFlood: Math.round(flashFlood),
      strongWinds: Math.round(strongWinds),
      supercell: Math.round(supercell),
    },
    hailMm,
    torro: torroScale,
  };
}

// ─── Met Office DataHub (Site-Specific hourly) ──────────────────────────────
// Primary source. Pulls per-point hourly forecast for ~48h, mapped onto our
// 3-hourly TCM steps. Returns { "lat_lon": <openMeteoLikeShape> } so the
// existing buildPerStep() works unchanged.
async function fetchMetOfficePoint(lat, lon, apiKey) {
  const url = `https://data.hub.api.metoffice.gov.uk/sitespecific/v0/point/hourly?latitude=${lat}&longitude=${lon}&excludeParameterMetadata=true&includeLocationName=false`;
  const res = await fetch(url, {
    signal: AbortSignal.timeout(15000),
    headers: { apikey: apiKey, accept: 'application/json' },
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`MO ${res.status} ${body.slice(0, 140)}`);
  }
  const data = await res.json();
  const ts = data?.features?.[0]?.properties?.timeSeries || [];
  if (!ts.length) throw new Error('MO empty timeSeries');

  // Build aligned hourly arrays, length up to 96 (we'll pad with nulls if shorter).
  const N = Math.min(96, ts.length);
  const hourly = {
    cape: new Array(N).fill(null),
    lifted_index: new Array(N).fill(null),
    convective_inhibition: new Array(N).fill(null),
    dew_point_2m: new Array(N).fill(null),
    temperature_2m: new Array(N).fill(null),
    freezing_level_height: new Array(N).fill(null),
    precipitation: new Array(N).fill(null),
    wind_gusts_10m: new Array(N).fill(null),
    wind_speed_10m: new Array(N).fill(null),
    wind_speed_500hPa: new Array(N).fill(null),
    wind_speed_850hPa: new Array(N).fill(null),
  };
  for (let i = 0; i < N; i++) {
    const t = ts[i] || {};
    hourly.temperature_2m[i] = t.screenTemperature ?? null;
    hourly.dew_point_2m[i] = t.screenDewPointTemperature ?? null;
    // MO gust in m/s → km/h to match Open-Meteo units our scoring expects.
    hourly.wind_gusts_10m[i] = t.windGustSpeed10m != null ? t.windGustSpeed10m * 3.6 : null;
    hourly.wind_speed_10m[i] = t.windSpeed10m != null ? t.windSpeed10m * 3.6 : null;
    hourly.precipitation[i] = t.totalPrecipAmount ?? t.totalSnowAmount ?? 0;
  }
  return { hourly };
}

async function fetchMetOfficeBatch(points, apiKey) {
  const out = {};
  // Limit concurrency to ~6 in-flight to respect Met Office throttling.
  const CONC = 6;
  let idx = 0;
  let failures = 0;
  async function worker() {
    while (idx < points.length) {
      const myIdx = idx++;
      const pt = points[myIdx];
      try {
        const d = await fetchMetOfficePoint(pt.lat, pt.lon, apiKey);
        out[`${pt.lat}_${pt.lon}`] = d;
      } catch (e) {
        failures++;
        if (failures <= 3) console.warn(`[tcmGrid] MO ${pt.lat},${pt.lon}`, e.message);
        if (failures > 10) return; // bail out → fallback will fill the gaps
      }
    }
  }
  await Promise.all(Array.from({ length: CONC }, worker));
  return out;
}

// Fetch Open-Meteo in batches of ~50 points.
async function fetchOMBatch(points) {
  const out = {};
  const BATCH = 50;
  const HOURLY = [
    'cape','lifted_index','convective_inhibition','dew_point_2m','temperature_2m',
    'freezing_level_height','precipitation','wind_gusts_10m','wind_speed_10m',
    'wind_speed_500hPa','wind_speed_850hPa',
  ].join(',');
  for (let i = 0; i < points.length; i += BATCH) {
    const batch = points.slice(i, i + BATCH);
    const lats = batch.map(p => p.lat).join(',');
    const lons = batch.map(p => p.lon).join(',');
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lats}&longitude=${lons}` +
      `&hourly=${HOURLY}&timezone=UTC&forecast_days=4`;
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(25000) });
      if (!res.ok) { console.warn('[tcmGrid] OM batch', res.status); continue; }
      const data = await res.json();
      const arr = Array.isArray(data) ? data : [data];
      arr.forEach((d, idx) => {
        const pt = batch[idx];
        if (!pt || !d?.hourly) return;
        out[`${pt.lat}_${pt.lon}`] = d;
      });
    } catch (e) {
      console.warn('[tcmGrid] OM batch err', e.message);
    }
    await new Promise(r => setTimeout(r, 350));
  }
  return out;
}

function p95(arr) { if (!arr.length) return 0; const s = [...arr].sort((a,b)=>a-b); return s[Math.floor(s.length*0.95)]; }
function p05(arr) { if (!arr.length) return 0; const s = [...arr].sort((a,b)=>a-b); return s[Math.floor(s.length*0.05)]; }

function buildSummary(grid) {
  return [0,1,2,3].map(d => {
    const ts=[],hl=[],tn=[],lg=[],subT=[],subH=[],subF=[],subW=[],subS=[];
    const capes=[],shears=[],gusts=[],precs=[],winds=[],hails=[],torros=[];
    let stormy = 0;
    for (const p of grid) {
      // Peak across the day's 8 steps (use _fullSteps to also pick metrics)
      const sliceFull = (p._fullSteps || p.perStep).slice(d * STEPS_PER_DAY, (d+1) * STEPS_PER_DAY);
      const slice = sliceFull;
      let peakTs=0,peakHl=0,peakTn=0,peakLg=0;
      let peakSubT=0,peakSubH=0,peakSubF=0,peakSubW=0,peakSubS=0;
      let peakCape=0,peakShear=0,peakGust=0,peakPrec=0,peakWind=0,peakHailMm=0,peakTorro=0;
      for (const st of slice) {
        if (st.scores.thunderstorm > peakTs) peakTs = st.scores.thunderstorm;
        if (st.scores.hail > peakHl) peakHl = st.scores.hail;
        if (st.scores.tornado > peakTn) peakTn = st.scores.tornado;
        if (st.scores.lightning > peakLg) peakLg = st.scores.lightning;
        if (st.scores.sub.tornado > peakSubT) peakSubT = st.scores.sub.tornado;
        if (st.scores.sub.hail > peakSubH) peakSubH = st.scores.sub.hail;
        if (st.scores.sub.flashFlood > peakSubF) peakSubF = st.scores.sub.flashFlood;
        if (st.scores.sub.strongWinds > peakSubW) peakSubW = st.scores.sub.strongWinds;
        if (st.scores.sub.supercell > peakSubS) peakSubS = st.scores.sub.supercell;
        if (st.metrics.cape > peakCape) peakCape = st.metrics.cape;
        if (st.metrics.shear > peakShear) peakShear = st.metrics.shear;
        if (st.metrics.gust > peakGust) peakGust = st.metrics.gust;
        if (st.metrics.precip > peakPrec) peakPrec = st.metrics.precip;
        if (st.metrics.wind > peakWind) peakWind = st.metrics.wind;
        if (st.scores.hailMm > peakHailMm) peakHailMm = st.scores.hailMm;
        if (st.scores.torro > peakTorro) peakTorro = st.scores.torro;
      }
      ts.push(peakTs); hl.push(peakHl); tn.push(peakTn); lg.push(peakLg);
      if (peakTs >= 10) {
        stormy++;
        subT.push(peakSubT); subH.push(peakSubH); subF.push(peakSubF); subW.push(peakSubW); subS.push(peakSubS);
        capes.push(peakCape); shears.push(peakShear); gusts.push(peakGust); precs.push(peakPrec);
        winds.push(peakWind); hails.push(peakHailMm); torros.push(peakTorro);
      }
      p.perDay = p.perDay || [];
      p.perDay[d] = { scores: {
        thunderstorm: peakTs, hail: peakHl, tornado: peakTn, lightning: peakLg,
        sub: { tornado: peakSubT, hail: peakSubH, flashFlood: peakSubF, strongWinds: peakSubW, supercell: peakSubS },
        hailMm: peakHailMm, torro: peakTorro,
        metrics: { cape: peakCape, shear: peakShear, gust: peakGust, precip: peakPrec, wind: peakWind, li: 0 },
      }};
    }
    return {
      thunderstorm: p95(ts), hail: p95(hl), tornado: p95(tn), lightning: p95(lg),
      stormyCells: stormy, totalCells: grid.length,
      sub: { tornado: p95(subT), hail: p95(subH), flashFlood: p95(subF), strongWinds: p95(subW), supercell: p95(subS) },
      ranges: {
        cape:   { min: p05(capes),   max: p95(capes)   },
        shear:  { min: p05(shears),  max: p95(shears)  },
        gust:   { min: p05(gusts),   max: p95(gusts)   },
        precip: { min: p05(precs),   max: p95(precs)   },
        wind:   { min: p05(winds),   max: p95(winds)   },
        hailMm: { min: 0,            max: p95(hails)   },
        torro:  { min: 0,            max: Math.max(0, ...torros) },
      },
    };
  });
}

Deno.serve(async (req) => {
  const t0 = Date.now();
  try {
    const base44 = createClientFromRequest(req);
    let body = {};
    try { body = await req.json(); } catch (_) {}
    const region = (body.region === 'eu') ? 'eu' : 'uk';
    const force = !!body.force;
    const cacheKey = `tcm-${region}-v2`;

    if (!force) {
      try {
        const cached = await db.asServiceRole.entities.RiskGridCache.filter({ cache_key: cacheKey });
        const e = cached?.[0];
        if (e && e.expires_at && new Date(e.expires_at).getTime() > Date.now()) {
          return Response.json({ ok: true, cached: true, builtAt: new Date(e.generated_at).getTime(), region, ...e.grid_data });
        }
      } catch (_) {}
    }

    const pts = buildGrid(region);
    console.log(`[tcmGrid] ${region}: ${pts.length} points`);

    // Per-point cache: skip API calls for points whose data is still fresh.
    const moData = {};
    const omData = {};
    const needFetch = [];
    let pointCacheHits = 0;
    for (const pt of pts) {
      const cached = pointCacheGet(region, pt.lat, pt.lon);
      if (cached) {
        if (cached._src === 'mo') moData[`${pt.lat}_${pt.lon}`] = cached.data;
        else omData[`${pt.lat}_${pt.lon}`] = cached.data;
        pointCacheHits++;
      } else {
        needFetch.push(pt);
      }
    }
    console.log(`[tcmGrid] point-cache hits: ${pointCacheHits}/${pts.length}, fetching ${needFetch.length}`);

    // Primary: Met Office DataHub (Site-Specific hourly). Fallback: Open-Meteo.
    const moKey = Deno.env.get('MET_OFFICE_TCM_KEY') || '';
    if (moKey && region === 'uk' && needFetch.length) {
      try {
        const moFresh = await fetchMetOfficeBatch(needFetch, moKey);
        for (const [k, v] of Object.entries(moFresh)) {
          moData[k] = v;
          const [lat, lon] = k.split('_').map(Number);
          pointCacheSet(region, lat, lon, { _src: 'mo', data: v });
        }
        console.log(`[tcmGrid] MO fresh hits: ${Object.keys(moFresh).length}/${needFetch.length}`);
      } catch (e) { console.warn('[tcmGrid] MO batch failed', e.message); }
    }
    const stillMissing = needFetch.filter(p => !moData[`${p.lat}_${p.lon}`]);
    if (stillMissing.length) {
      const omFresh = await fetchOMBatch(stillMissing);
      for (const [k, v] of Object.entries(omFresh)) {
        omData[k] = v;
        const [lat, lon] = k.split('_').map(Number);
        pointCacheSet(region, lat, lon, { _src: 'om', data: v });
      }
      console.log(`[tcmGrid] OM fallback for ${stillMissing.length} pts, fresh hits ${Object.keys(omFresh).length}`);
    }

    const grid = [];
    let usedMO = 0, usedOM = 0;
    for (const pt of pts) {
      const key = `${pt.lat}_${pt.lon}`;
      const d = moData[key] || omData[key];
      if (!d) continue;
      if (moData[key]) usedMO++; else usedOM++;
      const perStep = buildPerStep(d);
      // Keep both scores AND metrics in perStep so summary rebuild works after loading from cache
      const perStepSlim = perStep.map(s => ({ scores: s.scores, metrics: s.metrics }));
      grid.push({ lat: pt.lat, lon: pt.lon, perStep: perStepSlim, _fullSteps: perStep, _src: moData[key] ? 'mo' : 'om' });
    }
    console.log(`[tcmGrid] hits: ${grid.length}/${pts.length} (MO ${usedMO}, OM ${usedOM})`);

    const summary = buildSummary(grid);
    // Strip temp _fullSteps from payload (only needed during summary build)
    for (const p of grid) { delete p._fullSteps; delete p._src; }
    const run = new Date().toISOString();
    const sourceLabel = usedMO && usedOM ? `Met Office (primary) + Open-Meteo fallback` : usedMO ? `Met Office DataHub` : `Open-Meteo (ECMWF+UKMO+AROME blend)`;
    const grid_data = { grid, summary, run, source: sourceLabel, counts: { mo: usedMO, om: usedOM } };

    try {
      const existing = await db.asServiceRole.entities.RiskGridCache.filter({ cache_key: cacheKey });
      const payload = {
        cache_key: cacheKey,
        generated_at: run,
        expires_at: new Date(Date.now() + CACHE_TTL_MS).toISOString(),
        model_run: `${sourceLabel} · ${region.toUpperCase()}`,
        grid_data,
        diagnostics: { points: pts.length, hits: grid.length, ms: Date.now() - t0 },
      };
      if (existing?.[0]) await db.asServiceRole.entities.RiskGridCache.update(existing[0].id, payload);
      else await db.asServiceRole.entities.RiskGridCache.create(payload);
    } catch (e) { console.warn('[tcmGrid] cache save', e.message); }

    return Response.json({ ok: true, cached: false, builtAt: Date.now(), region, ...grid_data });
  } catch (e) {
    console.error('[tcmGrid] error', e);
    return Response.json({ ok: false, error: String(e?.message || e) }, { status: 500 });
  }
});